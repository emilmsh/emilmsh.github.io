---
type: theory-audit
status: positive-numerical-gate-not-continuum-theorem
last_updated: 2026-07-23
audited_note: 134-heterogeneous-buyer-risk-aversion-refinement-gate.md
audited_code: ../code/audit_heterogeneous_buyer_risk_aversion_refinement.py
audit_code: ../code/audit_heterogeneous_ra_refined_pbe.py
related_notes:
  - 79-equilibrium-selection-framework.md
  - 123-risk-aversion-refined-proof-of-concept.md
  - 136-heterogeneous-ra-d1-geometry.md
---

# Gate 137: independent audit of the continuous heterogeneous-CARA candidate

## 1. Verdict

The construction in Note 134 is an internally coherent and well-separated
**numerical D1 candidate**. I find no missing receiver-plan branch and no
algebraic error in its deviation thresholds. The reported candidate and all
main margins reproduce.

One part of the refinement argument can be upgraded immediately. On the
high-price branch, the top-value threshold is strictly decreasing in the
CARA coefficient by a short analytical argument; no cross-
\(\alpha\) grid is needed there.

The probing-undercut branch is not yet a continuum proof. There are two
distinct unproved inequalities:

1. the gain index must fall with \(\alpha\) along the implicit wait--probe
   frontier; and
2. the lower-endpoint type must beat every waiter below that frontier, not
   only the frontier types.

The second point cannot be discarded by invoking the local geometry in Note
136. For a large undercut, the waiter threshold need not be minimized at the
wait--probe boundary within a fixed \(\alpha\) slice. Note 134 correctly uses
a separate full-type grid, and that grid still selects
\((b,\alpha)=(1,\underline\alpha)\). But a grid is not a proof over the
continuum, especially because the comparison has zero uniform gap as types
converge to that endpoint.

Accordingly, Note 134 should remain labelled a positive numerical gate. It
supports a clean conditional theorem and a small computer-assisted proof
project, but not yet an unconditional continuum theorem.

## 2. Independent reproduction

The audited primitives are

\[
(n_L,n_H)=(2,7),\qquad A=\pi=\frac12,\qquad \kappa=0.01,
\]

\[
\alpha\sim U[\underline\alpha,5],\qquad
\underline\alpha=0.369754026773,qquad
q=0.655954391463.
\]

Using a separate implementation of the transformed auction moments, the
Gate 137 audit returns

\[
\begin{array}{lc}
\text{endpoint frontier residual }F(1,\underline\alpha)
    &-9.93\times10^{-14},\\
\text{seller-price residual }T(q)-q
    &-1.80\times10^{-13},\\
\beta(5)&0.773349949657,\\
\Pr(\text{probe})&0.171264245296,\\
\mathbb E[R_7(B)\mid\text{probe}]-q&0.195891049930,\\
R_2(1)-q&0.010712275204.
\end{array}
\tag{1}
\]

These agree with Note 134 to the displayed precision. They are
floating-point and Gauss--Legendre calculations, not interval enclosures.

## 3. Complete receiver-plan audit

For a common posterior over buyer type, seller continuation revenues satisfy

\[
R_2(b)\in[1/3,2/3],\qquad
R_7(b)\in[3/4,7/8],
\tag{2}
\]

and \(R_7(b)>R_2(b)\) pointwise. The rationalizable contingent-plan set is
therefore exactly

\[
\begin{array}{c|c}
p\text{ region}&\mathcal A(p)\\ \hline
p<1/3&(0,0)\\
1/3\le p\le2/3&(r,0),\quad r\in[0,1]\\
2/3<p<3/4&(1,0)\\
3/4\le p\le7/8&(1,x),\quad x\in[0,1]\\
p>7/8&(1,1).
\end{array}
\tag{3}
\]

Every mixing probability in (3) is attainable: choose a posterior that
makes the relevant state indifferent. The other state then has a strict best
response because the revenue supports are disjoint. There is no omitted
second response coordinate and no independent-state-posterior mistake.

There is one harmless endpoint wording issue in Note 134. At exactly
\(p=7/8\), state \(H\) can mix under the posterior \(b=1\); it is not true
that both states accept under *every* posterior at that exact price. Equation
(21) in Note 134 already gives the correct weak-boundary plan set. No buyer
gains there under the candidate, so the equilibrium conclusion is unchanged.

## 4. Threshold algebra

Let

\[
E^*(b,\alpha)=\min\{W(b,\alpha),P(b,\alpha;q)\}.
\]

For an undercut \(p<q\) on the \((r,0)\) branch, a type gains exactly when
\(r\) exceeds

\[
r(b,\alpha;p)=
\frac{e^{\alpha\kappa}W(b,\alpha)-E^*(b,\alpha)}
{A e^{\alpha\kappa}
 [M_2(b,\alpha)-e^{-\alpha(b-p)}]},
\tag{4}
\]

whenever the denominator is positive. Types with a nonpositive denominator
cannot be made better off by increasing \(L\)'s acceptance probability. On
the wait--probe frontier, (4) becomes

\[
r_F(\alpha;p)
=\frac{Z_2-e^{\alpha q}}{Z_2-e^{\alpha p}}
=\frac{1}{1+\Gamma_\varepsilon(\alpha)},
\qquad \varepsilon=q-p,
\tag{5}
\]

where

\[
\Gamma_\varepsilon(\alpha)
=
\frac{1-e^{-\alpha\varepsilon}}
     {e^{\alpha\kappa}-1}
\frac{1}{1+H(\alpha)},
\qquad
H(\alpha)=e^{-\alpha q}Z_7(\beta(\alpha),\alpha).
\tag{6}
\]

Every relevant undercut satisfies \(p<q<2/3\). Below \(1/3\), both states
reject under every posterior. On \([1/3,q)\), the complete rationalizable
set is exactly \((r,0)\). Hence minimizing (4) is sufficient for full
gain-set dominance in this calibration; there is no suppressed
\(H\)-response coordinate on an undercut.

For \(p\in[3/4,7/8]\), only \(H\)'s acceptance probability varies. The
threshold is

\[
x(b,\alpha;p)=
\frac{e^{\alpha\kappa}
[Ae^{-\alpha(b-p)}+\pi M_7]-E^*}
{\pi e^{\alpha\kappa}
[M_7-e^{-\alpha(b-p)}]}.
\tag{7}
\]

Equations (4)--(7) agree with Note 134.

## 5. Undercut ordering along the frontier

Write

\[
t(\alpha)=e^{\alpha\kappa}-1,
\]

and define the frontier residual

\[
F(b,\alpha)
=Z_2(b,\alpha)-e^{\alpha(q+\kappa)}
-t(\alpha)Z_7(b,\alpha).
\tag{8}
\]

With \(S_n=1-b^n\),

\[
F_b=\alpha e^{\alpha b}[S_2-tS_7]>0
\quad (b<1)
\tag{9}
\]

under the analytical single-crossing bound in Note 134. Thus each interior
frontier root is unique.

The first factor in (6) is strictly decreasing for every
\(\varepsilon>0\). Indeed,

\[
\frac{\varepsilon}{e^{\alpha\varepsilon}-1}<\frac1\alpha
<\frac{\kappa}{1-e^{-\alpha\kappa}}.
\tag{10}
\]

It therefore suffices to prove \(H'(\alpha)\ge0\). Implicit
differentiation gives an especially small sign test. For an interior root,

\[
H'(\alpha)
=e^{-\alpha q}\frac{J(b,\alpha)}{S_2-tS_7},
\tag{11}
\]

where, using \(F=0\),

\[
\boxed{
J
=S_2 Z_{7,\alpha}-S_7 Z_{2,\alpha}
+S_7(q+\kappa)Z_2
+(\kappa S_7-qS_2)Z_7.}
\tag{12}
\]

Thus a rigorous cross-\(\alpha\) undercut proof has been reduced to the
one-dimensional implicit-curve inequality

\[
J(\beta(\alpha),\alpha)>0.
\tag{13}
\]

The endpoint \((1,\underline\alpha)\) is nonregular because both
\(F_b\) and \(J\) vanish there. A second-order expansion in \(1-b\) gives
the finite right derivative

\[
H'_+(\underline\alpha)
=e^{-\underline\alpha q}
\left[
Z_{7,\alpha}-qZ_7
-\frac{7F_\alpha}{2-7t}
\right]_{(1,\underline\alpha)}.
\tag{14}
\]

The independent audit obtains

\[
H'_+(\underline\alpha)=0.210041753858,
\tag{15}
\]

and, on an endpoint-excluding 20,001-point grid along the exact numerical
frontier,

\[
\min H'=0.096364923274,
\tag{16}
\]

attained at the reported upper endpoint \(\alpha=5\). These are large
numerical margins, but (13) has not been interval-certified. Consequently,
the exact all-undercut cross-\(\alpha\) order remains numerical.

## 6. Why the full waiter check remains essential

For a waiter, (4) can be written in transformed moments as

\[
r_W(b,\alpha;p)
=
\frac{(1-e^{-\alpha\kappa})
[A Z_2(b,\alpha)+\pi Z_7(b,\alpha)]}
{A[Z_2(b,\alpha)-e^{\alpha p}]}.
\tag{17}
\]

With \(A=\pi=1/2\), its derivative in \(b\) has sign determined by

\[
\frac{\partial\log r_W}{\partial b}
=\alpha e^{\alpha b}
\left[
\frac{S_2+S_7}{Z_2+Z_7}
-\frac{S_2}{Z_2-e^{\alpha p}}
\right].
\tag{18}
\]

At the upper coefficient endpoint and the largest audited price cut,

\[
\left.
\frac{\partial\log r_W}{\partial b}
\right|_{\alpha=5,\ b=\beta(5),\ p=1/3}
=0.070191382245>0.
\tag{19}
\]

Hence waiters immediately below \(\beta(5)\) have a lower threshold than
the frontier type at \(\alpha=5\). This does **not** defeat the candidate:
their thresholds remain above the much lower threshold of
\((1,\underline\alpha)\) on the reported grid. It does show that a proof
cannot reduce all undercuts to frontier types by fixed-\(\alpha\)
single-crossing alone.

The independent \((401\times801)\) full-type audit over 101 prices again
returns

\[
(b,\alpha)=(1,\underline\alpha)
\]

on every price row, with zero displayed excess over the grid minimum. This
is positive evidence, not a continuum certificate. Types
\((b,\alpha)\to(1,\underline\alpha)\) have thresholds converging to the
endpoint threshold, so there is no uniform raw difference that a coarse
mesh can exploit.

## 7. High-price ordering is analytical

Within a fixed \(\alpha\) slice, the hypothetical-prober version of (7)
falls with \(b\), because its numerator is independent of \(b\) after
multiplication by \(e^{\alpha b}\), while
\(Z_7(b,\alpha)\) is increasing. A waiter has a weakly larger numerator
than the corresponding hypothetical prober. A type for which the denominator
is nonpositive cannot be induced to gain by more \(H\)-acceptance. Therefore
the lowest gain threshold in each slice is attained at \(b=1\).

Let \(Y\) be the maximum of seven iid uniform draws. At \(b=1\), put
\(\delta=p-q>0\). Equation (7) becomes

\[
x_T(\alpha;p)
=\frac{A}{\pi}
\frac{1-e^{-\alpha\delta}}
{\mathbb E[e^{\alpha(Y-p)}]-1}.
\tag{20}
\]

Now define

\[
g_z(\alpha)=\frac{e^{\alpha z}-1}{\alpha}.
\]

For every real \(z\),

\[
g_z'(\alpha)
=\frac{e^{\alpha z}(\alpha z-1)+1}{\alpha^2}\ge0,
\tag{21}
\]

because \(e^u(u-1)+1\ge0\) for all real \(u\). Thus

\[
\frac{\mathbb E[e^{\alpha(Y-p)}]-1}{\alpha}
=\mathbb E[g_{Y-p}(\alpha)]
\]

is increasing. It is strictly positive for \(p\le\mathbb E[Y]=7/8\) by
strict Jensen, including at equality because \(Y\) is nondegenerate. In
contrast,

\[
\frac{1-e^{-\alpha\delta}}{\alpha}
\]

is strictly decreasing. Their ratio in (20) is therefore strictly
decreasing in \(\alpha\) for every \(q<p\le7/8\).

This proves, without a grid, that \((b,\alpha)=(1,5)\) has the largest
high-price strict-gain set whenever any type can gain. For \(p<7/8\), the
seller in state \(H\) rejects under that belief because
\(R_7(1)=7/8>p\). The remaining \(L\)-only allocation costs more than the
on-path price \(q\), so it does not induce the selected type to deviate.

## 8. Remaining raw-PBE numerical check

Every price strictly above \(7/8\) is accepted in both states under every
posterior. Since the buyer's deviation moment worsens with the price, it is
enough to rule out the limiting all-accept allocation at \(p=7/8\), namely
to show

\[
e^{(7/8)\alpha}
\ge
A e^{\alpha q}+\pi Z_7(1,\alpha)
\quad
\text{for all }\alpha\in[\underline\alpha,5].
\tag{22}
\]

Indeed, \(Z_7(b,\alpha)\) is increasing in \(b\), and the equilibrium
moment is no larger than the hypothetical probing moment. Thus (22) reduces
the original two-dimensional knockout grid to a one-dimensional inequality.

The independent grid finds a minimum moment gap of

\[
0.053196035211
\]

and reproduces the minimum certainty-equivalent gap

\[
0.062568604740.
\]

Again, these are strong numerical margins, but (22) is not yet an interval
bound.

## 9. Smallest route to a continuum theorem

A bounded proof upgrade should do four things and no more:

1. **Equilibrium root.** Use outward-rounded quadrature to enclose the joint
   endpoint equation and seller-price fixed point. Equation (9) already gives
   uniqueness of each interior \(b\)-root.

2. **Frontier undercut order.** Enclose (12) on boxes intersecting
   \(F=0\), treating the endpoint separately with (14). The numerical lower
   margin in (16) suggests this is a small one-dimensional interval task.

3. **All waiters.** Prove
   \(r_W(b,\alpha;p)\ge
   r_F(\underline\alpha;p)\) on
   \(b\le\beta(\alpha)\) and
   \(p\in[1/3,q)\). Factor out \(q-p\) near \(p=q\), use a local Taylor
   argument around \((1,\underline\alpha)\), and interval-enclose the compact
   complement. This is the main missing D1 step; (19) shows why frontier
   monotonicity alone is insufficient.

4. **Knockout.** Interval-enclose the one-dimensional inequality (22).
   The high-price D1 ordering itself requires no further computation because
   Section 7 proves it analytically.

Until these four items are complete, the correct claim is:

> Heterogeneous buyer CARA generates a robust numerical zero-urgency
> probing PBE candidate that passes the complete-plan interim-D1 audit on
> dense endpoint-inclusive meshes. Conditional on the two continuum
> undercut inequalities and the interval-enclosed fixed point and knockout
> bound, it is a D1-compatible continuum equilibrium.

Run

    python code/audit_heterogeneous_ra_refined_pbe.py

for the independent Gate 137 audit.
