# Terminal seller counteroffers inside the one-offer game

> **Status correction (2026-07-25).** The isolated English-clock
> counteroffer result is valid, but the coupled early-offer numerical audits below
> impose an unrecorded non-linkage restriction. If the identified early buyer
> later wins, a seller with perfect recall also conditions on that buyer's
> earlier wait or offer decision. The resulting action-selected posterior
> generally changes the counteroffer threshold. The probing-only, full-menu,
> and D1 conclusions below therefore do not yet establish robustness of the
> perfect-recall game. They remain valid only for the reduced-form plug-in in
> which the terminal decision maker cannot use the earlier action when
> inferring the winner's value. Merely hiding the winner's name is not enough
> if the decision maker still knows that one anonymous bidder was selected by
> the earlier action. Notes 141, 143, and 144 give the completed
> perfect-recall probing-only recalculation and interval certificate.

## Status and bottom line

This note connects the coarse-history terminal counteroffer equilibrium in
Note 116 to the early one-offer game. It gives a positive robustness result in
the demand-only specialization. A seller who can reject the provisional
auction outcome and make one winner-specific counteroffer implements an
endogenous monopoly reserve. After substituting that distorted terminal
mechanism for the committed English-auction benchmark, both a probing-only
candidate and a full-menu candidate retain no early offer, rejected attempts,
and successful pre-emption. The displayed candidates pass a floating-point
audit of the paper's complete strict-gain interim-D1 test over all nested
contingent seller plans.

The qualification is economically important. The monopoly reserve can make
the terminal allocation inefficient, so early trade can sometimes have
positive bilateral surplus even without urgency. Terminal non-commitment is
therefore not a neutral robustness perturbation. The audited candidates
below nevertheless have strictly positive buyer-urgency cutoffs for every
on-path offer, so their attempts continue to be selected by urgency.

The audit is
[the terminal-counteroffer plug-in](../code/audit_terminal_counteroffer_one_offer_plugin.py).

## 1. Coarse terminal history

Let the seller's physical no-sale payoff be the public constant \(v\). At the
terminal stage the bidders use an English clock. When all but one bidder have
dropped out, let \(x\) be the highest losing dropout price. The seller observes
\(x\), but not the provisional winner's maximum cap. It either accepts \(x\)
or extinguishes that outcome and makes one counteroffer \(p>x\). Rejection of
the counteroffer gives the seller \(v\); the losing bidders cannot be recalled.

The reserve equivalence is independent of the number of iid bidders. With
\(m\geq2\) active bidders, let \(X\) and \(x\) be the highest and
second-highest values. Their joint density for \(X>x\) is proportional to

\[
F(x)^{m-2}f(x)f(X).
\]

Consequently,

\[
f_{X\mid x,m}(y)=\frac{f(y)}{1-F(x)},
\qquad y\geq x.
\]

The conditional distribution of the provisional winner is therefore
\(F(\cdot\mid b\geq x)\), independently of \(m\). This remains true if the
seller does not observe a demand state governing \(m\): every state-specific
conditional distribution is the same, so their posterior mixture is the same.

Hence a counteroffer \(p>x\) gives the seller

\[
v+\frac{(p-v)[1-F(p)]}{1-F(x)}.
\tag{1}
\]

Let \(\rho(v)\) be the unique interior maximizer of

\[
(p-v)[1-F(p)].
\tag{2}
\]

The seller counters at \(\rho(v)\) when \(x<\rho(v)\) and accepts \(x\) when
\(x\geq\rho(v)\). The outcome is therefore a second-price auction with
reserve \(\rho(v)\).

Truthful dropout is a weak best response even when the bidder does not know the
demand state or the realized number of rivals. Fix the realized rival caps. If
their highest cap is at least \(\rho(v)\), winning entails paying that cap; if
it is below \(\rho(v)\), winning entails paying \(\rho(v)\). Dropping at value
selects the positive-surplus outcome whenever one exists, while a cap above
value can only create a loss. The argument is pointwise in the realized rival
caps and therefore survives uncertainty about their number. With
\(F=U[0,1]\),

\[
\rho(v)=\frac{1+v}{2}.
\tag{3}
\]

This is the coarse-history protocol. If the seller observes and conditions on
an informative maximum report by the provisional winner, Note 116's ratchet
obstruction applies instead; Section 6 returns to that boundary.

## 2. Reduced-form auction objects

Let \(n_s\) be the number of late bidders in demand state
\(s\in\{L,H\}\), and write \(r=\rho(v)\). Let \(Y_{1s}\) and \(Y_{2s}\)
be the largest and second-largest late values. A patient early buyer with
value \(b\) has terminal surplus

\[
\mathbb E[(b-\max\{r,Y_{1s}\})^+],
\]

so its maximum early payment is

\[
w_s^{CO}(b)
=b-\mathbb E[(b-\max\{r,Y_{1s}\})^+].
\tag{4}
\]

For uniform values this becomes

\[
w_s^{CO}(b)
=
\begin{cases}
b, & b\leq r,\\[2mm]
b-\dfrac{b^{n_s+1}-r^{n_s+1}}{n_s+1}, & b>r.
\end{cases}
\tag{5}
\]

Let \(R_F(n,b;r)\) denote the committed-threshold seller payoff when the
threshold and no-sale payoff are both \(r\). The counteroffer mechanism differs
only when the early buyer is below \(r\) and every late buyer also falls below
\(r\). On that event the physical payoff is \(v\), not \(r\). Therefore, for
an arbitrary common CDF \(F\),

\[
R_s^{CO}(b)
=R_F(n_s,b;r)
 -(r-v)F(r)^{n_s}\mathbf 1\{b<r\},
\qquad
C_s^{CO}(b)=R_s^{CO}(b)-d_S.
\tag{6}
\]

Under \(F=U[0,1]\), the correction is
\((r-v)r^{n_s}\mathbf 1\{b<r\}\), which is what the numerical audit
implements.

Equation (6) also shows why this protocol is not innocuous. For \(b<r\), the
buyer never wins the terminal auction and \(w_s^{CO}(b)=b\). Whenever

\[
R_s^{CO}(b)<b<r,
\tag{7}
\]

there is positive bilateral surplus from an early sale even at zero urgency:
early agreement avoids monopoly exclusion. At \(b=r\), the early buyer itself
clears the reserve, so seller continuation jumps upward by

\[
(r-v)F(r)^{n_s}.
\tag{8}
\]

This discontinuity is a feature of the counteroffer protocol, not a numerical
artifact. Buyer willingness remains continuous at \(r\).

## 3. Demand-only calibration

Set

\[
F=U[0,1],\quad
(n_L,n_H)=(2,3),\quad
v=.4,\quad
r=.7,\quad
\pi=\tfrac12,\quad
d_S=.01,
\tag{9}
\]

and retain the baseline truncated-exponential buyer-urgency distribution with
rate 10. The private seller state is demand only; the physical fallback and
hence the counteroffer reserve are public and common across states.

The continuation ordering can be checked analytically despite the jumps. For
\(b<r\),

\[
C_H^{CO}(b)-C_L^{CO}(b)=.05805.
\tag{10}
\]

For \(b\geq r\), the correction in (6) is zero and

\[
\begin{aligned}
C_H^{CO}(b)-C_L^{CO}(b)
={}&\frac16-b^2+\frac53b^3-\frac34b^4\\
&+\frac14r^4-\frac13r^3.
\end{aligned}
\tag{11}
\]

At \(b=r\), (11) equals

\[
.01395>0.
\tag{12}
\]

Its derivative is

\[
b(3b-2)(1-b)\geq0
\qquad\text{for }b\in[r,1].
\tag{13}
\]

Thus \(C_H^{CO}(b)>C_L^{CO}(b)\) pointwise, including both sides and the
value of the discontinuity. The low- and high-demand jumps at \(r\) are,
respectively,

\[
.147
\qquad\text{and}\qquad
.1029.
\tag{14}
\]

Both continuation functions are nondecreasing, but their difference falls at
the common jump before increasing above it.

Buyer willingness satisfies

\[
w_H^{CO}(b)-w_L^{CO}(b)
=
\begin{cases}
0,&b\leq r,\\[1mm]
\dfrac{b^3-r^3}{3}-\dfrac{b^4-r^4}{4},&b>r.
\end{cases}
\tag{15}
\]

Above \(r\), its derivative is \(b^2(1-b)\geq0\). Hence
\(w_H^{CO}\geq w_L^{CO}\) and the willingness difference is weakly
increasing on the whole support. Pointwise continuation ordering and monotone
buyer willingness are the two structural properties used by the nested-menu
and D1 arguments.

The counteroffer distortion creates the additional surplus region in (7).
In the two states, respectively, the audited negative-wedge intervals are
approximately

\[
(.56201,.7)
\quad\text{and}\quad
(.62006,.7),
\tag{16}
\]

where the upper endpoint is approached from below. The gross wedges jump from
\(-.138\) to \(.009\) in state \(L\), and from \(-.07995\) to
\(.02295\) in state \(H\), at \(r\). The equilibrium certificates below do
not use the negative-wedge channel on path.

## 4. Probing-only equilibrium

Let

\[
\kappa=.01,
\qquad
\bar d=.019.
\tag{17}
\]

The probing fixed point is

\[
q_L=.768823840543.
\tag{18}
\]

The low-demand seller accepts and the high-demand seller rejects. The attempt
mass is \(.0399163013\), yielding

\[
\Pr(\text{no early offer})=.960083699,
\]

\[
\Pr(\text{rejected attempt})
=\Pr(\text{successful pre-emption})
=.019958151.
\tag{19}
\]

The scalar price residual is zero at reported precision; independent
high-order quadrature gives opposite endpoint residual signs
\((.132777,-.001759)\). The wait--probe cutoff is minimized at \(b=1\)
and equals approximately

\[
.007824>0.
\tag{20}
\]

Thus every initiating buyer has positive urgency even though the terminal
mechanism admits the off-path surplus region in (16).

The discontinuity in seller continuation requires one adjustment to the
baseline proof. The function \(C_L^{CO}-w_L^{CO}\) jumps upward at \(r\), so
the baseline shortcut that treats this difference as globally decreasing
cannot be invoked. Here the highest feasible wait--probe marginal value is
directly \(b_L^0=1\), and the required deterrence inequality is checked at
that value:

\[
C_L^{CO}(1)-q_L=.002176>0.
\tag{21}
\]

For every probing undercut, monotonicity of (15) makes the highest-value
marginal type D1-permitted on the complete nested plan set
\[
\{(x,0):x\in[0,1]\}\cup\{(1,y):y\in[0,1]\}.
\]
Belief on \(b=1\) makes seller \(L\) reject the relevant undercuts by (21),
and seller \(H\) rejects by pointwise ordering. For overcuts, the required
\(H\)-acceptance probability is minimized by the highest-value,
highest-urgency probing type. The best all-state deviation has gain

\[
-.001100580.
\tag{22}
\]

The top-value off-path response thresholds are

\[
(C_L^{CO}(1),C_H^{CO}(1))=(.771,.800025).
\tag{23}
\]

An explicit inactive-price audit checks both sides and equality at each
threshold. Because payoff decreases in price within a fixed response region,
these endpoints exhaust the continuum. Its largest inactive-price gain is

\[
-.001088080
\tag{24}
\]

at the cheapest \(L\)-only price \(p=.771\). Thus the probing assessment has
a complete nested-plan interim-D1-compatible completion.

## 5. Full-menu equilibrium

Now set

\[
\kappa=.05,
\qquad
\bar d=1.
\tag{25}
\]

The two-price fixed point is

\[
(q_L,q_H)
=(.685533774109,.753166476086).
\tag{26}
\]

The action masses for waiting, probing, and knockout are

\[
(M_0,M_L,M_H)
=(.734153617,.043363698,.222482685),
\tag{27}
\]

so the observed outcomes have probabilities

\[
(\text{no early offer},\text{rejection},\text{success})
=(.734153617,.021681849,.244164534).
\tag{28}
\]

The three global urgency-cutoff ranges, written from their minima to maxima,
are

\[
[.004533774,.785533774],
\quad
[.007653976,.803166476],
\quad
[.010774178,.820799178].
\tag{29}
\]

Every on-path attempt therefore has positive urgency. The sorting margin is
\(.003120202\), the two seller-response slacks are \(.031448221\) and
\(.027979455\), and the fixed-point residuals are below
\(3\times10^{-15}\). A width-\(10^{-4}\) price box has strictly positive
interiority and inward-face margins; the smallest face margin is
\(9.9941\times10^{-5}\).

The jump in \(C_s^{CO}\) does not invalidate the fixed-point existence
argument. Buyer action weights depend on the continuous willingness functions,
and seller continuation is bounded with a fixed, measure-zero discontinuity
at \(r\). Dominated convergence therefore preserves continuity of the price
map. The continuation functions are nondecreasing, so the monotone-likelihood
corner reduction used for the price-box faces also survives the jump.

For D1, the top-value off-path slacks are

\[
C_L^{CO}(1)-q_L=.085466,
\qquad
C_H^{CO}(1)-q_H=.046859.
\tag{30}
\]

For \(p<q_L\), the highest-value wait--probe marginal type is D1-permitted by
(15), and the first inequality in (30) supports rejection. For
\(q_L<p<q_H\), the highest-value probe--knockout marginal type is
D1-permitted, and the second inequality supports \(H\)-rejection; any
\(L\)-acceptance cannot create a gain above the cheaper equilibrium probe.
For \(p\geq q_H\), even all-state acceptance is weakly worse than the
equilibrium knockout.

This comparison uses every nested plan on both branches. Continuity of
\(C_s^{CO}\) is not required: pointwise \(C_H^{CO}>C_L^{CO}\) makes every
rationalizable seller plan nested under any common posterior, while posterior
mixing convexifies each seller's continuation range. The monotone willingness
gap ranks the buyer gain sets exactly as in the continuous baseline.

The explicit inactive-price audit again checks the two thresholds in (23),
their adjacent floating-point values, the interior response intervals, and
the price endpoints. Its largest gain is

\[
-.042733113.
\tag{31}
\]

Together, (15) and (30)--(31) establish a complete nested-plan
interim-D1-compatible completion for the full-menu assessment.

## 6. Interpretation and stopping boundary

The positive result is narrower and more informative than simply replacing
one reserve by another. Under coarse terminal information, a realistic
one-shot seller counteroffer does not eliminate the paper's screening
mechanism: both the probing-only equilibrium and the richer two-price menu
continue to generate the three empirical outcome categories. The displayed
equilibria also retain urgency as the on-path selection force.

Two limits should remain explicit.

1. **Rich bid histories.** If the seller learns the provisional winner's
   maximum report and uses it in the counteroffer, a high buyer shades to
   reduce the personalized demand. Note 116 proves that no symmetric,
   strictly increasing, no-overbid pure equilibrium survives on an active
   interval. A pooling or mixed terminal equilibrium would have to be solved
   jointly with early offers.
2. **Private state-dependent fallback.** If \(v_s\), and therefore
   \(\rho(v_s)\), varies with the seller's private state, the exclusion jump
   can disturb pointwise continuation ordering. The present result
   deliberately holds \(v\) common and lets private demand generate the two
   continuation states. A full aligned-composite counteroffer model is not
   established here.

For publication, the demand-only coarse-history result is a sufficient
robustness check. It shows that terminal counteroffers need not overturn the
central outcomes while also identifying exactly why non-commitment may add a
new source of early-trade surplus. A global rich-history bargaining model
would be a separate project rather than a necessary completion of the current
paper.

## 7. Claim ledger

**Analytical:** reserve equivalence for any fixed number of iid bidders;
invariance of the winner's conditional distribution to an unknown demand
state governing bidder count; truthful dropout pointwise in realized rival
caps; formulas (4)--(8) for arbitrary \(F\); the demand-only pointwise
continuation order; monotonicity of the willingness gap; continuity of the
price maps despite the fixed reserve jump; and transfer of the complete
nested-plan D1 comparisons conditional on the displayed strict equilibrium
inequalities.

**Numerically audited in floating point (not interval-certified):** the
probing and full-menu fixed points; action and
outcome masses; seller responses; inactive-offer deviations; price endpoints;
both floating-point sides and equality at the reserve and off-path acceptance
thresholds; the positive price-box face signs; and the reported D1 slacks.

**Not claimed:** interval-arithmetic existence; uniqueness; a coupled
early-offer equilibrium under rich terminal histories; a pooling or mixed
solution to the terminal ratchet problem; or an aligned-composite result with
private state-dependent fallback.
