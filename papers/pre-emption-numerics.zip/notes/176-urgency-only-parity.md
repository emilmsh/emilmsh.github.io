---
type: independent-theory-audit
status: urgency-only-parity-verified-knockout-only-counterexample-with-exact-gate
last_updated: 2026-07-28
active_manuscript: ../manuscripts/Manuscript.tex
audited_code: ../code/audit_urgency_only_knockout_only_d1.py
related_notes:
  - 114-three-microfoundation-refinement-gate.md
  - 132-seller-urgency-only-refined-pbe.md
  - 133-seller-urgency-only-independent-audit.md
  - 175-general-state-microfoundations-restructure.md
manuscript_state: >
  Audited against the working tree of 2026-07-28 (HEAD 3c11420 plus the
  uncommitted microfoundations restructure that adds sec:microfoundations,
  sec:microcompare, and cor:urgencyprobing).  All references below are to
  labels, not line numbers.
---

# Urgency-only microfoundation: parity audit (T1--T5)

Urgency-only setting throughout: common terminal environment \(Q_L=Q_H=Q\),
\(v_L=v_H=v\), so common \(w(b)\), \(R(b)\), \(u(b)\), and common wedge
\(\Gamma(b)=R(b)-w(b)\geq0\) with \(\Gamma(\bar b)=0\); state-dependent seller
timing cost \(d_{S,s}=z_s\) with \(z_U>z_P\geq0\).  Labels: \(L\) = urgent
(\(C_L(b)=R(b)-z_U\)), \(H\) = patient (\(C_H(b)=R(b)-z_P\)).  Then
\(C_H-C_L=z_U-z_P>0\) is constant, \(w_H\equiv w_L\), and
\(\Delta w\equiv0\) is a *global* willingness plateau.  Write
\(A=1-\pi\), \(\pi=\Pr(s=H)\).

## 0. Verdicts

- **T1 (holds, with one restatement).**  Assumption `ass:ordering` holds
  under urgency-only clause by clause, provided its last clause is read with
  the state's own timing cost:
  \(\Gamma_s(b)=C_s(b)+d_{S,s}-w_s(b)\) weakly decreasing.  The working tree
  already writes the clause as \(\Gamma_L(b)=C_L(b)+d_{S,L}-w_L(b)\); this is
  correct and harmless everywhere the clause is used.  One leftover
  bookkeeping slip remains in the sentence after the assumption
  (\(C_s(\bar b)=w_s(\bar b)-d_S\) should be \(-d_{S,s}\)).
- **T2 (all task algebra verified).**
  \(\bar D_L=\kappa/(1-\pi)-z_U\), \(\bar D_H=\kappa-z_P\),
  \(\Delta_D=(z_U-z_P)-\pi\kappa/(1-\pi)\), window upper endpoint
  \([(1-\pi)z_U-z_P]/\pi\), positivity \(\iff z_U<\Gamma(\underline
  b)+\kappa/(1-\pi)\), D1 sufficiency \(\bar D_L\geq0\iff z_U\leq
  \kappa/(1-\pi)\).  In the Example, \(\bar D_L=0\) exactly.  No error found
  in the task's algebra; two refinements noted (window nonemptiness needs
  \((1-\pi)z_U>z_P\), automatic when \(z_P\leq\kappa\); the exact probing D1
  condition in wedge form is \(\Gamma(b_L^0)\geq z_U-\kappa/(1-\pi)\)).  The
  new `cor:urgencyprobing` in the working tree is verified line by line.
- **T3 (MAIN; settled both ways, with an exact boundary).**  The knockout-only
  exclusion (`prop:boundarycompleteness`) does **not** extend to urgency-only.
  A pure knockout-only PBE with positive waiting and knockout mass **survives
  criterion D1** (strict-gain form, contingent-plan representation, exactly as
  in `app:probingregime`) at the Example's own primitives, with boundary price
  \(q^\ast=0.637358061052\), waiting mass \(0.6155\), knockout mass
  \(0.3845\).  The exact survival gate at a knockout-only price \(q_H\) is
  \[
  \text{(i) } z_U-z_P\leq\bigl[C_H(b_K^0)-q_H\bigr]+\frac{\pi\kappa}{1-\pi},
  \qquad
  \text{(ii) } q_H\leq C_H(b_K^0),
  \qquad
  b_K^0=\min\{\bar b,\ w^{-1}(q_H+\kappa)\},
  \]
  and (i) implies (ii) whenever \(\Delta_D\geq0\).  Equivalently, at an
  interior \(b_K^0\): survives iff \(z_U\leq\Gamma(b_K^0)+\kappa/(1-\pi)\).
  The exclusion **returns** exactly when the urgency gap exceeds this bound:
  verified failures at \(z_U\in\{.025,.03,.05\}\) (Example primitives have
  boundary \(z_U^\ast=0.023043582\)).  The manuscript's current conjecture
  sentence (sec:microcompare, TODO line) is right in spirit but **not exact as
  worded**: the operative premium is at the top *feasible marginal* value
  \(b_K^0\), not the top of the pool, and the boundary carries the slack
  \(\pi\kappa/(1-\pi)\).  Suggested replacement text in §T3.9.
- **T4 (verified).**  \(D_L(b;q_L)\) strictly decreasing (attempts select high
  \(b\), as in the baseline); \(Z(b;q)=q_H-q_L-\pi\kappa/(1-\pi)\) constant in
  \(b\), so the probing band \(D_H-D_L=Z/\pi\) has constant urgency-width
  (Example: \(0.093902289\), matching the manuscript audit).  Rejection
  reveals seller patience, which does not enter the buyer's auction
  continuation \(u(b)\): the buyer learns nothing payoff-relevant.  Empirical
  fingerprints in §T4.3, including the discriminating null against the
  demand/aligned bid-log prediction.
- **T5 (confirmed).**  `prop:disclosure` part (iii) uses only: \(s\) public,
  pure strategies, \(\kappa>0\), and rejection \(\equiv\) waiting.  Fully
  general across microfoundations; nothing demand-only in the argument.  (The
  *institutional* disclosure regime remains demand-specific because only
  demand is certifiable, as sec:microcompare now says.)

Numerical claims: composite Simpson, 131,072 endpoint-inclusive panels;
fixed-point residuals \(\leq2.2\times10^{-16}\); machinery validated by
reproducing the manuscript's independently audited urgency-only full-menu
Example to every displayed digit.  Reproduce with
`python code/audit_urgency_only_knockout_only_d1.py` (deterministic, stdlib
only).

---

## T1. Assumption `ass:ordering` under urgency-only

Clause by clause, using the common-environment formulas (note 114 eqs.
(1)--(4), specialized to \(Q_L=Q_H=Q\), \(v_L=v_H=v\)):

1. **Positivity \(C_L(\underline b)>0\).**  Reads \(z_U<R(\underline b)\).  A
   primitive restriction, exactly as \(d_S<R_L(\underline b)\) in the
   baseline.  Example: \(R(0)=.472>.02\).  Holds.
2. **\(w_s\) continuous, strictly increasing.**  \(w\) is the common
   eq:patientwillingness object: slope 1 below \(v\), slope
   \(1-\phi(F(b))>0\) on \((v,\bar b)\) when \(Q(N\geq1)>0\).  Strict
   increase on the closed support follows by integration (the derivative
   vanishes only at \(b=\bar b\)), identically to the baseline.  Holds.
3. **\(C_s\) continuous, nondecreasing, strictly increasing on a top
   interval.**  \(C_s=R-z_s\) inherits both from \(R\): \(R'=0\) below \(v\),
   \(R'(b)=[1-F(b)]\,\mathbb E_Q[NF(b)^{N-1}]>0\) on \((v,\bar b)\) (note 114
   eq. (3)).  Needs \(v<\bar b\) (maintained).  Holds.
4. **\(w_L\leq w_H\).**  Holds with equality everywhere.  The clause is
   weak, so a global tie is admissible.
5. **\(C_L<C_H\) pointwise.**  \(R-z_U<R-z_P\iff z_U>z_P\).  Strict by
   assumption.  Holds.  (This is the only clause carrying the state
   ordering; it is what makes seller responses nested under the common
   posterior.)
6. **\(w_H-w_L\) weakly increasing.**  \(\equiv0\): weakly increasing.
   Holds (degenerately).
7. **Wedge clause — the bookkeeping issue.**  As historically written,
   \(\Gamma_L(b)=C_L(b)+d_S-w_L(b)\) presumes a common public \(d_S\); under
   urgency-only there is no such object, and mechanically inserting either
   \(z_U\) or \(z_P\) gives different functions.  The correct statement with
   state-dependent timing costs is
   \[
   \Gamma_s(b)=C_s(b)+d_{S,s}-w_s(b)\ \text{ weakly decreasing (each }s),
   \]
   which under urgency-only collapses to the single common wedge
   \(\Gamma(b)=R(b)-w(b)=\mathbb E[(\max\{v,Y_{2N}\}-b)^+]\), weakly
   decreasing by lem:wedge.  The working tree already restates the clause as
   \(\Gamma_L(b)=C_L(b)+d_{S,L}-w_L(b)\) — equivalent for the \(L\)-wedge and
   sufficient, because **every use of the clause needs only the \(L\)-state
   wedge**:
   - `app:probingregime`, proof of `cor:probingd1`: defines
     \(\Xi_L(b)=C_L(b)-w_L(b)+\kappa/(1-\pi)=\Gamma_L(b)-d_{S,L}+\kappa/(1-\pi)\)
     and uses only that \(\Xi_L\) is weakly decreasing.  Under urgency-only
     \(\Xi_L=\Gamma-z_U+\kappa/(1-\pi)\): weakly decreasing.  Transfer exact.
   - `prop:probingregime` proof and the no-early-offer argument use the top
     type's maximality and eq:topknockoutcutoff, not the wedge clause.
   - The main-text uses (`cor:stategains`, the eq:stateordering display) are
     statements about \(\Gamma_s\) per state; the working tree's new sentence
     after `cor:stategains` ("with a state-dependent seller timing cost the
     state-\(s\) condition reads \(d_B+d_{S,s}\geq\Gamma_s(b)\)") is the
     correct generalization: under urgency-only \(\Gamma_H=\Gamma_L=\Gamma\)
     and \(d_{S,H}<d_{S,L}\) keep the three-case structure with thresholds
     ordered by \(z_s\).
   - `prop:boundarycompleteness` does **not** use the wedge clause; it uses
     the strict shape of \(\Delta w\) from the *aligned composite*
     specification directly (see T3.1).
   Conclusion: the restatement is harmless; no proof consumes more than
   monotonicity of the accepting state's own wedge.

   Residual nit: the sentence after the assumption still reads
   "\(C_s(\bar b)=w_s(\bar b)-d_S\)"; should be \(d_{S,s}\).

Note 114 §§2--4 verified the reduced-form transfer of the no-early-offer,
probing, full-menu, cardinality, and probing/full-menu D1 results for D/V/C
using only its eqs. (1)--(6) with weakly increasing \(\Delta w\).  Urgency-only
satisfies that reduced form: \(\Delta w\equiv0\) is weakly increasing, note
114 (6) holds with \(C_H-C_L=z_U-z_P>0\) and \(w_H=w_L\), and note 114 (3)
gives the top-interval strict increase of \(C_L\).  Hence all of note 114 §4
transfers verbatim to urgency-only; only the knockout-only exclusion (its §5
gate) is at issue, which is T3.

## T2. `prop:probingregime` specialized to urgency-only

Because \(\Gamma(\bar b)=0\), the terminal identity gives
\(C_s(\bar b)=w(\bar b)-z_s\).  Substituting into
eq:auctionentrythresholds and eq:entrygap:

\[
\bar D_L=C_L(\bar b)-w_L(\bar b)+\frac{\kappa}{1-\pi}
        =\frac{\kappa}{1-\pi}-z_U,
\qquad
\bar D_H=C_H(\bar b)-\bar w(\bar b)+\kappa=\kappa-z_P,
\]
\[
\Delta_D=\bar D_H-\bar D_L
=(z_U-z_P)-\frac{\pi\kappa}{1-\pi}
\quad\text{(also directly from eq:entrygap with }\Delta w(\bar b)=0),
\]
\[
\bar D_L+\frac{\Delta_D}{\pi}
=\frac{(1-\pi)z_U-z_P}{\pi}
\quad\text{(consistent with eq:topknockoutcutoff:}\ 
D_H(\bar b;C_L(\bar b),C_H(\bar b))=[(1-\pi)z_U-z_P]/\pi).
\]

Positivity condition:
\(C_L(\underline b)-w_L(\underline b)+\kappa/(1-\pi)>0
\iff \Gamma(\underline b)+\kappa/(1-\pi)>z_U\).

So the probing-only window requires exactly the task's chain
\[
\frac{\pi\kappa}{1-\pi}+z_P<z_U<\Gamma(\underline b)+\frac{\kappa}{1-\pi},
\qquad
\bar D_L<\bar d\leq\frac{(1-\pi)z_U-z_P}{\pi}.
\]
**All of the task's algebra checks out; nothing to correct.**  Two
refinements, neither an error:

1. Since \(\bar d>0\), the \(\bar d\)-window is nonempty only if its upper
   endpoint is positive, i.e. \((1-\pi)z_U>z_P\).  This is implied by
   \(\Delta_D>0\) whenever \(z_P\leq\kappa\), but is an extra (mild)
   restriction when \(z_P>\kappa\).
2. \(\bar D_L\geq0\iff z_U\leq\kappa/(1-\pi)\) is only the *sufficient* D1
   condition.  The exact condition of `cor:probingd1`, \(q_L\leq
   C_L(b_L^0)\), has the wedge form
   \(\Gamma(b_L^0)\geq z_U-\kappa/(1-\pi)\) when \(b_L^0<\bar b\) (from
   \(D_L(b_L^0;q_L)=0\), i.e. \(w(b_L^0)=q_L+\kappa/(1-\pi)\)), and holds
   automatically when \(b_L^0=\bar b\) (interior fixed point).  This is the
   same functional form as the knockout gate in T3 — the unifying object is
   the wedge at the top feasible marginal value of the relevant rung.

**Tension/compatibility.**  Probing window needs
\(z_U>z_P+\pi\kappa/(1-\pi)\); D1 sufficiency needs
\(z_U\leq\kappa/(1-\pi)\).  Both hold on
\(\bigl(z_P+\pi\kappa/(1-\pi),\ \kappa/(1-\pi)\bigr]\), nonempty **iff
\(z_P<\kappa\)**.  For \(z_P\geq\kappa\) (or \(z_U>\kappa/(1-\pi)\)) the
sufficient condition is unavailable and D1 survival must run through the
exact wedge condition above, which buys the extra room \(\Gamma(b_L^0)>0\).

**Numerical cross-check at the Example** (\(\kappa=.01\), \(\pi=.5\),
\(z_U=.02\), \(z_P=0\)): \(\kappa/(1-\pi)=.02\), so \(\bar D_L=0\) exactly —
confirmed; the Example sits precisely on the D1-sufficiency boundary.
\(\bar D_H=.01\), \(\Delta_D=.01>0\), window \(\bar d\in(0,.02]\), positivity
margin \(\Gamma(0)+.02-z_U=.472\).  The Example's \(\bar d=1\) far exceeds
the window's upper endpoint \(.02\) — consistent with the Example being
full-menu (knockout active with mass \(.2645\)) rather than probing-only.

The working tree's new `cor:urgencyprobing` states exactly these objects
(\(\bar D_L=\kappa/(1-\pi)-d_{S,L}\), \(\Delta_D=\Delta z-\pi\kappa/(1-\pi)\),
window endpoint \([(1-\pi)d_{S,L}-d_{S,H}]/\pi\), positivity
\(d_{S,L}<\min\{R(\underline b),\Gamma(\underline b)+\kappa/(1-\pi)\}\), D1
sufficiency \(d_{S,L}\leq\kappa/(1-\pi)\)) and its proof substitutes
correctly.  Verified line by line.

## T3. Knockout-only and criterion D1 under urgency-only

**Answer: the exclusion does not extend.  Under urgency-only, refined pure
knockout-only equilibria exist, including at the paper's own Example
primitives; and the exclusion returns above an exact urgency-gap boundary.**
The task's instruction not to presume the counterexample was heeded: §§T3.3--
T3.5 derive the gate in both directions before any construction.

### T3.1 Where the aligned proof uses demand variation

The proof of `prop:boundarycompleteness` (app:boundarycompleteness) works at
the wait--knockout marginal curve \((b,D_K(b))\), \(D_K(b)=q_H-\bar
w(b)+\kappa\), and evaluates the gain from an undercut \(p=q_H-\delta\) under
a nested plan \(a=(a_L,a_H)\) (eq:knockoutmarginalgain; note 114 (15)--(16)):
\[
m_b(a)=\rho(a)(\delta+\kappa)-A\pi(a_L-a_H)\,\Delta w(b)-\kappa,
\qquad \rho(a)=Aa_L+\pi a_H .
\]
The **only** term through which the marginal type's identity matters is
\(-A\pi(a_L-a_H)\Delta w(b)\).  The proof's ranking step
(eq:knockoutranking) makes this strict — lower-\(\Delta w\) marginal types
have strictly larger gain sets at partial plans — **using the strict increase
of \(\Delta w\) above \(v_L\) from the aligned/demand specification**
(eq:willingnessdifference; note 114 (7), (9)).  Strict-gain D1 then deletes
every marginal type except \(\beta_K=\inf\mathcal B_K\) (or the lower plateau
\([\beta_K,v_L]\), where \(C_H\) is *constant*).  Since the knockout pool has
mass above \(\max\{\beta_K,v_H\}\) where \(C_H\) strictly rises, on-path
sequential rationality forces \(C_H(\beta_K)<\mathbb E[C_H\mid
q_H]\leq q_H\) (note 114 (17)), so an undercut
\(p\in(C_H(\beta_K),q_H)\) is accepted by both states under **every**
D1-permitted posterior and profits every surviving marginal buyer.  That is
the exclusion.  The demand-variation input is thus precisely: *strict*
monotonicity of \(\Delta w\) over the feasible marginal set (or, failing
that, constancy of \(C_H\) on the surviving plateau) — note 114 §8's gate.

### T3.2 Why the fallback plateau disarms it — and urgency-only more so

Fallback-only has \(\Delta w\) constant above \(v_H\) while \(C_H\) still
rises there (note 114 (8), (3)).  If \(\beta_K\geq v_H\), *all* feasible
marginal types tie (identical gain sets), D1 deletes none of them, and the
off-path posterior may sit on the **top** marginal type, whose continuation
value can exceed \(q_H\) and make both states reject every undercut — note
114 §6's counterexample (\(q_H=.654467\), \(\beta_K=.6231>v_H\),
\(C_L(1)=989/1500>q_H\)).

Urgency-only is the global version of this: \(\Delta w\equiv0\) on the whole
support, so the tie is unconditional — **every** feasible wait--knockout
marginal type has the same gain set after every undercut, with no location
condition like \(\beta_K\geq v_H\) to check — while \(C_H=R-z_P\) is strictly
increasing above \(v\).  Note 114 §8's gate fails globally, so the aligned
proof cannot transfer; whether the *conclusion* fails too is exactly the
question of whether the top of the tied curve is strong enough to deter
undercuts.  It need not be: unlike fallback-only, urgency subtracts
\(z_U\) from the urgent seller's continuation *without any offsetting
movement in \(w\) or \(R\)*, so a large urgency gap can sink
\(C_L\) at the top of the curve below the deterrence threshold.  Both
outcomes occur; the boundary is exact and is derived next.

### T3.3 Scalar reduction and the tied curve

In the contingent-plan representation (lem:interimd1representation), after
any price \(p\) a nested plan matters to the buyer only through
\(\rho=Aa_L+\pi a_H\in[0,1]\), because \(w_H\equiv w_L\): a type
\((b,d)\)'s deviation payoff is \(\rho(z-p)-\kappa\) with \(z=w(b)+d\)
(note 133 §4's reduction, which the manuscript's Example audit already
uses).  Against the knockout-only equilibrium value
\(U^\ast(z)=\max\{0,\,z-q_H-\kappa\}\), the weak-gain set of a type with
scalar \(z\) is \(\{\rho\geq\tau(z;p)\}\),
\[
\tau(z;p)=\frac{\kappa+U^\ast(z)}{z-p}\quad(z>p),
\]
which is strictly decreasing in \(z\) on \(z\leq q_H+\kappa\) and strictly
increasing on \(z\geq q_H+\kappa\) (for \(p<q_H\)).  So for **every**
undercut, the deviation-eager set is the curve
\[
\Theta_K=\{(b,d):\,w(b)+d=q_H+\kappa,\ d\in[0,\bar d]\},
\]
whose value-range is \([\beta_K,b_K^0]\),
\(\beta_K=\max\{\underline b,\,w^{-1}(q_H+\kappa-\bar d)\}\),
\[
b_K^0=\min\{\bar b,\ w^{-1}(q_H+\kappa)\}.
\]
All curve types tie (identical gain sets: \(\Delta w\equiv0\)); all off-curve
types have strictly smaller gain sets and are deleted whenever deletion has
bite (the marginal strict-gain tail is nonempty inside the rationalizable
\((x,0)\) branch iff \(\tau(q_H+\kappa;p)=\kappa/(q_H+\kappa-p)<A\), i.e.
iff \(p<q_H-\pi\kappa/A\); for larger \(p\) no plan gives any type a strict
gain exceeding what the completion below already deters).  D1-permitted
posteriors after an undercut are therefore exactly the distributions on
\(\Theta_K\) (unrestricted where all gain sets are empty).  This confirms the
task-sketch's location of the eager types — but note the sketch's inference
is inverted: D1 does **not** force beliefs onto the low-\(b\) end of the
curve; ties let the completion choose the top, and only the *top's* strength
decides survival.

Key belief statistics over permitted posteriors: \(\mathbb E[C_s(b)]\) ranges
over \([C_s(\beta_K),\,C_s(b_K^0)]\) (\(R\) nondecreasing), with maximum at
the singleton \(\delta_{(b_K^0,\,D_K(b_K^0))}\); when \(b_K^0<\bar b\) this
type has \(d=0\) and \(w(b_K^0)=q_H+\kappa\), hence the useful identity
\[
C_s(b_K^0)=q_H+\kappa+\Gamma(b_K^0)-z_s .
\]

### T3.4 Survival direction (proved)

Fix a knockout-only PBE with price \(q_H\), positive waiting and knockout
mass.  Suppose
\[
\text{(i)}\quad z_U\leq\Gamma(b_K^0)+\frac{\kappa}{1-\pi}
\qquad\text{and}\qquad
\text{(ii)}\quad q_H\leq C_H(b_K^0),
\]
where at \(b_K^0=\bar b\) (i) is read through the unified form
\(C_L(b_K^0)\geq q_H-\pi\kappa/(1-\pi)\) (they coincide at interior
\(b_K^0\) by the identity above, using \(\Gamma(\bar b)=0\)).  Then the
single off-path belief \(\mu(\cdot\mid p)=\delta_{(b_K^0,\,D_K(b_K^0))}\) for
all \(p\neq q_H\), with sequentially rational responses, is a D1-compatible
completion:

- **\(p<C_L(b_K^0)\):** both states reject (thresholds
  \(C_L(b_K^0)\leq C_H(b_K^0)\)).  Every type's gain is
  \(-\kappa-U^\ast\leq-\kappa<0\).
- **\(C_L(b_K^0)\leq p<q_H\):** the urgent state accepts, the patient state
  rejects (\(p<q_H\leq C_H(b_K^0)\) by (ii)); the response is \((1,0)\),
  \(\rho=A\).  The sup over *all* types of the gain
  \(A(z-p)-\kappa-U^\ast(z)\) is attained on the curve (increasing in \(z\)
  below it, decreasing above it) and equals
  \[
  A(q_H+\kappa-p)-\kappa\ \leq\ A(q_H+\kappa-C_L(b_K^0))-\kappa
  =A\Bigl(z_U-\Gamma(b_K^0)-\frac{\kappa}{1-\pi}\Bigr)\leq0
  \]
  by (i).  No strict gain.
- **\(p>q_H\) (overcuts):** for every \(\rho\) and every type,
  \(\rho(z-p)-\kappa<U^\ast(z)\) (note 133 §4.4 verbatim; the note 114
  eq. (26) analogue is \(A(q_H-p)-\pi\kappa<0\), trivially negative here
  since \(\Delta w=0\) and \(p>q_H\)).  Gain sets are empty; D1 is
  unrestricted; keep the same belief.

Since the belief sits on the tied curve wherever deletion bites and is
unrestricted elsewhere, it is D1-permitted at every off-path price.  The
equilibrium survives.  (At equality in (i) the sup gain is \(0\): weak, not
strict, so the strict-gain criterion still passes; the survival region is
closed.)

### T3.5 Failure direction (proved)

Suppose (i) fails: \(z_U>\Gamma(b_K^0)+\kappa/(1-\pi)\), equivalently
\(C_L(b_K^0)<q_H-\pi\kappa/(1-\pi)\).  Pick any
\(p\in(C_L(b_K^0),\,q_H-\pi\kappa/(1-\pi))\); note
\(p>C_L(b_K^0)>C_L(\underline b)\) and
\(\tau(q_H+\kappa;p)=\kappa/(q_H+\kappa-p)<\kappa/(\kappa/A)=A\), so the
curve types' strict-gain sets are nonempty inside the rationalizable
\((x,0)\) branch and the D1 deletion leaves exactly \(\Theta_K\).  Under
**every** permitted posterior, \(\mathbb E[C_L]\leq C_L(b_K^0)<p\): the
urgent state must accept, so every sequentially rational response has
\(\rho\geq A\).  The curve types' gain is then at least
\(A(q_H+\kappa-p)-\kappa>A\cdot\kappa/A-\kappa=0\), strict.  Every
D1-consistent completion admits a profitable deviation: **fails strict-gain
D1.**  If instead (ii) fails, \(q_H>C_H(b_K^0)\), any
\(p\in(C_H(b_K^0),q_H)\) forces acceptance by both states under every
permitted posterior and every knockout type gains \(q_H-p>0\): fails.
(When \(\Delta_D\geq0\), (i) implies (ii), so (i) alone is the boundary in
the economically relevant region; and when \(b_K^0=\bar b\), (ii) is already
implied by PBE, since a price above \(C_H(\bar b)\) would be undercut
profitably under any beliefs.)

**Exact gate (both directions together).**  A pure knockout-only PBE with
positive waiting and knockout mass survives strict-gain D1 in the
contingent-plan representation **iff**
\[
\boxed{\ z_U-z_P\ \leq\ \bigl[C_H(b_K^0)-q_H\bigr]+\frac{\pi\kappa}{1-\pi}
\quad\text{and}\quad q_H\leq C_H(b_K^0),\qquad
b_K^0=\min\{\bar b,\,w^{-1}(q_H+\kappa)\}.\ }
\]
Under boundary pricing \(q_H=\mathbb E[C_H(b)\mid\text{pool}]\), the first
condition reads: *the urgency gap is at most the top feasible marginal
type's continuation premium over the knockout pool, plus the screening slack
\(\pi\kappa/(1-\pi)\)*:
\(z_U-z_P\leq R(b_K^0)-\mathbb E[R(b)\mid\text{pool}]+\pi\kappa/(1-\pi)\).

**Class-level boundary.**  The gate tightens in \(q_H\): with
\(\psi(q)=q-\pi\kappa/(1-\pi)-C_L(b_K^0(q))\), on the interior branch
\(\psi'(q)=1-R'(b_K^0)/w'(b_K^0)\geq0\) because for \(b>v\)
\[
R'(b)=(1-F)\,\mathbb E[NF^{N-1}]\ \leq\ \mathbb E[1-F^{N}]=1-\phi(F)=w'(b),
\]
using \(1-x^N=(1-x)\sum_{k<N}x^k\geq(1-x)Nx^{N-1}\); on the corner branch
\(\psi'=1\).  Hence survival of *any* knockout-only PBE price is decided at
the **lowest** PBE price, the boundary fixed point \(q^\ast\), and the
D1-surviving price set is an interval \([q^\ast,q^{\max}]\) with
\(q^{\max}\) solving \(\psi=0\) (empty iff \(\psi(q^\ast)>0\)).  The
boundary fixed point exists generically by the intermediate value theorem on
\([C_H(\underline b),C_H(\bar b)]\), with positive waiting mass automatic
(\(D_K(\underline b)=q+\kappa>0\)) and positive knockout mass whenever
\(\kappa<\bar d+z_P\)-type interiority holds; existence is therefore not
knife-edge.

### T3.6 Counterexample at the Example's own primitives (verified numerically)

Primitives: \(F=U[0,1]\), \(n=2\), \(v=.4\), \(z_U=.02\), \(z_P=0\),
\(\pi=.5\), \(\kappa=.01\), buyer urgency truncated-exponential(10) on
\([0,1]\) — i.e. Example `prop:sellerurgencystate` unchanged, including
\(\bar d=1\).  Script: `code/audit_urgency_only_knockout_only_d1.py`
(Simpson, 131,072 endpoint-inclusive panels; bisection tolerance
\(10^{-15}\)).  Machinery validation (Part A): reproduces the manuscript
Example's \((q_L,q_H)=(.586756515,.643707660)\), masses
\((.550185181,.185288486,.264526333)\), outcome probabilities
\((.550185,.092644,.357171)\), cutoff gap \(.093902289\), and the audit
margins \(.009043008\), \(.024292340\), \(.044292340\) — every displayed
digit of the manuscript audit.

Knockout-only boundary fixed point and PBE conditions:

| object | value | condition | status |
|---|---|---|---|
| \(q^\ast\) | \(0.637358061052\) | \(q^\ast=\mathbb E[C_H\mid\text{pool}]\), residual \(1.1\times10^{-16}\) | boundary equality |
| waiting mass \(M_0\) | \(0.615536971\) | \(>0\) | holds |
| knockout mass \(M_K\) | \(0.384463029\) | \(>0\) | holds |
| outcome probs | \((.615537,\ 0,\ .384463)\) | attempts, no rejections | knockout-only |
| urgent on-path margin | \(q^\ast-\mathbb E[C_L\mid\text{pool}]=0.020000000\) | \(=z_U-z_P>0\) | strict acceptance |
| patient on-path | indifferent at \(q^\ast\) | accepts at equality | holds |
| buyer strategy | wait iff \(d<D_K(b)=q^\ast+\kappa-w(b)\) | exact cutoff optimality | holds by construction |

D1 objects and gates:

| object | value |
|---|---|
| \(D_K(1)\) | \(-0.040641939<0\) (top-value patient type strictly inside knockout) |
| \(b_K^0=w^{-1}(q^\ast+\kappa)\) | \(0.790989184\) |
| \(\Gamma(b_K^0)\) | \(0.003043582\) \((=(1-b_K^0)^3/3)\) |
| \(C_L(b_K^0),\ C_H(b_K^0)\) | \(0.630401643,\ 0.650401643\) |
| gate (i) \(z_U\leq\Gamma(b_K^0)+\kappa/(1-\pi)\) | \(.02\leq.023043582\), margin \(0.003043582\) |
| gate (ii) \(q^\ast\leq C_H(b_K^0)\) | margin \(0.013043582\) |
| full-rejection variant \(C_L(b_K^0)-q^\ast\) | \(-0.006956418<0\) — two-branch completion required |

Two-branch completion (single belief \(\delta_{(b_K^0,0)}\) at every
\(p<q^\ast\)) with analytic sup gains, confirmed on a \(1601\times1601\)
type grid (grid sups sit on the tied curve and match the analytic bounds to
grid resolution):

| price region | response | sup type gain (analytic) | grid |
|---|---|---|---|
| \(p<0.630401643\) | both reject | \(-\kappa=-0.01\) | \(-0.01\) |
| \(p\in[0.630401643,\ q^\ast)\) | urgent accepts, patient rejects | \(A(q^\ast+\kappa-p)-\kappa\leq-0.001521791\) | \(-0.001522\) at \((b,d)=(.630,.079)\), on the curve |
| \(p>q^\ast\) | any | \(<0\) (empty gain sets) | \(-0.02\) at \(p=q^\ast+.02\) |

All PBE and all D1 conditions that `app:probingregime` (and the Example's
own audit in `app:privatesellerurgency`) impose are satisfied with strict
margins except the intended boundary equality at \(q^\ast\).  **This is a
refined pure knockout-only equilibrium with positive waiting mass at the
paper's urgency-only Example primitives.**  It coexists with the full-menu
equilibrium of the Example: under urgency-only, D1 does *not* make
rejections essential.

### T3.7 A cleaner full-rejection variant (note 114 §6 template)

The two-branch completion is forced at \(\kappa=.01\) because
\(z_U>\kappa\).  Raising the offer cost to \(\kappa=.05\) (all else the
Example's) gives the exact analogue of note 114's fallback-only
construction: \(q^\ast=0.643706593437\) (residual \(2.2\times10^{-16}\);
the near-coincidence with the Example's full-menu \(q_H=.643708\) is
numerical accident, not identity), \(M_0=0.716425624\),
\(M_K=0.283574376\), \(D_K(1)=0.005706593\geq0\) so the top-value type
\(\theta^\ast=(1,D_K(1))\) is itself marginal and D1-retained, and
\[
C_L(1)-q^\ast=0.024293407>0:
\]
belief on \(\theta^\ast\) makes **both** states reject **every** undercut,
exactly as \(C_L(1)>q_H\) does in note 114 (25).  Gate margins: (i)
\(.08\), (ii) \(.044293\).  Overcut and low-price grid checks negative
(\(-0.05\), \(-0.02\)).

### T3.8 The failure boundary, sharply

At the Example primitives the fixed point \(q^\ast\), pool, and
\(b_K^0\) do not involve \(z_U\) (only \(C_H=R-z_P\) enters the map), so the
survival boundary in \(z_U\) is a genuine vertical cut:
\[
z_U^\ast=\Gamma(b_K^0)+\frac{\kappa}{1-\pi}=0.023043582 .
\]
- \(z_U\leq z_U^\ast\): survives.  D1-surviving price band at \(z_U=.02\):
  \([q^\ast,q^{\max}]=[0.637358061,\ 0.678000000]\), which at this
  calibration coincides with the raw-PBE band because \(z_U=\kappa/(1-\pi)\)
  exactly (the two upper endpoints \(w(1)-z_U+\pi\kappa/(1-\pi)\) and the
  \(\psi\)-root merge at the corner \(q=w(1)-\kappa=.678\)).  At
  \(z_U=.022\) the band shrinks to \([0.637358061,\ 0.646980728]\).
  Patient-seller rent margins \(q-T_K(q)\) sampled across the band are
  positive (\(+.0021\) to \(+.0343\)), so the interior band prices are PBEs.
- \(z_U>z_U^\ast\): every knockout-only PBE (boundary or rent-priced) fails
  D1, by T3.5 plus \(\psi\) monotonicity.  Verified killer intervals
  \((C_L(b_K^0),\,q^\ast-\pi\kappa/(1-\pi))\) and forced-acceptance marginal
  gains: \(z_U=.025\): \((.625402,.627358)\), gain \(\geq.000489\);
  \(z_U=.03\): \((.620402,.627358)\), gain \(\geq.001739\);
  \(z_U=.05\): \((.600402,.627358)\), gain \(\geq.006739\).
- Raw-PBE existence dies later, at
  \(z_U^{\text{raw}}=w(1)-q^\ast+\pi\kappa/(1-\pi)=0.060641939\): for
  \(z_U\in(z_U^\ast,z_U^{\text{raw}}]\) unrefined knockout-only PBEs exist
  and D1 eliminates them — the exclusion is "driven by D1" exactly as in the
  aligned case — while for \(z_U>z_U^{\text{raw}}\) even PBE fails.
- \(z_P\) sensitivity (\(z_P=.005\), \(z_U=.02\)): \(q^\ast=0.631047391\),
  \(b_K^0=0.774688490\), gap gate
  \(z_U-z_P=.015\leq R(b_K^0)-\mathbb E[R\mid\text{pool}]
  +\pi\kappa/(1-\pi)=0.018812667\): survives.

Interpretation.  The task-sketch's conjectured breaking mechanism — low-\(b\)
types on the attempt boundary making urgent-seller acceptance credible — is
exactly what operates in the failure region, but it needs the urgency gap to
be large enough to drag even the *top* of the tied curve below
\(q_H-\pi\kappa/(1-\pi)\); below that threshold D1's tie-tolerance rescues
the equilibrium through top-of-curve beliefs.  So the answer to "can it
break knockout-only even without demand variation?" is: yes, iff
\(z_U-z_P\) exceeds the top feasible marginal premium plus
\(\pi\kappa/(1-\pi)\); not at the Example calibration.

### T3.9 Correction to the manuscript's conjecture sentence

sec:microcompare currently conjectures existence "whenever the top-value
continuation premium in the knockout pool exceeds the urgency gap
\(d_{S,L}-d_{S,H}\)".  Two corrections make it exact:

1. the premium must be evaluated at the **top feasible marginal value**
   \(b_K^0=\min\{\bar b,w^{-1}(q_H+\kappa)\}\), not at \(\bar b\): when
   \(D_K(\bar b)<0\) the top-value types strictly prefer knockout and are
   D1-deleted after undercuts.  At the Example primitives the \(\bar
   b\)-premium is \(R(1)-q^\ast=.050642\), yet survival fails already at
   \(z_U-z_P=.025\) because the operative premium is
   \(C_H(b_K^0)-q^\ast=.013044\);
2. the boundary carries the screening slack \(+\pi\kappa/(1-\pi)\) (small
   undercuts are deterred even under forced urgent-seller acceptance).

Suggested replacement (drop-in for the conjecture sentence and its TODO;
adapt notation to house style):

> Under urgency variation the willingness gap is flat everywhere, which
> disarms the same step of the exclusion argument, and the exclusion in fact
> fails: at the primitives of Example [ref], the boundary knockout-only
> price \(q_H=.637358\) supports a pure knockout-only PBE with positive
> waiting mass satisfying every criterion-D1 condition in the
> contingent-plan representation.  In general, writing
> \(b_K^0=\min\{\bar b,w^{-1}(q_H+\kappa)\}\) for the highest feasible
> wait--knockout marginal value, a knockout-only PBE survives criterion D1
> if and only if \(q_H\leq C_H(b_K^0)\) and
> \(d_{S,L}-d_{S,H}\leq C_H(b_K^0)-q_H+\pi\kappa/(1-\pi)\): the exclusion
> returns exactly when the urgency gap exceeds the top feasible marginal
> type's continuation premium plus the screening slack.  [Appendix/audit
> reference: notes/176, code/audit_urgency_only_knockout_only_d1.py.]

If a formal proposition is preferred, T3.4--T3.5 above are proposition-ready
(the survival direction and the failure direction are both complete proofs
under the urgency-only reduced form plus the maintained regularity of
`ass:ordering`); the numerical instance then plays the role the fallback
counterexample plays in `app:boundarycompleteness`.

## T4. Sorting and inference under urgency-only

**Sorting.**  With common \(w\):
\[
D_L(b;q_L)=q_L-w(b)+\frac{\kappa}{1-\pi},
\qquad
\frac{\partial D_L}{\partial b}=-w'(b)<0 :
\]
the attempt cutoff is strictly decreasing, so attempts select high match
values exactly as in the baseline (eq:attemptordering) — the seller still
learns about \(b\), and hence about its rejection value, from the fact of an
attempt.  The probing-vs-knockout gap collapses to a constant:
\[
Z(b;q)=q_H-q_L-\pi\bigl[w_H(b)-w_L(b)\bigr]-\frac{\pi\kappa}{1-\pi}
=q_H-q_L-\frac{\pi\kappa}{1-\pi},
\]
so \(D_H(b)-D_L(b)=Z/\pi\) is constant in \(b\): the probing region is a
band of **constant urgency-width** above the attempt boundary.  Example
check: \((q_H-q_L)/\pi-\kappa/(1-\pi)=.093902289\), matching the audit's
"positive constant cutoff gap".  Both cutoffs shift with the same slope
\(-w'(b)\), so
\(\partial\Pr(p=q_L\mid b)/\partial b
=w'(b)\,[g(D_L(b))-g(D_H(b))]\): zero under uniform urgency (the knife-edge
of eq:uniformselection), strictly positive under any strictly decreasing
urgency density such as the Example's truncated exponential — under
urgency-only, higher-value buyers are (weakly) *more* likely to probe,
whereas demand/aligned variation pushes this derivative negative.

**Inference.**  An attempt moves the seller's posterior toward high \(b\)
(monotone selection, as baseline).  In the reverse direction the buyer
learns nothing payoff-relevant from rejection: rejection of \(q_L\) reveals
\(s=H\) (patient), but \(u_s(b)=\mathbb E[(b-\max\{v,Y_{1N}\})^+]\) is
state-invariant under urgency-only, so the revealed state does not enter the
rejected buyer's continuation payoff, its optimal bid (truthful regardless),
or its no-sale odds.  (Caveat, per sec:microcompare's footnote: patience
becomes payoff-relevant again under the continued-bargaining extension,
through the negotiation channel rather than the auction.)

**Empirical fingerprints.**
1. Acceptance/rejection should correlate with observable *seller-urgency
   proxies* (bridge financing, completed onward purchase, short chosen
   settlement dates, listing-timing pressure) and not with pre-offer demand
   indicators, conditional on price and observables — the mirror image of
   the aligned prediction 1 in sec:predictions.
2. Conditional on an attempt occurring and on observables, the subsequent
   bid log after a rejection should be statistically indistinguishable from
   the bid log after no attempt: same participation distribution, same price
   distribution.  This is a sharp *null* that discriminates urgency-only
   from demand/aligned (where rejection predicts stronger participation —
   manuscript prediction 3) and from fallback-only (where rejection predicts
   higher no-sale/withdrawal hazard).  sec:microcompare's fingerprint
   paragraph states exactly this triple; verified.
3. Attempt incidence rising in proxies for match value transfers unchanged;
   the probing share of attempts is flat in those proxies under uniform
   urgency and rising under decreasing urgency density (formula above) —
   a finer, distribution-sensitive fingerprint peculiar to urgency-only.

## T5. Public-state benchmark

`prop:disclosure` part (iii): with the state publicly observed before the
buyer acts and \(\kappa>0\), every on-path submitted offer is accepted in
any pure-strategy PBE.  The appendix proof (app:disclosure) is one
sentence: "With public \(s\), a surely rejected offer is dominated by
waiting."  Its ingredients are exactly: (a) \(s\) public and seller
strategies pure, so the buyer knows, for each price, whether it will be
accepted; (b) rejection leads to the same terminal auction as waiting; (c)
\(\kappa>0\), so a knowingly rejected offer nets \(-\kappa<0\) relative to
waiting.  **No demand-only structure is used** — the argument never touches
\(Q_s\), \(v_s\), \(w_s\), or \(\Delta w\) — so the benchmark is fully
general across microfoundations: with a publicly known urgent/patient
seller, rejected attempts vanish in every pure-strategy PBE, and the
state-\(s\) pooling fixed points \(\widehat q_s\) of parts (i)--(ii) apply
with \(\widehat D_s(b;q)=q-w(b)+\kappa\) and entry boundary
\(\bar D_s^{\mathrm{FD}}=\kappa-z_s\).  The *policy* wrapper differs:
committed disclosure of urgency is not implementable by certification
(urgency has no verifiable record), which is why sec:microcompare correctly
scopes the disclosure analysis to demand.  The benchmark statement itself —
private seller information is the sole source of on-path rejections —
survives verbatim under urgency-only.

## Claim ledger

**Proved analytically here (or transferred with citation):** T1 clause
checks and the harmlessness of the wedge-clause restatement (uses of the
clause enumerated: \(\Xi_L\) monotonicity in app:probingregime;
`cor:stategains` generalization); T2 formulas and the equivalences with
eq:auctionentrythresholds/eq:entrygap/eq:topknockoutcutoff; note 114
§§2--4 reduced-form transfer applied to urgency-only (\(\Delta w\equiv0\)
weakly increasing; note 114 eqs. (3), (6)); the scalar-\(\rho\) reduction
(note 133 §4); the tied-curve characterization; the exact knockout-only D1
gate, both directions (T3.4, T3.5); \(R'\leq w'\) and hence the
class-level monotonicity \(\psi'\geq0\); the T4 sorting formulas; the T5
generality claim.

**Verified numerically** (composite Simpson, 131,072 endpoint-inclusive
panels; bisection tolerance \(10^{-15}\); fixed-point residuals
\(\leq2.2\times10^{-16}\); machinery validated against the manuscript's
independently reproduced Example to all displayed digits; sup-gain grid
checks on \(1601^2\) types consistent with the analytic sups to grid
resolution): \(q^\ast=0.637358061052\) and all Part B/C/D/E quantities in
T3.6--T3.8, including gate margins \(0.003043582\) and \(0.013043582\), the
failure demonstrations at \(z_U\in\{.025,.03,.05\}\), the price bands, the
\(z_P=.005\) row, and the \(\kappa=.05\) full-rejection variant.  These are
tight numerical brackets, not interval-arithmetic certificates; every
strategic margin used is strict except the intended boundary equalities.

**Conjectured:** nothing load-bearing.  (The statement that *every* price in
\([q^\ast,q^{\max}]\) is a PBE relies on the sampled positivity of
\(q-T_K(q)\) at five interior points plus continuity; the gate itself at any
given price is analytic.)

**Outside scope** (mirroring note 114 §9): seller mixing; all-knockout
assessments with zero waiting mass; crossings of urgency with demand or
fallback states (the manuscript's four-type ladder discussion covers the
architecture); general-\((F,Q)\) numerical instances beyond the computed
uniform/\(n=2\) calibration — the gate derivation itself is general under
the urgency-only reduced form and `ass:ordering`.

## Reproduction

`python code/audit_urgency_only_knockout_only_d1.py` — deterministic,
standard library only, runs in a few minutes; Part A validates the
integration machinery against Example `prop:sellerurgencystate`, Parts B--D
produce every number in T3.6--T3.8, Part E the \(\kappa=.05\) variant.
