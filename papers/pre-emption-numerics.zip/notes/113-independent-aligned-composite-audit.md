---
type: independent-theory-audit
status: aligned-composite-certificates-and-refinement-transfer-verified
last_updated: 2026-07-22
active_manuscript: ../manuscripts/Manuscript.tex
audited_note: 112-aligned-composite-calibration.md
audited_code: ../code/audit_aligned_composite_calibration.py
related_notes:
  - 107-combined-market-interest-and-retention-state.md
  - 109-information-structure-baseline-audit.md
  - 110-four-state-and-composite-state-screening.md
  - 111-private-no-sale-information-and-terminal-bidding.md
---

# Independent audit of the aligned composite-state calibration

## 1. Verdict

The two preferred certificates in Note 112 pass an independent audit.  For
the aligned binary state

\[
(n_L,v_L)=(2,.38),\qquad (n_H,v_H)=(3,.42),
\]

the displayed probing-only root and the displayed globally interior
full-menu root were reproduced with a separate composite-Simpson
implementation.  The reproduction did not import the candidate solver.  It
used 65,536 panels for the fixed-point and posterior calculations, explicit
checks at \(0,v_L,v_H,1\), and a separate 32,768-panel calculation at 401
points on each price-box face.  The candidate script was also run from its
default entry point after the preferred rows were finalized; it returned
eight probing certificates, eight full-menu certificates, twelve strict
nearby full-menu roots, and the two preferred certificates reported in Note
112.

No algebraic error, missed support endpoint, profitable inactive knockout
deviation, seller-response reversal, or refinement defect was found.  The
lower plateau in \(\Delta w\) is genuine and makes its numerical monotonicity
margin zero; it is not a failed monotonicity check.  The plateau is aligned
with a flat segment of \(C_H\), which is exactly what preserves the pure
knockout-only D1 exclusion.

The price box is an analytic continuum reduction followed by strict numerical
corner checks.  It is strong numerical evidence for the conditional
Poincare--Miranda theorem, independently reproduced here, but it is not an
interval-arithmetic computer-assisted proof.  Note 112 states that limitation
correctly.

## 2. Auction algebra

Let \(n\) be the number of late buyers, let \(v\) be the committed terminal
standing value, and let all match values be independent uniform draws on
\([0,1]\).  Direct integration gives

\[
w_{n,v}(b)
=b-\mathbf 1\{b>v\}\int_v^b t^n\,dt
=b-\frac{(b^{n+1}-v^{n+1})_+}{n+1}.
\tag{1}
\]

The seller's gross terminal payoff is

\[
R_{n,v}(b)=
\begin{cases}
\dfrac{n-1}{n+1}+v^n-\dfrac{n-1}{n+1}v^{n+1},&b\leq v,\\[2mm]
\dfrac{n-1}{n+1}+b^n-\dfrac{n}{n+1}b^{n+1}
+\dfrac{v^{n+1}}{n+1},&b>v.
\end{cases}
\tag{2}
\]

Hence \(C_{n,v}=R_{n,v}-d_S\), and the competitive wedge is

\[
\Gamma_{n,v}(b)=R_{n,v}(b)-w_{n,v}(b)
=
\begin{cases}
R_{n,v}(0)-b,&b\leq v,\\[1mm]
\dfrac{n-1}{n+1}+b^n-\dfrac{n-1}{n+1}b^{n+1}-b,&b>v.
\end{cases}
\tag{3}
\]

In particular, \(R_{n,v}(1)=w_{n,v}(1)\).  The terminal no-sale event is that
the early buyer and all \(n\) late buyers have values below \(v\), so its
pre-selection probability is \(v^{n+1}\).

Under \(n_H>n_L\) and \(v_H\geq v_L\), coupling the additional late buyers
and the higher standing value gives

\[
C_H(b)>C_L(b),\qquad w_H(b)\geq w_L(b),\qquad
\Gamma_H(b)\geq\Gamma_L(b).
\tag{4}
\]

The willingness difference has the two-kink form reported in Note 112.  Its
derivative away from the kinks is

\[
\Delta w'(b)=
\begin{cases}
0,&b<v_L,\\
b^{n_L},&v_L<b<v_H,\\
b^{n_L}-b^{n_H},&b>v_H.
\end{cases}
\tag{5}
\]

It is therefore weakly increasing everywhere and strictly increasing above
\(v_L\).  Direct evaluation of (1) and the piecewise expression agrees to
\(1.81\times10^{-16}\), including both kinks and both support endpoints.

At \(b=1\), writing \(A=1-\pi\), the probing-window thresholds simplify to

\[
\bar D_L=-d_S+\frac{\kappa}{A},\qquad
\bar D_H=A\Delta w(1)-d_S+\kappa,
\tag{6}
\]

\[
\Delta_D=A\Delta w(1)-\frac{\pi\kappa}{A}.
\tag{7}
\]

These identities reproduce the threshold calculations in the candidate
script.

## 3. Probing-only certificate

For \(\kappa=.02\), \(\bar d=.045\), \(\pi=1/2\), \(d_S=.01\), and urgency
rate 10, the independently evaluated root is

\[
q_L=.6713880405168651.
\]

The separate integration produced the following checks:

| quantity | independent value | Note 112 value |
|---|---:|---:|
| \(T_L(C_L(0))-C_L(0)\) | \(.160696745803\) | \(.160696745823\) |
| \(T_L(C_L(1))-C_L(1)\) | \(-.002900954650\) | \(-.002900954659\) |
| \(T_L(q_L)-q_L\) | \(-2.19\times10^{-11}\) | \(2.22\times10^{-16}\) in absolute value |
| probe mass | \(.032574485102\) | \(.032574485052\) |
| \(E[C_H\mid q_L]-q_L\) | \(.071341453834\) | \(.071341453864\) |
| \(C_L(1)-q_L\) | \(.003569292816\) | \(.003569292816\) |

The small difference in integration residuals is explained by the independent
method not splitting every Simpson panel at every endogenous crossing.  It is
many orders of magnitude below every strict economic margin.

The primitive thresholds are

\[
(\bar D_L,\bar D_H,\Delta_D,
\bar D_L+\Delta_D/\pi)
=(.03,.046410953333,.016410953333,.062821906667).
\]

Thus the primitive probing window is strict.  The additional left-endpoint
condition is also strict:

\[
C_L(0)-w_L(0)+\frac{\kappa}{A}=.489442667>0.
\]

The wait--probe cutoff is checked at both endpoints.  It equals
\(.711388041\) at \(b=0\) and \(.026430707\) at \(b=1\); the positive probing
mass begins at \(b=.860446282\).

### Inactive knockout deviations

The least costly both-state-acceptance deviation under the supporting
top-type belief is priced at \(C_H(1)\).  Its gain relative to the better of
waiting and probing is maximized at \((b,d)=(1,.045)\).  Exact endpoint
evaluation gives

\[
\max_{b,d}\{V_K(b,d)-\max[0,V_P(b,d)]\}
=-.010695599742.
\]

An independent grid over 4,001 buyer values, with urgency evaluated at
\(0,\bar d\), the action cutoff, and its two adjacent sides, found the same
maximizer and value.  Higher both-state prices are still less attractive.
Offers rejected in both states are dominated by no early offer.  Together
with the positive \(H\)-rejection margin and the boundary-pricing equality for
\(L\), these checks exhaust the inactive pure acceptance profiles.

The independently reproduced outcome probabilities are

\[
(\Pr(\text{no early offer}),\Pr(\text{rejection}),
\Pr(\text{success}))
=(.967425515,.016287243,.016287243).
\]

The pre-selection no-sale probabilities are
\((.38^3,.42^4)=(.054872,.03111696)\).  Every buyer below \(v_L\) waits, and
every \(H\)-state probe reaches the terminal auction, so these probabilities
are unchanged in this probing calibration.

## 4. Full-menu certificate

For \(\kappa=.05\) and \(\bar d=1\), the preferred root is

\[
(q_L,q_H)=(.609677720962387,.705343970180778).
\]

The independent fixed-point residuals are

\[
(4.35\times10^{-12},-1.22\times10^{-12}),
\]

compared with \((-1.21\times10^{-14},-1.11\times10^{-15})\) under the
candidate's kink-split Gauss rules.  The independent action masses are

\[
(M_0,M_L,M_H)
=(.765415357754,.067872418840,.166712223407),
\]

and imply

\[
(\Pr(\text{no early offer}),\Pr(\text{rejection}),
\Pr(\text{success}))
=(.765415357754,.033936209420,.200648432827).
\]

The two seller-response slacks independently reproduce as

\[
E[C_H\mid q_L]-q_L=.065659595341,
\]

\[
q_H-E[C_L\mid q_H]=.066483642830.
\]

The endpoint ranges are

\[
D_L\in[.024720388,.709677721],\qquad
D_A\in[.033975684,.755343970],
\]

\[
D_H\in[.043230979,.801010219],qquad
\min_b Z(b)=.009255295885.
\]

Consequently \(0<D_L<D_H<\bar d\) for every \(b\), and all three actions
have positive mass.  A 4,001-point value grid evaluated buyer payoffs at
\(d=0,\bar d,D_L(b),D_H(b)\) and on both sides of each cutoff.  The largest
gain from departing from the prescribed action was
\(5.6\times10^{-17}\), numerical zero.  The two D1 rejection margins are

\[
C_L(1)-q_L=.065279612371,qquad
C_H(1)-q_H=.042435269819.
\]

### Independent price-box check

For the half-widths \((.004,.004)\), the independent calculation gives the
three global-interiority margins

\[
(.020720387629,.186989780601,.001255295885).
\]

The four face minima, computed with 32,768 Simpson panels and 401 points per
face, are

\[
(.004000000010,.003999999990,
.003997164766,.003996803069).
\]

They agree with Note 112 and occur at the four corners identified there.
The corner reduction is analytic.  Under global interiority, write
\(K=1-e^{-\lambda\bar d}\).  At fixed \(q_L\), the probing weight has the
form

\[
m_L(b)=\frac{a e^{\lambda w_L(b)}-c e^{\lambda w_H(b)}}{K}.
\]

Raising \(q_H\) lowers \(c\) and adds weight proportional to
\(e^{\lambda w_H(b)}\).  The ratio of this added weight to existing probe
weight is proportional to

\[
\frac{1}{a e^{-\lambda\Delta w(b)}-c},
\]

which is weakly increasing in \(b\).  Since \(C_L\) increases, \(T_L\) is
weakly increasing in \(q_H\).  At fixed \(q_H\), the knockout weight is

\[
m_H(b)=\frac{c e^{\lambda w_H(b)}-e^{-\lambda\bar d}}{K}.
\]

Raising \(q_L\) raises \(c\) and again adds weight proportional to
\(e^{\lambda w_H(b)}\), but its ratio to existing knockout weight is
proportional to

\[
\frac{1}{c-e^{-\lambda\bar d}e^{-\lambda w_H(b)}},
\]

which is weakly decreasing in \(b\).  Hence \(T_H\) is weakly decreasing in
\(q_L\).  The continuum face minima therefore equal the relevant corner
values; the dense face grid is a redundant diagnostic rather than the logical
basis for the reduction.

The independently computed equilibrium no-sale probabilities are

\[
(.054352108415,.030956751169),
\]

with prior-weighted probability \(.042654429792\), matching Note 112.

## 5. Refinement plateau

The only new wrinkle relative to a common public standing value is the flat
part of \(\Delta w\) below \(v_L\).  It does not invalidate either displayed
equilibrium's D1 completion.  In the globally interior full menu, the
top-marginal types remain D1-permitted because \(\Delta w\) is weakly
increasing; the strict displayed price slacks make the relevant seller reject
each undercut.  In the probing-only equilibrium, the highest feasible
wait--probe marginal is \(b=1\), and \(q_L<C_L(1)\).

The plateau also preserves the pure knockout-only exclusion.  Let \(\beta_K\)
be the lowest feasible wait--knockout marginal value.  If
\(\beta_K>v_L\), \(\Delta w\) is strictly increasing and the usual
lowest-marginal-type D1 argument applies.  If \(\beta_K\leq v_L\), D1 can
retain a set of tied marginal types contained in the lower plateau rather
than a singleton.  But \(C_H\) is constant on the larger interval
\([0,v_H]\), so every posterior supported on that D1 plateau gives the same
\(H\)-continuation value.

Positive knockout mass and monotone buyer selection place positive on-path
weight on values above \(v_H\), where \(C_H\) strictly increases.  Seller
\(H\)'s on-path sequential rationality therefore implies

\[
q_H\geq E[C_H(b)\mid q_H]>C_H(\beta_K).
\]

If \(q_H>C_H(1)\), an undercut above \(C_H(1)\) is already a profitable
belief-proof PBE deviation.  Otherwise an undercut sufficiently close to
\(q_H\) lies in the continuation-value range, is accepted under every
posterior supported on the permitted plateau, and benefits its marginal
buyers.  Thus every nondegenerate pure knockout-only PBE in the maintained
class fails the strict-gain interim-D1 test; boundary pricing is not needed.
The conclusion remains conditional on positive waiting and knockout mass,
\(\kappa>0\), and nested seller responses.  It does not classify mixed
seller acceptance or an all-knockout assessment.

## 6. Claim ledger

**Verified analytically:** equations (1)--(7); statewise ordering; the
two-kink shape and endpoint identities; the probing primitive window; the
top-endpoint inactive-knockout maximization; global full-menu cutoff logic;
the price-box corner reduction; probing and globally interior full-menu D1
transfer; and the aligned-plateau repair of global nondegenerate pure
knockout-only D1 exclusion without boundary pricing.

**Independently reproduced numerically:** both preferred fixed points; scalar
root signs; all displayed action masses and outcome probabilities; posterior
seller inequalities; no-sale probabilities; support and cutoff endpoints;
the full-menu buyer best responses; global-interiority margins; and all four
price-box face signs.

**Rerun, but not independently re-solved row by row:** the candidate script's
finite search counts of eight probing certificates, eight full-menu
certificates, and twelve nearby strict full-menu roots.

**Not established:** interval-arithmetic bounds; uniqueness; mixed seller
responses; richer signaling schedules; incentive-compatible revelation of
the hidden standing value; or a sequential microfoundation in which the
seller learns a future no-sale payoff only after the early-offer stage.
