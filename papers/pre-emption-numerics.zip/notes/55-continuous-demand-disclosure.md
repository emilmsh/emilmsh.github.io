---
type: theory-derivation
status: reserve-no-sale-disclosure-pbe-and-welfare-audited
last_updated: 2026-07-22
active_manuscript: ../manuscripts/Manuscript.tex
code: ../code/verify_continuous_demand_disclosure.py
---

# Demand disclosure with a public reserve and possible no sale

## 1. Result

Full disclosure of the seller's demand state separates the offer problem into
two state-specific one-dimensional screening problems. The result extends to
the reserve-price baseline: the planned auction has public reserve \(\ell\),
the seller retains a dwelling worth \(\ell\) if no buyer clears the reserve,
and private early prices may lie below \(\ell\). In each disclosed state, an
exact threshold determines whether no-early-offer behavior can be sustained.
Once the threshold is crossed, a positive-mass pooling equilibrium exists: the
buyer waits below a cutoff and offers one state-specific price above it. Every
on-path attempt is accepted.

Disclosure therefore eliminates failed attempts in the maintained
pure-strategy one-offer game with a positive attempt cost and acceptance at
equality. It does not necessarily reduce pre-emption. Removing acceptance
risk can increase completed early sales and the exclusion of late buyers.

The pooling equilibrium is a PBE existence result. Interim D1 permits its
supporting undercut beliefs under an additional boundary condition, but not
for every primitive configuration. Neither PBE nor interim D1 establishes
uniqueness.

## 2. State-specific disclosed problem

Let the demand state \(s\in\{L,H\}\) be public before the buyer acts. Retain
the continuous and independent buyer type

\[
(b,d)\sim F\times G
\quad\text{on}\quad
[\underline b,\bar b]\times[0,\bar d].
\]

Let \(Y_{1s}\geq Y_{2s}\) be the two highest late values. With the public
reserve and retention value \(\ell\), define

\[
w_s^\ell(b)
=\mathbb E_s[\min\{b,\max\{\ell,Y_{1s}\}\}],
\]

\[
C_s^\ell(b)
=\mathbb E_s[\max\{\ell,Y_{2s},\min\{b,Y_{1s}\}\}]-d_S.
\]

Thus \(w_s^\ell(b)=b\) and \(C_s^\ell(b)\) is flat when
\(b\leq\ell\). Before the early buyer's value is observed, the no-sale
probability in state \(s\) is \(F(\ell)^{n_s+1}\). Above the reserve the
objects retain the strict monotonicity used by the equilibrium construction.

Conditional on state \(s\), an accepted price \(q\) gives the buyer
incremental payoff

\[
w_s^\ell(b)+d-q-\kappa.
\]

Define the disclosed-state offer cutoff and conditional offer mass

\[
\widehat D_s(b;q)=q-w_s^\ell(b)+\kappa,
\qquad
\widehat m_s(b;q)
=1-\widehat G(\widehat D_s(b;q)),
\]

where \(\widehat G\) extends \(G\) by zero below \(0\) and one above
\(\bar d\). Whenever

\[
\widehat M_s(q)
=\int_{\underline b}^{\bar b}\widehat m_s(b;q)f(b)\,db
>0,
\]

Bayes' rule gives the posterior density among offerers,

\[
\widehat h_s(b;q)
=
\frac{\widehat m_s(b;q)f(b)}
     {\widehat M_s(q)}.
\]

The minimum pooling price accepted by seller \(s\) is its posterior
continuation value. Hence define

\[
\widehat T_s(q)
=
\int_{\underline b}^{\bar b}
C_s^\ell(b)\widehat h_s(b;q)\,db.
\tag{1}
\]

An active disclosed-state pooling price is a fixed point
\(\widehat q_s=\widehat T_s(\widehat q_s)\).

## 3. Exact statewise no-early-offer boundary and active pooling

Define

\[
\overline D_s^{\,F,\ell}
=C_s^\ell(\bar b)-w_s^\ell(\bar b)+\kappa.
\tag{2}
\]

### Proposition 1. Disclosed-state entry

Fix a disclosed state \(s\) and suppose the maintained monotonicity and
state-ordering assumptions of the manuscript hold.

1. A no-early-offer PBE exists in state \(s\) if and only if

   \[
   \bar d\leq\overline D_s^{\,F,\ell}.
   \tag{3}
   \]

   It has an interim-D1-compatible completion.

2. If

   \[
   \bar d>\overline D_s^{\,F,\ell},
   \tag{4}
   \]

   then no no-early-offer PBE exists in state \(s\), and (1) has a fixed point

   \[
   \widehat q_s
   \in(C_s^\ell(\underline b),C_s^\ell(\bar b)).
   \tag{5}
   \]

   The following assessment is a PBE:

   \[
   p_s(b,d)=
   \begin{cases}
   \varnothing,
     &d<\widehat D_s(b;\widehat q_s),\\
   \widehat q_s,
     &d\geq\widehat D_s(b;\widehat q_s).
   \end{cases}
   \tag{6}
   \]

   The seller accepts \(\widehat q_s\), uses Bayes' rule on path, and assigns
   every other submitted price to \(b=\bar b\).

3. If, in addition,

   \[
   C_s^\ell(\underline b)-w_s^\ell(\underline b)+\kappa\geq0,
   \tag{7}
   \]

   both waiting and offering have positive probability in the active pooling
   equilibrium.

#### Proof

Under no-early-offer behavior, the cheapest offer that is accepted under every
posterior is \(C_s^\ell(\bar b)\). Its payoff is

\[
w_s^\ell(b)+d-C_s^\ell(\bar b)-\kappa,
\]

which is increasing in \(b\) and \(d\). It is nonpositive for every type if
and only if it is nonpositive at \((\bar b,\bar d)\), giving (3). When (3)
holds, assign off-path offers to \((\bar b,\bar d)\). Prices below
\(C_s^\ell(\bar b)\) are rejected, while higher prices cannot improve upon the
cheapest accepted deviation. The highest type has the weakest strict-gain
requirement, so the same posterior is permitted by interim D1. If (3) fails,
the offer \(C_s^\ell(\bar b)\) strictly benefits types near
\((\bar b,\bar d)\) under every posterior, ruling out no-early-offer PBE.

Now impose (4). On
\([C_s^\ell(\underline b),C_s^\ell(\bar b)]\), positive offer mass at the upper
endpoint follows from

\[
\widehat D_s(\bar b;C_s^\ell(\bar b))
=\overline D_s^{\,F,\ell}<\bar d.
\]

It follows at every lower price as well. The map \(\widehat T_s\) is
continuous and takes values in the same interval. At the lower endpoint,
the offer pool contains a positive measure of values above \(\ell\), where
\(C_s^\ell\) is strictly increasing, so

\[
\widehat T_s(C_s^\ell(\underline b))>C_s^\ell(\underline b).
\]

At the upper endpoint, the positive-measure pool contains values strictly
below \(\bar b\), so

\[
\widehat T_s(C_s^\ell(\bar b))<C_s^\ell(\bar b).
\]

The intermediate value theorem gives (5).

At the fixed point, (6) is the buyer's optimal on-path choice and the seller
is indifferent at \(\widehat q_s\). Under the off-path posterior
\(b=\bar b\), every price below \(C_s^\ell(\bar b)\) is rejected. Every accepted
deviation costs at least \(C_s^\ell(\bar b)>\widehat q_s\). A waiting type that
benefited from such a deviation would benefit still more from the on-path
price. Hence no type deviates.

Condition (7) and
\(\widehat q_s>C_s^\ell(\underline b)\) imply
\(\widehat D_s(\underline b;\widehat q_s)>0\), giving positive waiting mass.
Condition (4) and
\(\widehat q_s<C_s^\ell(\bar b)\) imply
\(\widehat D_s(\bar b;\widehat q_s)<\bar d\), giving positive offer mass.
\(\square\)

The two states can be combined independently. In a canonical full-disclosure
equilibrium, use no-early-offer behavior in every state satisfying (3), and the
pooling assessment in every state satisfying (4). Thus disclosure can induce
offers in both states, one state, or neither state.

## 4. Failed attempts

### Proposition 2. No on-path rejection after full disclosure

Suppose \(\kappa>0\), the demand state is public before the buyer acts, and the
seller follows the maintained rule of accepting at equality. In any
pure-strategy PBE, an on-path submitted offer is accepted. Hence

\[
\Pr_F(O\setminus A)=0.
\tag{8}
\]

#### Proof

Once \(s\) is public, the buyer knows the seller's response to every price. A
surely rejected offer produces \(-\kappa\), while no offer produces zero.
Therefore no positive-measure buyer type submits a price that is rejected on
path. \(\square\)

The positive-cost condition gives strict dominance. If seller mixing at
indifference were allowed instead of the maintained acceptance convention,
rejection could reappear as equilibrium randomization rather than
state-screening. That is outside the baseline assessment.

## 5. Interim D1

Suppose \(\kappa>0\). The positive pooling PBE is not automatically interim-D1 compatible. For an
undercut \(p<\widehat q_s\), let \(x\) be the seller's acceptance probability.
A type \((b,d)\) requires

\[
r_{b,d}(p)
=
\frac{\widehat U_s^*(b,d)+\kappa}
     {w_s^\ell(b)+d-p},
\qquad
\widehat U_s^*(b,d)
=\max\{0,w_s^\ell(b)+d-\widehat q_s-\kappa\},
\tag{9}
\]

to weakly gain. Every marginal type

\[
(b,\widehat D_s(b;\widehat q_s))
\quad\text{with}\quad
0\leq\widehat D_s(b;\widehat q_s)\leq\bar d
\]

has the same threshold

\[
r^*(p)
=
\frac{\kappa}{\kappa+\widehat q_s-p}.
\tag{10}
\]

Types whose cutoffs lie above \(\bar d\) or below zero require a strictly
higher acceptance probability and are deleted by the strict-gain test.

Define the highest surviving marginal value

\[
b_s^0
=
\sup\{b:
0\leq\widehat D_s(b;\widehat q_s)\leq\bar d\}.
\tag{11}
\]

Provided the marginal set is nonempty, the pooling PBE has an interim-D1
completion for undercuts if and only if

\[
\widehat q_s\leq C_s^\ell(b_s^0).
\tag{D1-F}
\]

Necessity follows because, if
\(\widehat q_s>C_s^\ell(b_s^0)\), an undercut between these two values is accepted
under every posterior supported on D1-surviving types. Sufficiency follows by
placing belief on the highest surviving marginal type after every undercut.
The sub-reserve plateau in \(C_s^\ell\) does not change the criterion:
\(C_s^\ell\) remains nondecreasing, so the highest surviving marginal value
still maximizes the seller's continuation value.

A convenient sufficient condition is

\[
\widehat D_s(\bar b;\widehat q_s)\geq0,
\tag{12}
\]

because then \(b_s^0=\bar b\) and
\(\widehat q_s<C_s^\ell(\bar b)\). A stronger primitive sufficient condition is

\[
C_s^\ell(\underline b)-w_s^\ell(\bar b)+\kappa\geq0.
\tag{13}
\]

The distinction matters. The numerical grid audit below finds active pooling
PBEs that fail (D1-F) when high-\(b\) buyers offer even at zero urgency. Full
disclosure removes state-contingent rejection at the PBE level, but interim D1
does not support the single-price pooling construction for all primitives.

## 6. Incidence relative to private demand information

In a disclosed state with active pooling, define

\[
\widehat M_s
=
\int
\left[1-\widehat G(\widehat D_s(b;\widehat q_s))\right]
f(b)\,db.
\tag{14}
\]

Then

\[
\Pr_F(O)=\Pr_F(A)
=(1-\pi)\widehat M_L+\pi\widehat M_H,
\qquad
\Pr_F(O\setminus A)=0,
\tag{15}
\]

where \(\widehat M_s=0\) in a state assigned no-early-offer behavior.

For comparison, suppose the private-information baseline has the active
two-price equilibrium \((q_L,q_H)\). In state \(L\), every attempt is
accepted and the private acceptance cutoff is

\[
D_L^\ell(b)=q_L-w_L^\ell(b)+\frac{\kappa}{1-\pi}.
\]

In state \(H\), only knockout offers are accepted and the cutoff is

\[
D_H^\ell(b)=\frac{q_H-(1-\pi)q_L}{\pi}-w_H^\ell(b).
\]

The disclosed-minus-private cutoff shifts are independent of \(b\):

\[
\widehat D_L(b)-D_L^\ell(b)
=
\widehat q_L-q_L-\frac{\pi}{1-\pi}\kappa,
\tag{16}
\]

\[
\widehat D_H(b)-D_H^\ell(b)
=
\widehat q_H+\kappa
-\frac{q_H-(1-\pi)q_L}{\pi}.
\tag{17}
\]

Therefore disclosure expands completed pre-emption in state \(L\) if the
right-hand side of (16) is negative, and in state \(H\) if the right-hand side
of (17) is negative, with the inequalities reversed for contraction. These
conditions compare the endogenous price change with the removal of
acceptance risk. They do not imply a general incidence ranking.

## 7. Incidence and welfare decomposition

The fixed-point condition gives the seller zero expected gain relative to the
auction within each disclosed-state offer pool:

\[
\int
\widehat m_s(b;\widehat q_s)
\left[\widehat q_s-C_s^\ell(b)\right]
f(b)\,db
=0.
\tag{18}
\]

Thus the seller's ex ante payoff in the canonical disclosure equilibrium
equals its auction payoff. Relative to the private two-price equilibrium, the
seller loses the weak-state rent on knockout offers:

\[
U_S^F-U_S^D
=
-(1-\pi)M_H
\int
[C_H^\ell(b)-C_L^\ell(b)]h_H(b)\,db
\leq0.
\tag{19}
\]

The inequality is strict when knockout offers occur. In a private probing-only
equilibrium, \(M_H=0\) and the seller is indifferent on average under both
information regimes.

The early buyer's disclosed-state gain relative to the auction is

\[
U_E^F-U_E^B
=
\sum_s\Pr(s)
\int f(b)
\int_{\widehat D_s(b)}^{\bar d}
[d-\widehat D_s(b)]\,dG(d)\,db
\geq0.
\tag{20}
\]

Its gain relative to the private-information equilibrium is not signed,
because disclosure changes both information and equilibrium prices.

Let

\[
\Lambda_s^\ell(b)
=
\mathbb E_s[
(Y_{1s}-\max\{\ell,b,Y_{2s}\})^+
]
\]

be late-buyer surplus in the auction. Disclosure changes late-buyer payoff
relative to the auction by

\[
U_{\mathrm{late}}^F-U_{\mathrm{late}}^B
=
-\sum_s\Pr(s)
\int \widehat m_s(b;\widehat q_s)
\Lambda_s^\ell(b)f(b)\,db.
\tag{21}
\]

For an exact total-surplus comparison, let

\[
L_s^\ell(b)
=(\ell-b)^+
+\mathbb E_s[(Y_{1s}-\max\{b,\ell\})^+]
\]

be the auction's expected allocative gain and let
\(\kappa^R\in[0,\kappa]\) be the resource component of the attempt cost.
Couple the private and disclosed regimes on the same realization of
\((b,d,s)\), and write \(A_r,O_r\) for acceptance and offer under regime
\(r\in\{D,F\}\). Because \(O_F=A_F\),

\[
\boxed{
W^F-W^D
=
\kappa^R\Pr_D(O_D\setminus A_D)
+
\mathbb E\!\left[
(A_F-A_D)
\{d+d_S-L_s^\ell(b)-\kappa^R\}
\right].
}
\tag{22}
\]

The first term is the resource cost saved by eliminating failed private-state
attempts. The second term values the early allocations added or removed by
disclosure. Disclosure can increase or reduce welfare: eliminating rejection
costs need not offset the surplus lost when additional late buyers are
excluded.

## 8. Continuous calibration and numerical audit

The calculations are reproduced by
`code/verify_continuous_demand_disclosure.py`. Under the manuscript's
continuous calibration with \(F=U[0,1]\), \(\ell=0.4\),
\((n_L,n_H)=(2,7)\), \(\pi=1/2\), \(d_S=0.01\), and
\((\kappa,\bar d,\lambda)=(0.12,1.2,10)\), the no-sale probabilities are
\(0.064\) in \(L\) and \(0.00065536\) in \(H\). The private-demand menu is

\[
(q_L,q_H)=(0.609031542,0.829183938),
\]

while the disclosed-state prices are

\[
\widehat q_L=0.633695436,
\qquad
\widehat q_H=0.829176789.
\]

The conditional disclosed-state offer masses are

\[
\widehat M_L=0.155658948,
\qquad
\widehat M_H=0.090236869.
\]

The incidence comparison is

\[
\begin{array}{l|cc}
&\text{private demand}&\text{full disclosure}\\
\hline
\Pr(\text{attempt})&0.059993929&0.122947908\\
\Pr(\text{completed pre-emption})&0.046566705&0.122947908\\
\Pr(\text{rejected attempt})&0.013427225&0
\end{array}
\]

and the payoff changes relative to the auction benchmark are

\[
\begin{array}{l|rr}
&\text{private demand}&\text{full disclosure}\\
\hline
\text{seller}&0.002907851&0\\
\text{early buyer}&0.004652310&0.012289830\\
\text{late buyers}&-0.001923648&-0.005068184\\
\text{total surplus}&0.005636513&0.007221645
\end{array}
\]

when the full attempt cost is treated as a resource cost. In this calibration,
disclosure roughly doubles attempt incidence, eliminates rejection, transfers
the seller's information rent, and raises total surplus. These signs are
calibration-specific.

The value integrals are split at \(\ell\) and at every endogenous urgency
cutoff, including thin entry regions. The primitive audit covers 105
configurations and 162 active state problems.
It finds a pooling fixed point in every active problem. Of the 162 fixed
points, 129 satisfy (D1-F), while 33 fail it. No multiple fixed point appears
on this grid, but the theory does not establish uniqueness.

## 9. Integration-ready claims and limitations

The following claims are ready for a concise manuscript extension:

1. Full verifiable disclosure yields an exact statewise no-early-offer
   boundary, (3).
2. When entry occurs, a one-price disclosed-state pooling PBE exists.
3. With \(\kappa>0\) and the maintained acceptance convention, every on-path
   attempt is accepted; rational failed probing disappears.
4. Disclosure can increase or decrease completed pre-emption, with exact
   cutoff comparisons (16)--(17).
5. The canonical pooling equilibrium removes the seller's cross-state
   information rent, while the welfare effect is ambiguous by (22).

The remaining limitations are substantive:

1. The pooling PBE is not unique; accepted price menus that signal \(b\) have
   not been ruled out.
2. Interim-D1 survival requires (D1-F) and fails in part of the active region.
3. The seller-payoff ranking is conditional on the boundary-price pooling
   equilibrium.
4. Disclosure is verifiable and imposed. Voluntary or manipulable disclosure
   requires a separate reporting game.
5. No monotone Blackwell comparison is claimed for partial disclosure.
