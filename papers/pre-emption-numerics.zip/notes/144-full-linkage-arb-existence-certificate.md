---
type: computer-assisted-proof
status: interval-certified-existence-and-interim-D1-survival
last_updated: 2026-07-25
active_manuscript: ../manuscripts/Manuscript.tex
---

# Full-linkage terminal counteroffers: Arb existence certificate

## Status and scope

This note upgrades the full-linkage probing-only assessment in Notes 141 and
143 from a floating-point fixed-point audit to a computer-assisted existence
proof.  Outward-rounded Arb arithmetic certifies an exact root of the three
simultaneous equilibrium equations.  The same program proves that both
action-selected terminal reserves are global optima, encloses the strict
on-path PBE margins, and verifies the strict numerical endpoint inequalities
used by the analytical interim-D1 proof in Note 143.

The protocol is unchanged:

1. the terminal seller perfectly recalls the identified early buyer's
   wait/probe action;
2. a continuous English clock reveals the last losing dropout but not the
   winner's unexercised value;
3. the seller may make at most one terminal counteroffer;
4. the winner may accept or reject but cannot revise its bid; and
5. the primitives are
   \[
   F=U[0,1],\quad(n_L,n_H)=(2,3),\quad v=.4,\quad
   d_S=.01,\quad\pi=.5,\quad\kappa=.01,
   \]
   with a truncated-exponential buyer-urgency distribution of rate \(10\)
   on \([0,.15]\).

The certificate is
[`../code/certify_full_linkage_counteroffer_equilibrium.py`](../code/certify_full_linkage_counteroffer_equilibrium.py).
It uses `python-flint==0.9.0` at 60 decimal digits.  Arb supplies
outward-rounded ball arithmetic and validated adaptive integration.

## 1. Continuous fixed-point equations

Let \(q\) be the probing price and let \(r_P,r_W\) be the early-winner
terminal thresholds following probing and waiting.  Write \(a(b)\) for the
probability that value \(b\) probes.  At the candidate primitives, the first
positive probing value is
\[
b_0=q+2\kappa-\bar d,
\]
and the certified ordering is
\[
.4<b_0<r_W<.7<r_P<1.
\tag{1}
\]
Above \(b_0\), the urgency cutoff lies strictly between zero and \(\bar d\).
The clipped part of the strategy therefore has the fixed piece structure used
by the program.

Instead of maximizing posterior revenue on a grid, use its interior
first-order condition.  Define
\[
\begin{aligned}
F_q(q,r_P,r_W)
&=\int_{b_0}^1
a(b)\{C_L(b;r_P)-q\}\,db,\\
F_P(q,r_P,r_W)
&=\int_{r_P}^1a(b)\,db-(r_P-v)a(r_P),\\
F_W(q,r_P,r_W)
&=\int_{r_W}^1\{1-a(b)\}\,db
 -(r_W-v)\{1-a(r_W)\}.
\end{aligned}
\tag{2}
\]
Positive probing mass makes \(F_q=0\) equivalent to the \(L\)-seller's
zero-rent price equation.  The last two equations are the posterior-revenue
first-order conditions for the probing and waiting posteriors.

Automatic differentiation is carried through every validated integral.  For
the box
\[
\begin{aligned}
X_q&=.7384064140054715464\ \mathbin{\pm}10^{-10},\\
X_P&=.7809572231735911265\ \mathbin{\pm}10^{-10},\\
X_W&=.6611403199398241447\ \mathbin{\pm}10^{-10},
\end{aligned}
\tag{3}
\]
the program constructs the Krawczyk operator
\[
K(X)=x_0-RF(x_0)+\{I-R\,DF(X)\}(X-x_0),
\tag{4}
\]
where \(R\) is an exact dyadic midpoint of the inverse numerical Jacobian.
The certified image is
\[
\begin{aligned}
K_q(X)&=.7384064140054715\ \mathbin{\pm}5.73\times10^{-17},\\
K_P(X)&=.78095722317359113\ \mathbin{\pm}9.23\times10^{-18},\\
K_W(X)&=.6611403199398241\ \mathbin{\pm}5.26\times10^{-17}.
\end{aligned}
\tag{5}
\]
Thus \(K(X)\subset\operatorname{int}X\).  The Krawczyk theorem gives an exact
root of (2), unique within \(X\).  This is local uniqueness of the root in
the displayed box, not uniqueness of PBE in the game.

## 2. Global terminal-reserve optimality

For action \(A\in\{P,W\}\), let
\[
H_A(r)=T_A(r)-(r-v)f_A(r)
\tag{6}
\]
be the derivative of the corresponding posterior-revenue objective, where
\(T_A\) is its selected upper tail and \(f_A\) its unnormalized selected
density.  Equation \(F_P=0\) is \(H_P(r_P)=0\), and \(F_W=0\) is
\(H_W(r_W)=0\).

Below \(b_0\), \(H_P\) is constant because no type probes, while
\(H_W'(r)=-2\).  On the active support the script interval-subdivides every
cutoff piece, including both one-sided formulas at \(r_W\) and \(r_P\), and
certifies
\[
H_P'(r)\leq-.3313248786,\qquad
H_W'(r)\leq-.2251168478.
\tag{7}
\]
Consequently, each revenue derivative crosses zero only once.  The two
coordinates certified in (3) are therefore the global posterior-revenue
maximizers, not merely stationary points.  The induced scalar counteroffer
rules remain sequentially optimal after every clock dropout.

## 3. On-path PBE margins

At the exact root, the outward-rounded enclosures give
\[
\begin{aligned}
M_P&\in .13460217\ \mathbin{\pm}6.07\times10^{-9},\\
C_H(P)-q&\in .02490920\ \mathbin{\pm}2.15\times10^{-9},\\
D(1)&\in .040637366\ \mathbin{\pm}4.96\times10^{-10}.
\end{aligned}
\tag{8}
\]
Hence both waiting and probing have positive mass, the \(L\)-seller is
indifferent by \(F_q=0\), the \(H\)-seller strictly rejects the probing
price, and all probing types have positive urgency.  The three outcome
probabilities are enclosed by
\[
\begin{aligned}
\Pr(\text{no early offer})&\in
.86539783\ \mathbin{\pm}6.07\times10^{-9},\\
\Pr(\text{rejection})=\Pr(\text{success})&\in
.06730109\ \mathbin{\pm}3.33\times10^{-9}.
\end{aligned}
\tag{9}
\]
The differences from Notes 141 and 143 are within their reported
midpoint-grid error.  Equations (3), (8), and (9) replace those
floating-point values for proof purposes.

## 4. Interim-D1 endpoint certificate

The continuum arguments in Note 143 are analytical.  Their numerical inputs
are now enclosed rather than point-evaluated.  The smallest relevant strict
endpoint margins include
\[
\begin{array}{c|c}
\text{inequality}&\text{certified margin}\\ \hline
q-\overline K_L(r_W)&.01073454\ \mathbin{\pm}2.61\times10^{-9}\\
\overline K_L(.678)-q&.000607146\ \mathbin{\pm}3.32\times10^{-10}\\
\min\overline\Xi(.678,x)&.003997983\ \mathbin{\pm}5.46\times10^{-10}\\
\overline K_H(.85)-p^\dagger&.002049650\ \mathbin{\pm}1.37\times10^{-10}\\
g_U(b_c;.85,x(.8),.8)&-.002644755\ \mathbin{\pm}4.79\times10^{-10}.
\end{array}
\tag{10}
\]
The equal-revenue continuations at the two interval-valued reserves use a
rigorous Lipschitz enlargement.  On \(r\in[.6,.9]\), differentiating the
equal-revenue expression and using
\[
0\leq R_s\leq1,\qquad
0\leq\partial_rR_s=r^{n_s}\leq1,\qquad
r-v\geq.2
\]
gives \(|\overline K_s'(r)|<20\).  Arb evaluates the midpoint integral and
adds \(20\) times the input radius.

For the complete irregular-policy high-price branch, the revenue-cap
argument in Note 143 reduces sender payoffs to four deterministic response
corners.  Exact linearity in urgency reduces each corner to
\(d=0,\bar d,D(b)\); interval subdivision over \(b\) then gives the rigorous
upper bounds
\[
\begin{array}{c|c}
(a_L,a_H)&\sup_\tau\{u_\tau-U^*(\tau)\}\\ \hline
(1,1)&0\quad\text{exactly at }(1,\bar d),\\
(1,0)&<-.0368285204,\\
(0,1)&<-.0326518206,\\
(0,0)&<-.0087061102.
\end{array}
\tag{11}
\]
The first equality follows algebraically from the definition of
\(p^\dagger\).  Higher prices worsen accepted trade and raise every relevant
rejection floor.  Thus the complete high-price continuation-plan argument is
preserved.

The scalar witness mixing probabilities stay strictly in \((0,1)\), the
undercut overlap statistic stays positive, and the two upper witness branches
overlap.  Combining these certified inequalities with the non-domination and
belief construction in Note 143 proves that the exact PBE in (3) admits the
same standard strict-gain interim-D1 completion.  Under the final
\(\delta_1\) belief, rejected deviations have gain at most
\(-\kappa=-.01\), while the cheapest accepted deviation has gain below
\(-.124300428\).

## Proposition and claim boundary

**Proposition (computer-assisted full-linkage existence).**  Under the
primitives and one-counteroffer protocol stated above, there exists a
probing-only PBE in the box (3).  Its action-selected terminal counteroffers
are globally and sequentially optimal.  No early offer, a rejected probing
offer, and successful pre-emption all have positive probability.  The PBE
admits the complete-plan standard strict-gain interim-D1 completion
constructed in Note 143.

**Computer-assisted proof:** exact root existence and local box uniqueness;
global reserve optimality; the strict PBE margins; and all numerical
endpoint inequalities used by the Note-143 refinement proof.

**Analytical inputs retained from Note 143:** the complete continuation-plan
representation, scalar witness construction, equal-revenue tail dominance,
marginal- and top-urgency gain rankings, the irregular-policy revenue cap,
and the D1 non-domination logic.

**Not established:** a full-menu equilibrium under perfect recall; existence
outside the displayed parameter vector; global equilibrium uniqueness;
intermediate linkage probabilities; informative winner reports or jump bids;
buyer revision; or repeated terminal bargaining.
