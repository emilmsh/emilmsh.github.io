# A positive-cost region for the canonical renegotiation equilibrium

**Status (2026-07-20).** This note generalizes the fixed cost triple in
note 71. It holds the canonical allocation path fixed and adjusts the two
continuation prices with the buyer's proposal costs. The adjustment leaves
the initiation and acceptance--revision cutoffs, and hence the on-path action
partition and posteriors, unchanged. The tremble-only termination cutoff moves
with \(\kappa\). The same path is a PBE on an explicit open region of
positive costs, including a simple rational box.

The main comparative-static result is sharp for this construction. The
proposal-cost adjustment leaves a patient initiator's private rent unchanged:
the lower agreement price exactly reimburses the initial and revised buyer
proposal costs in expectation. The costs nevertheless tighten equilibrium
existence because the seller finances that price adjustment and pays her own
counteroffer cost.

This is a sufficient-region result for the fixed \(q\)-\(r\)-\(p\) path. It
does not characterize every equilibrium at other costs, and it adds no
refinement claim beyond the selected Bayes-limit consistency argument in
notes 70 and 71.

## 1. Fixed primitives and cost-adjusted prices

Keep the primitives from note 71:
\[
n_L=2,\qquad n_H=5,\qquad
\pi=\frac3{10},\qquad A:=1-\pi=\frac7{10},
\tag{1}
\]
\[
b,Y_i\sim U[0,1],\qquad
G_\eta=\eta\delta_0+(1-\eta)U[0,1],
\qquad 0\leq\eta<1,
\tag{2}
\]
with mutual independence and public seller urgency \(d_S=0\). The auction
objects are
\[
w_n(b)=b-\frac{b^{n+1}}{n+1},
\qquad
C_n(b)=\frac{n-1}{n+1}+b^n-\frac{n}{n+1}b^{n+1}.
\tag{3}
\]
Write \(w_L=w_2,w_H=w_5,C_L=C_2,C_H=C_5\). Fix
\[
\beta=\frac9{10},\qquad q=\frac12,\qquad
w_L(\beta)=\frac{657}{1000}.
\tag{4}
\]

Let the initial proposal cost \(\kappa\), later buyer proposal cost \(c_B\),
and seller counteroffer cost \(c_S\) be positive. Set
\[
p(\kappa,c_B)
:=w_L(\beta)-\frac{c_B+\kappa}{A},
\tag{5}
\]
\[
r(\kappa)
:=Aw_L(\beta)-\kappa+\pi.
\tag{6}
\]
The note-71 prices are the special case
\((\kappa,c_B,c_S)=(1/2000,1/1000,1/500)\).

The useful price-order identities are
\[
p-q
=\frac{157}{1000}-\frac{10}{7}(c_B+\kappa),
\tag{7}
\]
\[
r-p
=\frac{1029}{10000}+\frac{10}{7}c_B+\frac37\kappa>0,
\tag{8}
\]
\[
1-r=\frac{2401}{10000}+\kappa>0.
\tag{9}
\]
Consequently,
\[
c_B+\kappa<\frac{1099}{10000}
\tag{10}
\]
is exactly the remaining condition for \(q<p<r<1\).

## 2. Why the on-path buyer partition is invariant to costs

After \(r\), the buyer compares termination, revision to \(p\), and
acceptance. The termination--revision, initiation, and
acceptance--revision cutoffs are
\[
a(b)=p+\frac{c_B}{A}-w_L(b)
=w_L(\beta)-w_L(b)-\frac{\kappa}{A},
\tag{11}
\]
\[
x(b)=a(b)+\frac{\kappa}{A}
=w_L(\beta)-w_L(b),
\tag{12}
\]
\[
y(b)=\frac{r-Ap-c_B-\pi w_H(b)}{\pi}
=1-w_H(b).
\tag{13}
\]
Thus the on-path buyer partition from note 71 is unchanged. The
termination cutoff \(a(b)\) varies with \(\kappa\), but it governs only types
that reach \(r\) through a tremble. The buyer
initiates at \(q\) iff \(d\geq\max\{x(b),0\}\). After \(r\), the buyer
terminates for \(d<a(b)\), revises to \(p\) for
\(a(b)\leq d<y(b)\), and accepts \(r\) for \(d\geq y(b)\).
Positive \(\kappa\) gives \(a(b)<x(b)\), so every on-path initiator strictly
prefers revision to termination when revision is prescribed.

The four global price-deviation margins used in note 71 become
\[
A[C_L(1)-p]-c_B
=\frac{203}{30000}+\kappa>0,
\tag{14}
\]
\[
C_H(1)-r
=\frac{2203}{30000}+\kappa>0,
\tag{15}
\]
\[
A[C_L(1)-p]
=\frac{203}{30000}+c_B+\kappa>0,
\tag{16}
\]
\[
C_H(1)+c_B-r
=\frac{2203}{30000}+c_B+\kappa>0.
\tag{17}
\]
These compare, respectively, an initial \(L\)-only deviation, an initial
both-state deviation, a revised \(L\)-only deviation, and a revised
both-state deviation with the prescribed continuation. They are strictly
positive for every nonnegative \(\kappa,c_B\). Hence the cost restriction
comes from price ordering, seller incentives, and the recursive completion,
not from a new buyer-price deviation.

## 3. A checkable cost region

Because (12)--(13) are invariant, all action masses and posterior numerators
are invariant to costs. Write \(Z_q,Z_p,Z_r\) for the masses that initiate,
revise to \(p\), and accept \(r\), respectively. For
\(h\in\{q,p\}\), write
\[
N_{sh}:=\int \Pr(h\mid b)C_s(b)\,db.
\tag{18}
\]
Every object is affine in \(\eta\). The exact coefficients, written as
intercept plus slope times \(\eta\), are
\[
\begin{array}{c|cc}
&\text{intercept}&\text{slope}\\ \hline
Z_q&30361/40000&-26361/40000\\
Z_p&237581/840000&-153581/840000\\
Z_r&10/21&-10/21\\ \hline
N_{Lq}&56394727/140000000&-47105727/140000000\\
N_{Hq}&2758384873/5000000000&-16415862861/35000000000\\
N_{Lp}&509657629/3780000000&-258854629/3780000000\\
N_{Hp}&813804710987/4095000000000&
-475343454737/4095000000000
\end{array}
\tag{19}
\]
and \(\bar C_{sh}:=N_{sh}/Z_h\) for \(h\in\{q,p\}\).

Define the seller's unnormalized continuation values after \(q\),
\[
V_L:=pZ_p+rZ_r,
\qquad
V_H:=N_{Hp}+rZ_r.
\tag{20}
\]
The six on-path seller margins are
\[
\begin{aligned}
M_{Lq}^{\,q}&:=V_L-(q+c_S)Z_q,&
M_{Lq}^{\,A}&:=V_L-c_SZ_q-N_{Lq},\\
M_{Hq}^{\,q}&:=V_H-(q+c_S)Z_q,&
M_{Hq}^{\,A}&:=V_H-c_SZ_q-N_{Hq},\\
M_{Lp}&:=pZ_p-N_{Lp},&
M_{Hp}&:=N_{Hp}-pZ_p.
\end{aligned}
\tag{21}
\]
The first four make both seller states counter at \(r\) rather than accept
\(q\) or invoke the auction. The last two make \(L\) accept \(p\) and \(H\)
invoke the auction.

For the recursive completion, define
\[
\Delta(\eta,c_B)
:=\min\left\{
\begin{array}{l}
w_L(\beta)-c_B-\bar C_{Lq},\\
w_L(\beta)-c_B-\bar C_{Lp},\\
\bar C_{Hq}-\bar C_{Lq}-c_B,\\
\bar C_{Hp}-\bar C_{Lp}-c_B,\\
C_L(1)-\bar C_{Lq},\\
C_L(1)-\bar C_{Lp},\\
C_H(1)-C_L(1)-c_B
\end{array}\right\}.
\tag{22}
\]
If \(\Delta>0\) and \(c_S>c_B\), choose
\[
0<\varepsilon<
\min\{c_S-c_B,\Delta(\eta,c_B)\}.
\tag{23}
\]
At each \(h\in\{q,p\}\), use the posterior-consistent tail
\[
\tau_h=\bar C_{Lh}+\varepsilon,
\qquad
T_h=\tau_h+c_B.
\tag{24}
\]
The first two lines of (22) make every type in the reached posterior willing
to use the tail; the next two make \(H\)'s auction value exceed the buyer's
acceptance cutoff; the following two put the tail below any alternative
buyer offer accepted by \(L\) under the high-match off-path belief. The last
line closes the auxiliary high-match tail. Condition (23) makes \(L\)
strictly accept \(\tau_h\) while ensuring that a further seller counteroffer
is strictly worse than the auction. The remaining recursive strategies and
beliefs are exactly those in notes 70 and 71.

Define \(\mathcal R_\eta\) as the set of positive
\((\kappa,c_B,c_S)\) satisfying
\[
c_B+\kappa<\frac{1099}{10000},\qquad
c_S>c_B,\qquad
\Delta(\eta,c_B)>0,
\tag{25}
\]
and
\[
M_{Lq}^{\,q},M_{Lq}^{\,A},M_{Hq}^{\,q},M_{Hq}^{\,A},
M_{Lp},M_{Hp}>0.
\tag{26}
\]

**Proposition 1 (positive-cost region).** For every
\(0\leq\eta<1\) and every
\((\kappa,c_B,c_S)\in\mathcal R_\eta\), the canonical strategy profile with
prices (4)--(6) and a tail choice satisfying (23) is a PBE. All on-path
seller actions are strict. For \(\eta>0\), a positive mass of patient buyers
initiates, revises, and reaches agreement in \(L\), while the same action
sequence ends in the auction in \(H\).

**Proof.** Equations (12)--(13) reproduce the on-path cutoffs and action
weights, so the Bayes posteriors are those in (19). Equation (11) gives the
cost-adjusted off-path best response and establishes \(a(b)<x(b)\).
Equations (14)--(17)
exclude every initial and revised price deviation under the recursive
off-path assessment. Conditions (21) and (26) establish each prescribed
on-path seller response. Equations (22)--(24) establish every strict
inequality used by the posterior-consistent recursive-tail argument in note
70, including the auxiliary high-match history. Hence the strategy profile
is sequentially rational at every history and Bayes' rule applies at the
reached offers. This establishes the PBE. The patient outcomes follow from
\(x(b)<0<y(b)\) for \(b>\beta\). \(\square\)

This proposition supplies a finite list of exact, checkable inequalities; it
is not a necessity claim for arbitrary completions. For fixed costs, every
unnormalized expression in (21)--(23) is affine in \(\eta\) after
multiplying by its positive posterior denominator. If every strict margin is
positive at \(\eta=0\), the connected strict
\(\eta\)-interval for the fixed path that contains zero ends at the first
positive root in that finite list.

## 4. A transparent robust box

The following closed box lies strictly inside the sufficient region:
\[
\begin{gathered}
0\leq\eta\leq\frac9{10},\\
\frac1{10000}\leq\kappa\leq\frac1{1000},\qquad
\frac1{2000}\leq c_B\leq\frac1{800},\\
\frac3{2000}\leq c_S\leq\frac1{400}.
\end{gathered}
\tag{27}
\]
In particular, the lower bound on \(c_S\) exceeds the upper bound on \(c_B\).
Choose \(\varepsilon=(c_S-c_B)/2\). Every unnormalized condition is then
multi-affine in \((\eta,\kappa,c_B,c_S)\), so its minimum over (27) occurs at
a vertex. Exact enumeration of all sixteen vertices gives strictly positive
margins. The smallest seller margin is
\[
\frac{56186341}{131040000000}
=0.0004287724\ldots,
\tag{28}
\]
for \(H\)'s counter-versus-auction comparison after \(q\). The smallest
tail margin is
\[
\frac1{8000}=0.000125
\tag{29}
\]
for the strict \(\varepsilon\) gap. The original note-71 cost triple lies in
the interior of (27). Thus that example is not knife-edge in any of the
three proposal costs.

On the original cost slice, exact root comparison reproduces
\[
\eta^\dagger
=\frac{117204341}{120480341}
=0.972808842\ldots,
\tag{30}
\]
with \(H\)'s counter-versus-auction comparison after \(q\) binding first.

## 5. Cost incidence and the patient initiator's rent

For a patient buyer with \(b>\beta\), the equilibrium path is \(q,r,p\).
Relative to waiting for the auction, the buyer obtains
\[
\begin{aligned}
\rho_B(b)
&=A[w_L(b)-p]-c_B-\kappa\\
&=A[w_L(b)-w_L(\beta)].
\end{aligned}
\tag{31}
\]
The agreement price falls by \((c_B+\kappa)/A\). Because agreement occurs
with probability \(A\), the expected payment falls by exactly
\(c_B+\kappa\), fully reimbursing the two buyer proposal costs. Neither the
set of patient initiators nor their private rent changes with
\(\kappa,c_B,c_S\) while the adjusted-price equilibrium remains feasible.
This is capitalization into the equilibrium price, not a statement that
costs would be irrelevant if prices were held fixed.

The rent is zero at \(b=\beta\), strictly increasing above \(\beta\), and
equals
\[
\rho_B(1)=\frac{203}{30000}
=0.006766667\ldots
\tag{32}
\]
at the top. Conditional on \(b\sim U[\beta,1]\), its mean is
\[
\mathbb E[\rho_B(b)\mid b>\beta,d=0]
=\frac{539}{120000}
=0.004491667\ldots.
\tag{33}
\]
The aggregate patient-buyer rent is therefore
\[
\eta\int_\beta^1\rho_B(b)\,db
=\eta\frac{539}{1200000}.
\tag{34}
\]

The incidence on the seller moves in the opposite direction. For a patient
initiator of match value \(b\), the seller's expected payoff change relative
to the planned auction is
\[
\begin{aligned}
\rho_S(b)
&=A[p-C_L(b)]-c_S\\
&=A[w_L(\beta)-C_L(b)]
-(\kappa+c_B+c_S).
\end{aligned}
\tag{35}
\]
Thus each increase in a buyer proposal cost is passed through one-for-one to
the seller through a lower \(p\), and the seller additionally bears \(c_S\).
This explains why patient private rent is cost-invariant while feasibility
is not.

The directions in the six seller margins make the same point. Their partial
derivatives are
\[
\begin{array}{c|ccc}
&\partial/\partial\kappa&
\partial/\partial c_B&\partial/\partial c_S\\ \hline
M_{Lq}^{\,q},M_{Lq}^{\,A}
&-(Z_p/A+Z_r)&-Z_p/A&-Z_q\\
M_{Hq}^{\,q},M_{Hq}^{\,A}
&-Z_r&0&-Z_q\\
M_{Lp}&-Z_p/A&-Z_p/A&0\\
M_{Hp}&+Z_p/A&+Z_p/A&0.
\end{array}
\tag{36}
\]
Hence \(\kappa\) tightens every seller condition except \(H\)'s rejection of
\(p\), which it relaxes. The later buyer cost \(c_B\) tightens the
\(L\)-state conditions and relaxes \(H\)'s rejection of \(p\); it does not
enter \(H\)'s continuation payoff after \(q\), because \(H\) sends a revising
buyer to the auction. The seller cost \(c_S\) directly tightens both states'
counteroffer incentives after \(q\).

The tail conditions add one distinction. The initial cost \(\kappa\) does
not enter them because the cutoff adjustment leaves the posterior fixed.
The later buyer cost \(c_B\) raises \(T_h\), the buyer's direct-acceptance
cutoff, and shrinks both the pooling slack and the gap \(c_S-c_B\). A
seller cost strictly above \(c_B\) is useful
for ruling out further counteroffers, but a higher \(c_S\) simultaneously
reduces the seller's on-path counteroffer payoff. Accordingly, the binding
constraint can change across the cost region even though the on-path buyer
behavior does not.

## 6. Audit

The self-contained exact-rational script
`code/audit_canonical_cost_region.py` re-derives the auction polynomials,
on-path buyer thresholds, action masses, and posterior numerators without
importing
the note-71 audit. It checks every inequality in (7)--(26), verifies the
sixteen vertices of (27), reproduces the original root (30), and proves the
rent and incidence identities (31)--(35) using exact arithmetic.
