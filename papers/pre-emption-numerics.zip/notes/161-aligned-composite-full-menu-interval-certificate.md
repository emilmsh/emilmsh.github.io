---
type: computer-assisted-theory-certificate
status: exact-section-6-full-menu-root-and-premises-certified
last_updated: 2026-07-26
active_manuscript: ../manuscripts/Manuscript.tex
code: ../code/certify_aligned_composite_full_menu.py
related_notes:
  - 93-primitive-full-menu-existence.md
  - 94-interval-full-menu-certificate.md
  - 97-independent-overlap-certificate-audit.md
  - 112-aligned-composite-calibration.md
  - 113-independent-aligned-composite-audit.md
---

# Interval certificate for the aligned-composite full menu

## 1. Verdict

The exact aligned-composite calibration displayed in Section 6 has a
computer-assisted existence proof.  Outward-rounded Arb arithmetic certifies
both:

1. all Poincaré--Miranda premises on the price rectangle displayed in the
   manuscript; and
2. a locally unique fixed point inside a much smaller price box, by a strict
   Krawczyk inclusion.

Every strict numerical inequality used to turn the fixed point into the
boundary-price full-menu PBE is certified on the root box.  The two endpoint
inequalities used by the analytical contingent-plan D1 proof are also strict.
This upgrades the fixed point, action masses, seller-response margins, and
reported outcome probabilities in Notes 112--113 from independently
reproduced floating-point calculations to outward-rounded interval
statements.

The certificate is local.  It does not establish global uniqueness, select
the boundary-price equilibrium among nearby positive-rent PBEs, or classify
mixed seller responses or richer signaling menus.

## 2. Exact primitives

The primitives are represented by exact rationals:

\[
(n_L,v_L)=\left(2,\frac{19}{50}\right),\qquad
(n_H,v_H)=\left(3,\frac{21}{50}\right),
\]

\[
\pi=\frac12,\qquad d_S=\frac1{100},\qquad
\kappa=\frac1{20},\qquad \bar d=1,\qquad\lambda=10.
\]

Buyer and late-bidder values are independent uniform draws on \([0,1]\).
Buyer urgency has the truncated-exponential CDF

\[
G(d)=\frac{1-e^{-10d}}{1-e^{-10}},
\qquad d\in[0,1].
\]

For \(b\leq v\),

\[
w_{n,v}(b)=b,\qquad
C_{n,v}(b)=
\frac{n-1}{n+1}+v^n-\frac{n-1}{n+1}v^{n+1}-d_S.
\]

For \(b>v\),

\[
w_{n,v}(b)=b-\frac{b^{n+1}-v^{n+1}}{n+1},
\]

\[
C_{n,v}(b)=
\frac{n-1}{n+1}+b^n-\frac{n}{n+1}b^{n+1}
+\frac{v^{n+1}}{n+1}-d_S.
\]

The script splits every integral at \(v_L\) and \(v_H\), so the integrands are
analytic on each integration cell.

## 3. Smooth fixed-point equations

On the full-menu price box, all urgency cutoffs are strictly interior and
\(D_L(b)<D_H(b)\) for every \(b\).  The unnormalised action weights can
therefore be written

\[
\widetilde m_0(b)=1-e^{-10D_L(b)},\qquad
\widetilde m_L(b)=e^{-10D_L(b)}-e^{-10D_H(b)},
\]

\[
\widetilde m_H(b)=e^{-10D_H(b)}-e^{-10}.
\]

The common factor \(1-e^{-10}\) cancels from posterior means.  Rather than
certifying ratios directly, the script solves the equivalent numerator
equations

\[
\Psi_L(q)=
\int_0^1\widetilde m_L(b;q)\,[C_L(b)-q_L]\,db=0,
\]

\[
\Psi_H(q)=
\int_0^1\widetilde m_H(b;q)\,[C_H(b)-q_H]\,db=0.
\]

Positive probing and knockout masses make
\(\Psi(q)=0\) equivalent to \(T(q)=q\).

## 4. Large price rectangle

The exact decimal endpoints of the manuscript rectangle are

\[
\mathcal Q_0=
[0.605677721,0.613677721]
\times[0.701343970,0.709343970].
\]

The three endpoint reductions for global interiority have outward-rounded
lower bounds

\[
D_L>0:\quad 0.0207203876666\ldots,
\]

\[
D_H<\bar d:\quad 0.1869897810000\ldots,
\]

\[
Z>0:\quad 0.0012552956666\ldots.
\]

The rectangle is strictly contained in

\[
[C_L(0),C_L(1)]\times[C_H(0),C_H(1)].
\]

The continuum face inequalities are reduced analytically to four corners.
Under global interiority, increasing \(q_H\) adds probing weight with a
likelihood ratio increasing in \(b\), because
\(\Delta w(b)=w_H(b)-w_L(b)\) is weakly increasing.  Since \(C_L\) is
nondecreasing, \(T_L\) is weakly increasing in \(q_H\).  Increasing \(q_L\)
adds knockout weight with a likelihood ratio decreasing in \(b\); since
\(C_H\) is nondecreasing, \(T_H\) is weakly decreasing in \(q_L\).
Consequently the four face minima are the four relevant corner values.

Arb gives the strict inward margins

\[
(0.0039999996495\ldots,\;
  0.0040000003504\ldots,\;
  0.0039971649448\ldots,\;
  0.0039968028903\ldots).
\]

Thus the conditional Poincaré--Miranda proposition alone already establishes
at least one exact full-menu fixed point in \(\operatorname{int}\mathcal Q_0\).
No sampled price-face grid enters this conclusion.

## 5. Small root box and local uniqueness

Automatic differentiation is carried through the validated Arb integrals.
The Krawczyk calculation uses the box

\[
\begin{split}
q_L&\in[
0.609677720961387,\;
0.609677720963387],\\
q_H&\in[
0.705343970179778,\;
0.705343970181778].
\end{split}
\]

Its Krawczyk image is contained strictly in its interior and is concentrated
near

\[
(q_L,q_H)=
(0.609677720962382,\;0.705343970180778).
\]

The script also certifies directly that this small root box lies strictly
inside the large price rectangle.  Its four containment margins all exceed
\(0.0039999998\).

The interval determinant of \(D_q\Psi\) is bounded away from zero:

\[
\det D_q\Psi\in
[0.027512959\ldots,0.027512961\ldots].
\]

The Krawczyk theorem therefore establishes existence and uniqueness of the
zero of \(\Psi\) inside this small box.  This is local uniqueness of the
boundary-price root, not uniqueness of PBE in the model.

## 6. Equilibrium premises at the exact root

Uniformly over the certified root box, Arb encloses the three cutoff ranges as

\[
D_L(b)\in[0.024720387\ldots,0.709677722\ldots],
\]

\[
\widetilde D_H(b)\in
[0.033975683\ldots,0.755343971\ldots],
\]

\[
D_H(b)\in[0.043230978\ldots,0.801010220\ldots].
\]

The global screening margin is

\[
\min_b Z(b)>0.009255295\ldots.
\]

Hence waiting, probing, and knockout are all optimal for positive sets of
buyer types.  Their masses are enclosed around

\[
(M_0,M_L,M_H)=
(0.765415358,\;0.067872419,\;0.166712223).
\]

The off-diagonal seller-response margins are strict:

\[
\mathbb E[C_H(b)\mid q_L]-q_L>0.0656595,
\]

\[
q_H-\mathbb E[C_L(b)\mid q_H]>0.0664836.
\]

The exact shape assumptions used by the proposition are analytical polynomial
facts.  On the three value intervals,

\[
\Delta w'(b)=0,\quad b^2,\quad b^2-b^3,
\]

so \(\Delta w\) is weakly increasing.  Each \(C_s\) is nondecreasing and
strictly increasing above its kink, while

\[
\Gamma_L'(b)=-1\quad(b<v_L),\qquad
\Gamma_L'(b)=-(1-b)^2\quad(b>v_L).
\]

An interval subdivision additionally verifies \(C_H(b)>C_L(b)\) throughout
\([0,1]\); its deliberately conservative lower bound is \(0.0488720\).
The exact aligned-state coupling gives the same ordering analytically.

Finally, \(\kappa>0\), \(\Delta w\) is weakly increasing, and the two
D1-relevant endpoint margins are

\[
C_L(1)-q_L>0.0652796,\qquad
C_H(1)-q_H>0.0424352.
\]

These are precisely the strict numerical premises used by the manuscript's
analytical contingent-plan D1 completion.

## 7. Outcomes and no sale

The interval-certified observed outcome probabilities are centred at

\[
\Pr(\text{no early offer})=0.765415358,
\]

\[
\Pr(\text{attempt and rejection})=0.033936209,
\]

\[
\Pr(\text{successful pre-emption})=0.200648433.
\]

Accounting for equilibrium selection, the state-conditional no-sale
probabilities are enclosed around

\[
(0.05435210842,\;0.03095675117),
\]

with prior-weighted probability \(0.04265442979\).

## 8. Reproduction

The executable source is
`code/certify_aligned_composite_full_menu.py`.  It has no random seed and no
search step.  The public dependency file pins `python-flint==0.9.0`.
From the repository root, install and run it as

```text
python -m pip install -r code/requirements-publication.txt
python code/certify_aligned_composite_full_menu.py
```

The expected first line is

```text
aligned-composite full-menu Arb certificate: PASS
```

Adding `--json` emits the same certified root box, Krawczyk image, margins,
action masses, outcomes, and no-sale probabilities as deterministic
machine-readable JSON.  The `arb` member of each interval record is the full
outward enclosure.  The members named `lower` and `upper` are themselves Arb
ball strings enclosing the directed endpoint computations, not plain scalar
decimal bounds.  Keeping all three as strings prevents binary floating-point
conversion from narrowing an outward Arb enclosure.  The JSON and human
reports include both the root-box containment margins and the four margins
placing the large rectangle strictly inside the price domain.

The script reports the installed `python-flint` version and the working
precision.  The audited run used `python-flint 0.9.0` and 60 decimal digits.

## 9. Claim ledger

**Interval-certified:** the large price-box endpoint margins and four inward
face signs; existence of a full-menu fixed point; existence and local
uniqueness of a fixed point in the small root box; nonsingularity of its
Jacobian; positive action masses; all cutoff ranges; the global screening
margin; the two off-diagonal seller responses; the two D1 endpoint slacks;
outcome probabilities; and equilibrium no-sale probabilities.

**Analytical:** the uniform-auction formulas; the equivalence between
\(\Psi=0\) and \(T(q)=q\); the polynomial shape and state-ordering results;
the likelihood-ratio corner reduction for the four continuum price faces; the
PBE construction conditional on those premises; and the contingent-plan D1
argument conditional on its endpoint inequalities.

**Not established:** global uniqueness; PBE price selection; a global
classification of mixed or richer menus; endogenous disclosure of the hidden
no-sale value; or robustness to arbitrary changes in the primitive
distributions.
