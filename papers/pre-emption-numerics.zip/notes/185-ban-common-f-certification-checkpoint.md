# Ban-Welfare Common-`F` Certification Checkpoint

Date: 2026-08-03

## Settled Numerical Pair

The displayed ban comparison now stays within the continuous common-`F` full-menu model. Common primitives are

`
(n_L,n_H)=(2,6), (v_L,v_H)=(.2,.4), pi=.5,
d_S=0, kappa^R=kappa=.02, d_bar=1.
`

Buyer urgency follows
`G(d)=10^-4 d + (1-10^-4)[1-(1-d)^30]`, which has a continuously differentiable density bounded below by `10^-4`. The two mean-.5 common value distributions are

- `F^S=.01 U[0,1]+.99 Beta(40,40)`;
- `F^T=.01 U[0,1]+.99[(16/17)Beta(38,42)+(1/17)Beta(9,1)]`.

`code/audit_ban_welfare_examples.py` solves both equilibria independently at two quadrature resolutions and checks global cutoff interiority, positive masses of waiting/probing/knockout, seller-response slacks, D1 endpoint slacks, incidence, and the welfare decomposition. It obtains

- `W^B-W^D=-.003527651553` under `F^S`;
- `W^B-W^D= .000303351715` under `F^T`.

The direct welfare calculation agrees with excluded late-buyer surplus minus the early buyer's and seller's equilibrium rents to below `5e-10`.

## Certification Status

The initial Arb/Krawczyk implementation used generic complex adaptive integration with exact monomial and Bernstein representations of the integer-beta CDFs. Generic `acb.integral` evaluation was either prohibitively slow or produced unusably wide balls because the terminal continuation functions involve powers of degree-79 beta-mixture polynomials. That failed implementation was not registered in `claims.json` and was removed from `code/`.

The completed certificate, `code/certify_ban_welfare_examples.py`, instead uses a rational 24,000-cell grid and outward-rounded Arb enclosures. It bounds the terminal auction integrals from the monotonicity of first- and second-order-statistic survival probabilities and the unimodality of excluded-bidder surplus. Outer expectations are enclosed as Lebesgue--Stieltjes cell sums. Interval Krawczyk operators certify locally unique price roots in the reported boxes; the same root enclosures certify global cutoff interiority, positive masses of all three actions, seller-response inequalities, D1 endpoint inequalities, and both welfare signs.

The certified welfare intervals are

- `W^B-W^D in [-.003662070,-.003393114]` under `F^S`;
- `W^B-W^D in [.000261675,.000345072]` under `F^T`.

The independently enclosed rent-identity intervals overlap the direct welfare intervals in both rows. The certificate establishes local uniqueness within each reported root box, not global equilibrium uniqueness. It is registered alongside the floating-point cross-check in `claims.json`.
