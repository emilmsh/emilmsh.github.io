---
type: interval-certificate-upgrade
status: all-seven-items-certified-pass
last_updated: 2026-07-28
active_manuscript: ../manuscripts/Manuscript.tex
certificate_script: ../code/certify_urgency_only_knockout_gate.py
float_audit: ../code/audit_urgency_only_knockout_only_d1.py
related_notes:
  - 176-urgency-only-parity.md
  - 161 and 163 (Section 6 certificate; construction and audit)
manuscript_state: >
  Written against the working tree of 2026-07-28 (HEAD 3c11420 plus the
  uncommitted microfoundations restructure).  References are to labels.
  The manuscript itself was NOT edited; Section 5 gives exact drop-in
  replacement sentences for the agent that owns the documents.
---

# Urgency-only knockout-only D1 gate: interval certificates

This note upgrades every numerical premise of Proposition
`prop:urgencyknockoutgate` / Appendix `app:urgencyknockoutgate` (derivation
notes/176 §T3) from tight floating-point brackets to outward-rounded
interval/ball certificates with Krawczyk root enclosures, the same standard
as the Section 6 aligned-composite full-menu certificate (notes 161/163).

**Verdict: PASS on all seven requested items.**  Script:
`code/certify_urgency_only_knockout_gate.py` (deterministic, runs in under
one second, version-gated to the pinned `python-flint==0.9.0` of
`code/requirements-publication.txt`; `--json` emits the machine-readable
intervals).  No new dependency; the existing float audit
`code/audit_urgency_only_knockout_only_d1.py` is unchanged and remains an
independent cross-check.

## 1. Method

Primitives are exact rationals: \(F=U[0,1]\), \(n=2\), \(v=2/5\),
\(\pi=1/2\), \(\kappa=1/100\) (variant \(1/20\)), \(d_{S,L}=1/50\),
\(d_{S,H}=0\), truncated-exponential urgency (rate 10) on \([0,1]\).  With
\(n=2\) the uniform formulas `eq:uniformformulas` give, for \(b>v\),
\(w(b)=b-(b^3-v^3)/3\), \(R(b)=1/3+b^2-2b^3/3+v^3/3\), and the exact
algebraic identity \(\Gamma(b)=R(b)-w(b)=(1-b)^3/3\); below \(v\), \(w(b)=b\)
and \(R\) is the constant \(59/125\).  \(C_s=R-d_{S,s}\).  All polynomial
integrals (\(\int R\,db\), \(\int_0^v e^{\lambda b}db\)) are exact ball
arithmetic; the only non-elementary objects are
\(\int e^{\lambda w(b)}db\) and \(\int R(b)e^{\lambda w(b)}db\) above \(v\)
(the exponential of a cubic), which Arb's validated adaptive integration
encloses with outward rounding at 60-digit working precision and
\(10^{-45}\) tolerance.

Two root problems, both one-dimensional Krawczyk with a midpoint
preconditioner, derivative enclosure over the box by complex-ball automatic
differentiation, strict interior inclusion of the Krawczyk image, and a
derivative box excluding zero (existence plus local uniqueness of a simple
root):

- **\(\kappa=1/100\).**  The knockout weight
  \(\min\{1,\,1-G(q+\kappa-w(b))\}\) has a kink at the value where
  \(w(b)=q+\kappa\), so the fixed point is parameterised by the kink
  \(t=b_K^0\) with \(q=w(t)-\kappa\); the substitution \(b=v+(t-v)s\)
  removes the moving endpoint, and the residual
  \(\Phi(t)=\int R\,dM_K-(w(t)-\kappa)M_K\) is smooth in \(t\).  The
  certificate also proves the decomposition's validity on the box
  (\(w(t)<1\), monotone \(w\), \(D_K(\bar b)<0\)) and transfers local
  uniqueness to \(q^\ast=w(t^\ast)-\kappa\) by certifying
  \(w'(t)=1-t^2>0\) on the box.
- **\(\kappa=1/20\).**  \(D_K(\bar b)\geq0\), so the cutoff is positive on
  the whole support, there is no kink, and Krawczyk runs directly in the
  price; the corner condition \(D_K(\bar b)>0\) and \(q^\ast+\kappa<1\) are
  certified so the formula is valid on the box.

Root centers are hard-coded 39-digit strings obtained by deterministic
Newton polishing of the audit-script floats against the same certified
residuals (quadratic convergence; center residuals \(\sim10^{-40}\)); the
certified boxes have radius \(10^{-12}\).

## 2. Certified enclosures (κ = 1/100, Example primitives)

Krawczyk box for \(t=b_K^0\): center
\(0.790989184302433229243461208738\), radius \(10^{-12}\); Krawczyk-image
radius \(6.6\times10^{-22}\); \(\Phi'\) enclosure
\([-0.1144825864\pm8.5\times10^{-11}]\), excludes zero.  All radii below are
outward.

| item | quantity | certified enclosure | radius |
|---|---|---|---|
| 1 | \(q^\ast\) | \(0.637358061053039\) | \(1.7\times10^{-12}\) |
| 2 | \(b_K^0\) | \(0.790989184302433\) | \(1.0\times10^{-12}\) |
| 2 | \(\Gamma(b_K^0)=(1-b_K^0)^3/3\) | \(0.003043582132\) | \(4.4\times10^{-14}\) |
| 2 | \(D_K(\bar b)\) (interiority, \(<0\)) | \(-0.040641938947\) | \(1.7\times10^{-12}\) |
| 3 | gate (i) \(\Gamma+\kappa/(1-\pi)-d_{S,L}\) | \(0.003043582132>0\) strict | \(4.4\times10^{-14}\) |
| 3 | gate (ii) \(C_H(b_K^0)-q^\ast\) | \(0.013043582132>0\) strict | \(4.5\times10^{-12}\) |
| 3 | \((1,0)\)-branch deterrence sup (\(<0\)) | \(-0.001521791066\) | \(2.3\times10^{-12}\) |
| 4 | \(d_{S,L}^\ast=\Gamma(b_K^0)+\kappa/(1-\pi)\) | \(0.023043582132\) | \(4.4\times10^{-14}\) |
| 5 | waiting mass (\(>0\)) | \(0.615536970858\) | \(6.0\times10^{-12}\) |
| 5 | knockout mass (\(>0\)) | \(0.384463029142\) | \(6.0\times10^{-12}\) |
| — | raw-PBE persistence bound | \(0.060641938947\) | \(1.7\times10^{-12}\) |

Item 7, failure demonstrations (killer interval
\((C_L(b_K^0),\,q^\ast-\pi\kappa/(1-\pi))\) certified nonempty; midpoint
forced-acceptance gain certified strictly positive; gap certified below the
raw-PBE persistence bound, so the exclusion is driven by D1):

| \(d_{S,L}\) | killer width | midpoint gain | raw-persistence margin |
|---|---|---|---|
| \(.025\) | \(0.001956417868\) | \(0.000489104467\) | \(0.035641938947\) |
| \(.03\) | \(0.006956417868\) | \(0.001739104467\) | \(0.030641938947\) |
| \(.05\) | \(0.026956417868\) | \(0.006739104467\) | \(0.010641938947\) |

(all radii \(\leq6.1\times10^{-12}\); all sign checks strict).

## 3. Certified enclosures (κ = 1/20 variant, item 6)

Krawczyk box for \(q^\ast\): center
\(0.643706593437314578528702405883\), radius \(10^{-12}\); Krawczyk-image
radius \(1.5\times10^{-22}\); \(\Phi'\) enclosure
\([-0.2835323766\pm5.6\times10^{-11}]\), excludes zero.

| quantity | certified enclosure | radius |
|---|---|---|
| \(q^\ast\) | \(0.643706593437315\) | \(1.0\times10^{-12}\) |
| \(D_K(\bar b)\) margin (\(>0\), corner \(b_K^0=\bar b\)) | \(0.005706593437\) | \(1.0\times10^{-12}\) |
| \(C_L(\bar b)-q^\ast\) (\(>0\), full rejection) | \(0.024293406563\) | \(1.0\times10^{-12}\) |
| gate (i), corner form \(C_H(\bar b)-q^\ast+\pi\kappa/(1-\pi)-\Delta z\) | \(0.074293406563\) | \(1.0\times10^{-12}\) |
| gate (ii) \(C_H(\bar b)-q^\ast\) | \(0.044293406563\) | \(1.0\times10^{-12}\) |
| waiting / knockout mass (\(>0\)) | \(0.716425623578\) / \(0.283574376422\) | \(2.9\times10^{-12}\) |

## 4. Reconciliation with the floating-point audit

Every displayed digit in the manuscript
(\(.637358061\), \(.790989\), \(.003044\), \(.013044\), \(.023044\),
\(.615537/.384463\), \(.060642\), \(.643707\)) is confirmed by the
enclosures.  One correction at the sub-display level: the audit script and
note 176 report \(q^\ast=0.637358061052\); the certified value is
\(0.637358061053039\pm1.7\times10^{-12}\), so the audit's twelfth decimal
carries a Simpson-level error of about \(1\times10^{-12}\).  No manuscript
text displays that digit, so nothing in the paper changes.  The variant
\(q^\ast=.643706593437\) is confirmed at all reported digits.

## 5. Exact manuscript replacements (for the docs-owning agent; NOT applied)

The manuscript never cites script filenames; it describes certificates in
prose, as at the Section 6 example and `prop:terminalcounterofferslinked`.
Matching that house style:

**(a) Required drop-in, `app:urgencyknockoutgate`, final sentence of the
"Numerical instance and boundary" paragraph.**  Replace

> The reported quantities are tight numerical brackets rather than interval
> certificates; every strategic margin used is strict except the intended
> boundary equalities.

with

> An outward-rounded ball-arithmetic calculation applies the Krawczyk
> theorem to both boundary fixed points, for \(\kappa=.01\) in the marginal
> coordinate \(b_K^0\) and for \(\kappa=.05\) directly in the price, and
> proves existence and local uniqueness with root enclosures of radius
> below \(2\times10^{-12}\); the same calculation certifies strict signs,
> with enclosure radii below \(10^{-11}\), for both gate margins, the
> survival boundary, the waiting and knockout masses, the
> partial-acceptance deterrence bound, the killer-interval widths and
> raw-persistence margins at \(d_{S,L}\in\{.025,.03,.05\}\), and the corner
> and full-rejection margins of the \(\kappa=.05\) variant.  Every
> strategic margin used is certified strict except the intended boundary
> equalities.

**(b) Recommended upgrade, `sec:microcompare`, sentence after
`prop:urgencyknockoutgate`.**  Replace

> Appendix~\ref{app:urgencyknockoutgate} proves both directions and reports
> an independently reproduced numerical audit.

with

> Appendix~\ref{app:urgencyknockoutgate} proves both directions and reports
> an interval-certified numerical instance.

**(c) Optional micro-edit, same appendix paragraph.**  "independently
reproduced failures occur at \(d_{S,L}\in\{.025,.03,.05\}\)" may read
"certified failures occur at \(d_{S,L}\in\{.025,.03,.05\}\)"; sentence (a)
already carries the blanket statement, so this is cosmetic.

Bookkeeping for the same agent: `code/claims.json`, `code/README.md`, and
the reproduction-runner manifest do not yet list
`certify_urgency_only_knockout_gate.py`; `manuscripts/ProofsDerivationsAudit.tex`
has no urgency-gate module yet (it predates the restructure), so when that
module is written it should cite this certificate rather than the float
audit alone.

## 6. Honesty: what this certificate does and does not cover

Certified: everything numerical that `prop:urgencyknockoutgate` and
`app:urgencyknockoutgate` consume — both boundary fixed points (existence
and local uniqueness in their boxes), interiority/corner status of
\(b_K^0\), both gate margins, the survival boundary, the deterrence bound
of the survival completion's partial-acceptance branch, both action masses,
the raw-PBE persistence bound, and the three killer intervals.  The
survival and failure directions themselves are the appendix's analytic
proofs; \(R'\leq w'\) (interval monotonicity of the gate residual) is exact
algebra in note 176.

Not covered, hedges stay as written: the full-menu urgency-only Example
`prop:sellerurgencystate` — its fixed point \((q_L,q_H)=(.586757,.643708)\),
masses, and D1 audit in `app:privatesellerurgency` remain an independently
reproduced floating-point assessment ("endpoint-inclusive numerical
assessment" wording unchanged); the D1-surviving price-band upper endpoints
\(.678\) and \(.646980728\) and the \(d_{S,H}=.005\) sensitivity row of note
176 §T3.8 (not displayed in the manuscript); and local root uniqueness is
not global equilibrium uniqueness, exactly as for the other certificates.

## 7. Reproduction

    python -m pip install -r code/requirements-publication.txt
    python code/certify_urgency_only_knockout_gate.py
    python code/certify_urgency_only_knockout_gate.py --json

Deterministic, no randomness, standard certificate conventions: exact
rational primitives, outward rounding everywhere, `require`-gated PASS that
survives `python -O`, version gate on `python-flint==0.9.0`.  Verified pass
on 2026-07-28 under Python 3.12, python-flint 0.9.0 (runtime 0.4 s).
