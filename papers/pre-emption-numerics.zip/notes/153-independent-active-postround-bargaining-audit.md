---
type: independent-theory-audit
status: pass-raw-pbe-with-explicit-claim-boundary
last_updated: 2026-07-26
audited_note: 152-active-postround-bargaining-pbe.md
audited_code: ../code/audit_active_postround_bargaining_pbe.py
---

# Independent audit of the active post-round bargaining PBE

## Verdict

**PASS as an isolated raw pure PBE, subject to the claim boundary in
Note 152.** After two repairs found during the audit, the displayed
bidding-round plus post-round game has a complete pure-strategy assessment
with active buyer counteroffers. Middle winner types counter the pooled
seller demand; the low-fallback seller accepts and the high-fallback seller
terminates without sale. Higher winner types accept the pooled demand.

The two repairs are substantive bookkeeping requirements but do not overturn
the construction.

1. After an unused low-clock seller demand, the buyer believes \(L\).
   Countering at \(P\) then buys certain rather than probability-one-half
   acceptance, so the correct accept-versus-counter threshold is
   \[
   \widehat b_C=P+c_B=.503,
   \]
   not the on-path pooled-posterior threshold \(b_C=.506\).
2. In the higher-clock audit, the state-specific demand needs to maximize the
   seller's price objective only below its clock cutoff \(\chi_s\). Above
   \(\chi_s\), accepting the standing bid must instead dominate every new
   demand. Applying the demand-maximization assertion above the cutoff
   generated the original script failure.

The corrected note and script implement both repairs. I find no remaining
profitable pure price deviation, recounter, clock overbid, or switch-point
deviation.

This verdict does **not** establish interim D1, sequential-equilibrium
consistency under a particular tremble, robustness to continuous off-path
beliefs, coupling to the early pre-emption game, or uniqueness. The result is
a PBE of the isolated public-clock plus post-round bargaining game.

## 1. Buyer sorting after the pooled demand

At every \(x<y=.3\), both seller states demand \(R=.7\). The buyer retains
prior \(\theta=1/2\) and compares exit, countering at \(P=.5\), and accepting:
\[
 0,\qquad
 (1-\theta)(b-P)-c_B,\qquad
 b-R.
\]
The counter becomes weakly profitable at
\[
 b_C=P+\frac{c_B}{1-\theta}=.506,
\]
and acceptance overtakes countering at
\[
 b_A=\frac{R-(1-\theta)P-c_B}{\theta}=.894.
\]
Hence the prescribed exit--counter--accept partition is correct. Every
nonspecial buyer proposal is deterred by the top-value completion checked in
Section 4 below.

After an unused initial seller demand \(z\) at a low-clock history, the buyer
instead believes \(L\). Its counter payoff is then \(b-P-c_B\), so
\[
 \widehat b_C=P+c_B=.503.
\]
If \(z\leq\widehat b_C\), accepting \(z\) dominates countering whenever trade
is individually rational. If \(z>\widehat b_C\), types
\(b\geq\widehat b_C\) counter at \(P\), and lower types exit. This verifies
the corrected off-path response over the entire price interval.

## 2. Low-clock seller deviations over the price continuum

Conditional on truthful clock dropout \(x<y\), the winner is uniform on
\([x,1]\). The on-path payoffs are
\[
 U_L^R(x)
 =\frac{v_L(b_C-x)+P(b_A-b_C)+R(1-b_A)}{1-x}-c_S,
\]
\[
 U_H^R(x)
 =\frac{v_H(b_A-x)+R(1-b_A)}{1-x}-c_S.
\]

For \(L\), an unused demand \(z\leq\widehat b_C\) gives
\[
 \frac{v_L(z-x)+z(1-z)}{1-x}-c_S
\]
when \(z>x\), and \(z-c_S\) when \(z\leq x\). The first expression is
strictly increasing through the relevant interval because its unconstrained
maximum is \((1+v_L)/2=.6>\widehat b_C\). At any
\(z>\widehat b_C\), all types above \(\widehat b_C\) counter at \(P\), which
gives less than the boundary demand because
\[
 \widehat b_C(1-\widehat b_C)>P(1-\widehat b_C).
\]
Thus the global unused-price maximum is attained at
\(z=\widehat b_C\).

For \(H\), every \(z>\widehat b_C\) induces a counter followed by exit and
therefore yields \(v_H-c_S\). Selling at a price no greater than
\(\widehat b_C<v_H\) cannot improve on this envelope. Direct exit gives
\(v_H\).

Endpoint evaluation and monotonicity reproduce the corrected minimum
margins:
\[
\begin{array}{c|cc}
 &\text{on path minus outside action}
 &\text{on path minus best unused price}\\ \hline
L&.140000&.018809\\
H&.008600&.010600.
\end{array}
\]
The inequalities are strict on the complete interval \(x\in[0,y)\), not
merely on the price grid.

## 3. Active counter and recursive continuation

After the special counter \(P\), \(L\) accepts and \(H\) exits. If either
seller instead recounters at \(z\), the buyer believes \(L\). With
\[
 \tau=v_L=.2,\qquad T=\tau+c_B=.203,
\]
the type-conditioned optimal response is:

- for \(z\leq T\), accept exactly when \(b\geq z\);
- for \(z>T\), counter at \(\tau\) exactly when \(b\geq T\);
- otherwise exit.

These rules also make the continuation optimal for types that reached the
history through an earlier deviation. The best recounter payoff is
\[
 T-c_S=.201
\]
for \(L\), and
\[
 v_H-c_S=.598
\]
for \(H\). The margins relative to accepting \(P\) and exiting are therefore
\(.299\) and \(.002\).

The prices \(P\) and \(\tau\) must be special only at their stated public
histories. Repeating the same numerical price after another history invokes
the nonspecial completion. This history specificity prevents a buyer from
reopening the low-state sale branch after a top-value counter.

For every nonspecial buyer proposal \(p\), the seller assigns probability one
to \(b=1\). It demands \(1\) when \(p<1-c_S\) and accepts otherwise. The
cheapest immediately accepted effective expenditure is
\[
 1-c_S+c_B=1.001>1.
\]
A lower proposal induces a demand of \(1\), and any further buyer proposal
adds another \(c_B\). Thus no buyer type benefits from a nonspecial proposal.
The same history-dependent rules close every finite continuation. A
perpetual unilateral proposal path accumulates unbounded positive costs and
cannot be profitable.

## 4. Higher-clock seller actions

At \(x\geq y\), a direct accept-or-exit demand \(r>x\) gives state \(s\)
\[
 D_s(r,x)
 =v_s+\frac{(r-v_s)(1-r)}{1-x}-c_S.
\]
This objective is strictly concave in \(r\) and has the unique unconstrained
maximum
\[
 r_s=\frac{1+v_s}{2},
\]
so \(r_L=.6\) and \(r_H=.8\). The clock cutoffs solving
\(D_s(r_s,\chi_s)=\chi_s\) are
\[
 \chi_L=.570698056604,\qquad
 \chi_H=.778975015605.
\]
For \(y\leq x<\chi_s\), demanding \(r_s\) strictly dominates both the
outside option and every other demand. At \(x=\chi_s\), accepting \(x\) and
demanding \(r_s\) tie. For \(x>\chi_s\), accepting \(x\) strictly dominates
the globally best new demand and fallback \(v_s\). This covers the complete
price continuum, including demands below the standing bid.

At histories where \(r_L\) and \(r_H\) are on path, Bayes' rule assigns the
buyer the corresponding degenerate seller-state belief. After an unused
higher-clock price, the belief may be arbitrary: the buyer accepts exactly
when \(b\geq z\), exits otherwise, and cannot profitably counter under the
top-value completion. The response is therefore belief independent.

## 5. Clock bidding and switch points

Let \(V(b,x)\) be the expected continuation payoff from becoming provisional
winner when the highest rival drops at \(x\).

- If \(x<y\), \(V=0\) for \(b<b_C\), while every type with positive payoff
  has \(b\geq b_C>y>x\).
- If \(y\leq x<\chi_L\), \(V=0\) for \(b<r_L\), while every type with positive
  payoff has \(b\geq r_L>\chi_L>x\).
- If \(\chi_L\leq x<\chi_H\), then for \(b<r_H\),
  \[
  V(b,x)=(1-\theta)(b-x),
  \]
  and every \(b\geq r_H\) is above \(x\).
- If \(x\geq\chi_H\), then \(V(b,x)=b-x\).

Therefore
\[
 V(b,x)\geq0\quad\text{when }x<b,\qquad
 V(b,x)\leq0\quad\text{when }x>b.
\]
Truthful dropout is a pointwise weak best response. The inequalities also
hold at the one-sided limits of \(y,\chi_L,\chi_H\). Types in the zero-payoff
regions can safely overstay, but no type gains strictly from overbidding.
Under the prescribed truthful strategy there is consequently no atom or
bunching at a switch point.

The winner posterior generated by truthful continuous dropout is uniform on
\([x,1]\). After on-path \(R\) followed by \(P\), Bayes' rule truncates it to
the uniform distribution on \([b_C,b_A)\); because \(x<y<b_C\), that posterior
does not depend on \(x\). The seller-state posterior after pooled \(R\) is the
prior \(\theta\). These are the only positive-probability belief restrictions
used by the active path.

## 6. Incidence and reproduction

With three iid uniform bidders,
\[
 \Pr(x<y)=3y^2-2y^3=.216.
\]
The active-counter mass is
\[
 3(b_A-b_C)y^2=.10476,
\]
which splits into \(.05238\) low-state sales and \(.05238\) high-state
breakdowns. Direct acceptance of \(R\) has mass
\[
 3(1-b_A)y^2=.02862.
\]
The remaining low-clock exit mass is \(.08262\). All incidence formulas
follow directly by assigning one bidder to the stated winner interval and
the other two values below \(y\).

I reran the corrected public audit with the bundled Python runtime. It exits
successfully and reproduces all cutoffs, seller margins, zero clock-sign
violations, and incidence figures above. I separately reconstructed the
continuum objectives and checked an endpoint-inclusive independent numerical
grid; no additional violation appears.

## Claim boundary

The result establishes:

- a raw pure PBE of the isolated clock-plus-post-round game;
- unrestricted proposal rights after every finite history;
- positive-probability active buyer counteroffers;
- state-contingent sale and state-contingent bargaining breakdown; and
- truthful English-clock dropout as a weak best response.

It does not establish:

- interim D1 or another dynamic refinement;
- belief-continuous implementation of the low/high clock switch;
- coupling to early pre-emption with perfect recall of the early action;
- local primitive robustness, global equilibrium characterization, or
  uniqueness; or
- that active counteroffers occur in every PBE.
