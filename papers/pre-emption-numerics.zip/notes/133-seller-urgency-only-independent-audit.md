---
type: theory-audit
status: pbe-and-d1-verified-corrections-integrated-in-note-132
last_updated: 2026-07-23
audited_note: 132-seller-urgency-only-refined-pbe.md
audited_code: ../code/audit_seller_urgency_only_refined_pbe.py
related_notes:
  - 79-equilibrium-selection-framework.md
  - 132-seller-urgency-only-refined-pbe.md
---

# Seller-urgency-only equilibrium: independent audit

## 1. Bottom line

The numerical fixed point and the raw-PBE construction in Note 132 check out.
The interim-D1 conclusion also survives. The version audited here initially
used an incomplete price partition; the current Note 132 incorporates the
correction derived below.

The material repair is narrow:

- for sufficiently low prices, rejection by both seller types is the only
  response plan that is sequentially rational under any posterior;
- no buyer type can then gain or break even, so D1 deletes no type;
- Note 132 instead says that only the wait--probe marginal types are
  D1-undominated after every \(p<q_L\).

This error does not invalidate the equilibrium. In the omitted low-price
region D1 permits every posterior, including the high-\(b\) posterior that
makes both seller types reject. The corrected price-by-price completion is
given below.

There is also an interpretation issue. The calibration retains a
nondegenerate buyer-urgency type \(d\). It therefore shows that seller urgency
is the only private seller state and can finance some trades by buyers with
\(d=0\); it does not show that seller urgency is the only source of gains from
trade in the equilibrium.

The independent audit did not modify Note 132 or its script. The current
Note 132 was subsequently repaired using this audit.

## 2. Independent fixed-point and PBE check

The primitives imply

\[
\underline R
=R(b)\big|_{b\leq v}
=\frac13+0.4^2-\frac{0.4^3}{3}
=0.472,
\]

and

\[
\overline R=R(1)=0.688.
\]

Thus the urgent and patient continuation supports are

\[
C_L(b)\in[0.452,0.668],
\qquad
C_H(b)\in[0.472,0.688].
\tag{1}
\]

A new 131,072-panel Simpson solve gives

\[
(q_L,q_H)
=(0.586756515147,\ 0.643707659769),
\tag{2}
\]

with residuals

\[
(-1.61\times10^{-14},\ -2.33\times10^{-15}).
\]

These prices differ from the 65,536-panel values in Note 132 by less than
\(5.3\times10^{-12}\). The corresponding action masses are

\[
(M_0,M_L,M_H)
=(0.550185181075,\ 0.185288486218,\ 0.264526332707).
\tag{3}
\]

The on-path posterior continuation rows are

\[
\begin{array}{c|cc}
 & C_L & C_H\\ \hline
q_L&0.586756515147&0.606756515147\\
q_H&0.623707659769&0.643707659769.
\end{array}
\tag{4}
\]

Hence the urgent seller accepts \(q_L\) at equality while the patient seller
rejects with margin \(\Delta=0.02\). At \(q_H\), the patient seller accepts at
equality and the urgent seller accepts strictly with the same margin.

Buyer payoffs are affine in \(d\), with slopes \(0,A,1\). The adjacent
cutoffs are

\[
D_L(b)=q_L-w(b)+\frac{\kappa}{A},
\qquad
D_H(b)=\frac{q_H-Aq_L}{\pi}-w(b).
\]

Their ranges at (2) are

\[
D_L(b)\in[-0.081243484853,\ 0.606756515147],
\]

\[
D_H(b)\in[0.012658804391,\ 0.700658804391],
\]

and their gap is the positive constant

\[
D_H(b)-D_L(b)=0.093902289244.
\tag{5}
\]

The ordered intersections therefore give the global pointwise buyer best
response, including \(b,d\in\{0,1\}\). Cutoffs outside the urgency support
simply remove the corresponding extreme action region.

For the raw off-path completion, posterior \(b=1\) gives thresholds

\[
(C_L(1),C_H(1))=(0.668,0.688).
\tag{6}
\]

With acceptance at equality, the exact endpoint-inclusive response rule is:

\[
\begin{array}{c|c}
\text{price}&\text{acceptance}\\ \hline
p<0.668&\text{neither seller}\\
0.668\leq p<0.688&\text{urgent seller only}\\
p\geq0.688&\text{both sellers}.
\end{array}
\tag{7}
\]

Rejection loses \(\kappa\). Every price in the second row is strictly above
\(q_L\) and buys the same profile as \(q_L\). Every price in the third row is
strictly above \(q_H\) and buys the same profile as \(q_H\). This proves that
there is no off-path buyer deviation, including at \(p=0.668\) and
\(p=0.688\). Together with (4)--(5), the raw PBE check passes.

This remains a numerical fixed-point certificate, not an interval-arithmetic
existence proof. Note 132 already describes it as a numerical existence
certificate.

## 3. Exact contingent-plan domain

Let

\[
\bar R=\mathbb E[R(b)\mid p]\in[\underline R,\overline R].
\]

At an unexpected price \(p\), the urgent seller compares \(p\) with
\(\bar R-\Delta\), while the patient seller compares it with \(\bar R\).
Let \(x\) and \(y\) be their respective mixing probabilities at
indifference. Sequentially rational contingent plans therefore have the two
nested branches

\[
(x,0),\qquad (1,y).
\]

Because buyer willingness is common across seller states, a plan matters to
the buyer only through aggregate acceptance

\[
r=Aa_L+\pi a_H.
\]

The first branch traces \(r\in[0,A]\); the second traces
\(r\in[A,1]\). A branch is available at price \(p\), however, only if the
posterior mean needed for seller indifference lies in
\([\underline R,\overline R]\). The exact union
\(\mathcal A_r(p)\) is

\[
\mathcal A_r(p)=
\begin{cases}
\{0\},
&0\leq p<\underline R-\Delta=0.452,\\
[0,A],
&0.452\leq p<\underline R=0.472,\\
[0,1],
&0.472\leq p\leq\overline R-\Delta=0.668,\\
[A,1],
&0.668<p\leq\overline R=0.688,\\
\{1\},
&p>0.688.
\end{cases}
\tag{8}
\]

For example, an urgent seller can mix only when
\(\bar R=p+\Delta\), so the first branch exists only for
\(p\in[0.452,0.668]\). A patient seller can mix only when
\(\bar R=p\), so the second branch exists only for
\(p\in[0.472,0.688]\).

Equation (8) was the missing qualification in the audited draft of Note 132. The complete
two-branch envelope maps to \([0,1]\), but not every point of that envelope is
rationalizable at every price.

## 4. Correct strict-gain D1 characterization

Write

\[
z=w(b)+d
\]

and

\[
U^\star(z)
=\max\{0,A(z-q_L)-\kappa,z-q_H-\kappa\}.
\]

Under aggregate response \(r\), the deviation payoff is

\[
r(z-p)-\kappa.
\]

Whenever a type can gain, its strict-gain set is the tail of the available
response domain above

\[
\tau(z;p)
=\frac{\kappa+U^\star(z)}{z-p}.
\tag{9}
\]

The two equilibrium marginal values are

\[
z_L=q_L+\frac{\kappa}{A}
=0.606756515147,
\tag{10}
\]

\[
z_H=\frac{q_H-Aq_L}{\pi}
=0.700658804391.
\tag{11}
\]

### 4.1 Very low prices: \(0\leq p<0.452\)

By (8), \(\mathcal A_r(p)=\{0\}\). Every deviation payoff equals
\(-\kappa<U^\star(z)\). Thus every type has empty weak- and strict-gain sets.
No type D1-dominates another, and **all buyer types are D1-undominated**.

This is the region omitted by the audited draft. D1 nevertheless permits belief on
the type used below, and both seller types reject such a low price.

### 4.2 Undercuts with a nontrivial response:
\(0.452\leq p<q_L\)

For waiting types, (9) is

\[
\tau(z;p)=\frac{\kappa}{z-p},
\]

which decreases up to \(z_L\). For probing types,

\[
\tau(z;p)=\frac{A(z-q_L)}{z-p},
\]

whose derivative has the sign of \(q_L-p>0\). For knockout types,

\[
\tau(z;p)=\frac{z-q_H}{z-p},
\]

whose derivative has the sign of \(q_H-p>0\). The unique minimizing value is
therefore \(z=z_L\).

Moreover,

\[
\tau(z_L;p)
=\frac{\kappa}{z_L-p}<A
\]

for every \(p<q_L\). The strict-gain tail is consequently nonempty even when
the available domain is only \([0,A]\). Every nonmarginal type's weak-gain
set is strictly contained in a \(z_L\)-type's strict-gain set. Exactly the
types with \(z=z_L\) are D1-undominated.

D1 does not rank types with the same \(z\). Choose the largest feasible
\(b\), which has \(d=0\):

\[
b_L^0=0.699522891097.
\]

The independently reproduced seller margin is

\[
C_L(b_L^0)-q_L=0.009043008127>0.
\tag{12}
\]

Hence both seller types reject every \(p<q_L\) under this D1-permitted
posterior.

The same posterior is also permitted in the very-low-price region, where D1
deletes no type. Thus (12) deters every off-path price below \(q_L\), though
the survivor argument differs across the threshold \(0.452\).

### 4.3 Prices between the menu points:
\(q_L<p<q_H\)

This interval lies inside \([0.472,0.668]\), so (8) gives the complete domain
\([0,1]\). On the probing piece, the derivative of (9) has the sign of
\(q_L-p<0\); on the knockout piece it has the sign of \(q_H-p>0\).
The unique minimizing value is therefore \(z=z_H\).

The largest feasible value among types with \(z=z_H\) is

\[
b_H^0=1,
\qquad
d_H^0=z_H-w(1)=0.012658804391.
\]

Under belief on this type,

\[
C_L(1)-q_H=0.024292340229>0,
\]

\[
C_H(1)-q_H=0.044292340229>0.
\tag{13}
\]

Both seller types therefore reject every \(p<q_H\). Note 132 checks only the
second inequality and then observes correctly that urgent-only acceptance at
a price above \(q_L\) could not help. Equation (13) gives the stronger direct
response.

### 4.4 Prices above the knockout:
\(p>q_H\)

No buyer type can weakly gain under any \(r\in[0,1]\). If \(z\leq p\),

\[
r(z-p)-\kappa\leq-\kappa<0\leq U^\star(z).
\]

If \(z>p\), then

\[
r(z-p)-\kappa
\leq z-p-\kappa
<z-q_H-\kappa
\leq U^\star(z).
\]

Thus all weak- and strict-gain sets are empty and D1 again deletes no type.
The deviation is unprofitable independently of the posterior and of which
subset of (8) is available.

At \(q_L\) and \(q_H\), Bayes' rule applies because both prices are on path.
The four regions above exhaust the nonnegative off-path price set.

### Corrected survivor table

\[
\begin{array}{c|c|c}
\text{price region}&\mathcal A_r(p)&\text{D1-undominated types}\\ \hline
[0,0.452)&\{0\}&\text{all types}\\
[0.452,q_L)&[0,A]\text{ or }[0,1]&z=z_L\\
(q_L,q_H)&[0,1]&z=z_H\\
(q_H,\infty)&\text{as in (8)}&\text{all types}.
\end{array}
\tag{14}
\]

The beliefs in (12)--(13), together with payoff dominance above \(q_H\),
establish an interim-D1-compatible completion. The proposition's refinement
conclusion is therefore valid after repairing its price partition.

## 5. Interpretation and presentation findings

### 5.1 “Seller urgency alone” needs qualification

The buyer has a nondegenerate private urgency \(d\) in the audited
calibration, and buyer sorting depends on \(z=w(b)+d\). The construction
proves that:

- seller urgency is the only private seller-side screening state;
- seller urgency creates bilateral surplus that can support some offers by
  buyers with \(d=0\); and
- common buyer willingness across seller states collapses D1 to the scalar
  \(z\).

It does not prove that seller urgency alone, with \(d\equiv0\), generates the
reported full-menu equilibrium or all of its early trade. Claims that seller
urgency “does both jobs” should be read in the first, seller-state sense or
weakened accordingly.

### 5.2 Minor source-formatting defects

Note 132 uses plain parentheses where LaTeX inline delimiters were evidently
intended throughout Sections 2--4, for example "(G)", "(n=2)", and
"(q_L)". Equation (5) also contains the literal text "qquad" without the
leading backslash. These defects do not affect the mathematics but should be
fixed before any reader-facing use.

## 6. Final classification

**Verified**

- the reported fixed point to doubled quadrature resolution;
- positive action masses and globally ordered buyer cutoffs;
- both on-path seller responses;
- all raw-PBE deviations, including continuation-threshold endpoints;
- existence of an interim-D1-compatible completion.

**Corrections integrated in the current Note 132**

- the claim that only \(z=z_L\) survives D1 for every \(p<q_L\);
- the missing response-domain qualification (8);
- the unqualified "seller urgency alone" interpretation;
- minor LaTeX source corruption.

**Not claimed**

- a formal interval enclosure of an exact fixed point;
- uniqueness or belief-independent implementation;
- an equilibrium with degenerate buyer urgency \(d\equiv0\).
