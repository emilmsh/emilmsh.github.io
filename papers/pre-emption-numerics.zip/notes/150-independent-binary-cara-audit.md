---
type: independent-theory-audit
status: main-proposition-passes-open-region-scope-repair
last_updated: 2026-07-26
audited_note: 147-risk-aversion-stronger-equilibrium-results.md
audited_code: ../code/risk_aversion_strong_binary_cara_certificate.py
---

# Independent audit of the binary-CARA refined equilibrium

## 1. Verdict

The binary zero-urgency equilibrium in Note 147 passes this independent
audit. I reconstruct the CARA payoff equations, the raw PBE, the complete
posterior-rationalizable receiver-plan set, and both variable-branch D1
rankings below. I find no omitted off-path price cell and no reversed
inequality that invalidates Proposition 1.

The supplied Arb program also reproduces successfully under
`python-flint==0.9.0`. Its interval claims are narrower than the complete
theorem, but they cover the numerical ingredients that the analytic proof
actually needs: the root brackets, sorting margins, continuum low-price
rankings, seller signs, high-price cutoff, knockout inequalities, IFT
diagonal entries, and the thickening derivative.

There are three qualifications.

1. The main binary proposition has no blocker.
2. The phrase “lower root” for \(\alpha_H\) is not established by the
   certificate. The program proves existence and uniqueness only inside the
   displayed \(\alpha_H\) box. Nothing in Proposition 1 requires a global
   root ranking, so this is a wording repair.
3. Corollary 1 is an open calibrated family in the four declared coordinates
   \((\pi,\kappa,\alpha_L,\lambda)\), with \(\alpha_H\) solved as part of the
   continuation. It is not an open neighborhood in the natural full
   primitive vector
   \((\pi,\kappa,\alpha_L,\alpha_H,\lambda)\). If “open parameter region” is
   meant in the full-dimensional sense, that claim is not proved.

Corollary 2 is a valid local analytic thickening argument: it constructs
particular absolutely continuous two-band distributions for all sufficiently
small widths. The Arb program certifies the nonzero derivative and the
strict binary margins at width zero; it does not enclose an explicit positive
width or certify a full band equilibrium at a reported
\(\varepsilon>0\). The result should therefore remain classified as an
existential IFT-and-continuity corollary, not as a positive-radius interval
certificate.

## 2. Reproduction of the certificate

I reran

```text
$env:PYTHONPATH='C:\tmp\codex_pyflint'
& 'C:\Users\EmilMathiasStrømHals\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' code\risk_aversion_strong_binary_cara_certificate.py
```

with `python-flint==0.9.0` at 80 decimal digits. It exits successfully and
reproduces, among other quantities,

\[
\begin{aligned}
q
&=.655960451221776724309094715318\ldots,\\
\beta
&\in
[.811699930342777,\ .811699930342781],\\
\alpha_H
&\in
[2.78802798023663,\ 2.78802798043663],\\
p^\dagger
&\in
[.7916264605331845,\ .7916264666103468].
\end{aligned}
\tag{1}
\]

The decisive reproduced strict margins include

\[
\begin{array}{c|r}
\text{quantity}&\text{outward-rounded bound}\\ \hline
2/7-(e^{\alpha_H\kappa}-1)&.25744171366\pm4.28\cdot10^{-12}\\
\sup N_{\alpha_H}(b,1/3)&-.1731567991586961\ldots\\
\inf(\Gamma_L-\Gamma_H)/\delta&7.824085724857545\ldots\\
R_2(1)-q&.0107062154448899\ldots\\
E[R_7\mid B\geq\beta]-q&.1954402118990\pm2.93\cdot10^{-14}\\
7/8-p^\dagger&.08337354\pm6.62\cdot10^{-9}\\
\mathcal G_c(\alpha_H,0)&-.0005138999\pm4.42\cdot10^{-11}.
\end{array}
\tag{2}
\]

The output probabilities are

\[
(.90584996517139,\ .047075017414305,\ .047075017414305)
\tag{3}
\]

for no offer, rejection, and early agreement. Every ball in (3) is strictly
positive.

## 3. CARA payoff reconstruction

Let \(X_n(b)=(b-Y_{1n})^+\) be the early buyer's terminal-auction
monetary surplus in demand state \(n\). With CARA coefficient \(\alpha>0\),
the buyer maximizes expected utility \(-E[e^{-\alpha x}]\), equivalently
minimizes the exponential cost moment. Define

\[
M_n(b,\alpha)
=E[e^{-\alpha X_n(b)}],
\qquad
Z_n(b,\alpha)
=e^{\alpha b}M_n(b,\alpha)
=E[e^{\alpha\min\{b,Y_{1n}\}}].
\tag{4}
\]

Under the equal demand prior, waiting has moment

\[
W(b,\alpha)=\frac{M_2(b,\alpha)+M_7(b,\alpha)}2.
\tag{5}
\]

If a price \(p\) is accepted in state \(L\) with probability \(r\) and in
state \(H\) with probability \(x\), the deviation moment is

\[
\begin{aligned}
D(b,\alpha;p,r,x)
=e^{\alpha\kappa}\bigg[
&\frac12\{r e^{-\alpha(b-p)}+(1-r)M_2\}\\
&+\frac12\{x e^{-\alpha(b-p)}+(1-x)M_7\}
\bigg].
\end{aligned}
\tag{6}
\]

The proposed on-path response is \((r,x)=(1,0)\), so probing at \(q\)
has moment

\[
P(b,\alpha;q)
=e^{\alpha\kappa}
\left[
\frac12e^{-\alpha(b-q)}
+\frac12M_7(b,\alpha)
\right].
\tag{7}
\]

Multiplying \(2(W-P)\) by \(e^{\alpha b}>0\) gives

\[
F(b,\alpha;q)
=Z_2(b,\alpha)
-e^{\alpha(q+\kappa)}
-(e^{\alpha\kappa}-1)Z_7(b,\alpha).
\tag{8}
\]

Thus \(F<0\) means strict waiting and \(F>0\) means strict probing. The
derivative is

\[
F_b
=\alpha e^{\alpha b}
\left[
(1-b^2)
-(e^{\alpha\kappa}-1)(1-b^7)
\right].
\tag{9}
\]

Because

\[
\frac{1-b^2}{1-b^7}\geq\frac27
\tag{10}
\]

and the certificate proves
\(e^{\alpha_H\kappa}-1<2/7\), \(F\) is strictly increasing in \(b\)
for both coefficient classes.

The risk-neutral seller's continuation revenue is

\[
R_n(b)
=\frac{n-1}{n+1}+b^n-\frac{n}{n+1}b^{n+1}.
\tag{11}
\]

Its statewise ranges are

\[
R_2([0,1])=[1/3,2/3],
\qquad
R_7([0,1])=[3/4,7/8].
\tag{12}
\]

These disjoint intervals drive both the raw completion and the complete
receiver-plan partition.

## 4. Root equations and on-path PBE

The construction sets \(\alpha_L=.37\) and imposes

\[
F(1,\alpha_L;q)=0.
\tag{13}
\]

Since \(F_b>0\), every \(\alpha_L\) buyer below \(b=1\) strictly waits.
The top tie is assigned to waiting.

The high-curvature cutoff and the low-state boundary price solve

\[
F(\beta,\alpha_H;q)=0,
\qquad
q=E[R_2(B)\mid B\geq\beta]
=\frac{3+\beta+\beta^2-\beta^3}{6}.
\tag{14}
\]

The second expression is strictly increasing in \(\beta\in(0,1)\).
The beta sign bracket therefore gives its unique solution. The
\(\alpha_H\) sign bracket and \(F_\alpha>0\) give a unique
\(\alpha_H\) solution inside the reported box. They do not establish that
this box contains the globally “lower” positive root of the unrestricted
equation.

The resulting buyer strategy is

\[
\begin{array}{c|c}
\alpha=\alpha_L&\text{wait for every }b,\\
\alpha=\alpha_H,\ b<\beta&\text{wait},\\
\alpha=\alpha_H,\ b\geq\beta&\text{offer }q.
\end{array}
\tag{15}
\]

Conditional on the offer, \(B\) is uniform on \([\beta,1]\). Equation
(14) makes seller \(L\) indifferent; the equilibrium tie break is
acceptance. The certificate gives

\[
E[R_7(B)\mid B\geq\beta]-q>0,
\tag{16}
\]

so seller \(H\) strictly rejects. With coefficient mass \(1/2\), the
attempt probability is \((1-\beta)/2\), and each demand state receives
half of it. This gives (3).

## 5. Raw-PBE completion

After every off-path price, place probability one on \(b=1\). The
coefficient is irrelevant to the risk-neutral seller. Sequential
optimality gives

\[
\begin{array}{c|c}
p<2/3&(0,0),\\
2/3\leq p<7/8&(1,0),\\
p\geq7/8&(1,1),
\end{array}
\tag{17}
\]

with acceptance at the two equality boundaries.

Every raw deviation is unprofitable:

- If \(p<2/3\), both states reject. The moment is
  \(e^{\alpha\kappa}W>W\), so the buyer pays the attempt cost and reaches
  the same auction.
- If \(2/3\leq p<7/8\), the response is the same \(L\)-only allocation
  as on path, but \(p>q\). Hence
  \(P(b,\alpha;p)>P(b,\alpha;q)\geq E^*(b,\alpha)\).
- If \(p\geq7/8\), both states accept. Relative to probing at \(q\), the
  sign of the moment difference is the sign of

\[
e^{\alpha p}
-\frac12e^{\alpha q}
-\frac12Z_7(b,\alpha).
\tag{18}
\]

Expression (18) decreases in \(b\), increases in \(p\), and is certified
strictly positive at \((b,p)=(1,7/8)\) for both coefficients. Thus the
all-state deviation is worse than the on-path probe at every value and
therefore also worse than \(E^*=\min\{W,P(q)\}\).

This proves the raw PBE.

## 6. Complete rationalizable response-plan partition

For any common posterior over buyer types, seller \(n\)'s rejection value
lies in the interval in (12). Conversely, every point in each interval is
attainable by a degenerate posterior on a suitable \(b\). Therefore the
complete set of posterior-rationalizable receiver plans is

\[
\begin{array}{c|c}
\text{price}&\text{plans}\\ \hline
p<1/3&(0,0),\\
1/3\leq p\leq2/3&(r,0),\quad r\in[0,1],\\
2/3<p<3/4&(1,0),\\
3/4\leq p\leq7/8&(1,x),\quad x\in[0,1],\\
p>7/8&(1,1).
\end{array}
\tag{19}
\]

The endpoint overlaps are intentional. At \(p=1/3\) or \(2/3\),
seller \(L\) can be indifferent; at \(p=3/4\) or \(7/8\), seller \(H\)
can be indifferent. Because the continuation intervals are disjoint, the two
seller coordinates can never vary simultaneously. Equation (19) therefore
omits no receiver-action branch.

## 7. Low-price D1 ranking

Let \(E^*=\min\{W,P(q)\}\). On the \((r,0)\) branch, increasing \(r\)
improves a deviation only if

\[
M_2(b,\alpha)>e^{-\alpha(b-p)}.
\tag{20}
\]

When (20) holds, the strict-gain set is the upper interval
\((r(b,\alpha;p),1]\), where

\[
r(b,\alpha;p)
=
\frac{e^{\alpha\kappa}W-E^*}
{\frac12e^{\alpha\kappa}
[M_2-e^{-\alpha(b-p)}]}.
\tag{21}
\]

If the denominator is nonpositive, no value of \(r\) can generate a gain:
at \(r=0\) the buyer already has the strictly worse moment
\(e^{\alpha\kappa}W\), and increasing \(r\) then weakly raises it.

For an equilibrium prober or wait--probe boundary type, (21) reduces to

\[
r_F(b,\alpha;p)
=
\frac{Z_2(b,\alpha)-e^{\alpha q}}
{Z_2(b,\alpha)-e^{\alpha p}}.
\tag{22}
\]

For \(p<q\), this threshold is strictly increasing in \(Z_2\), hence in
\(b\). A prober slice is therefore minimized at its lower value boundary.

For a waiter, differentiation of (21) gives the sign index

\[
N_\alpha(b,p)
=(S_2+S_7)(Z_2-e^{\alpha p})
-S_2(Z_2+Z_7),
\qquad
S_n=1-b^n.
\tag{23}
\]

The analytic \(5/9\) bound makes (23) negative for every
\(\alpha_L\) waiter and every \(p\geq1/3\). The interval subdivision
certifies it is negative for every \(\alpha_H\) waiter
\(b\leq\beta\). Thus the two within-class minima are

\[
(1,\alpha_L)
\quad\text{and}\quad
(\beta,\alpha_H).
\tag{24}
\]

For these two boundary types, write
\(X_i=Z_2(b_i,\alpha_i)-e^{\alpha_iq}>0\) and
\(\delta=q-p\). Then

\[
r_i(p)=\frac1{1+\Gamma_i(\delta)},
\qquad
\frac{\Gamma_i(\delta)}{\delta}
=
\frac{\alpha_i e^{\alpha_iq}}{X_i}
\frac{1-e^{-\alpha_i\delta}}{\alpha_i\delta}.
\tag{25}
\]

The 512-cell interval calculation covers
\(\delta\in[0,.323]\supset[0,q-1/3]\) and proves

\[
\frac{\Gamma_L(\delta)-\Gamma_H(\delta)}{\delta}>7.824.
\tag{26}
\]

Consequently

\[
r_L(p)<r_H(p)
\quad\text{for every }p\in[1/3,q).
\tag{27}
\]

The unique global D1 survivor is therefore
\(\theta_L^*=(1,\alpha_L)\). Under that belief,

\[
p<q<R_2(1)<R_7(1),
\tag{28}
\]

so both sellers reject. The deviation reaches the same auction after paying
\(\kappa\) and is unprofitable.

The inequality direction is important and is correct: the certificate proves
\(\Gamma_L>\Gamma_H\), which implies
\(1/(1+\Gamma_L)<1/(1+\Gamma_H)\). The lower-curvature endpoint has the
larger strict-gain set.

## 8. High-price D1 ranking

On the \((1,x)\) branch, the hypothetical-prober threshold is

\[
x_T(b,\alpha;p)
=
\frac{e^{\alpha p}-e^{\alpha q}}
{Z_7(b,\alpha)-e^{\alpha p}}.
\tag{29}
\]

A waiter has a weakly larger numerator and hence a weakly higher threshold.
For fixed \(\alpha\), \(Z_7\) increases in \(b\), so (29) is minimized at
\(b=1\).

At \(b=1\), put \(\Delta=p-q>0\). Up to the common demand-prior factor,
(29) is the ratio of

\[
\frac{1-e^{-\alpha\Delta}}{\alpha}
\quad\text{and}\quad
\frac{E[e^{\alpha(Y_{1,7}-p)}]-1}{\alpha}.
\tag{30}
\]

The first expression strictly decreases in \(\alpha\). The second strictly
increases because

\[
\frac{d}{d\alpha}
\frac{e^{\alpha z}-1}{\alpha}
=
\frac{e^{\alpha z}(\alpha z-1)+1}{\alpha^2}\geq0
\tag{31}
\]

for every real \(z\). Its expectation is positive for
\(p\leq E[Y_{1,7}]=7/8\), strictly so by Jensen's inequality.
Therefore the unique global threshold minimizer is

\[
\theta_H^*=(1,\alpha_H).
\tag{32}
\]

Its threshold reaches one at

\[
p^\dagger
=\frac1{\alpha_H}
\log\left[
\frac{e^{\alpha_Hq}+Z_7(1,\alpha_H)}2
\right].
\tag{33}
\]

For \(3/4\leq p<p^\dagger\), D1 selects \(\theta_H^*\).
Seller \(H\) then rejects because
\(p<p^\dagger<7/8=R_7(1)\). Seller \(L\) accepts, but the resulting
\(L\)-only allocation costs more than the on-path price \(q\).

For \(p\geq p^\dagger\), even the smallest threshold is at least one.
No buyer has a strict gain for any \(x\in[0,1]\). This includes the exact
boundary \(p=p^\dagger\), where the top high-curvature type is only
indifferent at \(x=1\).

## 9. Audit of the whole price line

The following table combines the raw-PBE and D1 arguments.

| price region | rationalizable variation | reason no deviation survives |
|---|---|---|
| \(p<1/3\) | fixed \((0,0)\) | rejection in both states plus \(\kappa\) |
| \(1/3\leq p<q\) | \((r,0)\) | D1 selects \(\theta_L^*\); both sellers reject |
| \(q<p\leq2/3\) | \((r,0)\) | both endpoint moments exceed \(E^*\), hence every mixture does |
| \(2/3<p<3/4\) | fixed \((1,0)\) | same allocation as at \(q\), higher price |
| \(3/4\leq p<p^\dagger\) | \((1,x)\) | D1 selects \(\theta_H^*\); \(H\) rejects |
| \(p^\dagger\leq p\leq7/8\) | \((1,x)\) | no strict gain even at \(x=1\) |
| \(p>7/8\) | fixed \((1,1)\) | certified knockout inequality |

At \(q\), Bayes' rule applies. At \(2/3\) and \(7/8\), the relevant
seller can mix under some posterior, as recorded in (19); the proposed
belief and tie break select acceptance. At \(p^\dagger\), D1 is
unrestrictive because all strict-gain sets are empty. These exact endpoints
do not create missing cells.

The only proof step that Note 147 compresses too heavily is the
\(q<p\leq2/3\) row. It is nevertheless valid. At \(r=0\), the deviation
moment is \(e^{\alpha\kappa}W>E^*\). At \(r=1\), it is
\(P(p)>P(q)\geq E^*\). Equation (6) is affine in \(r\), so every
intermediate response is also worse. This fills the apparent gap without an
additional numerical assumption.

## 10. What the Arb program does and does not certify

The program directly certifies:

- the exact endpoint identity defining \(q\);
- sign brackets for \(\beta\) and \(\alpha_H\), global beta monotonicity,
  and local \(\alpha_H\) uniqueness inside its box;
- the global one-cutoff margin for both coefficient atoms;
- the complete high-curvature waiter inequality on
  \([0,.812]\);
- the normalized cross-curvature inequality for every probing undercut;
- on-path seller signs, the top-belief rejection margin, and both
  all-state knockout margins;
- the high-price cutoff and \(7/8-p^\dagger>0\);
- the three nonzero diagonal entries used in the binary IFT;
- the lower-endpoint \(\alpha\) derivative and the continuous-thickening
  center derivative; and
- positive attempt, rejection, and agreement masses.

The program does not directly interval-certify:

- the response-plan partition (19), which follows analytically from the
  disjoint continuation ranges;
- the high-price ordering in (29)--(32), which is analytic;
- the fixed-response and \(q<p\leq2/3\) no-gain arguments;
- a global ordering of all positive roots of
  \(F(\beta,\alpha;q)=0\);
- a numerical radius for the IFT neighborhood in Corollary 1; or
- any explicit \(\varepsilon>0\) two-band equilibrium.

These distinctions do not weaken Proposition 1. They do matter for how the
two robustness corollaries are labeled.

## 11. Audit of the open-neighborhood claim

For

\[
z=(\pi,\kappa,\alpha_L,\lambda),
\tag{34}
\]

Note 147 writes three equations in the three unknowns
\((q,\beta,\alpha_H)\):

\[
\begin{aligned}
G_1(q;z)&=F_z(1,\alpha_L;q),\\
G_2(q,\beta)&=E[R_2(B)\mid B\geq\beta]-q,\\
G_3(q,\beta,\alpha_H;z)&=F_z(\beta,\alpha_H;q).
\end{aligned}
\tag{35}
\]

Their Jacobian has the lower-triangular pattern

\[
\begin{pmatrix}
G_{1q}&0&0\\
-1&G_{2\beta}&0\\
G_{3q}&G_{3\beta}&G_{3\alpha_H}
\end{pmatrix}.
\tag{36}
\]

The certificate proves all three diagonal entries are bounded away from
zero. The IFT therefore does exactly establish a unique local map

\[
(q,\beta,\alpha_H)=g(z)
\tag{37}
\]

for every \(z\) in some open neighborhood of the four-dimensional base
point. The normalized D1 inequalities and all seller and knockout margins
are strict on compact price branches, so the same assessment persists along
this map after shrinking the neighborhood. The coefficient mass
\(\lambda\) does not enter (35), and its local continuation is immediate.

The scope issue is that \(\alpha_H\) is itself a primitive support point of
the buyer's coefficient distribution. In the natural five-dimensional
primitive vector

\[
(\pi,\kappa,\alpha_L,\alpha_H,\lambda),
\tag{38}
\]

equation (37) traces a four-dimensional graph. It does not contain an open
five-dimensional ball. Thus:

- Corollary 1 is correct if read as an open four-parameter family in which
  the second coefficient support point is recalibrated endogenously; but
- it does not prove robustness to an independent perturbation of
  \(\alpha_H\), and it should not be advertised as a full-dimensional open
  primitive region.

This is the only substantive scope blocker found in the binary part.

## 12. Audit of the continuous two-band thickening

For the lower band

\[
[\alpha_L-\varepsilon,\alpha_L],
\tag{39}
\]

the certified sign
\(F_\alpha(1,\alpha_L;q)>0\), the endpoint identity
\(F(1,\alpha_L;q)=0\), and \(F_b>0\) imply that every sufficiently
nearby lower-band coefficient waits at every value below one. The endpoint
\((1,\alpha_L)\) remains the only binary-boundary tie.

For \(\alpha\) near \(\alpha_H\), \(F_b>0\) gives a smooth cutoff
\(\beta(\alpha)\). Define

\[
H(\alpha)
=\int_{\beta(\alpha)}^1[R_2(b)-q]\,db.
\tag{40}
\]

The upper-band seller equation is

\[
\mathcal G(c,\varepsilon)
=\frac12\int_{-1}^1H(c+\varepsilon t)\,dt=0.
\tag{41}
\]

At the binary point,

\[
\beta'(\alpha_H)=-\frac{F_\alpha}{F_b}<0
\tag{42}
\]

and

\[
\mathcal G_c(\alpha_H,0)
=H'(\alpha_H)
=-[R_2(\beta)-q]\beta'(\alpha_H)<0.
\tag{43}
\]

The last inequality has the certified margin in (2). The ordinary IFT
therefore supplies a center \(c(\varepsilon)\) for every sufficiently small
positive \(\varepsilon\). Equation (41) is exactly the low-state seller's
pooled zero-rent numerator; the omitted density and band-width factors are
strictly positive constants and do not affect its zero.

The refinement continuation is also logically sound:

- the low-slice waiter ordering is uniform for coefficients just below
  \(\alpha_L\);
- the strict high-waiter and normalized cross-band bounds persist on small
  compact coefficient neighborhoods;
- any surviving low-band undercut belief is supported at \(b=1\), so both
  sellers reject;
- the high-price threshold decreases in \(\alpha\), selecting the largest
  upper-band coefficient at \(b=1\); and
- seller and knockout inequalities persist by their strict binary margins.

This proves an existential two-band corollary. It does not supply a
computable \(\varepsilon_0\), an interval enclosure for
\(c(\varepsilon)\) at a positive width, or an open neighborhood in a space
of coefficient densities. None of those stronger claims should be
attributed to the current certificate.

## 13. Final claim ledger

**Passes**

- the binary CARA payoff and sorting equations;
- the certified root boxes and all reported interval margins;
- the raw probing-only PBE with positive no-offer, rejection, and agreement;
- the complete rationalizable receiver-plan partition;
- the complete low- and high-price strict-gain D1 rankings;
- the whole-price-line off-path completion;
- Proposition 1; and
- the existential continuous two-band IFT construction.

**Needs a scope or wording repair**

- “the lower root” should become “the unique root in the certified box”
  unless a global root-order proof is added;
- “open parameter region” should be identified as a four-parameter
  calibrated family with \(\alpha_H\) adjusted by (37), not a
  full-dimensional open set of all distribution primitives; and
- the two-band corollary should remain labeled analytic and local, with no
  implication that a positive band width was itself interval-certified.

**Not established**

- global root or equilibrium uniqueness;
- robustness to arbitrary independent perturbations of both coefficient
  atoms;
- an explicit IFT neighborhood or positive two-band width;
- an open set of absolutely continuous coefficient densities; or
- the connected-support continuum candidate from Note 134.
