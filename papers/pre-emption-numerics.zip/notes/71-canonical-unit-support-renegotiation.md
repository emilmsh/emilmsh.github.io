# A canonical unit-support renegotiation equilibrium

**Status (2026-07-20).** This note gives the cleanest parameter example for
the unrestricted renegotiation extension. The early buyer and every late
bidder have values \(U[0,1]\), and the continuous component of buyer urgency
is also \(U[0,1]\). A positive atom on zero urgency can be added over an
explicit large interval. The construction uses the posterior-consistent
recursive completion from note 70, so it does not rely on the special
low-type tail belief in notes 64 and 68.

The result is a PBE. A selected atom-preserving, full-support Bayes-limit
regularization reproduces its off-path beliefs. This is a belief-consistency
check under one perturbation family, not a formal generalized sequential-
equilibrium proof. Dynamic D1, forward induction, global tremble invariance,
uniqueness, and belief-independent implementation are not established.

## 1. Primitives and auction values

The early buyer's match value and every late bidder's value are drawn from
\[
F=U[0,1].
\tag{1}
\]
There are \(n_L=2\) late bidders in state \(L\) and \(n_H=5\) in state
\(H\), with
\[
\pi=\Pr(H)=\frac3{10},
\qquad
A:=1-\pi=\frac7{10}.
\tag{2}
\]
The buyer's urgency distribution is
\[
G_\eta
=\eta\delta_0+(1-\eta)U[0,1],
\qquad \eta\in[0,1].
\tag{3}
\]
More explicitly, let \(b\), \(s\), \(d_B\), and an i.i.d.\ sequence
\((Y_i)_{i\geq1}\) be mutually independent, with
\(b,Y_i\sim U[0,1]\) and \(d_B\sim G_\eta\); the first \(n_s\) late bidders
participate in state \(s\). Write \(d:=d_B\) below. Seller urgency is public
and normalized to \(d_S=0\).

With \(n\) late uniform values, the buyer's auction willingness and the
seller's auction continuation value are
\[
w_n(b)=b-\frac{b^{n+1}}{n+1},
\tag{4}
\]
\[
C_n(b)
=\frac{n-1}{n+1}+b^n-\frac{n}{n+1}b^{n+1}.
\tag{5}
\]
Write \(w_L=w_2,w_H=w_5,C_L=C_2,C_H=C_5\). The proposal costs are
\[
\kappa=\frac1{2000},
\qquad
c_B=\frac1{1000},
\qquad
c_S=\frac1{500}.
\tag{6}
\]

The buyer may wait for the planned auction or pay \(\kappa\) to make the
initial binding proposal. Thereafter proposals alternate. At every response,
the recipient may accept, end bargaining and activate the unchanged auction,
or counter. Each later buyer proposal costs \(c_B\), and each seller
counteroffer costs \(c_S\).
All three costs are borne by the relevant proposer and are not
transfers. If bargaining stops after finitely many proposals, acceptance
implements early trade and termination activates the auction, in either case
net of accumulated proposal costs. If proposals continue forever,
the completion assigns planned-auction payoffs net of all accumulated
proposal costs, with payoff \(-\infty\) for a party whose cost sum diverges.
Because \(c_B,c_S>0\), perpetual alternation gives both parties
\(-\infty\).

## 2. Prices and buyer thresholds

Let
\[
\beta:=\frac9{10},
\qquad
q:=\frac12.
\tag{7}
\]
Since
\[
w_L(\beta)=\frac{657}{1000},
\tag{8}
\]
choose
\[
p:=w_L(\beta)-\frac{c_B+\kappa}{A}
=\frac{573}{875},
\tag{9}
\]
\[
r:=Aw_L(\beta)-\kappa+\pi
=\frac{3797}{5000}.
\tag{10}
\]
Thus
\[
q=0.5<p=0.654857143<r=0.7594.
\tag{11}
\]

After the seller counteroffer \(r\), the buyer can terminate, revise to
\(p\), or accept \(r\). The corresponding continuation payoffs are
\[
0,
\qquad
P(b,d):=A[w_L(b)+d-p]-c_B,
\tag{12}
\]
\[
E(b,d):=Aw_L(b)+\pi w_H(b)+d-r.
\tag{13}
\]
The revision-termination, initiation, and acceptance-revision thresholds are
\[
a(b):=p+\frac{c_B}{A}-w_L(b),
\tag{14}
\]
\[
x(b):=a(b)+\frac{\kappa}{A}
=w_L(\beta)-w_L(b),
\tag{15}
\]
\[
y(b):=\frac{r-Ap-c_B-\pi w_H(b)}{\pi}
=1-w_H(b).
\tag{16}
\]
The last equality follows by substituting (9)--(10). It is the main
algebraic simplification from using unit urgency support.

The endpoint values are
\[
\begin{array}{c|ccc}
&b=0&b=\beta&b=1\\ \hline
x(b)&657/1000&0&-29/3000\\
y(b)&1&377147/2000000&1/6.
\end{array}
\tag{17}
\]
Moreover,
\[
\frac{d}{db}[y(b)-x(b)]=b^5-b^2<0
\quad\text{for }b\in(0,1),
\tag{18}
\]
and \(y(\beta)>x(\beta)=0\). Hence \(x(b)<y(b)\) below \(\beta\), and
\(0<y(b)\) above it.

The initial and post-\(r\) strategies are therefore
\[
\begin{cases}
\text{wait},&b<\beta,\ d<x(b),\\
\text{offer }q,&d\geq\max\{x(b),0\},
\end{cases}
\tag{19}
\]
followed, for every type that reaches \(r\), by
\[
\begin{cases}
\text{terminate},&d<a(b),\\
\text{revise to }p,&a(b)\leq d<y(b),\\
\text{accept }r,&d\geq y(b).
\end{cases}
\tag{20}
\]
Every on-path initiator is above \(x(b)>a(b)\), so termination after \(r\)
does not occur on path. The first row is nevertheless required to define a
best response for types that reach \(r\) only through a tremble.

A patient type \(d=0\) strictly waits when \(b<\beta\). It strictly
initiates and revises when \(b>\beta\), because then
\[
a(b)<x(b)<0<y(b).
\tag{21}
\]
The initial tie at \(b=\beta\) has zero probability under continuous \(F\);
prescribe initiation there.

## 3. Action weights and posteriors

Under the continuous component \(U[0,1]\), define
\[
e_0(b)=x_+(b),
\quad
m_0(b)=y(b)-x_+(b),
\tag{22}
\]
\[
h_0(b)=1-y(b)=w_H(b),
\quad
z_0(b)=1-x_+(b),
\tag{23}
\]
where \(x_+(b):=\max\{x(b),0\}\). These are the conditional probabilities
of waiting, revising, accepting \(r\), and initiating.

The patient atom waits below \(\beta\), revises above \(\beta\), and never
accepts \(r\). Hence
\[
e_\eta(b)
=(1-\eta)e_0(b)+\eta\mathbf 1\{b<\beta\},
\tag{24}
\]
\[
m_\eta(b)
=(1-\eta)m_0(b)+\eta\mathbf 1\{b\geq\beta\},
\tag{25}
\]
\[
h_\eta(b)=(1-\eta)h_0(b),
\tag{26}
\]
\[
z_\eta(b)
=(1-\eta)z_0(b)+\eta\mathbf 1\{b\geq\beta\}.
\tag{27}
\]

Integrating over \(b\sim U[0,1]\) gives
\[
Z_e(\eta)
=\frac{9639+26361\eta}{40000},
\tag{28}
\]
\[
Z_p(\eta)
=\frac{237581-153581\eta}{840000},
\tag{29}
\]
\[
Z_h(\eta)
=(1-\eta)\frac{10}{21},
\tag{30}
\]
\[
Z_q(\eta)
=\frac{30361-26361\eta}{40000}.
\tag{31}
\]
They are respectively the aggregate masses of waiting, revising, accepting
\(r\), and initiating, and satisfy
\[
Z_e+Z_p+Z_h=1,
\qquad
Z_p+Z_h=Z_q.
\tag{32}
\]

Bayes' rule gives the posterior density after \(q\),
\[
f_q^\eta(b)=\frac{z_\eta(b)}{Z_q(\eta)},
\tag{33}
\]
and after \(p\),
\[
f_p^\eta(b)=\frac{m_\eta(b)}{Z_p(\eta)}.
\tag{34}
\]
Define the unnormalized auction continuations
\[
N_{sq}(\eta)
:=\int_0^1z_\eta(b)C_s(b)\,db,
\tag{35}
\]
\[
N_{sp}(\eta)
:=\int_0^1m_\eta(b)C_s(b)\,db.
\tag{36}
\]
The posterior auction values are
\[
\bar C_{sq}(\eta)=\frac{N_{sq}(\eta)}{Z_q(\eta)},
\qquad
\bar C_{sp}(\eta)=\frac{N_{sp}(\eta)}{Z_p(\eta)}.
\tag{37}
\]
Every mass and numerator in (28)--(36) is affine in \(\eta\).

## 4. On-path seller incentives

After \(q\), both seller states counter at \(r\). Before subtracting the
counteroffer cost, their unnormalized payoffs are
\[
V_L(\eta)
:=pZ_p(\eta)+rZ_h(\eta),
\tag{38}
\]
\[
V_H(\eta)
:=N_{Hp}(\eta)+rZ_h(\eta).
\tag{39}
\]
The complete on-path seller inequalities are
\[
V_s-(q+c_S)Z_q>0,
\qquad s\in\{L,H\},
\tag{40}
\]
\[
V_s-c_SZ_q-N_{sq}>0,
\qquad s\in\{L,H\},
\tag{41}
\]
\[
pZ_p-N_{Lp}>0,
\tag{42}
\]
\[
N_{Hp}-pZ_p>0.
\tag{43}
\]
Equations (40)--(41) compare \(r\) with accepting \(q\) and invoking the
auction. Equations (42)--(43) make \(L\) accept \(p\) and \(H\) invoke the
auction.

Exact integration reduces the six left sides to
\[
\begin{array}{c|c}
\text{inequality}&\text{unnormalized strict margin}\\ \hline
L:\ r\text{ versus }q&
\dfrac{97493167-88505167\eta}{588000000}\\[4pt]
L:\ r\text{ versus auction}&
\dfrac{209471659-211036159\eta}{1470000000}\\[4pt]
H:\ r\text{ versus }q&
\dfrac{734314608737-601422352487\eta}{4095000000000}\\[4pt]
H:\ r\text{ versus auction}&
\dfrac{117204341-120480341\eta}{16380000000}\\[4pt]
L:\ p\text{ versus auction}&
\dfrac{266643493-271217293\eta}{5292000000}\\[4pt]
H:\ \text{auction versus }p&
\dfrac{387410369909+104670423841\eta}{28665000000000}.
\end{array}
\tag{44}
\]
The first expression to reach zero is seller \(H\)'s comparison between
\(r\) and the auction after \(q\). Define
\[
\eta^\dagger
:=\frac{117204341}{120480341}
=0.972808842\ldots.
\tag{45}
\]
All other expressions in (44) are strictly positive at
\(\eta^\dagger\).

## 5. Posterior-consistent recursive completion

Let \(h\in\{q,p\}\) denote the preceding on-path buyer offer and set
\[
\varepsilon
:=\frac{c_S-c_B}{2}
=\frac1{2000}.
\tag{46}
\]
At the seller posterior following \(h\), define
\[
\tau_h(\eta)
:=\bar C_{Lh}(\eta)+\varepsilon,
\qquad
T_h(\eta):=\tau_h(\eta)+c_B.
\tag{47}
\]
After an unexpected seller price \(\zeta\), the buyer believes state \(L\).
For the actual buyer type, write \(v=w_L(b)+d\) and prescribe
\[
\begin{array}{c|cc}
&\text{seller price}&\text{buyer response}\\ \hline
v>T_h&\zeta\leq T_h&\text{accept}\\
v>T_h&\zeta>T_h&\text{offer }\tau_h\\
v\leq T_h&\zeta\leq v&\text{accept}\\
v\leq T_h&\zeta>v&\text{terminate}.
\end{array}
\tag{48}
\]
This compares the payoffs \(v-\zeta,v-T_h,0\) and is therefore globally
optimal.

Every type in the \(q\)- or \(p\)-posterior has
\[
v\geq w_L(\beta)>\tau_h(\eta)+c_B.
\tag{49}
\]
Thus all such types pool on \(\tau_h\) following a high seller price, and the
assessment retains the preceding posterior. Seller \(L\) strictly accepts the
tail by \(\varepsilon\), while seller \(H\) strictly invokes the auction.

At \(\eta=\eta^\dagger\), where the first on-path inequality reaches its
boundary, the tail values and the relevant strict margins are
\[
\begin{array}{c|cccc}
h&\tau_h&
w_L(\beta)-T_h&
\bar C_{Hh}-\tau_h&
C_L(1)-\tau_h\\ \hline
q&0.640757946&0.015242054&0.168315372&0.025908721\\
p&0.650315079&0.005684921&0.167132113&0.016351588.
\end{array}
\tag{50}
\]
The unnormalized versions of all three margins are affine in \(\eta\).
They are positive at zero and at \(\eta^\dagger\), and therefore throughout
the interval.

A seller price at or below \(T_h\) yields at most
\[
T_h-c_S
=\bar C_{Lh}+\varepsilon+c_B-c_S
<\bar C_{Lh}.
\tag{51}
\]
Above \(T_h\), seller \(L\) receives \(\tau_h-c_S<\bar C_{Lh}\), while
seller \(H\) invokes the auction and receives
\(\bar C_{Hh}-c_S<\bar C_{Hh}\). Thus a further counteroffer never beats the
posterior auction value. The seller comparisons in (40)--(43) are therefore
exhaustive.

At every unexpected nonspecial buyer price, use the limiting high-match,
high-urgency belief \((b,d)=(1,1)\). Seller acceptance thresholds are then
\(C_L(1)=2/3\) and \(C_H(1)=5/6\). After a seller counter at such a history,
apply (48) to every actual buyer type using
\[
\tau_*:=C_L(1),
\qquad
T_*:=C_L(1)+c_B.
\tag{52}
\]
The believed type can use this tail with margin
\[
w_L(1)+1-T_*=\frac{999}{1000}>0.
\]
Seller \(L\) accepts \(\tau_*\) while indifferent to the auction, seller
\(H\) strictly auctions, and no alternative buyer offer accepted by \(L\)
can be cheaper. Since \(c_S>c_B\), every further seller counteroffer is
strictly worse. Apply the same rules after every longer history.

For a selected Bayes-limit regularization, preserve atoms on the prescribed
\(q\)- and \(p\)-history tails and use shrinking neighborhoods
\[
N_n=\{(b,d):b>1-\delta_n,\ d>1-\delta_n\},
\qquad \delta_n\downarrow0,
\]
whose likelihood density at nonspecial buyer offers dominates that of types
outside \(N_n\), while all tremble probabilities vanish. Bayes' rule then
selects \(\delta_{(1,1)}\). Add a full-support density over prices as in note
70. At every finite public history \(h\) followed by an unexpected seller
price \(\zeta\), choose positive full-support seller subdensities \(\lambda^n_{L,h}(\zeta)\) and
\(\lambda^n_{H,h}(\zeta)\) with vanishing total mass and relative rates such
that the full \(L/H\) likelihood ratio, including the likelihood of \(h\),
diverges pointwise in \(\zeta\). Let these subdensities depend on the state
and public history but not on the buyer's hidden type. They select the
buyer's posterior belief in state \(L\) while leaving the seller's
conditional posterior over buyer types unchanged. Apply the construction
recursively after every longer finite history. Bayes posteriors then converge
to the beliefs used in the PBE under this selected atom-preserving family.
Other type-dependent density perturbations can select different off-path
posteriors.

The high-match thresholds preserve the global buyer-price comparisons:
\[
A[C_L(1)-p]-c_B
=\frac{109}{15000}>0,
\tag{53}
\]
\[
C_H(1)-r
=\frac{1109}{15000}>0,
\tag{54}
\]
\[
A[C_L(1)-p]
=\frac{31}{3750}>0,
\tag{55}
\]
\[
C_H(1)+c_B-r
=\frac{281}{3750}>0.
\tag{56}
\]
These are respectively the binding comparisons with an initial \(L\)-only
offer, an initial both-state offer, a revised \(L\)-only offer, and a revised
both-state offer. They are type-by-type and independent of \(\eta\).

## 6. Existence and patient outcomes

**Proposition 1 (canonical unit-support PBE).** For every
\[
0\leq\eta\leq\eta^\dagger,
\tag{57}
\]
the unrestricted alternating-offer game has a PBE with prices
\((q,r,p)\) and buyer strategies (19)--(20). After \(q\), both seller states
counter at \(r\); after \(p\), seller \(L\) accepts and seller \(H\) invokes
the auction. The optimality inequalities are (38)--(43), and off-path play
uses the recursive completion (46)--(52). All on-path seller actions are strict for
\(0\leq\eta<\eta^\dagger\). At \(\eta=\eta^\dagger\), seller \(H\) is
indifferent between \(r\) and the auction after \(q\), so the stated path is
a weak PBE under the prescribed tie-breaking; above it, \(H\) strictly
prefers the auction. Thus \([0,\eta^\dagger)\) is the maximal interval with
strict on-path seller incentives for this fixed path.

**Proof.** Equations (14)--(21) establish buyer optimality on path.
Equations (53)--(56) establish the initial and post-\(r\) global price
comparisons. For later histories, apply the recursive-tail lemma in note 70:
(48) defines the best response of every actual buyer type, (49)--(50) make
the prescribed tail cheaper than every other accepted buyer offer, and (52)
closes histories carrying the high-type off-path posterior. Equations
(40)--(45) establish all on-path seller actions, while (47)--(51) bound every
off-path seller price by the posterior auction value and close the same
argument recursively. Bayes' rule gives (33)--(37) at the reached buyer
offers, while the assessment retains the same posterior after the off-path
pooling tail. Thus the assessment is a PBE. The strict-window and endpoint
claims follow from the binding expression in (44).
\(\square\)

To discipline off-path beliefs, the regularization above makes Bayes
posteriors converge to the beliefs used under one selected atom-preserving,
full-support perturbation family. This is a belief-consistency check, not a
formal generalized sequential-equilibrium proof. Other type-dependent density
perturbations can select different off-path posteriors. We make no
sequential-equilibrium or dynamic-D1 claim.

For \(0<\eta\leq\eta^\dagger\), literally patient buyers attempt with mass
\[
\Pr(d=0,\text{ attempt})
=\eta(1-\beta)=\frac{\eta}{10}.
\tag{58}
\]
Their attempts fail in state \(H\) and succeed in state \(L\), giving
\[
\Pr(d=0,\text{ attempt then auction})
=\frac{3\eta}{100},
\tag{59}
\]
\[
\Pr(d=0,\text{ early agreement})
=\frac{7\eta}{100}.
\tag{60}
\]
The total outcome probabilities are
\[
\Pr(\text{no attempt})
=\frac{9639+26361\eta}{40000},
\tag{61}
\]
\[
\Pr(\text{attempt then auction})
=\frac{237581-153581\eta}{2800000},
\tag{62}
\]
\[
\Pr(\text{early agreement})
=\frac{1887689-1691689\eta}{2800000}.
\tag{63}
\]
All three outcomes occur with positive probability throughout (57).

For example, at \(\eta=1/100\),
\[
\Pr(\text{no attempt})=0.24756525,
\tag{64}
\]
\[
\Pr(\text{attempt then auction})=0.084301854,
\tag{65}
\]
\[
\Pr(\text{early agreement})=0.668132896.
\tag{66}
\]
The patient attempt, failure, and agreement masses are respectively
\(0.001,0.0003,0.0007\).

## 7. Role among the renegotiation results

This construction supersedes notes 64 and 68 as the preferred numerical
example. It normalizes both match values and the continuous urgency component
to \([0,1]\), incorporates a literal patient atom, and builds the
posterior-consistent recursive completion into the theorem. Notes 64 and 68
remain valid raw-PBE constructions and useful independent checks.

The conceptual division of labor is unchanged. Note 67 gives the general
no-urgency impossibility: if every buyer is patient, positive-cost
pre-emption cannot occur when the unchanged auction remains available.
Consistently, the present fixed path fails before \(\eta=1\). Note 70 gives
the general posterior-consistent tail logic used here. The present note is
the canonical parameter example, not a theorem for arbitrary \(F\), \(G\),
costs, or bargaining protocols.

The self-contained exact-rational script
`code/audit_unit_urgency_patient_atom.py` derives the auction polynomials and
thresholds from scratch, integrates every affine action weight and posterior,
finds the first exact root among all seller and tail inequalities, verifies
all match-value endpoints and global buyer deviations, and reproduces
(28)--(66).
