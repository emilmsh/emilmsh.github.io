# Three-channel aligned-composite recalibration

## Purpose

The earlier aligned numerical example varied late participation and the seller's no-sale fallback but held the seller timing cost fixed. The maintained quantitative example now activates all three aligned microfoundations:

\[
(n_L,v_L,d_{S,L})=(2,.38,.02),\qquad
(n_H,v_H,d_{S,H})=(3,.42,0).
\]

Thus state \(H\) has stronger late participation, a higher fallback, and a more patient seller. With \(\pi=.5\), the prior mean seller timing cost remains .01, matching the former common value while moving continuation values in the aligned direction.

## Full-menu calibration

At \(F=U[0,1]\), \(\kappa=.05\), and rate-10 truncated-exponential buyer urgency on \([0,1]\), the selected boundary-price fixed point is

\[
(q_L,q_H)=(.609022919152066,.715349726668132).
\]

The action masses are

\[
(M_W,M_P,M_K)=(.763873954916,.100548543668,.135577501415),
\]

which imply observed probabilities

\[
(\Pr(W),\Pr(\text{rejection}),\Pr(\text{pre-emption}))
=(.763873954916,.050274271834,.185851773250).
\]

The state-conditional equilibrium no-sale probabilities are .054348676619 and .030986926962, with prior mean .042667801791. Conditional mean prices are .686587543070 among completed pre-emptions and .574123695751 among completed bidding-round sales, a difference of .112463847318.

`code/certify_aligned_composite_full_menu.py` supplies the outward-rounded Arb certificate for the price rectangle, Krawczyk root enclosure, action and outcome masses, seller-response and D1 margins, no-sale probabilities, and positive conditional price difference. `code/audit_aligned_composite_calibration.py` is the independent floating-point cross-check.

## Probing-only calibration

With the same seller states, \(\kappa=.02\), and buyer urgency on \([0,.045]\), the exact waiting-only boundary is .02 and the sufficient waiting--probing window is

\[
.02<\bar d\leq .092821906667.
\]

At \(\bar d=.045\), the probing price is .659155057710 and the attempt mass is .073608826276. The three observable outcome probabilities are .926391173724, .036804413138, and .036804413138.

## Scope of other numerical exercises

The main Section 7 exercise and the Section 5 probing illustration use all three channels. Other exercises may impose common state components when that restriction isolates the intended result: the ban examples hold seller timing costs fixed to vary only the common buyer-value distribution; the disclosure examples hold fallback and timing costs fixed to isolate verifiable participation information; bargaining and risk-aversion exercises retain their own purpose-specific primitives.
