# Heterogeneous buyer risk aversion: a positive refinement gate

**Status (2026-07-23).** This note reopens one narrow question left by Notes
123, 127, and 130. Those notes hold the buyer's CARA coefficient fixed. The
lowest value in a positive-mass probing pool is then the type most willing to
undercut, and the low-demand seller accepts under the resulting D1 belief.
Here the CARA coefficient is an additional private, continuously distributed
buyer type. A bounded demand-only calibration reverses the relevant
conclusion: the wait--probe frontier starts at the highest buyer value, and
that high-\(b\) endpoint has the largest undercut gain set. The low-demand
seller rejects under the permitted endpoint belief.

The result is a **positive numerical gate**, not a new continuum theorem. The
single-crossing algebra, complete contingent-plan reduction, deviation
thresholds, and fixed-response branches are analytical. A high-order
quadrature solves the equilibrium, while endpoint-inclusive meshes audit the
global cross-\(\alpha\) order, all waiter types, and the knockout branch. The
calculation is not interval arithmetic and does not construct a finite-tremble
sequential foundation. It does establish a comfortably separated candidate
for which buyer risk aversion alone supports all three outcomes and survives
the paper's strict-gain interim-D1 test within the stated numerical accuracy.

## 1. Environment and buyer sorting

Retain the committed demand-only terminal auction with

\[
F=U[0,1],\qquad (n_L,n_H)=(2,7),\qquad
\pi=A=\frac12,\qquad \kappa=0.01,
\tag{1}
\]

and set buyer and seller urgency and the seller's standing value to zero. The
seller and all late buyers are risk neutral. The early buyer privately
observes

\[
b\sim U[0,1],\qquad
\alpha\sim U[\underline\alpha,5],
\tag{2}
\]

independently, and has CARA utility \(-e^{-\alpha x}\). Both coordinates are
private to the buyer. For \(n\) iid uniform late values, define

\[
M_n(b,\alpha)
=\mathbb E\!\left[e^{-\alpha(b-Y_1)^+}\right]
=1-b^n+n\int_0^b y^{n-1}e^{-\alpha(b-y)}\,dy
\tag{3}
\]

and

\[
Z_n(b,\alpha)=e^{\alpha b}M_n(b,\alpha).
\tag{4}
\]

Waiting and offering a probing price \(q\), accepted only in \(L\), have
exponential cost moments

\[
\begin{aligned}
W(b,\alpha)
&=A M_2(b,\alpha)+\pi M_7(b,\alpha),\\
P(b,\alpha;q)
&=e^{\alpha\kappa}
\left[Ae^{-\alpha(b-q)}+\pi M_7(b,\alpha)\right].
\end{aligned}
\tag{5}
\]

The buyer chooses the lower moment. Let \(\beta(\alpha)\) solve
\(P=W\). Multiplying by \(e^{\alpha b}\) gives the useful frontier identity

\[
Z_2-e^{\alpha q}
=\left(e^{\alpha\kappa}-1\right)
\left[e^{\alpha q}+\frac{\pi}{A}Z_7\right],
\tag{6}
\]

where both transformed moments are evaluated at
\((\beta(\alpha),\alpha)\).

The cutoff in \(b\) is unique. Indeed, after moving the two sides of the
moment equality into one transformed difference, its derivative in \(b\) is
proportional to

\[
A(1-b^2)-\pi(e^{\alpha\kappa}-1)(1-b^7).
\tag{7}
\]

Because

\[
\frac{1-b^2}{1-b^7}\geq\frac27
\quad\text{and}\quad
\frac{2A}{7}-\pi(e^{5\kappa}-1)
=0.117221594669>0,
\tag{8}
\]

the transformed difference is strictly increasing for every \(b<1\) and
every coefficient in the support. Thus each coefficient has one connected
upper-\(b\) probing interval.

## 2. Joint endpoint and seller-price equations

Choose the lower support endpoint jointly with the probing price so that the
frontier begins at the top buyer value:

\[
P(1,\underline\alpha;q)=W(1,\underline\alpha).
\tag{9}
\]

The risk-neutral \(L\) seller's continuation revenue conditional on \(b\) is

\[
R_2(b)=\frac13+b^2-\frac23b^3.
\tag{10}
\]

Bayes consistency and seller indifference require

\[
q=
\frac{
\displaystyle\int_{\underline\alpha}^{5}
\int_{\beta(\alpha)}^1R_2(b)\,db\,d\alpha}
{
\displaystyle\int_{\underline\alpha}^{5}
\left[1-\beta(\alpha)\right]d\alpha}.
\tag{11}
\]

Solving (9)--(11) gives

\[
\boxed{
\underline\alpha=0.369754026773,
\qquad q=0.655954391463.}
\tag{12}
\]

The frontier satisfies

\[
\beta(\underline\alpha)=1,
\qquad
\beta(5)=0.773349949657.
\tag{13}
\]

The buyer waits below the frontier and offers \(q\) weakly above it. The
endpoint tie in (9) has zero prior mass and can be assigned either action.
The resulting probing mass is

\[
m_P=0.171264245296.
\tag{14}
\]

Hence the probabilities of no offer, an accepted offer, and a rejected offer
are, respectively,

\[
(0.828735754704,\ 0.085632122648,\ 0.085632122648).
\tag{15}
\]

The \(H\) seller's posterior mean continuation revenue is

\[
\mathbb E[R_7(B)\mid\text{probe}]
=0.851845441393,
\tag{16}
\]

so \(H\) rejects \(q\) with margin \(0.195891049930\). Seller \(L\) is
indifferent by (11) and accepts.

## 3. Raw-PBE completion

At every unexpected price, put probability one on \(b=1\); the coefficient
coordinate is payoff irrelevant to the risk-neutral seller. The point-type
continuation values are

\[
R_2(1)=\frac23,
\qquad
R_7(1)=\frac78.
\tag{17}
\]

Thus both states reject below \(2/3\), only \(L\) accepts between \(2/3\)
and \(7/8\), and both accept at or above \(7/8\). The first threshold exceeds
the on-path price by

\[
R_2(1)-q=0.010712275204.
\tag{18}
\]

Any unexpected price below \(2/3\) is rejected. A price in
\([2/3,7/8)\) has the same \(L\)-only acceptance profile as \(q\) but is more
expensive. It remains only to check an all-state offer at \(R_7(1)=7/8\),
since any higher price is worse. On a \(1001\times2001\) endpoint-inclusive
\((\alpha,b)\) grid, the smallest equilibrium certainty-equivalent advantage
over that deviation is

\[
0.062568604740,
\tag{19}
\]

attained at \((\alpha,b)=(5,1)\). This completes the numerical raw-PBE check.

## 4. Complete contingent-plan D1 reduction

For an off-path price \(p\), let \(\mathcal A(p)\) be the union of seller
contingent plans that are best responses to some common posterior over
\((b,\alpha)\). The strict-gain interim-D1 rule deletes a buyer type when its
weak-gain set is strictly contained in another type's strict-gain set. The
seller's continuation ranges are disjoint:

\[
R_2(b)\in[1/3,2/3],
\qquad
R_7(b)\in[3/4,7/8].
\tag{20}
\]

Consequently the full rationalizable plan set has only the following
branches:

\[
\begin{array}{c|c}
\text{price region}&\text{rationalizable response variation}\\ \hline
p<1/3 & (0,0)\\
1/3\leq p\leq2/3 & (r,0),\quad r\in[0,1]\\
2/3<p<3/4 & (1,0)\\
3/4\leq p\leq7/8 & (1,x),\quad x\in[0,1]\\
p>7/8 & (1,1).
\end{array}
\tag{21}
\]

Here entries give acceptance by \((L,H)\). At a boundary, mixing is supported
by a posterior that makes the relevant state indifferent. Thus (21) is the
complete contingent-plan set; there is no suppressed second receiver-action
coordinate on either variable branch.

### 4.1 Probing undercuts

Only \(p<q\) can produce a gain on the \((r,0)\) branch. Let

\[
E^*(b,\alpha)=\min\{W(b,\alpha),P(b,\alpha;q)\}
\tag{22}
\]

be the equilibrium moment. Whenever acceptance in \(L\) is beneficial, a
type strictly gains exactly when \(r\) exceeds

\[
r(b,\alpha;p)=
\frac{e^{\alpha\kappa}W(b,\alpha)-E^*(b,\alpha)}
{A e^{\alpha\kappa}
\left[M_2(b,\alpha)-e^{-\alpha(b-p)}\right]}.
\tag{23}
\]

On the wait--probe frontier, (23) becomes

\[
r_F(\alpha;p)
=\frac{Z_2-e^{\alpha q}}{Z_2-e^{\alpha p}}
=\frac1{1+\Gamma(\alpha;p)},
\tag{24}
\]

where

\[
\Gamma(\alpha;p)
=\frac{e^{\alpha q}-e^{\alpha p}}
{(e^{\alpha\kappa}-1)
\left[e^{\alpha q}+(\pi/A)Z_7\right]}.
\tag{25}
\]

Equation (25) is the exact cross-\(\alpha\) object that is absent when curvature is
common. A larger \(\Gamma\) means a lower threshold and a larger strict-gain
set. At the lower support endpoint, the corresponding marginal value is
\(b=1\), not the bottom value of a one-dimensional pooling interval.

The audit evaluates 301 prices from \(1/3\) to \(q-10^{-7}\), 5001 points on
the exact marginal curve, and a separate \(401\times801\) full type grid that
includes all waiters below every frontier. After normalizing out the
mechanical factor \(q-p\), the largest finite-difference slope of
\(\Gamma\) in \(\alpha\) is

\[
\max\Delta_\alpha[\Gamma/(q-p)]
=-1.472395888332.
\tag{26}
\]

Thus the gain index falls comfortably rather than nearly tying. On every
price row the full-grid minimum of (23) is attained at

\[
(b,\alpha)=(1,\underline\alpha),
\tag{27}
\]

and its threshold equals the marginal-curve endpoint threshold to displayed
precision. Interim D1 therefore permits the Dirac belief on (27). Under that
belief seller \(L\) rejects every \(p<q\), because
\(R_2(1)-p>R_2(1)-q>0\); \(H\) rejects independently of beliefs. The deviation
then pays the attempt cost and cannot gain.

This is the exact analogue of the baseline urgency logic: heterogeneity in a
second private buyer coordinate leaves a highest-\(b\) marginal point
D1-permitted even though positive-mass types below \(b=1\) offer on path.

### 4.2 High-price deviations

For \(p\in[3/4,7/8]\), seller \(L\) accepts under every posterior and only
\(H\)'s acceptance probability \(x\) can vary. A type's strict-gain threshold
is

\[
x(b,\alpha;p)=
\frac{
e^{\alpha\kappa}
\left[Ae^{-\alpha(b-p)}+\pi M_7(b,\alpha)\right]
-E^*(b,\alpha)}
{\pi e^{\alpha\kappa}
\left[M_7(b,\alpha)-e^{-\alpha(b-p)}\right]}.
\tag{28}
\]

Within each \(\alpha\) slice, the lowest threshold occurs at \(b=1\). For probers,
multiplication by \(e^{\alpha b}\) makes the numerator independent of \(b\)
and the denominator increasing in \(Z_7\). A waiter has a weakly larger
numerator than the corresponding hypothetical prober, so it cannot overturn
that ordering. At \(b=1\), (28) reduces to

\[
x_T(\alpha;p)
=\frac{A}{\pi}
\frac{e^{\alpha p}-e^{\alpha q}}
{Z_7(1,\alpha)-e^{\alpha p}}.
\tag{29}
\]

Across the coefficient support, the audited threshold in (29) is strictly
decreasing. Its largest finite-difference slope over the complete gain region
is

\[
-0.055322517353.
\tag{30}
\]

The full type grid independently returns \((b,\alpha)=(1,5)\) on every price
row. The last price at which any type can gain even when \(H\) accepts with
probability one solves \(x_T(5,p^\dagger)=1\):

\[
p^\dagger=0.812431395260.
\tag{31}
\]

For every \(p\in[3/4,p^\dagger)\), interim D1 permits the belief on
\((1,5)\). Seller \(H\) then rejects because \(R_7(1)=7/8>p\); \(L\)'s certain
acceptance leaves the deviator with the \(L\)-only profile at a price above
\(q\). The minimum rejection margin on this gain region is

\[
\frac78-p^\dagger=0.062568604740.
\tag{32}
\]

For \(p\in[p^\dagger,7/8)\), no type gains even if \(H\) accepts. At
\(p=7/8\), \(H\) may mix under the endpoint posterior, but no type gains
under any response. Strictly above \(7/8\), both states accept under every
posterior, and (19) rules out the cheapest all-accept deviation.

### 4.3 Exhaustion of prices

The remaining branches require no belief selection. Below \(1/3\), both
states reject and the attempt cost makes deviation strictly worse than
waiting. Between \(q\) and \(2/3\), any mixture by \(L\) is weakly worse than
the on-path offer \(q\), which is accepted by \(L\) for sure and costs less.
Between \(2/3\) and \(3/4\), the fixed \(L\)-only profile is again more
expensive than \(q\). Equations (31)--(32) and (19) cover every price at or
above \(3/4\). This exhausts (21), including both receiver-mixing branches.

## 5. Welfare accounting for the same refined assessment

The positive refinement result does not determine a welfare criterion.
Following Note 130, normalize every buyer type's CARA utility as

\[
\phi_\alpha(x)=\frac{1-e^{-\alpha x}}{\alpha},
\qquad
\phi_\alpha(0)=0,\quad \phi_\alpha'(0)=1,
\tag{33}
\]

give the risk-neutral seller and late buyers unit monetary weights, and weight
the uniform \((b,\alpha)\) population by its density. This is an explicit
normalized-utilitarian convention. It is not invariant to choosing different
relative utility scales or welfare weights.

For the refined equilibrium in (12)--(15), the normalized expected-utility
decomposition, including displaced late buyers, is

\[
\begin{array}{lr}
\text{early-buyer change} & +0.001353220465,\\
\text{seller change} & \phantom{+}0.000000000000,\\
\text{late-buyer change} & -0.000917314864,\\ \hline
\text{total change} & +0.000435905601.
\end{array}
\tag{34}
\]

The seller term is zero by the \(L\)-seller price equation. Because seller
revenue plus aggregate late-buyer surplus equals the highest late value, the
late-buyer term also satisfies

\[
(1-\pi)\left(q-\frac23\right)m_P
=-0.000917314864.
\tag{35}
\]

Using dollar certainty equivalents instead, integrate each realized
\((b,\alpha)\) type's interim CE gain before aggregating across the
population. The corresponding decomposition is

\[
\begin{array}{lr}
\text{early-buyer CE change} & +0.002042533484,\\
\text{seller CE change} & \phantom{+}0.000000000000,\\
\text{late-buyer change} & -0.000917314864,\\ \hline
\text{summed interim CE change} & +0.001125218620.
\end{array}
\tag{36}
\]

This criterion uses a common dollar unit but still requires the displayed
population weights and interim aggregation. One can instead take each
\(\alpha\) type's CE before \(b\) is drawn and then average across
\(\alpha\). That convention gives buyer and summed changes
\[
+0.001500621167
\quad\text{and}\quad
+0.000583306303,
\tag{37}
\]
respectively. It is not a representative-buyer CE before \(\alpha\) is
drawn: curvature is itself a preference type, so there is no single utility
function with which to take that earlier certainty equivalent.

Material surplus remains negative. If all of \(\kappa\) is a real resource
cost, the attempt and allocation components are

\[
\begin{aligned}
-\kappa\Pr(I)&=-0.001712642453,\\
-(1-\pi)\mathbb E[(Y_{1L}-B)^+\mathbf 1_{\{\mathrm{probe}\}}]
&=-0.000967714085,\\
\Delta M&=-0.002680356538.
\end{aligned}
\tag{38}
\]

Even if \(\kappa^R=0\), the allocation term in (38) is strictly negative.
Thus the same refined equilibrium has positive money-metric aggregate values
under the two stated conventions but destroys material surplus. Repeating the
welfare integration at orders \((256,192)\) instead of \((512,384)\) changes
the reported welfare totals by less than \(10^{-11}\); this convergence check
is numerical, not an interval enclosure.

## 6. Interval-certificate checkpoint

A later Arb feasibility audit separates routine numerical certification from
the genuinely missing continuum argument. The two equilibrium equations in
\((q,\underline\alpha)\), the frontier slope condition, and the high-price
deviation bound can all be enclosed by standard ball arithmetic. The obstacle
is the comparison between the endpoint type
\((1,\underline\alpha)\) and every waiting type after a probing undercut.

For \(p<q\), let \(F(b,\alpha)=W(b,\alpha)-P(b,\alpha;q)\leq0\) be the
waiter's equilibrium residual and write
\[
X=Z_2-e^{\alpha q},\qquad
D=e^{\alpha q}-e^{\alpha p},\qquad
U=-e^{-\alpha\kappa}F\geq0.
\]
Let \(X_0,D_0\) denote the corresponding quantities at
\((1,\underline\alpha)\). Cross-multiplying the two strict-gain thresholds
shows that endpoint dominance is equivalent to
\[
E:=XD_0-X_0D+U(X_0+D_0)\geq0.
\]
The expression is exactly zero at the endpoint for every \(p<q\), and its
margin also collapses as \(p\uparrow q\). An interval mesh therefore cannot
certify the comparison merely by increasing precision or subdivision. A
proof-level upgrade requires a local boundary lemma that factors both
\(1-b\) and \(q-p\) (with the waiter constraint implying
\(\alpha-\underline\alpha\) of second order in \(1-b\)), followed by interval
verification only on the compact complement.

This is a substantive multivariate boundary argument rather than an omitted
numerical check. Until it is supplied, the appropriate claim remains a
complete, comfortably separated numerical D1 audit rather than a
computer-assisted continuum theorem.

## 7. What is established and what remains open

**Proved analytically.** The moment and frontier identities (3)--(6); the
global one-cutoff property in \(b\) from (7)--(8); the complete
contingent-plan partition (21); the deviation thresholds (23)--(25) and
(28)--(29); the within-\(\alpha\) prober orderings; and the absence of gains on the
fixed-response price branches.

**Numerically audited.** The joint root (12), frontier endpoints, action
masses, seller margins, raw knockout bound, exact-frontier cross-\(\alpha\) rankings,
full-grid waiter comparisons, high-price cutoff, endpoint D1 beliefs, and the
normalized-utility, certainty-equivalent, and material-surplus decompositions
in (34)--(38).
Repeating the equilibrium calculation with 256 instead of 512
Gauss--Legendre nodes changes \(q\) by \(1.27\times10^{-10}\),
\(\underline\alpha\) by \(5.16\times10^{-9}\), and the probe mass by
\(1.52\times10^{-9}\).

**Not established.** The meshes are not interval enclosures, so the result is
not a computer-assisted theorem over the full continuum. There is no
finite-grid sequential-equilibrium construction, distributional robustness
theorem, uniqueness result, empirical calibration, seller risk aversion,
standing value, mixed strategy, or richer-contract classification here.

The bounded answer to the research question is nevertheless positive.
Private heterogeneous buyer risk aversion can do what fixed common curvature
could not: it creates a wait--probe marginal curve whose D1-permitted endpoint
has \(b=1\), and that endpoint deters every relevant undercut in the complete
contingent-plan audit. This is strong enough to reopen risk aversion as a
refinement-robust mechanism in the extension bank, but not yet strong enough
for a manuscript theorem.

Run

    python code/audit_heterogeneous_buyer_risk_aversion_refinement.py

to reproduce every displayed numerical claim.
