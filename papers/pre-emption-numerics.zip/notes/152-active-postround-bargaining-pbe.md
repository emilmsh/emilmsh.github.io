---
type: theory-extension
status: independently-audited-active-postround-raw-pbe-not-refined-or-coupled
last_updated: 2026-07-26
active_manuscript: ../manuscripts/Manuscript.tex
related_notes:
  - 116-terminal-counteroffers-with-standing-value.md
  - 141-perfect-recall-action-linkage-probing-candidate.md
  - 146-unrestricted-post-round-bargaining.md
  - 151-independent-unrestricted-terminal-audit.md
  - 153-independent-active-postround-bargaining-audit.md
---

# Active post-round bargaining with private fallback

## Scope and answer

Notes 146 and 151 embed unrestricted post-round proposal rights in the
perfect-recall probing equilibrium, but buyer counteroffers remain unused on
path. This note asks the narrower constructive question left open there:
can the bidding-round winner actively counter, have the low-fallback seller
accept, and have the high-fallback seller let negotiations break down?

The answer is yes in an isolated bidding-round plus post-round game. The
construction uses only ingredients already in the extension bank:

- iid private buyer values;
- a seller with binary private fallback value;
- a public English clock that reveals the last losing dropout but not the
  winner's unused value; and
- fixed positive costs for buyer and seller proposals.

At low clock prices both seller types pool on a demand. Middle winner types
counter; the low-fallback seller accepts and the high-fallback seller exits.
High winner types accept the pooled demand. At higher clock prices the seller
types separate and use their state-specific monopoly demands. This switch is
important: trying to sustain the pooled demand up to its endogenous acceptance
cutoff makes positive-surplus countering types bunch at that cutoff, after
which each can profitably outbid the atom by an arbitrarily small amount.

The displayed assessment is a **raw pure PBE**, not an interim-D1 result.
Its higher-clock separation is supported by history-dependent off-path
beliefs that jump at a selected public clock price. It has not been coupled
to the early pre-emption game with perfect recall of the early action.

## 1. Environment

There are three buyers with iid values
\[
 b_i\sim U[0,1].
\tag{1}
\]
They use a public English clock. Let \(x\) be the second-highest dropout and
let \(b\geq x\) be the provisional winner's unexercised value. The seller has
private fallback
\[
 v\in\{v_L,v_H\}=\{.2,.6\},
 \qquad \Pr(v=v_H)=\theta=\frac12.
\tag{2}
\]
The fallback state is independent of all buyer values and remains private
after the clock.

The seller may accept the binding standing bid \(x\), exit for \(v\), or pay
\[
 c_S=.002
\tag{3}
\]
and make a new demand, thereby extinguishing \(x\). Proposals then alternate
without a round cap. Every buyer proposal costs
\[
 c_B=.003.
\tag{4}
\]
A player may accept or exit after every proposal. No sale gives the seller
\(v\) and the buyer zero, net of accumulated proposal costs. Prices lie in
\([0,1]\); an infinite proposal path gives the proposer an unbounded total
cost.

## 2. Low-clock active bargaining

Fix the public clock switch
\[
 y=.3.
\tag{5}
\]
At every on-path history with \(x<y\), both seller types pool on
\[
 R=.7.
\tag{6}
\]
After \(R\), the buyer retains prior \(\theta=1/2\). It may exit, pay \(c_B\)
and counter at
\[
 P=.5,
\tag{7}
\]
or accept \(R\). The low seller accepts \(P\); the high seller exits.

The counter payoff and demand-acceptance payoff are
\[
 (1-\theta)(b-P)-c_B,
 \qquad
 b-R.
\tag{8}
\]
The two buyer cutoffs are therefore
\[
 b_C=P+\frac{c_B}{1-\theta}=.506,
\tag{9}
\]
\[
 b_A=\frac{R-(1-\theta)P-c_B}{\theta}=.894.
\tag{10}
\]
Thus
\[
 b<b_C:\text{ exit},\qquad
 b_C\leq b<b_A:\text{ counter }P,\qquad
 b\geq b_A:\text{ accept }R.
\tag{11}
\]

Conditional on a continuous truthful dropout \(x<y\), the winner is uniform
on \([x,1]\). The pooled-demand seller payoffs are
\[
 U_L^R(x)=
 \frac{v_L(b_C-x)+P(b_A-b_C)+R(1-b_A)}{1-x}-c_S,
\tag{12}
\]
\[
 U_H^R(x)=
 \frac{v_H(b_A-x)+R(1-b_A)}{1-x}-c_S.
\tag{13}
\]

At every unused initial seller price \(z\), let the buyer believe \(L\).
Conditional on that belief, accepting and countering at \(P\) tie at
\[
 \widehat b_C=P+c_B=.503.
\]
The buyer accepts \(z\leq\widehat b_C\) exactly when \(b\geq z\). At
\(z>\widehat b_C\), types \(b\geq\widehat b_C\) counter at \(P\), while
lower types exit. Notice that \(\widehat b_C\ne b_C\): equation (9) prices
the one-state acceptance probability into an offer made under the pooled
posterior, whereas the unused-price response conditions on \(L\).

Consequently the largest unused-price payoff of \(L\) is obtained at
\(z=\widehat b_C\):
\[
 \widehat U_L(x)=
 \frac{v_L(\widehat b_C-x)
       +\widehat b_C(1-\widehat b_C)}{1-x}-c_S.
\tag{14}
\]
The high seller never gains from selling below \(v_H\), and a counter at
\(P\) is followed by exit, so its unused-price envelope is below \(v_H\).
For every \(x\in[0,y)\),
\[
 U_L^R(x)>
 \max\{v_L,x,\widehat U_L(x)\},
\qquad
 U_H^R(x)>v_H.
\tag{15}
\]
The low seller's smallest audited margins are \(0.140000\) against its
outside action and \(0.018809\) against all unused prices. The high seller's
corresponding margins are \(0.008600\) and \(0.010600\).

## 3. Recursive completion after the active counter

After the on-path \(P\), the low seller accepts and the high seller exits.
To check recountering, set
\[
 \tau=v_L=.2,
\qquad T=\tau+c_B=.203.
\tag{16}
\]
After an unexpected seller recounter \(z\), the buyer believes \(L\). If
\(z\leq T\), it accepts if and only if \(b\geq z\), and otherwise exits. If
\(z>T\), it counters at \(\tau\) if and only if \(b\geq T\), and otherwise
exits. Every other buyer proposal invokes the nonspecial top-value
completion below. These type-conditioned rules also cover buyers who reach
the history through an earlier deviation. At \(\tau\), the seller assigns
probability one to \(b=\tau\); \(L\) accepts and \(H\) exits. The best
recounter payoffs are at most
\[
 T-c_S=.201<P
\tag{17}
\]
for \(L\), and
\[
 v_H-c_S=.598<v_H
\tag{18}
\]
for \(H\). Hence the two prescribed responses to \(P\) are strict.

Every nonspecial buyer proposal induces posterior \(b=1\). As in Note 146,
the seller counters at \(1\) below \(1-c_S\) and accepts at or above that
threshold. The cheapest immediately accepted effective expenditure is
\[
 1-c_S+c_B=1.001>1.
\tag{19}
\]
Because \(c_B\geq c_S\), a buyer cannot gain by countering the demand \(1\).
The same rules apply recursively. Positive proposal costs dominate perpetual
deviations.

The special-price rules are history specific. \(P=.5\) is special only when
it is the first buyer response to \(R\), or to an unused initial seller
demand at a low-clock history. The tail \(\tau=.2\) is special only as the
first response to a seller recounter after such a \(P\). The same numerical
price submitted later---after a top-value counter, for example---is
nonspecial and invokes the top-value completion. Thus a buyer cannot reopen
the low-state sale branch by repeating \(P\). Equations (16)--(19) exhaust
every later pure price rather than a selected grid.

## 4. Higher-clock separation

For \(x\geq y\), the seller types separate. Conditional on state \(s\), the
direct accept-or-exit demand maximizes
\[
 v_s+\frac{(r-v_s)(1-r)}{1-x}-c_S.
\tag{20}
\]
The state-specific monopoly demands are
\[
 r_L=\frac{1+v_L}{2}=.6,
\qquad
 r_H=\frac{1+v_H}{2}=.8.
\tag{21}
\]
Let \(\chi_s\) solve
\[
 v_s+\frac{(r_s-v_s)(1-r_s)}{1-\chi_s}-c_S=\chi_s.
\tag{22}
\]
Numerically,
\[
 \chi_L=.570698056604,
\qquad
 \chi_H=.778975015605.
\tag{23}
\]
Type \(s\) demands \(r_s\) for \(y\leq x<\chi_s\), and accepts \(x\) for
\(x\geq\chi_s\). At an on-path state-specific demand, the winner accepts
exactly when \(b\geq r_s\) and otherwise exits. Any buyer counter invokes
the top-value completion in (19). Thus countering is unprofitable, and
\(r_s\) globally maximizes the seller's price objective whenever a proposal
is optimal.

After any unused initial seller price \(z\) at \(x\geq y\), assign an
arbitrary belief over the seller state. The buyer accepts if and only if
\(b\geq z\), and otherwise exits; any buyer counter invokes the top-value
completion. Since this response is state independent, the arbitrary belief
does not affect payoffs. At the on-path prices \(r_L\) and \(r_H\), beliefs
are instead degenerate on the corresponding seller state by Bayes' rule.

At the null history \(x=y\), use the separating continuation. Beliefs after
unused prices at \(x<y\) and \(x\geq y\) differ. This history dependence is
permitted by PBE but is the main refinement limitation of the construction.

## 5. Endogenous clock bidding

Truthful dropout is a weak best response. Fix the highest rival dropout \(x\)
and let \(V(b,x)\) denote the payoff from becoming provisional winner.

- If \(x<y\), \(V(b,x)=0\) below \(b_C\) and is positive only for
  \(b\geq b_C>y>x\).
- If \(y\leq x<\chi_L\), both seller types demand their state-specific prices.
  The winning payoff is positive only for \(b\geq r_L>\chi_L>x\).
- If \(\chi_L\leq x<\chi_H\), \(L\) accepts \(x\) and \(H\) demands \(r_H\).
  For \(b<r_H\),
  \[
  V(b,x)=(1-\theta)(b-x),
  \tag{24}
  \]
  while every \(b\geq r_H>\chi_H>x\) has positive payoff.
- If \(x\geq\chi_H\), both sellers accept \(x\), so
  \[
  V(b,x)=b-x.
  \tag{25}
  \]

Hence \(V(b,x)\geq0\) whenever \(x<b\) and \(V(b,x)\leq0\) whenever
\(x>b\). Dropping at \(b\) is pointwise optimal against truthful rivals.
The weak regions are the familiar safe-dropout multiplicity below an
effective terminal threshold; no profitable overbidding remains.

The location of the switch in (5) matters. If both seller types instead pool
on \(R\) up to their endogenous acceptance cutoff, then \(b_C\)-to-cutoff
buyers earn positive counter surplus independent of \(x\). They all want to
remain until the top of that interval. A positive atom results, and any type
with positive surplus strictly gains by staying an epsilon beyond the atom:
the seller observes the same losing dropout and cannot observe the winner's
unused cap. The low-clock pooling region is therefore deliberately ended
below \(b_C\).

## 6. Proposition and incidence

**Proposition 1 (active post-round raw PBE).** The bidding-round plus
post-round bargaining game with (1)--(7), the strategies in Sections 2--5,
and the recursive beliefs in Section 3 has a pure PBE. Buyer counteroffers
are active with positive probability. Conditional on such a counter, \(L\)
accepts and \(H\) terminates without sale.

**Proof.** Equations (8)--(11) give the winner's sequentially rational
response to the pooled demand. Equations (12)--(15) exhaust the low-clock
seller's outside actions and every initial price. The type-conditioned rules
following (16), together with (17)--(19), exhaust recounters, nonspecial
buyer proposals, and longer histories, including histories reached through
an earlier buyer deviation. Equations (20)--(23) give the unique
direct-demand maximizer and the accept-versus-demand clock cutoff for each
separated seller state. The explicit unused-price rule at \(x\geq y\)
exhausts every corresponding seller-price deviation. Equations (24)--(25),
together with the first two cases in Section 5, make truthful dropout a
pointwise weak best response. Bayes' rule gives the uniform winner posterior
after every continuous on-path dropout, prior \(\theta\) after the pooled
demand, and degenerate seller-state beliefs after \(r_L\) and \(r_H\). After
on-path \(R\) followed by \(P\), the seller's posterior over the winner is
uniform on \([b_C,b_A)\); the condition \(x<y<b_C\) makes this posterior
independent of \(x\). All other beliefs are attached to zero-probability
histories. Positive costs dominate infinite unilateral proposal paths.
\(\square\)

With three iid bidders,
\[
 \Pr(x<y)=3y^2-2y^3=.216.
\tag{26}
\]
The unconditional mass of active buyer counteroffers is
\[
 3(b_A-b_C)y^2=.10476.
\tag{27}
\]
It splits equally into
\[
 \Pr(\text{counter, }L\text{ accepts})=.05238,
\qquad
\Pr(\text{counter, }H\text{ exits})=.05238.
\tag{28}
\]
Direct acceptance of \(R\) has mass
\[
 3(1-b_A)y^2=.02862.
\tag{29}
\]

## 7. Interpretation and stopping rule

The construction establishes that active post-round buyer revision is not
ruled out by the common-effective-expenditure lemma. That lemma applies to
two deterministic paths both ending in certain sale. Here the counter buys
sale only from \(L\); it deliberately risks breakdown against \(H\). The two
paths therefore have different slopes in \(b\), allowing middle types to
counter and high types to accept \(R\).

The result also identifies its own selection cost. Low-clock pooling and
higher-clock separation are supported by different off-path inferences
about an unused seller price. No dynamic D1, forward-induction, or
belief-continuity argument is supplied. Perfect recall of an earlier
pre-emption action would additionally replace the uniform winner posterior
by an action-selected posterior for an identified early-buyer winner.
Coupling the present assessment to early probing would therefore require a
new posterior fixed point and a new complete-plan refinement audit.

The correct classification is:

- **proved:** an isolated pure PBE with truthful clock bidding, unrestricted
  proposal rights, an active buyer counter, state-contingent sale, and
  state-contingent breakdown;
- **audited:** every pure price deviation and the clock sign condition for
  the displayed calibration;
- **not proved:** interim D1, robustness to continuous belief restrictions,
  coupling to early probing under perfect recall, uniqueness, or a global
  characterization.

The reproduction file is
[`../code/audit_active_postround_bargaining_pbe.py`](../code/audit_active_postround_bargaining_pbe.py).
