---
type: independent-theory-audit
status: superseded-by-perfect-recall-gap
last_updated: 2026-07-25
audited_note: 126-terminal-counteroffers-inside-the-one-offer-game.md
audit_code: ../code/audit_terminal_counteroffer_one_offer_plugin.py
---

# Independent audit of the terminal-counteroffer plug-in

> **Superseding correction.** This audit validates the reduced-form
> continuation used in Note 126, but it does not validate the corresponding
> perfect-recall game. If the early buyer later wins the clock auction, the
> seller remembers that buyer's earlier action. Conditional winner beliefs are
> then action selected, so the common monopoly cutoff used below is generally
> incorrect. The isolated English-clock lemma survives; the coupled
> probing-only, full-menu, and D1 conclusions require a new calculation.
> The reduced-form result therefore needs an informational firewall that keeps
> the earlier action out of terminal inference; bidder-name anonymity alone
> does not generally deliver the same posterior.

## Verdict

The demand-only coarse-history plug-in is valid after two corrections:

1. Note 126's corrupted LaTeX was repaired, and its seller-payoff correction
   was generalized from the uniform term \(r^{n_s}\) to
   \(F(r)^{n_s}\).
2. The code now audits both one-sided values at the reserve and every
   payoff-relevant inactive-price response interval, including equality and
   adjacent floating-point values at the off-path acceptance thresholds.

The reserve equivalence, truthful-dropout argument, reduced-form formulas,
pointwise state order, and monotone willingness difference remain analytical.
The probing and full-menu candidates, together with the conditional
nested-plan interim-D1 conclusions, survive the numerical audit.

One proof qualification matters. Because \(C_L^{CO}\) jumps at \(r\),
\(C_L^{CO}-w_L^{CO}\) is not globally decreasing. The probing D1 proof must
not import that baseline shortcut. It instead works directly because the
highest feasible marginal value is \(b=1\) and
\[
C_L^{CO}(1)-q_L=.002176159457>0.
\]
Note 126 now states this route explicitly.

## 1. Arbitrary bidder count and unknown demand

Suppose \(m\geq2\) iid bidders drop truthfully, and the seller observes only
the highest losing dropout \(x\). If \(X\) is the provisional winner's value,
the joint density of the two highest order statistics is
\[
m(m-1)F(x)^{m-2}f(x)f(X),
\qquad X>x.
\]
Conditioning on \(x\) gives
\[
f_{X\mid x,m}(y)=\frac{f(y)}{1-F(x)},
\qquad y\geq x.
\]
This distribution does not depend on \(m\). A demand state that changes the
number of bidders therefore does not change the seller's inference about the
winner after conditioning on \(x\), whether the state is observed or averaged
out.

The seller's payoff from a counteroffer \(p>x\) is consequently
\[
v+\frac{(p-v)[1-F(p)]}{1-F(x)}.
\]
Comparing this with accepting \(x\) shows that the seller counters at the
unique maximizer \(\rho(v)\) of
\[
(p-v)[1-F(p)]
\]
when \(x<\rho(v)\), and otherwise accepts \(x\). This implements a
second-price auction with reserve \(\rho(v)\) for every fixed \(m\).

Truthful dropout is a weak best response pointwise in the realized rival caps.
If the highest rival cap exceeds the reserve, a winner pays that cap; if it is
below the reserve, a winner pays the reserve. Reporting above value can only
create a loss, and reporting below value can only forgo nonnegative surplus.
Because this argument is ex post in the rival caps, a bidder need not know the
demand state or the realized number of rivals.

## 2. Reduced-form objects

With \(n_s\) late bidders and common reserve \(r=\rho(v)\), a patient early
buyer obtains
\[
\mathbb E[(b-\max\{r,Y_{1s}\})^+].
\]
Hence
\[
w_s^{CO}(b)
=b-\mathbb E[(b-\max\{r,Y_{1s}\})^+].
\]
For uniform values,
\[
w_s^{CO}(b)
=
\begin{cases}
b,&b\leq r,\\[1mm]
b-\dfrac{b^{n_s+1}-r^{n_s+1}}{n_s+1},&b>r.
\end{cases}
\]

Let \(R_F(n_s,b;r)\) be seller revenue under a committed threshold whose
no-sale payoff is \(r\). The coarse counteroffer mechanism pays the physical
fallback \(v\), rather than \(r\), precisely when \(b<r\) and all late values
are below \(r\). Therefore
\[
R_s^{CO}(b)
=R_F(n_s,b;r)
 -(r-v)F(r)^{n_s}\mathbf 1\{b<r\}.
\]
The jump at \(b=r\) is exactly
\[
(r-v)F(r)^{n_s}.
\]
The implementation and the strict indicator in the code are correct.

## 3. State order and willingness monotonicity

For
\[
(n_L,n_H)=(2,3),\qquad v=.4,\qquad r=.7,
\]
the continuation gap below the reserve is constant:
\[
C_H^{CO}-C_L^{CO}=.05805
\qquad (b<r).
\]
At and above the reserve it is
\[
\frac16-b^2+\frac53b^3-\frac34b^4
 +\frac14r^4-\frac13r^3.
\]
Its value at \(r\) is \(.01395\), and its derivative is
\[
b(3b-2)(1-b)\geq0
\qquad (b\in[r,1]).
\]
Thus \(C_H^{CO}>C_L^{CO}\) pointwise despite the unequal jumps. The audited
one-sided continuation values are
\[
\begin{array}{c|ccc}
&r^-&r&r^+\\ \hline
C_L^{CO}&.552&.699&.699\\
C_H^{CO}&.61005&.71295&.71295 .
\end{array}
\]

The willingness difference is
\[
w_H^{CO}-w_L^{CO}
=
\begin{cases}
0,&b\leq r,\\[1mm]
\dfrac{b^3-r^3}{3}-\dfrac{b^4-r^4}{4},&b>r,
\end{cases}
\]
with derivative \(b^2(1-b)\geq0\). The nested seller-response order and the
buyer-side D1 ranking therefore remain available.

## 4. PBE and discontinuous continuation

The jump in \(C_s^{CO}\) does not break either fixed-point argument.

- Buyer action weights depend on the continuous functions \(w_s^{CO}\).
- The seller functions are bounded, nondecreasing, and have one fixed
  measure-zero discontinuity.
- Integrating against the atomless buyer distribution makes the price maps
  continuous by dominated convergence.
- Nondecreasing \(C_s^{CO}\) is enough for the monotone-likelihood corner
  reduction on the full-menu price box.
- Pointwise \(C_H^{CO}>C_L^{CO}\) makes every rationalizable contingent seller
  plan nested under a common posterior.

Posterior mixing also fills the convex continuation ranges, so the jump does
not remove the adjacent mixing branches needed by the D1 comparison. Here
\[
C_L^{CO}(b)\in\{.552\}\cup[.699,.771],
\]
\[
C_H^{CO}(b)\in\{.61005\}\cup[.71295,.800025],
\]
while posterior expectations range over the convex hulls
\([.552,.771]\) and \([.61005,.800025]\).

The reproduced equilibria are:

| assessment | prices | action masses | fixed-point error |
|---|---:|---:|---:|
| probing | \(q_L=.768823840543\) | \((.960083699,.039916301)\) | \(0\) |
| full menu | \((.685533774109,.753166476086)\) | \((.734153617,.043363698,.222482685)\) | \(<3\times10^{-15}\) |

All three full-menu urgency cutoffs have strictly positive minima, and the
smallest inward price-box face margin is \(9.9941\times10^{-5}\).

## 5. Complete nested-plan D1

The relevant receiver-plan set is the complete union
\[
\{(x,0):x\in[0,1]\}
\cup
\{(1,y):y\in[0,1]\}.
\]
The discontinuity changes seller continuation values but not buyer deviation
payoffs on these branches.

For the probing assessment:

- undercuts are ranked by the monotone willingness difference; the
  highest-value wait--probe marginal type \(b=1\) is D1-permitted;
- \(C_L^{CO}(1)-q_L=.002176159457\) supports rejection;
- overcuts are ranked by the highest-value, highest-urgency probing type; and
- the best all-state gain is \(-.001100579729\).

For the full menu:

- the top wait--probe marginal type supports every \(p<q_L\);
- the top probe--knockout marginal type supports every
  \(q_L<p<q_H\);
- the top-value slacks are
  \[
  C_L^{CO}(1)-q_L=.085466225891,\qquad
  C_H^{CO}(1)-q_H=.046858523914;
  \]
- at \(p\geq q_H\), full acceptance cannot improve on the cheaper equilibrium
  knockout.

These comparisons cover both mixing branches, their deterministic endpoints,
and every off-path price interval. They do not rely on continuity of
\(C_s^{CO}\).

## 6. Numerical endpoint and inactive-price coverage

The corrected audit now includes:

- \(b=0,1,r^-,r,r^+\);
- both exact continuation jumps and their theoretical sizes;
- the negative-wedge interval endpoints on the left of \(r\);
- all urgency endpoints and every wait--offer or offer--offer cutoff;
- both root-bracketing price endpoints;
- all four full-menu price-box faces;
- the top-belief thresholds
  \((C_L^{CO}(1),C_H^{CO}(1))=(.771,.800025)\);
- equality and adjacent floating-point values at both thresholds;
- representative interior prices and \(p=0,1\).

Within a fixed seller-response interval, buyer payoff is decreasing in price,
so the left endpoint exhausts the continuum of inactive prices. The largest
audited inactive-price gains are
\[
-.001088079729
\]
for probing and
\[
-.042733112945
\]
for the full menu. Both assessments therefore retain strict off-path slack.

## Claim ledger

**Verified analytically:** arbitrary-bidder reserve equivalence; invariance to
an unknown demand count; truthful dropout; the general \(w^{CO}\) and
\(R^{CO}\) formulas; pointwise continuation ordering; monotone
\(\Delta w\); continuity of the integrated price maps; and the complete
nested-plan D1 transfer using direct top-marginal slacks.

**Verified numerically:** both fixed points, masses, seller responses,
one-sided reserve values, continuation jumps, cutoff endpoints, price-box
faces, inactive prices, and D1 deterrence margins.

**Still numerical rather than interval-certified:** existence of the reported
fixed points and the continuum face signs beyond the analytic monotonicity
reduction. No claim is made for rich terminal histories or private
state-dependent fallback.
