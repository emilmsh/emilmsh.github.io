---
type: theory-audit
status: refined-private-seller-urgency-state-full-menu-pbe-certified
last_updated: 2026-07-23
active_manuscript: ../manuscripts/Manuscript.tex
audit_code: ../code/audit_seller_urgency_only_refined_pbe.py
related_notes:
  - 51-continuous-type-interim-d1-audit.md
  - 53-continuous-regime-map.md
  - 79-equilibrium-selection-framework.md
  - 125-binary-private-seller-urgency-final-gate.md
  - 133-seller-urgency-only-independent-audit.md
---

# Private seller urgency as the sole seller state: a refined full menu

## 1. Result

Private seller urgency can replace prospective demand as the seller's private
screening state. A continuous-buyer-type equilibrium then has no early offer,
a probing offer accepted only by the urgent seller, and a knockout offer
accepted by both seller types. The equilibrium has an interim-D1-compatible
completion under the same contingent-plan representation used in the main
model.

The buyer still has a nondegenerate urgency type. The result therefore does
not show that seller urgency is the only source of gains in the entire
equilibrium. It shows that seller urgency contributes genuine bilateral gains,
is the only private seller-side dimension, and can finance offers by some
buyers with zero urgency. Rejection reveals a patient seller rather than
strong prospective demand, which is why this proof of concept should not
replace the baseline's empirical interpretation.

## 2. Environment

There is one common terminal auction environment. The early buyer has

\[
b\sim U[0,1],\qquad d\sim G,
\]

independently, where \(G\) is a rate-10 exponential distribution truncated
to \([0,1]\). There are \(n=2\) late bidders with independent uniform match
values. The common standing value is \(v=.4\). The terminal-auction objects
are

\[
w(b)=
\begin{cases}
b,&b\leq v,\\
b-\dfrac{b^3-v^3}{3},&b>v,
\end{cases}
\]

and

\[
R(b)=
\begin{cases}
\dfrac13+v^2-\dfrac{v^3}{3},&b\leq v,\\[5pt]
\dfrac13+b^2-\dfrac{2b^3}{3}+\dfrac{v^3}{3},&b>v.
\end{cases}
\]

The seller is urgent with probability \(A=1/2\) and patient with probability
\(\pi=1/2\). The urgent seller's continuation value is

\[
C_L(b)=R(b)-\Delta,
\]

whereas the patient seller's continuation value is

\[
C_H(b)=R(b).
\]

Set \(\Delta=.02\) and the incremental attempt cost to \(\kappa=.01\).
Seller urgency does not affect the buyer's terminal auction payoff, so both
seller states share the same \(w(b)\).

## 3. Buyer sorting and the boundary-price map

Let \(q_L\) be accepted only by the urgent seller and \(q_H\) be accepted by
both seller types. Relative to waiting, the buyer's payoffs are

\[
U_L(b,d)=A\{w(b)+d-q_L\}-\kappa,
\]

and

\[
U_H(b,d)=w(b)+d-q_H-\kappa.
\]

The two urgency cutoffs are

\[
D_L(b)=q_L-w(b)+\frac{\kappa}{A},
\qquad
D_H(b)=\frac{q_H-Aq_L}{\pi}-w(b).
\tag{1}
\]

When \(D_L(b)<D_H(b)\), the buyer waits below \(D_L(b)\), probes between
the two cutoffs, and makes the knockout offer above \(D_H(b)\). Write the
resulting action weights as \(m_0(b),m_L(b),m_H(b)\). The boundary-price map
is

\[
T_L(q_L,q_H)
=\frac{\int_0^1 C_L(b)m_L(b)\,db}
       {\int_0^1 m_L(b)\,db},
\]

\[
T_H(q_L,q_H)
=\frac{\int_0^1 C_H(b)m_H(b)\,db}
       {\int_0^1 m_H(b)\,db}.
\tag{2}
\]

The independently reproduced fixed point is

\[
(q_L,q_H)=(.586756515147,.643707659769),
\tag{3}
\]

with action masses

\[
(M_0,M_L,M_H)
=(.550185181075,.185288486218,.264526332707).
\tag{4}
\]

Thus the probabilities of no early offer, a rejected attempt, and successful
pre-emption are respectively

\[
.550185181075,\qquad
\pi M_L=.092644243109,\qquad
AM_L+M_H=.357170575816.
\tag{5}
\]

The minimum cutoff gap is .093902289244. Direct pointwise evaluation on a
\(2001\times2001\) endpoint-inclusive buyer grid finds no best-response
loss. A separate 131,072-panel Simpson calculation gives fixed-point
residuals \((-1.61\times10^{-14},-2.33\times10^{-15})\).

At \(q_L\), the urgent seller is indifferent and the patient seller rejects
with margin \(\Delta\). At \(q_H\), the patient seller is indifferent and the
urgent seller accepts with margin \(\Delta\). Under the posterior concentrated
on \(b=1\), the two continuation thresholds are

\[
(C_L(1),C_H(1))=(.668,.688).
\]

With acceptance at equality, a price below .668 is rejected by both seller
types, a price in \([.668,.688)\) is accepted only by the urgent seller, and a
price weakly above .688 is accepted by both. The last two profiles cost
strictly more than their corresponding on-path offers. Together with (1),
this completes the raw-PBE check, including the two response endpoints.

## 4. Complete interim-D1 argument

Buyer payoffs depend on type only through

\[
z=w(b)+d.
\]

After an unexpected price, seller best responses lie on the two nested
branches \((x,0)\) and \((1,y)\). Since buyer willingness is common across
seller types, a plan matters to the buyer only through aggregate acceptance
\(r=Aa_L+\pi a_H\). The deviation payoff is

\[
r(z-p)-\kappa,
\tag{6}
\]

whereas equilibrium payoff is

\[
U^*(z)=
\max\{0,A(z-q_L)-\kappa,z-q_H-\kappa\}.
\tag{7}
\]

The attainable posterior mean of \(R(b)\) lies in \([.472,.688]\). The exact
rationalizable aggregate-response set is therefore

\[
\mathcal A_r(p)=
\begin{cases}
\{0\},&0\leq p<.452,\\
[0,A],&.452\leq p<.472,\\
[0,1],&.472\leq p\leq.668,\\
[A,1],&.668<p\leq.688,\\
\{1\},&p>.688.
\end{cases}
\tag{8}
\]

For \(0\leq p<.452\), only rejection by both seller types is rationalizable.
Every buyer's weak- and strict-gain sets are empty, so D1 deletes no type. The
belief used below remains permitted and induces rejection.

For \(.452\leq p<q_L\), a type's strict-gain set is the available tail above

\[
\tau(z;p)=\frac{\kappa+U^*(z)}{z-p}.
\tag{9}
\]

This threshold decreases up to the wait--probe marginal value

\[
z_L=q_L+\frac{\kappa}{A}
\]

and increases thereafter. Exactly the types with \(z=z_L\) are
D1-undominated. D1 does not distinguish among buyers with the same \(z\), so
belief may be placed on the largest feasible \(b\). It has \(d=0\) and

\[
b_L^0=.699522891097,
\qquad
C_L(b_L^0)-q_L=.009043008127>0.
\tag{10}
\]

Both seller types therefore reject every \(p<q_L\) under this D1-permitted
belief.

For \(q_L<p<q_H\), (9) is minimized at the probe--knockout marginal value

\[
z_H=\frac{q_H-Aq_L}{\pi}.
\]

The largest feasible \(b\) among types with \(z=z_H\) is

\[
b_H^0=1,
\qquad
d_H^0=.012658804391.
\]

Under belief on this type,

\[
C_L(1)-q_H=.024292340231>0,
\qquad
C_H(1)-q_H=.044292340231>0.
\tag{11}
\]

Both seller types reject every intermediate deviation. For \(p>q_H\), no
buyer can weakly gain even under acceptance by both seller types, so all gain
sets are empty and the posterior is immaterial. Equations (8)--(11) exhaust
the nonnegative off-path price set and give an interim-D1-compatible
completion.

### Proposition. Refined full menu with private seller urgency

The strategies, prices, Bayes posteriors, and off-path beliefs above form a
PBE. The equilibrium generates no early offer, rejected attempts, and
successful pre-emption with positive probability, and it survives the
contingent-plan interim-D1 test.

## 5. Economic interpretation and boundary

Some high-\(b\) buyers with \(d=0\) probe in this equilibrium. This does not
contradict the competition-wedge result. The urgent seller is willing to
accept less than the patient seller, so seller urgency supplies genuine
bilateral gains. Patient buyers can share those gains through screening. The
construction supports the broader statement that urgency on at least one side
can overcome the competition wedge; it does not show that private information
alone creates surplus or that the same menu exists when \(d\equiv0\).

The result also clarifies the earlier four-state difficulty. A private seller
dimension that shifts only \(C\), as urgency does here, leaves the buyer's
terminal willingness common across seller types and collapses D1 comparisons
to the scalar \(z\). A fallback-value split generally shifts both \(C_s\) and
\(w_s\). Its contingent-plan gain sets need not collapse in this way. The
failure of the audited demand-by-fallback menus is therefore not caused by
the number four by itself.

Not established here are uniqueness, belief-independent implementation, or a
global characterization of all pure or mixed menus. The proposition is a
refined numerical existence certificate with an analytical D1 completion.
