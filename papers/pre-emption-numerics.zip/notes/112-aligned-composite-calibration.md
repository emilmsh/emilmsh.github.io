---
type: theory-audit
status: preferred-probe-and-full-menu-certificates-reproduced
last_updated: 2026-07-22
active_manuscript: ../manuscripts/Manuscript.tex
code: ../code/audit_aligned_composite_calibration.py
related_notes:
  - 89-general-F-separation-audit.md
  - 107-combined-market-interest-and-retention-state.md
  - 111-private-no-sale-information-and-terminal-bidding.md
---

# Aligned composite-state calibration

## 1. Scope and verdict

This note verifies that the bundled binary state in Note 107 has strict,
non-vacuous calibrations.  The seller observes

\[
s\mapsto(n_s,v_s),\qquad (n_L,v_L)=(2,.38),\quad(n_H,v_H)=(3,.42),
\]

before the early offer.  The value \(v_s\) is a hidden but committed terminal
standing value, not an asking price.  Early and late match values are common
independent \(U[0,1]\) draws, \(\pi=1/2\), \(d_S=.01\), and buyer urgency has
the truncated-exponential CDF

\[
G(d)=\frac{1-e^{-10d}}{1-e^{-10\bar d}},\qquad d\in[0,\bar d].
\]

Two separate calibrations pass:

1. a strict probing-only PBE with no early offer, a rejected attempt, and success all
   having positive probability; and
2. a strict globally interior full-menu PBE, with a certified invariant price
   rectangle and an interim-D1-compatible completion.

Thus neither the screening mechanism nor full-menu existence requires a large
participant gap.  This is a numerical non-vacuity result for one aligned
composite-state microfoundation.  It is not a claim that the bundled timing is
the preferred baseline, that the seller optimally reports \(v_s\), or that the
equilibrium is unique.

## 2. Analytic identities used by the audit

For \(F(b)=b\), \(b\in[0,1]\), the patient buyer willingness and seller gross
terminal payoff are

\[
w_{n,v}(b)=
\begin{cases}
b,&b\leq v,\\
b-\dfrac{b^{n+1}-v^{n+1}}{n+1},&b>v,
\end{cases}
\]

\[
R_{n,v}(b)=
\begin{cases}
\dfrac{n-1}{n+1}+v^n-\dfrac{n-1}{n+1}v^{n+1},&b\leq v,\\[2mm]
\dfrac{n-1}{n+1}+b^n-\dfrac{n}{n+1}b^{n+1}
+\dfrac{v^{n+1}}{n+1},&b>v,
\end{cases}
\]

with \(C_s=R_{n_s,v_s}-d_S\).  The terminal no-sale probability in state
\(s\), before selection by the early-offer strategy, is
\(v_s^{n_s+1}\).

The state difference in patient willingness has two kinks:

\[
\Delta w(b)=w_H(b)-w_L(b)=
\begin{cases}
0,&b\leq v_L,\\
\dfrac{b^{n_L+1}-v_L^{n_L+1}}{n_L+1},&v_L<b\leq v_H,\\[2mm]
\dfrac{v_H^{n_L+1}-v_L^{n_L+1}}{n_L+1}
+\dfrac{b^{n_L+1}-v_H^{n_L+1}}{n_L+1}
-\dfrac{b^{n_H+1}-v_H^{n_H+1}}{n_H+1},&b>v_H.
\end{cases}
\]

It is weakly increasing on \([0,1]\) and strictly increasing above \(v_L\).
This is the two-kink monotonicity used in the probing and full-menu D1
rankings.  The script checks the closed form against direct evaluation; the
maximum discrepancy is \(1.81\times10^{-16}\).

For the selected state, the support and continuation-price endpoints are

\[
b\in[0,1],\quad
(C_L(0),C_L(1))=(.449442667,.674957333),
\]

\[
(C_H(0),C_H(1))=(.548529520,.747779240).
\]

## 3. Preferred probing-only certificate

Set \(\kappa=.02\) and \(\bar d=.045\).  The probing fixed point is

\[
q_L=.671388040517.
\]

The signed scalar-map values at the price endpoints are

\[
T_L(C_L(0))-C_L(0)=.160696746>0,
\]

\[
T_L(C_L(1))-C_L(1)=-.002900955<0,
\]

and the independently re-evaluated fixed-point residual is
\(2.22\times10^{-16}\).  The wait--probe cutoff falls from
\(D_L(0)=.711388041\) to \(D_L(1)=.026430707\); maximal urgency first permits
probing at \(b=.860446282\).

The exact primitive thresholds are

\[
(\bar D_L,\bar D_H,\Delta_D,
 \bar D_L+\Delta_D/\pi)
=(.030000000,.046410953,.016410953,.062821907).
\]

Hence \(\bar D_L<\bar d<\bar D_L+\Delta_D/\pi\), while the left-endpoint
condition is strict.  No-early-offer PBE is therefore impossible and the
primitive probing theorem applies.

Seller \(L\)'s boundary-pricing residual is \(-2.22\times10^{-16}\).  Under
the same on-path posterior, seller \(H\)'s rejection slack is

\[
\mathbb E[C_H(b)\mid q_L]-q_L=.071341454>0.
\]

The exact top-endpoint maximization of a deviation accepted in both states
gives

\[
\max_{b,d}{V_K(b,d)-\max[0,V_P(b,d)]\}
=-.010695600<0.
\]

A dense endpoint-inclusive grid reproduces the same maximum.  For interim
D1, the highest feasible wait--probe marginal is \(b_L^0=1\), and

\[
C_L(1)-q_L=.003569293>0.
\]

Together with positive \(\kappa\), the two-kink monotonicity, and the strict
no-knockout inequality, this supplies the Note 89 D1 completion.

The wait and probe masses are

\[
(M_0,M_L)=(.967425515,.032574485).
\]

Thus the probabilities of no early offer, a rejected attempt, and a
successful early sale are respectively

\[
(.967425515,.016287243,.016287243).
\]

The state-conditional terminal no-sale probabilities are
\((.054872000,.031116960)\).  They are unchanged by equilibrium selection in
this calibration: low-value \(L\)-state buyers wait, while every \(H\)-state
probe is rejected.  Their prior-weighted probability is \(.042994480\).

## 4. Preferred globally interior full-menu certificate

Set \(\kappa=.05\) and \(\bar d=1\).  The fixed point is

\[
(q_L,q_H)=(.609677720962,.705343970181),
\]

with signed residuals

\[
(T_L-q_L,T_H-q_H)
=(-1.21\times10^{-14},-1.11\times10^{-15}).
\]

Define

\[
D_L=q_L-w_L+\frac{\kappa}{1-\pi},\quad
D_H=\frac{q_H-(1-\pi)q_L}{\pi}-w_H,
\]

and \(D_A=(1-\pi)D_L+\pi D_H\).  Across \(b\in[0,1]\), their endpoint
ranges are

\[
D_L\in[.024720388,.709677721],
\]

\[
D_A\in[.033975684,.755343970],
\]

\[
D_H\in[.043230979,.801010219].
\]

All cutoffs are strictly interior.  Moreover

\[
\min_b Z(b;q_L,q_H)=.009255296>0,
\]

so \(D_L<D_H\) globally.  The action masses are

\[
(M_0,M_L,M_H)=(.765415358,.067872419,.166712223),
\]

which imply outcome probabilities

\[
(\Pr(\text{no early offer}),\Pr(\text{rejection}),
  \Pr(\text{success}))
=(.765415358,.033936209,.200648433).
\]

The two off-diagonal seller inequalities are strict:

\[
\mathbb E[C_H\mid q_L]-q_L=.065659595,\qquad
q_H-\mathbb E[C_L\mid q_H]=.066483643.
\]

The boundary-price equalities hold to the fixed-point residuals above.

### Price-box certificate

Take the rectangle with half-widths \((.004,.004)\):

\[
Q=[.605677721,.613677721]\times[.701343970,.709343970].
\]

The minimum global-interiority margins throughout \(Q\), for respectively
\(D_L>0\), \(D_H<\bar d\), and \(Z>0\), are

\[
(.020720388,.186989781,.001255296).
\]

The four inward fixed-point-map face signs are bounded below by

\[
(.004000000,.004000000,.003997165,.003996803).
\]

These are continuum face signs, not merely sampled signs.  Under global
interiority and truncated-exponential \(G\), raising \(q_H\) adds probe weight
with a likelihood ratio increasing in \(b\) because \(\Delta w\) increases;
hence \(T_L\) weakly increases in \(q_H\).  Raising \(q_L\) adds knockout
weight with a likelihood ratio decreasing in \(b\); hence \(T_H\) weakly
decreases in \(q_L\).  Each face minimum therefore occurs at the reported
corner.  The script additionally checks 301 points on every face.

### Refinement and no sale

Global interiority supplies both marginal curves for every \(b\).  The two
top-marginal rejection slacks are

\[
C_L(1)-q_L=.065279612,qquad
C_H(1)-q_H=.042435270.
\]

With \(\kappa>0\) and weakly increasing \(\Delta w\), these are the decisive
probing-undercut and probe--knockout-undercut inequalities in the nested-plan
interim-D1 proof.

The pre-selection terminal no-sale probabilities remain
\((.054872000,.031116960)\).  Accounting for accepted early trades, the
equilibrium state-conditional probabilities are

\[
(.054352108,.030956751),
\]

and their prior-weighted probability is \(.042654430\).

## 5. Bounded search and claim ledger

The standalone script first checked the finite grid

\[
n_H\in\{7,3\},\qquad
(v_L,v_H)=(.4-\varepsilon,.4+\varepsilon),
\]

for \(\varepsilon\in\{.0025,.005,.01,.02\}\).  It found one strict probing
and one strict full-menu certificate in every one of the eight state rows.
A second bounded \(7\times5\) grid around the preferred \((2,3),(.38,.42)\)
row varied \(\kappa\in\{.05,.06,.07,.08,.09,.10,.12\}\) and
\(\bar d\in\{.6,.8,1,1.2,1.5\}\).  Twelve strict full-menu roots passed the
pre-screen.  The \((\kappa,\bar d)=(.05,1)\) row above was selected because it
supports the substantially wider explicit price box; this is not an
optimization claim.

The solver uses 140-point Gauss--Legendre rules on every interval split at
\(v_L,v_H\) and all endogenous cutoff crossings, then re-evaluates the
certificate with 260-point rules.  Support endpoints are checked explicitly.

**Analytic:** the auction formulas, no-sale formula, two-kink monotonicity,
primitive probing theorem, endpoint characterization of the most profitable
knockout deviation, nested-plan D1 rankings, and corner reduction for the
price-box faces.

**Numerically certified and independently reproduced:** the two displayed
fixed points, masses, posterior seller inequalities, no-sale incidences,
global interior margins, and price-box signs.

**Not established:** interval-arithmetic error bounds, seller incentive
compatibility for the hidden committed threshold, sequential learning of a
future no-sale payoff, mixed seller responses, richer signaling schedules,
or global equilibrium uniqueness.
