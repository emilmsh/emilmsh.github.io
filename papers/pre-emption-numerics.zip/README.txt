Numerical workbook for Pre-empting Competitive Sales

Start with pre-emption-numerics.ipynb to read and rerun the calculations.
To rerun: install Python 3.12, then from this extracted directory:
  python -m pip install -r code/requirements-workbook.txt
Open pre-emption-numerics.ipynb in Jupyter or VS Code and run all cells.
The notebook calls the existing scripts and creates a fresh results directory.

Without Jupyter (only numpy and python-flint required):
  python -m pip install -r code/requirements-publication.txt
  python code/run_reproduction.py --mode publication

This is the minimal code package: it contains runnable source, configuration,
requirements, expected generated figure sources and the executed notebook. It
does not include PDFs, recorded execution logs or historical proof notes.
PACKAGE_MANIFEST.json gives SHA-256 hashes for every other member. The public
HTML workbook links to the papers and shows the recorded execution. The
package-local claims manifest omits proof-note links because they are not
calculation inputs; the public repository retains the complete research audit.

This is a website release; no archive DOI has been assigned.
