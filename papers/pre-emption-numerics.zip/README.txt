Numerical workbook for Pre-empting Competitive Sales

Start with pre-emption-numerics.html to read the recorded results.
To rerun: install Python 3.12, then from this extracted directory:
  python -m pip install -r code/requirements-workbook.txt
Open pre-emption-numerics.ipynb in Jupyter or VS Code and run all cells.
The notebook calls the existing scripts and creates a fresh results directory.

Without Jupyter (only numpy and python-flint required):
  python -m pip install -r code/requirements-publication.txt
  python code/run_reproduction.py --mode publication

execution/ preserves the recorded commands, outputs, source hashes and environment.
PACKAGE_MANIFEST.json gives SHA-256 hashes for all other members.
PAPER_VERSIONS.json identifies the companion papers. Source TeX is not needed
to reproduce the numerical suite. Supporting notes retain historical labels;
use the workbook's section map for the revised papers. The HTML and notebook
download links refer to the public website when accessed there.

This is a website release; no archive DOI has been assigned.
