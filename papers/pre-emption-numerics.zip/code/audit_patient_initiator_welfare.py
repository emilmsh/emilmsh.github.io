"""Exact welfare audit for patient initiators in note 71.

The script uses only rational arithmetic and is independent of the
equilibrium-audit scripts.  It treats all proposal costs as real resources
when reporting the full-resource totals, while displaying the allocative
term separately.
"""

from fractions import Fraction as Q


def antiderivative_w_l(b: Q) -> Q:
    """Integral of w_L(b)=b-b^3/3."""
    return b**2 / 2 - b**4 / 12


def antiderivative_loss_l(b: Q) -> Q:
    """Integral of L_L(b)=2/3-b+b^3/3."""
    return 2 * b / 3 - b**2 / 2 + b**4 / 12


def antiderivative_gamma_l(b: Q) -> Q:
    """Integral of Gamma_L(b)=(1-b)^3/3."""
    return -(1 - b) ** 4 / 12


beta = Q(9, 10)
width = 1 - beta
prob_l = Q(7, 10)
prob_h = Q(3, 10)

kappa = Q(1, 2000)
c_b = Q(1, 1000)
c_s = Q(1, 500)
total_cost = kappa + c_b + c_s

p = Q(573, 875)
w_beta = Q(657, 1000)

integral_w = antiderivative_w_l(Q(1)) - antiderivative_w_l(beta)
mean_w = integral_w / width
mean_buyer_rent = prob_l * (mean_w - w_beta)

integral_loss_l = (
    antiderivative_loss_l(Q(1)) - antiderivative_loss_l(beta)
)
mean_loss_l = integral_loss_l / width
mean_allocative_loss = prob_l * mean_loss_l
mean_full_loss = total_cost + mean_allocative_loss

integral_gamma_l = (
    antiderivative_gamma_l(Q(1)) - antiderivative_gamma_l(beta)
)
mean_gamma_l = integral_gamma_l / width
mean_c_l = mean_w + mean_gamma_l
mean_seller_change = prob_l * (p - mean_c_l) - c_s
mean_pair_change = mean_buyer_rent + mean_seller_change
mean_late_surplus_loss = prob_l * (mean_loss_l - mean_gamma_l)
mean_late_payoff_change = -mean_late_surplus_loss
mean_total_payoff_change = mean_pair_change + mean_late_payoff_change

# Patient mass and state decomposition, leaving eta symbolic as a coefficient.
patient_attempt_mass_coefficient = width
unconditional_loss_coefficient = width * mean_full_loss
state_l_loss_coefficient = prob_l * width * (total_cost + mean_loss_l)
state_h_loss_coefficient = prob_h * width * total_cost

assert prob_l + prob_h == 1
assert total_cost == Q(7, 2000)
assert integral_loss_l == Q(13, 40000)
assert mean_loss_l == Q(13, 4000)
assert mean_allocative_loss == Q(91, 40000)
assert mean_full_loss == Q(231, 40000)
assert total_cost + mean_loss_l == Q(27, 4000)

assert mean_w == Q(7961, 12000)
assert mean_buyer_rent == Q(539, 120000)
assert mean_gamma_l == Q(1, 12000)
assert mean_c_l == Q(1327, 2000)
assert mean_seller_change == -Q(161, 20000)
assert mean_pair_change == -Q(427, 120000)
assert mean_late_surplus_loss == Q(266, 120000)
assert mean_late_payoff_change == -Q(266, 120000)
assert mean_total_payoff_change == -Q(693, 120000)
assert mean_total_payoff_change == -mean_full_loss

assert patient_attempt_mass_coefficient == Q(1, 10)
assert unconditional_loss_coefficient == Q(231, 400000)
assert state_l_loss_coefficient == Q(189, 400000)
assert state_h_loss_coefficient == Q(42, 400000)
assert (
    state_l_loss_coefficient + state_h_loss_coefficient
    == unconditional_loss_coefficient
)

print("PASS: exact patient-initiator welfare accounting")
print(f"proposal cost K (full-resource case): {total_cost}")
print(f"mean L-state allocative loss: {mean_loss_l}")
print(f"mean ex-ante allocative loss: {mean_allocative_loss}")
print(f"mean full loss per patient attempt: {mean_full_loss}")
print(f"mean buyer private gain: {mean_buyer_rent}")
print(f"mean seller private change: {mean_seller_change}")
print(f"mean buyer-seller joint change: {mean_pair_change}")
print(f"mean excluded-late-bidder loss: {mean_late_surplus_loss}")
print(f"mean late-bidder payoff change: {mean_late_payoff_change}")
print(f"mean total payoff change: {mean_total_payoff_change}")
print(
    "population full-loss coefficient (multiply by eta): "
    f"{unconditional_loss_coefficient}"
)
