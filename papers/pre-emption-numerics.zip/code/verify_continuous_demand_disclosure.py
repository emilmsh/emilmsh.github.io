"""Audit full demand disclosure in the continuous-b reserve baseline.

The disclosed demand state turns the buyer's problem into a separate
one-dimensional pooling problem in each state.  This script verifies the
state-specific fixed points, incidence, payoff, and welfare formulas for the
manuscript calibration with a public reserve and a possible no-sale outcome.
It also audits the existence and interim-D1 conditions on a grid of
primitives.  All value integrals are split at the reserve and at endogenous
urgency cutoffs, so neither the reserve kink nor thin offer regions are left
to a fixed global quadrature grid.
"""

from __future__ import annotations

from math import exp

import numpy as np
from numpy.polynomial.legendre import leggauss

from audit_reserve_no_sale_baseline import (
    revenue_uniform_reserve,
    wedge_uniform_reserve,
    w_uniform_reserve,
)

from explore_continuous_regime_map import (
    D_SELLER,
    MASS_TOL,
    N_H,
    N_L,
    PI,
    Primitives,
    RegimeModel,
)


CALIBRATION = Primitives(
    kappa=0.12,
    d_bar=1.2,
    urgency_rate=10.0,
)
RESOURCE_COST = CALIBRATION.kappa
ELL = 0.4
TOL = 5e-9
PIECEWISE_QUAD_N = 72
_PIECEWISE_NODES, _PIECEWISE_WEIGHTS = leggauss(PIECEWISE_QUAD_N)
_DISCLOSED_ROOT_CACHE: dict[
    tuple[float, float, float, float, str, int],
    list[float],
] = {}


class DisclosureReserveModel(RegimeModel):
    """Reserve-adjusted model with cutoff-aware value integration."""

    def __init__(self, primitives: Primitives, ell: float = ELL) -> None:
        self.ell = ell
        super().__init__(primitives)
        self.w_l = w_uniform_reserve(N_L, self.b, ell)
        self.w_h = w_uniform_reserve(N_H, self.b, ell)
        self.bar_w = (1.0 - PI) * self.w_l + PI * self.w_h
        self.w_l_sup = w_uniform_reserve(N_L, self.b_sup, ell)
        self.w_h_sup = w_uniform_reserve(N_H, self.b_sup, ell)
        self.bar_w_sup = (1.0 - PI) * self.w_l_sup + PI * self.w_h_sup
        self.c_l = revenue_uniform_reserve(N_L, self.b, ell) - D_SELLER
        self.c_h = revenue_uniform_reserve(N_H, self.b, ell) - D_SELLER
        self.c_l_bounds = (
            float(revenue_uniform_reserve(N_L, 0.0, ell) - D_SELLER),
            float(revenue_uniform_reserve(N_L, 1.0, ell) - D_SELLER),
        )
        self.c_h_bounds = (
            float(revenue_uniform_reserve(N_H, 0.0, ell) - D_SELLER),
            float(revenue_uniform_reserve(N_H, 1.0, ell) - D_SELLER),
        )

    def w_state(
        self,
        n_late: int,
        value: np.ndarray | float,
    ) -> np.ndarray | float:
        return w_uniform_reserve(n_late, value, self.ell)

    def c_state(
        self,
        n_late: int,
        value: np.ndarray | float,
    ) -> np.ndarray | float:
        return revenue_uniform_reserve(n_late, value, self.ell) - D_SELLER

    @staticmethod
    def _crossing(
        function,
        level: float,
    ) -> float | None:
        """Locate a crossing of a continuous monotone scalar function."""
        left, right = 0.0, 1.0
        f_left = float(function(left)) - level
        f_right = float(function(right)) - level
        if abs(f_left) < 1e-13:
            return left
        if abs(f_right) < 1e-13:
            return right
        if f_left * f_right > 0.0:
            return None
        for _ in range(64):
            middle = 0.5 * (left + right)
            f_middle = float(function(middle)) - level
            if f_left * f_middle <= 0.0:
                right = middle
                f_right = f_middle
            else:
                left = middle
                f_left = f_middle
        return 0.5 * (left + right)

    def integration_points(
        self,
        cutoff_functions=(),
        zero_functions=(),
    ) -> tuple[float, ...]:
        """Split at reserve, urgency truncations, and strategy switches."""
        points = [0.0, self.ell, 1.0]
        for cutoff in cutoff_functions:
            for level in (0.0, self.pr.d_bar):
                crossing = self._crossing(cutoff, level)
                if crossing is not None:
                    points.append(crossing)
        for function in zero_functions:
            crossing = self._crossing(function, 0.0)
            if crossing is not None:
                points.append(crossing)
        ordered = sorted(min(1.0, max(0.0, point)) for point in points)
        unique: list[float] = []
        for point in ordered:
            if not unique or point - unique[-1] > 2e-13:
                unique.append(point)
        return tuple(unique)

    def integrate_function(
        self,
        function,
        cutoff_functions=(),
        zero_functions=(),
    ) -> float:
        points = self.integration_points(cutoff_functions, zero_functions)
        return self.integrate_on_points(function, points)

    @staticmethod
    def integrate_on_points(function, points: tuple[float, ...]) -> float:
        total = 0.0
        for left, right in zip(points[:-1], points[1:]):
            if right - left <= 2e-13:
                continue
            values = left + 0.5 * (_PIECEWISE_NODES + 1.0) * (right - left)
            weights = 0.5 * (right - left) * _PIECEWISE_WEIGHTS
            total += float(np.dot(weights, function(values)))
        return total

    def state_mapping(self, state: str, price: float) -> float | None:
        n_late = N_L if state == "L" else N_H

        def cutoff(value):
            return price - self.w_state(n_late, value) + self.pr.kappa

        def offer_mass(value):
            return 1.0 - self.urgency_cdf(cutoff(value))

        points = self.integration_points(cutoff_functions=(cutoff,))
        denominator = self.integrate_on_points(offer_mass, points)
        if denominator <= 0.0:
            return None
        numerator = self.integrate_on_points(
            lambda value: self.c_state(n_late, value) * offer_mass(value),
            points,
        )
        return numerator / denominator

    def state_mass(self, state: str, price: float) -> float:
        n_late = N_L if state == "L" else N_H

        def cutoff(value):
            return price - self.w_state(n_late, value) + self.pr.kappa

        return self.integrate_function(
            lambda value: 1.0 - self.urgency_cdf(cutoff(value)),
            cutoff_functions=(cutoff,),
        )

    def private_cutoffs(self, q_l: float, q_h: float):
        a = 1.0 - PI

        def d_l(value):
            return q_l - self.w_state(N_L, value) + self.pr.kappa / a

        def d_aux(value):
            bar_w = (
                a * self.w_state(N_L, value)
                + PI * self.w_state(N_H, value)
            )
            return q_h - bar_w + self.pr.kappa

        def d_h(value):
            return (q_h - a * q_l) / PI - self.w_state(N_H, value)

        def z(value):
            return d_aux(value) - d_l(value)

        return d_l, d_aux, d_h, z

    def private_masses(self, q_l: float, q_h: float):
        d_l, d_aux, d_h, z = self.private_cutoffs(q_l, q_h)

        def masses(value):
            screening = z(value) > 0.0
            cdf_l = self.urgency_cdf(d_l(value))
            cdf_aux = self.urgency_cdf(d_aux(value))
            cdf_h = self.urgency_cdf(d_h(value))
            m_0 = np.where(screening, cdf_l, cdf_aux)
            m_l = np.where(screening, cdf_h - cdf_l, 0.0)
            m_h = np.where(screening, 1.0 - cdf_h, 1.0 - cdf_aux)
            return m_0, m_l, m_h

        breakpoints = (d_l, d_aux, d_h)
        switches = (z,)
        return masses, breakpoints, switches

    def private_integral(
        self,
        q_l: float,
        q_h: float,
        function,
    ) -> float:
        _, breakpoints, switches = self.private_masses(q_l, q_h)
        return self.integrate_function(
            function,
            cutoff_functions=breakpoints,
            zero_functions=switches,
        )

    def two_price_map(self, q: np.ndarray) -> np.ndarray | None:
        q_l, q_h = map(float, q)
        masses, breakpoints, switches = self.private_masses(q_l, q_h)
        points = self.integration_points(breakpoints, switches)
        mass_l = self.integrate_on_points(
            lambda value: masses(value)[1],
            points,
        )
        mass_h = self.integrate_on_points(
            lambda value: masses(value)[2],
            points,
        )
        if mass_l <= MASS_TOL or mass_h <= MASS_TOL:
            return None
        mapped_l = self.integrate_on_points(
            lambda value: self.c_state(N_L, value) * masses(value)[1],
            points,
        ) / mass_l
        mapped_h = self.integrate_on_points(
            lambda value: self.c_state(N_H, value) * masses(value)[2],
            points,
        ) / mass_h
        return np.array([mapped_l, mapped_h])


def tail_first_moment(
    cutoff: np.ndarray | float,
    primitives: Primitives,
) -> np.ndarray:
    """Return E[d 1{d >= cutoff}] for truncated-exponential urgency."""
    lower = np.clip(np.asarray(cutoff), 0.0, primitives.d_bar)
    rate = primitives.urgency_rate
    upper = primitives.d_bar
    denominator = 1.0 - exp(-rate * upper)
    moment = (
        (lower + 1.0 / rate) * np.exp(-rate * lower)
        - (upper + 1.0 / rate) * exp(-rate * upper)
    ) / denominator
    return moment


def disclosed_roots(
    model: DisclosureReserveModel,
    state: str,
    grid_size: int = 1201,
) -> list[float]:
    """Find state-specific pooling roots, including thin entry regions."""
    cache_key = (
        model.pr.kappa,
        model.pr.d_bar,
        model.pr.urgency_rate,
        model.ell,
        state,
        grid_size,
    )
    if cache_key in _DISCLOSED_ROOT_CACHE:
        return list(_DISCLOSED_ROOT_CACHE[cache_key])
    if state == "L":
        bounds = model.c_l_bounds
    else:
        bounds = model.c_h_bounds

    def mapping(price: float) -> float | None:
        return model.state_mapping(state, price)

    grid = np.linspace(bounds[0], bounds[1], grid_size)
    residuals: list[float | None] = []
    for price in grid:
        mapped = mapping(float(price))
        residuals.append(None if mapped is None else mapped - float(price))

    roots: list[float] = []
    for index in range(len(grid) - 1):
        f_left, f_right = residuals[index], residuals[index + 1]
        if f_left is None or f_right is None:
            continue
        if abs(f_left) < 1e-12:
            roots.append(float(grid[index]))
            continue
        if f_left * f_right > 0.0:
            continue
        left, right = float(grid[index]), float(grid[index + 1])
        for _ in range(64):
            middle = 0.5 * (left + right)
            mapped_middle = mapping(middle)
            mapped_left = mapping(left)
            assert mapped_middle is not None
            assert mapped_left is not None
            f_middle = mapped_middle - middle
            if (mapped_left - left) * f_middle <= 0.0:
                right = middle
            else:
                left = middle
        roots.append(0.5 * (left + right))

    unique: list[float] = []
    for root in roots:
        if not any(abs(root - old) < 2e-8 for old in unique):
            unique.append(root)
    _DISCLOSED_ROOT_CACHE[cache_key] = list(unique)
    return unique

def d1_data(
    state: str,
    price: float,
    primitives: Primitives,
    ell: float = ELL,
) -> tuple[float | None, float | None, bool]:
    """Return highest marginal b, its continuation value, and D1 survival."""
    n_late = N_L if state == "L" else N_H

    def cutoff(value: float) -> float:
        return (
            price
            - float(w_uniform_reserve(n_late, value, ell))
            + primitives.kappa
        )

    if cutoff(1.0) >= 0.0:
        highest_marginal = 1.0
    elif cutoff(0.0) <= 0.0:
        # Every type offers even at d=0.  There is no wait/offer margin.
        return None, None, False
    else:
        left, right = 0.0, 1.0
        for _ in range(90):
            middle = 0.5 * (left + right)
            if cutoff(middle) >= 0.0:
                left = middle
            else:
                right = middle
        highest_marginal = 0.5 * (left + right)

    continuation = (
        float(revenue_uniform_reserve(n_late, highest_marginal, ell))
        - D_SELLER
    )
    survives = price <= continuation + TOL
    return highest_marginal, continuation, survives


def allocation_gain(
    n_late: int,
    value: np.ndarray | float,
    ell: float = ELL,
) -> np.ndarray | float:
    """Return the reserve-adjusted terminal allocative gain."""
    value_array = np.asarray(value)
    threshold = np.maximum(value_array, ell)
    result = np.maximum(ell - value_array, 0.0) + (
        n_late / (n_late + 1.0)
        - threshold
        + threshold ** (n_late + 1) / (n_late + 1.0)
    )
    return float(result) if np.ndim(value_array) == 0 else result


def late_surplus(
    n_late: int,
    value: np.ndarray | float,
    ell: float = ELL,
) -> np.ndarray | float:
    """Return aggregate late-buyer surplus with reserve and possible no sale."""
    return allocation_gain(n_late, value, ell) - wedge_uniform_reserve(
        n_late,
        value,
        ell,
    )


def calibration_audit() -> dict[str, float]:
    model = DisclosureReserveModel(CALIBRATION)
    roots_l = disclosed_roots(model, "L")
    roots_h = disclosed_roots(model, "H")
    assert len(roots_l) == len(roots_h) == 1
    q_disclosed_l, q_disclosed_h = roots_l[0], roots_h[0]

    private_roots = model.solve_two_price()
    assert len(private_roots) == 1
    q_private_l, q_private_h = private_roots[0]

    private_masses, private_breakpoints, private_switches = (
        model.private_masses(q_private_l, q_private_h)
    )
    mass_no_offer = model.integrate_function(
        lambda value: private_masses(value)[0],
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )
    mass_probe = model.integrate_function(
        lambda value: private_masses(value)[1],
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )
    mass_knockout = model.integrate_function(
        lambda value: private_masses(value)[2],
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )
    private_attempt = mass_probe + mass_knockout
    private_rejected = PI * mass_probe
    private_completed = (1.0 - PI) * private_attempt + PI * mass_knockout

    disclosed: dict[str, dict[str, object]] = {}
    for state, price, n_late in (
        ("L", q_disclosed_l, N_L),
        ("H", q_disclosed_h, N_H),
    ):
        def cutoff(value, price=price, n_late=n_late):
            return (
                price
                - model.w_state(n_late, value)
                + CALIBRATION.kappa
            )

        aggregate_mass = model.state_mass(state, price)
        mapped_price = model.state_mapping(state, price)
        assert mapped_price is not None
        assert abs(price - mapped_price) < TOL
        assert aggregate_mass > 0.0
        assert model.integrate_function(
            lambda value: model.urgency_cdf(cutoff(value)),
            cutoff_functions=(cutoff,),
        ) > 0.0
        assert float(cutoff(1.0)) > 0.0
        _, _, survives = d1_data(state, price, CALIBRATION)
        assert survives
        disclosed[state] = {
            "price": price,
            "cutoff": cutoff,
            "mass": aggregate_mass,
        }

    disclosed_attempt = (
        (1.0 - PI) * float(disclosed["L"]["mass"])
        + PI * float(disclosed["H"]["mass"])
    )

    d_private_l, d_private_aux, d_private_h, _ = model.private_cutoffs(
        q_private_l,
        q_private_h,
    )
    d_disclosed_l = disclosed["L"]["cutoff"]
    d_disclosed_h = disclosed["H"]["cutoff"]
    assert callable(d_disclosed_l)
    assert callable(d_disclosed_h)
    predicted_shift_l = (
        q_disclosed_l
        - q_private_l
        - PI * CALIBRATION.kappa / (1.0 - PI)
    )
    predicted_shift_h = (
        q_disclosed_h
        + CALIBRATION.kappa
        - (
            q_private_h - (1.0 - PI) * q_private_l
        ) / PI
    )
    check_grid = np.linspace(0.0, 1.0, 401)
    assert np.max(
        np.abs(
            d_disclosed_l(check_grid)
            - d_private_l(check_grid)
            - predicted_shift_l
        )
    ) < TOL
    assert np.max(
        np.abs(
            d_disclosed_h(check_grid)
            - d_private_h(check_grid)
            - predicted_shift_h
        )
    ) < TOL

    def private_early_integrand(value):
        cutoff_l = d_private_l(value)
        cutoff_h = d_private_h(value)
        cutoff_aux = d_private_aux(value)
        first_l = tail_first_moment(cutoff_l, CALIBRATION)
        first_h = tail_first_moment(cutoff_h, CALIBRATION)
        cdf_l = model.urgency_cdf(cutoff_l)
        cdf_h = model.urgency_cdf(cutoff_h)
        survival_h = 1.0 - cdf_h
        probe_urgency_mass = cdf_h - cdf_l
        return (
            (1.0 - PI)
            * (
                first_l
                - first_h
                - cutoff_l * probe_urgency_mass
            )
            + first_h
            - cutoff_aux * survival_h
        )

    private_early = model.integrate_function(
        private_early_integrand,
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )

    def private_seller_integrand(value):
        _, probe, knockout = private_masses(value)
        return (
            (1.0 - PI)
            * (
                probe * (q_private_l - model.c_state(N_L, value))
                + knockout * (q_private_h - model.c_state(N_L, value))
            )
            + PI
            * knockout
            * (q_private_h - model.c_state(N_H, value))
        )

    private_seller = model.integrate_function(
        private_seller_integrand,
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )

    def private_late_loss_integrand(value):
        _, probe, knockout = private_masses(value)
        return (
            (1.0 - PI)
            * (probe + knockout)
            * late_surplus(N_L, value)
            + PI * knockout * late_surplus(N_H, value)
        )

    loss_private_late = model.integrate_function(
        private_late_loss_integrand,
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )

    disclosed_early = 0.0
    loss_disclosed_late = 0.0
    for state, state_probability, n_late in (
        ("L", 1.0 - PI, N_L),
        ("H", PI, N_H),
    ):
        cutoff = disclosed[state]["cutoff"]
        assert callable(cutoff)
        disclosed_early += state_probability * model.integrate_function(
            lambda value, cutoff=cutoff: (
                tail_first_moment(cutoff(value), CALIBRATION)
                - cutoff(value)
                * (1.0 - model.urgency_cdf(cutoff(value)))
            ),
            cutoff_functions=(cutoff,),
        )
        loss_disclosed_late += state_probability * model.integrate_function(
            lambda value, cutoff=cutoff, n_late=n_late: (
                (1.0 - model.urgency_cdf(cutoff(value)))
                * late_surplus(n_late, value)
            ),
            cutoff_functions=(cutoff,),
        )

    welfare_private = (
        private_seller + private_early - loss_private_late
    )
    welfare_disclosed = disclosed_early - loss_disclosed_late

    # Direct resource accounting and the disclosure decomposition.
    def direct_private_integrand(value):
        cutoff_l = d_private_l(value)
        cutoff_h = d_private_h(value)
        _, probe, _ = private_masses(value)
        return (
            (1.0 - PI)
            * (
                tail_first_moment(cutoff_l, CALIBRATION)
                + (D_SELLER - allocation_gain(N_L, value) - RESOURCE_COST)
                * (1.0 - model.urgency_cdf(cutoff_l))
            )
            + PI
            * (
                -RESOURCE_COST * probe
                + tail_first_moment(cutoff_h, CALIBRATION)
                + (D_SELLER - allocation_gain(N_H, value) - RESOURCE_COST)
                * (1.0 - model.urgency_cdf(cutoff_h))
            )
        )

    direct_private = model.integrate_function(
        direct_private_integrand,
        cutoff_functions=private_breakpoints,
        zero_functions=private_switches,
    )
    direct_disclosed = 0.0
    acceptance_change_value = 0.0
    for state, state_probability, n_late, private_cutoff in (
        ("L", 1.0 - PI, N_L, d_private_l),
        ("H", PI, N_H, d_private_h),
    ):
        disclosed_cutoff = disclosed[state]["cutoff"]
        assert callable(disclosed_cutoff)

        def disclosed_tail(value):
            cutoff = disclosed_cutoff(value)
            welfare_constant = (
                D_SELLER
                - allocation_gain(n_late, value)
                - RESOURCE_COST
            )
            return (
                tail_first_moment(cutoff, CALIBRATION)
                + welfare_constant * (1.0 - model.urgency_cdf(cutoff))
            )

        def private_tail(value):
            cutoff = private_cutoff(value)
            welfare_constant = (
                D_SELLER
                - allocation_gain(n_late, value)
                - RESOURCE_COST
            )
            return (
                tail_first_moment(cutoff, CALIBRATION)
                + welfare_constant * (1.0 - model.urgency_cdf(cutoff))
            )

        disclosed_component = model.integrate_function(
            disclosed_tail,
            cutoff_functions=(disclosed_cutoff,),
        )
        private_component = model.integrate_function(
            private_tail,
            cutoff_functions=(private_cutoff,),
        )
        direct_disclosed += state_probability * disclosed_component
        acceptance_change_value += state_probability * (
            disclosed_component - private_component
        )

    assert abs(welfare_private - direct_private) < 2e-8
    assert abs(welfare_disclosed - direct_disclosed) < 2e-8
    assert abs(
        welfare_disclosed
        - welfare_private
        - (
            RESOURCE_COST * private_rejected
            + acceptance_change_value
        )
    ) < 2e-8
    rejection_cost_saving = RESOURCE_COST * private_rejected
    disclosure_welfare_change = welfare_disclosed - welfare_private
    assert abs(mass_no_offer + private_attempt - 1.0) < TOL

    targets = {
        "q_disclosed_l": 0.633695435821,
        "q_disclosed_h": 0.829176788566,
        "mass_disclosed_l": 0.155658947575,
        "mass_disclosed_h": 0.090236868640,
        "private_attempt": 0.059993929487,
        "private_completed": 0.046566704856,
        "private_rejected": 0.013427224631,
        "disclosed_attempt": 0.122947908107,
        "private_welfare": 0.005636513279,
        "disclosed_welfare": 0.007221645431,
        "rejection_cost_saving": 0.001611266956,
        "acceptance_change_value": -0.000026134804,
        "disclosure_welfare_change": 0.001585132152,
    }

    results = {
        "q_private_l": q_private_l,
        "q_private_h": q_private_h,
        "q_disclosed_l": q_disclosed_l,
        "q_disclosed_h": q_disclosed_h,
        "mass_disclosed_l": float(disclosed["L"]["mass"]),
        "mass_disclosed_h": float(disclosed["H"]["mass"]),
        "private_attempt": private_attempt,
        "private_completed": private_completed,
        "private_rejected": private_rejected,
        "disclosed_attempt": disclosed_attempt,
        "private_seller": private_seller,
        "private_early": private_early,
        "private_late": -loss_private_late,
        "private_welfare": welfare_private,
        "disclosed_early": disclosed_early,
        "disclosed_late": -loss_disclosed_late,
        "disclosed_welfare": welfare_disclosed,
        "rejection_cost_saving": rejection_cost_saving,
        "acceptance_change_value": acceptance_change_value,
        "disclosure_welfare_change": disclosure_welfare_change,
        "cutoff_shift_l": predicted_shift_l,
        "cutoff_shift_h": predicted_shift_h,
    }
    for name, target in targets.items():
        assert abs(results[name] - target) < 3e-9, (
            name,
            results[name],
            target,
        )
    return results


def primitive_grid_audit() -> dict[str, int]:
    counts = {
        "configurations": 0,
        "active_state_problems": 0,
        "fixed_points": 0,
        "multiple_root_cases": 0,
        "d1_survival": 0,
        "d1_failure": 0,
    }
    for kappa in (0.001, 0.01, 0.05, 0.12, 0.3):
        for d_bar in (0.01, 0.05, 0.1, 0.15, 0.3, 0.8, 1.2):
            for urgency_rate in (1.0, 10.0, 25.0):
                counts["configurations"] += 1
                primitives = Primitives(
                    kappa=kappa,
                    d_bar=d_bar,
                    urgency_rate=urgency_rate,
                )
                model = DisclosureReserveModel(primitives)
                for state, n_late, bounds in (
                    ("L", N_L, model.c_l_bounds),
                    ("H", N_H, model.c_h_bounds),
                ):
                    entry_threshold = (
                        bounds[1]
                        - float(w_uniform_reserve(n_late, 1.0, ELL))
                        + kappa
                    )
                    if d_bar <= entry_threshold + 1e-12:
                        continue

                    counts["active_state_problems"] += 1
                    roots = disclosed_roots(model, state, grid_size=121)
                    assert roots
                    counts["fixed_points"] += len(roots)
                    if len(roots) > 1:
                        counts["multiple_root_cases"] += 1

                    for price in roots:
                        highest_marginal, continuation, survives = d1_data(
                            state,
                            price,
                            primitives,
                        )
                        assert highest_marginal is not None
                        assert continuation is not None
                        counts[
                            "d1_survival" if survives else "d1_failure"
                        ] += 1
    return counts


def boundary_and_d1_audit() -> dict[str, int]:
    """Stress exact entry boundaries and construct D1 failure witnesses."""
    counts = {
        "auction_boundary_checks": 0,
        "active_boundary_checks": 0,
        "d1_failure_witnesses": 0,
    }
    for kappa in (0.02, 0.05, 0.12, 0.3):
        for urgency_rate in (0.2, 1.0, 10.0, 50.0):
            for state, n_late in (("L", N_L), ("H", N_H)):
                reference = DisclosureReserveModel(
                    Primitives(
                        kappa=kappa,
                        d_bar=1.0,
                        urgency_rate=urgency_rate,
                    )
                )
                bounds = (
                    reference.c_l_bounds
                    if state == "L"
                    else reference.c_h_bounds
                )
                entry_threshold = (
                    bounds[1]
                    - float(w_uniform_reserve(n_late, 1.0, ELL))
                    + kappa
                )
                assert entry_threshold > 0.0

                for offset in (-1e-8, 0.0):
                    primitives = Primitives(
                        kappa=kappa,
                        d_bar=entry_threshold + offset,
                        urgency_rate=urgency_rate,
                    )
                    deviation_gain = (
                        float(w_uniform_reserve(n_late, 1.0, ELL))
                        + primitives.d_bar
                        - bounds[1]
                        - kappa
                    )
                    assert deviation_gain <= TOL
                    counts["auction_boundary_checks"] += 1

                primitives = Primitives(
                    kappa=kappa,
                    d_bar=entry_threshold + 1e-8,
                    urgency_rate=urgency_rate,
                )
                model = DisclosureReserveModel(primitives)
                roots = disclosed_roots(model, state, grid_size=81)
                assert roots
                for price in roots:
                    assert bounds[0] < price < bounds[1]
                    counts["active_boundary_checks"] += 1

    for kappa in (0.001, 0.01, 0.05, 0.12, 0.3):
        for d_bar in (0.01, 0.05, 0.1, 0.15, 0.3, 0.8, 1.2):
            for urgency_rate in (1.0, 10.0, 25.0):
                primitives = Primitives(
                    kappa=kappa,
                    d_bar=d_bar,
                    urgency_rate=urgency_rate,
                )
                model = DisclosureReserveModel(primitives)
                for state, n_late, bounds in (
                    ("L", N_L, model.c_l_bounds),
                    ("H", N_H, model.c_h_bounds),
                ):
                    entry_threshold = (
                        bounds[1]
                        - float(w_uniform_reserve(n_late, 1.0, ELL))
                        + kappa
                    )
                    if d_bar <= entry_threshold + 1e-12:
                        continue
                    for price in disclosed_roots(
                        model,
                        state,
                        grid_size=121,
                    ):
                        highest_marginal, continuation, survives = d1_data(
                            state,
                            price,
                            primitives,
                        )
                        assert highest_marginal is not None
                        assert continuation is not None
                        if survives:
                            assert price <= continuation + TOL
                            continue

                        undercut = 0.5 * (price + continuation)
                        assert continuation < undercut < price
                        cutoff = (
                            price
                            - float(
                                w_uniform_reserve(
                                    n_late,
                                    highest_marginal,
                                    ELL,
                                )
                            )
                            + kappa
                        )
                        assert -TOL <= cutoff <= d_bar + TOL
                        # All D1-surviving marginal types have weakly lower b,
                        # so this undercut is accepted under every permitted
                        # posterior and strictly benefits each of them.
                        assert price - undercut > 0.0
                        counts["d1_failure_witnesses"] += 1

    return counts

def main() -> None:
    results = calibration_audit()
    counts = primitive_grid_audit()
    stress_counts = boundary_and_d1_audit()

    print(
        "private prices: "
        f"q_L={results['q_private_l']:.12f}, "
        f"q_H={results['q_private_h']:.12f}"
    )
    print(
        "disclosed prices: "
        f"q_L={results['q_disclosed_l']:.12f}, "
        f"q_H={results['q_disclosed_h']:.12f}"
    )
    print(
        "disclosed conditional offer masses: "
        f"M_L={results['mass_disclosed_l']:.12f}, "
        f"M_H={results['mass_disclosed_h']:.12f}"
    )
    print(
        "private incidence: "
        f"attempt={results['private_attempt']:.12f}, "
        f"completed={results['private_completed']:.12f}, "
        f"rejected={results['private_rejected']:.12f}"
    )
    print(
        "disclosed incidence: "
        f"attempt=completed={results['disclosed_attempt']:.12f}, "
        "rejected=0"
    )
    print(
        "cutoff shifts: "
        f"L={results['cutoff_shift_l']:.9f}, "
        f"H={results['cutoff_shift_h']:.9f}"
    )
    print(
        "private payoff changes versus auction: "
        f"seller={results['private_seller']:.12f}, "
        f"early={results['private_early']:.12f}, "
        f"late={results['private_late']:.12f}, "
        f"total={results['private_welfare']:.12f}"
    )
    print(
        "disclosed payoff changes versus auction: "
        "seller=0, "
        f"early={results['disclosed_early']:.12f}, "
        f"late={results['disclosed_late']:.12f}, "
        f"total={results['disclosed_welfare']:.12f}"
    )
    print(
        "disclosure welfare change versus opacity: "
        f"total={results['disclosure_welfare_change']:.12f}, "
        f"saved rejected-attempt resources={results['rejection_cost_saving']:.12f}, "
        f"changed-acceptance component={results['acceptance_change_value']:.12f}"
    )
    print(
        "grid audit: "
        f"{counts['configurations']} primitive configurations, "
        f"{counts['active_state_problems']} active state problems, "
        f"{counts['fixed_points']} fixed points, "
        f"{counts['d1_survival']} D1-compatible, "
        f"{counts['d1_failure']} D1 failures, "
        f"{counts['multiple_root_cases']} multiple-root cases"
    )
    print(
        "boundary stress audit: "
        f"{stress_counts['auction_boundary_checks']} auction checks, "
        f"{stress_counts['active_boundary_checks']} active checks, "
        f"{stress_counts['d1_failure_witnesses']} explicit D1 witnesses"
    )
    print("continuous demand-disclosure audit: passed")


if __name__ == "__main__":
    main()
