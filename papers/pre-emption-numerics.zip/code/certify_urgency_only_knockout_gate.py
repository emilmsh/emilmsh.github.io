"""Rigorous Arb certificate for the urgency-only knockout-only D1 gate.

Requires ``python-flint==0.9.0``.  Arb supplies outward-rounded ball
arithmetic and validated adaptive integration.  The setting is the
urgency-only microfoundation of Proposition prop:urgencyknockoutgate and
Appendix app:urgencyknockoutgate (derivation notes/176-urgency-only-parity.md;
floating-point audit code/audit_urgency_only_knockout_only_d1.py).  The
exact primitives are

    F = U[0,1], n = 2 deterministic late bidders, v = 2/5,
    pi = 1/2, kappa = 1/100 (variant: 1/20),
    d_{S,L} = 1/50, d_{S,H} = 0,
    buyer urgency truncated-exponential(rate 10) on [0,1].

With n = 2 the uniform formulas eq:uniformformulas give, for b > v,

    w(b) = b - (b^3 - v^3)/3,      R(b) = 1/3 + b^2 - 2 b^3/3 + v^3/3,
    Gamma(b) = R(b) - w(b) = (1 - b)^3/3,

and constants below v.  C_s(b) = R(b) - d_{S,s}.

The script certifies:

1. existence and local uniqueness of the boundary knockout-only fixed point
   q* = E[C_H(b) | w(b) + d >= q* + kappa], via a one-dimensional Krawczyk
   enclosure.  Because the knockout weight min{1, ...} has a kink at the
   value b where w(b) = q + kappa, the root is parameterised by that kink
   t = b_K^0 with q = w(t) - kappa; the residual Phi(t) is then analytic
   piecewise in b with t-dependent endpoints removed by the substitution
   b = v + (t - v)s.  Local uniqueness transfers to q* because w' = 1 - b^2
   is certified positive on the box;
2. the enclosures of b_K^0 = w^{-1}(q* + kappa), Gamma(b_K^0), and the
   interiority D_K(bar b) < 0 that makes the kink parameterisation valid;
3. strict positivity of both gate margins of prop:urgencyknockoutgate,
   Gamma(b_K^0) + kappa/(1-pi) - d_{S,L} and C_H(b_K^0) - q*, plus the
   strict negativity of the (1,0)-branch deterrence supremum
   (1-pi)(q* + kappa - C_L(b_K^0)) - kappa used by the survival completion;
4. the survival boundary d_{S,L}* = Gamma(b_K^0) + kappa/(1-pi);
5. strict positivity of the waiting and knockout masses;
6. the kappa = 1/20 variant: Krawczyk enclosure of its fixed point q*, the
   corner condition D_K(bar b) >= 0 (so b_K^0 = bar b), the full-rejection
   margin C_L(bar b) - q* > 0, both gate margins, and positive masses;
7. the failure demonstrations at d_{S,L} in {1/40, 3/100, 1/20}: the killer
   undercut interval (C_L(b_K^0), q* - pi kappa/(1-pi)) is certified
   nonempty, the forced-acceptance gain at its midpoint is certified
   strictly positive, and each gap is certified below the raw-PBE
   persistence bound w(bar b) - q* + pi kappa/(1-pi).

The only non-elementary integrals are int e^{lambda w(b)} db and
int R(b) e^{lambda w(b)} db above v (the exponential of a cubic); Arb's
validated integration encloses them with outward rounding.  Everything
else is exact rational/polynomial arithmetic on balls.

This is a local existence certificate for the boundary-priced fixed point.
It does not establish global equilibrium uniqueness and does not replace
the analytic survival/failure proofs of app:urgencyknockoutgate; it
certifies every numerical premise those proofs consume.

Install the pinned public dependencies and run from the repository root:

    python -m pip install -r code/requirements-publication.txt
    python code/certify_urgency_only_knockout_gate.py

Add ``--json`` for deterministic machine-readable interval output.
"""

from __future__ import annotations

import argparse
import json

import flint
from flint import acb, arb, ctx


ctx.dps = 60

PI = arb("1/2")
A = 1 - PI
STANDING_VALUE = arb("2/5")
Z_L = arb("1/50")            # d_{S,L}: urgent-seller timing cost
Z_H = arb(0)                 # d_{S,H}: patient-seller timing cost
KAPPA = arb("1/100")
KAPPA_VARIANT = arb("1/20")
D_BAR = arb(1)
LAMBDA = arb(10)
EXP_BAR = (-LAMBDA * D_BAR).exp()
URGENCY_DENOMINATOR = 1 - EXP_BAR
FAILURE_GAPS = (arb("1/40"), arb("3/100"), arb("1/20"))

# R(b) on [0, v] with n = 2: (n-1)/(n+1) + v^n - (n-1) v^{n+1}/(n+1).
R_FLAT = arb(1) / 3 + STANDING_VALUE**2 - STANDING_VALUE**3 / 3
# int_0^v e^{lambda b} db, exact.
EXP_BELOW_V = ((LAMBDA * STANDING_VALUE).exp() - 1) / LAMBDA


class AD:
    """One-variable complex-ball automatic differentiation."""

    __slots__ = ("v", "g")

    def __init__(self, value, gradient=None):
        self.v = value if isinstance(value, acb) else acb(value)
        self.g = acb(0) if gradient is None else gradient

    def __add__(self, other):
        other = as_ad(other)
        return AD(self.v + other.v, self.g + other.g)

    __radd__ = __add__

    def __neg__(self):
        return AD(-self.v, -self.g)

    def __sub__(self, other):
        return self + (-as_ad(other))

    def __rsub__(self, other):
        return as_ad(other) - self

    def __mul__(self, other):
        other = as_ad(other)
        return AD(self.v * other.v, self.g * other.v + self.v * other.g)

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_ad(other)
        return AD(
            self.v / other.v,
            (self.g * other.v - self.v * other.g) / (other.v * other.v),
        )

    def __rtruediv__(self, other):
        return as_ad(other) / self

    def __pow__(self, exponent):
        return AD(
            self.v**exponent,
            exponent * self.v ** (exponent - 1) * self.g,
        )

    def exp(self):
        value = self.v.exp()
        return AD(value, value * self.g)


def as_ad(value):
    return value if isinstance(value, AD) else AD(value)


def require(condition, message):
    """Certificate gate that remains active under ``python -O``."""

    if not condition:
        raise AssertionError(message)


def willingness_upper(b):
    """w(b) on b >= v (n = 2, uniform values)."""

    return b - (b**3 - STANDING_VALUE**3) / 3


def revenue_upper(b):
    """R(b) on b >= v (n = 2, uniform values)."""

    return arb(1) / 3 + b**2 - 2 * b**3 / 3 + STANDING_VALUE**3 / 3


def wedge_upper(b):
    """Gamma(b) = R(b) - w(b) = (1 - b)^3/3 on b >= v (exact algebra)."""

    return (1 - b) ** 3 / 3


def revenue_antiderivative_upper(t):
    """int_v^t R(b) db, t >= v (polynomial, AD-able)."""

    return (
        (arb(1) / 3 + STANDING_VALUE**3 / 3) * (t - STANDING_VALUE)
        + (t**3 - STANDING_VALUE**3) / 3
        - (t**4 - STANDING_VALUE**4) / 6
    )


# int_0^1 R(b) db, exact.
REVENUE_INTEGRAL_FULL = (
    R_FLAT * STANDING_VALUE + revenue_antiderivative_upper(arb(1))
)


def integrate_ad(function, tolerance="1e-45"):
    """Validated integration over s in [0,1] of a value and its derivative."""

    output = []
    absolute_tolerance = arb(tolerance)
    for component_index in range(2):

        def component(s, analytic, component_index=component_index):
            value = function(AD(s))
            return value.v if component_index == 0 else value.g

        output.append(
            acb.integral(
                component,
                0,
                1,
                abs_tol=absolute_tolerance,
                rel_tol=absolute_tolerance,
                deg_limit=20,
                eval_limit=100000,
                depth_limit=40,
                use_heap=True,
            )
        )
    return AD(output[0], output[1])


def exponential_moments(t):
    """(int_v^t e^{lam w}, int_v^t R e^{lam w}) via b = v + (t - v)s.

    The substitution moves the t-dependence of the endpoint into the
    integrand, which stays entire in s, so validated integration and
    automatic differentiation in t both apply.
    """

    def integrand_one(s):
        b = STANDING_VALUE + (t - STANDING_VALUE) * s
        return (t - STANDING_VALUE) * (LAMBDA * willingness_upper(b)).exp()

    def integrand_revenue(s):
        b = STANDING_VALUE + (t - STANDING_VALUE) * s
        return (
            (t - STANDING_VALUE)
            * revenue_upper(b)
            * (LAMBDA * willingness_upper(b)).exp()
        )

    return integrate_ad(integrand_one), integrate_ad(integrand_revenue)


def boundary_residual(t, kappa):
    """Residual Phi(t) of the kink-parameterised boundary fixed point.

    The pool is {(b, d): w(b) + d >= q + kappa} with q = w(t) - kappa, so
    the knockout weight is 1 - G(w(t) - w(b)), equal to 1 on [t, 1] and to
    (e^{-lam(w(t) - w(b))} - e^{-lam})/(1 - e^{-lam}) on [0, t]; validity
    (0 <= w(t) - w(b) <= 1 on [0, t]) is certified separately.  Returns
    (Phi, knockout mass), both AD in t.
    """

    moment_one, moment_revenue = exponential_moments(t)
    weight_top = (-LAMBDA * willingness_upper(t)).exp()
    mass_knockout = (
        weight_top * (EXP_BELOW_V + moment_one) - EXP_BAR * t
    ) / URGENCY_DENOMINATOR + (1 - t)
    revenue_below = R_FLAT * STANDING_VALUE + revenue_antiderivative_upper(t)
    revenue_knockout = (
        weight_top * (R_FLAT * EXP_BELOW_V + moment_revenue)
        - EXP_BAR * revenue_below
    ) / URGENCY_DENOMINATOR + (REVENUE_INTEGRAL_FULL - revenue_below)
    price = willingness_upper(t) - kappa
    return revenue_knockout - price * mass_knockout, mass_knockout


def variant_constants():
    """Full-support exponential moments for the corner (kappa = 1/20) case."""

    moment_one, moment_revenue = exponential_moments(AD(acb(1)))
    j_one = EXP_BELOW_V + real_part(moment_one)
    j_revenue = R_FLAT * EXP_BELOW_V + real_part(moment_revenue)
    return j_one, j_revenue


def variant_residual(q, kappa, j_one, j_revenue):
    """Residual of the corner fixed point: cutoff positive on all of [0,1].

    Validity (0 <= q + kappa - w(b) <= 1 for all b) is certified
    separately via D_K(1) >= 0 and q + kappa < 1.  Returns
    (Phi, knockout mass), both AD in q.
    """

    weight_top = (-LAMBDA * (q + kappa)).exp()
    mass_knockout = (weight_top * j_one - EXP_BAR) / URGENCY_DENOMINATOR
    revenue_knockout = (
        weight_top * j_revenue - EXP_BAR * REVENUE_INTEGRAL_FULL
    ) / URGENCY_DENOMINATOR
    return revenue_knockout - q * mass_knockout, mass_knockout


def real_part(value):
    require(value.v.imag.contains(0), ("nonreal integral", value.v))
    return value.v.real


def krawczyk_scalar(evaluator, center_string, radius_string):
    """One-dimensional Krawczyk existence and local-uniqueness certificate."""

    center = arb(center_string).mid()
    box = arb(center, arb(radius_string))
    residual_center, _ = evaluator(AD(acb(center), acb(1)))
    residual_box, mass_box = evaluator(AD(acb(box), acb(1)))
    value_center = real_part(residual_center)
    derivative_center = residual_center.g.real
    require(
        residual_center.g.imag.contains(0),
        ("nonreal derivative", residual_center.g),
    )
    derivative_box = residual_box.g.real
    require(
        residual_box.g.imag.contains(0), ("nonreal derivative", residual_box.g)
    )
    preconditioner = (1 / derivative_center).mid()
    krawczyk_image = (
        center
        - preconditioner * value_center
        + (1 - preconditioner * derivative_box) * (box - center)
    )
    require(
        box.contains_interior(krawczyk_image),
        ("Krawczyk inclusion failed", box, krawczyk_image),
    )
    require(
        not derivative_box.contains(0),
        ("derivative box contains zero", derivative_box),
    )
    return {
        "center": center,
        "box": box,
        "krawczyk": krawczyk_image,
        "center_residual": value_center,
        "derivative_box": derivative_box,
        "mass_box": real_part(mass_box),
    }


# Newton-polished centers (deterministic; obtained from the same residuals
# at ctx.dps = 60, quadratically convergent from the audit-script floats).
ROOT_CENTER_KINK = "0.790989184302433229243461208738020407568"
ROOT_CENTER_VARIANT = "0.643706593437314578528702405882642208840"
ROOT_RADIUS = "1e-12"


def certify_main():
    """Items 1-5 and 7 at kappa = 1/100."""

    root = krawczyk_scalar(
        lambda t: boundary_residual(t, KAPPA), ROOT_CENTER_KINK, ROOT_RADIUS
    )
    t_box = root["box"]

    # Kink parameterisation validity and monotone transfer to q*.
    slope = 1 - t_box**2  # w'(t), exact polynomial
    require(slope > 0, ("w' not positive on root box", slope))
    require(
        t_box > STANDING_VALUE and t_box < 1,
        ("kink outside (v, 1)", t_box),
    )
    top_cutoff = willingness_upper(t_box)  # = q* + kappa
    require(
        top_cutoff < 1,
        ("pool cutoff exceeds urgency support", top_cutoff),
    )

    q_star = top_cutoff - KAPPA
    top_urgency_cutoff = q_star + KAPPA - willingness_upper(arb(1))  # D_K(1)
    require(
        top_urgency_cutoff < 0,
        ("D_K(bar b) not negative: kink not interior", top_urgency_cutoff),
    )

    gamma = wedge_upper(t_box)
    continuation_h = revenue_upper(t_box) - Z_H
    continuation_l = revenue_upper(t_box) - Z_L

    gate_one_margin = gamma + KAPPA / A - Z_L
    gate_two_margin = continuation_h - q_star
    require(
        gate_one_margin > 0, ("gate (i) margin not strict", gate_one_margin)
    )
    require(
        gate_two_margin > 0, ("gate (ii) margin not strict", gate_two_margin)
    )

    survival_boundary = gamma + KAPPA / A

    deterrence_partial = A * (q_star + KAPPA - continuation_l) - KAPPA
    require(
        deterrence_partial < 0,
        ("(1,0)-branch deterrence supremum not negative", deterrence_partial),
    )

    mass_knockout = root["mass_box"]
    mass_waiting = 1 - mass_knockout
    require(mass_knockout > 0, ("knockout mass not positive", mass_knockout))
    require(mass_waiting > 0, ("waiting mass not positive", mass_waiting))

    raw_bound = willingness_upper(arb(1)) - q_star + PI * KAPPA / A
    failures = []
    for gap in FAILURE_GAPS:
        continuation_l_gap = revenue_upper(t_box) - gap
        killer_top = q_star - PI * KAPPA / A
        killer_margin = killer_top - continuation_l_gap
        require(
            killer_margin > 0,
            ("killer interval empty at gap", gap, killer_margin),
        )
        killer_midpoint = (continuation_l_gap + killer_top) / 2
        midpoint_gain = A * (q_star + KAPPA - killer_midpoint) - KAPPA
        require(
            midpoint_gain > 0,
            ("forced-acceptance gain not positive", gap, midpoint_gain),
        )
        raw_margin = raw_bound - gap
        require(
            raw_margin > 0,
            ("gap above raw-PBE persistence bound", gap, raw_margin),
        )
        failures.append(
            {
                "gap": gap,
                "killer_margin": killer_margin,
                "midpoint_gain": midpoint_gain,
                "raw_margin": raw_margin,
            }
        )

    return {
        "root": root,
        "q_star": q_star,
        "b_k0": t_box,
        "slope": slope,
        "top_urgency_cutoff": top_urgency_cutoff,
        "gamma": gamma,
        "continuation_l": continuation_l,
        "continuation_h": continuation_h,
        "gate_one_margin": gate_one_margin,
        "gate_two_margin": gate_two_margin,
        "survival_boundary": survival_boundary,
        "deterrence_partial": deterrence_partial,
        "mass_waiting": mass_waiting,
        "mass_knockout": mass_knockout,
        "raw_bound": raw_bound,
        "failures": failures,
    }


def certify_variant():
    """Item 6 at kappa = 1/20 (corner case b_K^0 = bar b)."""

    j_one, j_revenue = variant_constants()
    root = krawczyk_scalar(
        lambda q: variant_residual(q, KAPPA_VARIANT, j_one, j_revenue),
        ROOT_CENTER_VARIANT,
        ROOT_RADIUS,
    )
    q_box = root["box"]

    corner_margin = q_box + KAPPA_VARIANT - willingness_upper(arb(1))
    require(corner_margin > 0, ("D_K(bar b) not positive", corner_margin))
    top_cutoff = q_box + KAPPA_VARIANT
    require(
        top_cutoff < 1,
        ("pool cutoff exceeds urgency support", top_cutoff),
    )

    continuation_l_top = revenue_upper(arb(1)) - Z_L
    continuation_h_top = revenue_upper(arb(1)) - Z_H
    full_rejection_margin = continuation_l_top - q_box
    require(
        full_rejection_margin > 0,
        ("C_L(bar b) - q* not positive", full_rejection_margin),
    )
    gate_one_margin = (
        continuation_h_top - q_box + PI * KAPPA_VARIANT / A - (Z_L - Z_H)
    )
    gate_two_margin = continuation_h_top - q_box
    require(gate_one_margin > 0, ("variant gate (i) failed", gate_one_margin))
    require(gate_two_margin > 0, ("variant gate (ii) failed", gate_two_margin))

    mass_knockout = root["mass_box"]
    mass_waiting = 1 - mass_knockout
    require(mass_knockout > 0, ("knockout mass not positive", mass_knockout))
    require(mass_waiting > 0, ("waiting mass not positive", mass_waiting))

    return {
        "root": root,
        "q_star": q_box,
        "corner_margin": corner_margin,
        "full_rejection_margin": full_rejection_margin,
        "gate_one_margin": gate_one_margin,
        "gate_two_margin": gate_two_margin,
        "mass_waiting": mass_waiting,
        "mass_knockout": mass_knockout,
    }


def run_certificate():
    require(
        flint.__version__ == "0.9.0",
        (
            "certificate audited only under python-flint 0.9.0; found ",
            flint.__version__,
        ),
    )
    return {"main": certify_main(), "variant": certify_variant()}


def interval_record(value, digits=35):
    """JSON-safe outward interval record.

    ``arb`` is the full outward enclosure.  ``lower`` and ``upper`` are Arb
    ball strings enclosing the directed endpoint computations; they are not
    plain scalar decimal bounds.
    """

    return {
        "arb": value.str(digits),
        "radius": value.rad().str(6),
        "lower": value.lower().str(digits),
        "upper": value.upper().str(digits),
    }


def json_payload(certificate):
    main = certificate["main"]
    variant = certificate["variant"]
    return {
        "certificate": "urgency-only knockout-only D1 gate",
        "status": "PASS",
        "dependency": {
            "python_flint": flint.__version__,
            "precision_decimal_digits": ctx.dps,
        },
        "interval_encoding": {
            "arb": "full outward Arb enclosure",
            "lower": (
                "Arb ball enclosing the directed lower-endpoint computation; "
                "not a scalar decimal"
            ),
            "upper": (
                "Arb ball enclosing the directed upper-endpoint computation; "
                "not a scalar decimal"
            ),
        },
        "exact_primitives": {
            "n": 2,
            "v": "2/5",
            "pi": "1/2",
            "d_S_L": "1/50",
            "d_S_H": "0",
            "kappa": "1/100",
            "kappa_variant": "1/20",
            "d_bar": "1",
            "lambda": "10",
        },
        "item1_root": {
            "b_k0_box": interval_record(main["root"]["box"]),
            "krawczyk_image": interval_record(main["root"]["krawczyk"]),
            "residual_at_center": interval_record(
                main["root"]["center_residual"]
            ),
            "derivative_box": interval_record(main["root"]["derivative_box"]),
            "willingness_slope_on_box": interval_record(main["slope"]),
            "q_star": interval_record(main["q_star"]),
        },
        "item2_marginal_type": {
            "b_k0": interval_record(main["b_k0"]),
            "gamma_b_k0": interval_record(main["gamma"]),
            "D_K_top_value": interval_record(main["top_urgency_cutoff"]),
        },
        "item3_gate_margins": {
            "gate_i": interval_record(main["gate_one_margin"]),
            "gate_ii": interval_record(main["gate_two_margin"]),
            "partial_branch_deterrence_sup": interval_record(
                main["deterrence_partial"]
            ),
            "C_L_b_k0": interval_record(main["continuation_l"]),
            "C_H_b_k0": interval_record(main["continuation_h"]),
        },
        "item4_survival_boundary": interval_record(
            main["survival_boundary"]
        ),
        "item5_masses": {
            "waiting": interval_record(main["mass_waiting"]),
            "knockout": interval_record(main["mass_knockout"]),
        },
        "item6_variant": {
            "q_star_box": interval_record(variant["root"]["box"]),
            "krawczyk_image": interval_record(variant["root"]["krawczyk"]),
            "residual_at_center": interval_record(
                variant["root"]["center_residual"]
            ),
            "derivative_box": interval_record(
                variant["root"]["derivative_box"]
            ),
            "D_K_top_value_margin": interval_record(variant["corner_margin"]),
            "full_rejection_margin": interval_record(
                variant["full_rejection_margin"]
            ),
            "gate_i_corner_form": interval_record(variant["gate_one_margin"]),
            "gate_ii": interval_record(variant["gate_two_margin"]),
            "waiting": interval_record(variant["mass_waiting"]),
            "knockout": interval_record(variant["mass_knockout"]),
        },
        "item7_failures": [
            {
                "d_S_L": failure["gap"].str(10),
                "killer_interval_width": interval_record(
                    failure["killer_margin"]
                ),
                "midpoint_forced_acceptance_gain": interval_record(
                    failure["midpoint_gain"]
                ),
                "raw_pbe_persistence_margin": interval_record(
                    failure["raw_margin"]
                ),
            }
            for failure in main["failures"]
        ],
        "raw_pbe_bound": interval_record(main["raw_bound"]),
    }


def display(label, value, digits=24):
    print(f"{label:44s}", value.str(digits))


def print_human(certificate):
    main = certificate["main"]
    variant = certificate["variant"]

    print("urgency-only knockout-only D1 gate Arb certificate: PASS")
    print("python-flint", flint.__version__, "precision", ctx.dps, "digits")

    print("\n[1] boundary fixed point, kappa = 1/100 (kink parameterisation)")
    display("b_K^0 root box", main["root"]["box"], 30)
    display("Krawczyk image", main["root"]["krawczyk"], 30)
    display("Phi residual at center", main["root"]["center_residual"])
    display("Phi' on root box", main["root"]["derivative_box"])
    display("w' on root box (transfer to q*)", main["slope"])
    display("q* = w(b_K^0) - kappa", main["q_star"], 30)
    print("  PASS: existence and local uniqueness in the box")

    print("\n[2] top feasible marginal type")
    display("b_K^0", main["b_k0"], 30)
    display("Gamma(b_K^0) = (1-b)^3/3", main["gamma"])
    display("D_K(bar b) (interiority, < 0)", main["top_urgency_cutoff"])
    print("  PASS: b_K^0 interior")

    print("\n[3] gate margins (strict)")
    display("C_L(b_K^0)", main["continuation_l"])
    display("C_H(b_K^0)", main["continuation_h"])
    display("gate (i)  Gamma + kappa/(1-pi) - d_SL", main["gate_one_margin"])
    display("gate (ii) C_H(b_K^0) - q*", main["gate_two_margin"])
    display("(1,0)-branch deterrence sup (< 0)", main["deterrence_partial"])
    print("  PASS: both gate margins strictly positive")

    print("\n[4] survival boundary")
    display("d_SL* = Gamma(b_K^0) + kappa/(1-pi)", main["survival_boundary"])

    print("\n[5] action masses (strict)")
    display("waiting mass", main["mass_waiting"])
    display("knockout mass", main["mass_knockout"])
    print("  PASS: both masses strictly positive")

    print("\n[6] kappa = 1/20 variant (corner b_K^0 = bar b)")
    display("q* root box", variant["root"]["box"], 30)
    display("Krawczyk image", variant["root"]["krawczyk"], 30)
    display("Phi residual at center", variant["root"]["center_residual"])
    display("Phi' on root box", variant["root"]["derivative_box"])
    display("D_K(bar b) margin (> 0)", variant["corner_margin"])
    display("C_L(bar b) - q* (> 0)", variant["full_rejection_margin"])
    display("gate (i), corner form", variant["gate_one_margin"])
    display("gate (ii) C_H(bar b) - q*", variant["gate_two_margin"])
    display("waiting mass", variant["mass_waiting"])
    display("knockout mass", variant["mass_knockout"])
    print("  PASS: root certified; all variant margins strictly positive")

    print("\n[7] failure demonstrations (exclusion returns above the gate)")
    display("raw-PBE persistence bound", main["raw_bound"])
    for failure in main["failures"]:
        print(f"  d_SL = {failure['gap'].str(6)}:")
        display("    killer interval width (> 0)", failure["killer_margin"])
        display("    midpoint forced-accept gain (> 0)",
                failure["midpoint_gain"])
        display("    raw-PBE persistence margin (> 0)", failure["raw_margin"])
    print("  PASS: killer interval nonempty at every listed gap")


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Outward-rounded interval certificate for the urgency-only "
            "knockout-only D1 gate (prop:urgencyknockoutgate)."
        )
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="emit the certified intervals as deterministic JSON",
    )
    arguments = parser.parse_args()
    certificate = run_certificate()
    if arguments.json:
        print(json.dumps(json_payload(certificate), indent=2, sort_keys=True))
    else:
        print_human(certificate)


if __name__ == "__main__":
    main()
