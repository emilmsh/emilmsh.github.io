"""Exact audit of a patient atom in the note-64 bargaining equilibrium.

Urgency is distributed as

    eta * delta_0 + (1-eta) * U[0,2].

The buyer strategies and the three path prices are unchanged.  All seller
posterior numerators and action masses are affine in eta, so every seller
incentive can be certified on an exact interval.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Callable, Dict, List, Tuple

import audit_common_uniform_continuous_types as base


Q = Fraction
Poly = List[Q]


def blend(poly: Poly, atom_poly: Poly, eta: Q) -> Poly:
    return base.add(base.scale(poly, 1 - eta), base.scale(atom_poly, eta))


def expectation(lower: Poly, upper: Poly) -> Q:
    return base.expectation(lower, upper)


def distribution_values(eta: Q) -> Dict[str, object]:
    # For b<beta the patient atom waits.  For b>=beta it initiates and
    # revises to p.  It never accepts r.
    attempt_lower = base.scale(base.ATTEMPT_LOWER, 1 - eta)
    attempt_upper = base.ONE
    revise_lower = base.scale(base.REVISE_LOWER, 1 - eta)
    revise_upper = blend(base.REVISE_UPPER, base.ONE, eta)
    accept = base.scale(base.ACCEPT, 1 - eta)
    wait_lower = blend(base.WAIT_LOWER, base.ONE, eta)

    z_q = expectation(attempt_lower, attempt_upper)
    z_p = expectation(revise_lower, revise_upper)
    z_accept = expectation(accept, accept)
    z_wait = expectation(wait_lower, base.ZERO)

    c_q_numerator = {
        "L": expectation(
            base.multiply(attempt_lower, base.C_L),
            base.multiply(attempt_upper, base.C_L),
        ),
        "H": expectation(
            base.multiply(attempt_lower, base.C_H),
            base.multiply(attempt_upper, base.C_H),
        ),
    }
    c_p_numerator = {
        "L": expectation(
            base.multiply(revise_lower, base.C_L),
            base.multiply(revise_upper, base.C_L),
        ),
        "H": expectation(
            base.multiply(revise_lower, base.C_H),
            base.multiply(revise_upper, base.C_H),
        ),
    }
    return {
        "z_q": z_q,
        "z_p": z_p,
        "z_accept": z_accept,
        "z_wait": z_wait,
        "c_q_numerator": c_q_numerator,
        "c_p_numerator": c_p_numerator,
    }


def affine(
    function: Callable[[Dict[str, object]], Q],
) -> Tuple[Q, Q]:
    at_zero = function(distribution_values(Q(0)))
    at_one = function(distribution_values(Q(1)))
    return at_zero, at_one - at_zero


def seller_inequality_affines() -> Dict[str, Tuple[Q, Q]]:
    base_result = base.run_audit()
    counter_bound = base_result["seller_values"]["counter_bound"]
    inequalities: Dict[str, Tuple[Q, Q]] = {}

    def counter_numerator(values: Dict[str, object], state: str) -> Q:
        if state == "L":
            return (
                base.P_REVISION * values["z_p"]
                + base.R_COUNTER * values["z_accept"]
            )
        return (
            values["c_p_numerator"]["H"]
            + base.R_COUNTER * values["z_accept"]
        )

    for state in ("L", "H"):
        inequalities[f"{state}: r versus accepting q"] = affine(
            lambda values, state=state: counter_numerator(values, state)
            - (base.Q_INITIAL + base.C_S) * values["z_q"]
        )
        inequalities[f"{state}: r versus auction after q"] = affine(
            lambda values, state=state: counter_numerator(values, state)
            - base.C_S * values["z_q"]
            - values["c_q_numerator"][state]
        )
        inequalities[f"{state}: r versus another counter"] = affine(
            lambda values, state=state: counter_numerator(values, state)
            - (counter_bound[state] + base.C_S) * values["z_q"]
        )

    inequalities["L: accept p versus auction"] = affine(
        lambda values: base.P_REVISION * values["z_p"]
        - values["c_p_numerator"]["L"]
    )
    inequalities["L: accept p versus another counter"] = affine(
        lambda values: (
            base.P_REVISION - counter_bound["L"]
        )
        * values["z_p"]
    )
    inequalities["H: auction after p versus accept"] = affine(
        lambda values: values["c_p_numerator"]["H"]
        - base.P_REVISION * values["z_p"]
    )
    inequalities["H: auction after p versus another counter"] = affine(
        lambda values: values["c_p_numerator"]["H"]
        - counter_bound["H"] * values["z_p"]
    )
    return inequalities


def exact_window(
    inequalities: Dict[str, Tuple[Q, Q]],
) -> Tuple[Q, str]:
    roots = []
    for name, (intercept, slope) in inequalities.items():
        if intercept <= 0:
            raise AssertionError(f"Baseline inequality is not strict: {name}")
        if slope < 0:
            roots.append((-intercept / slope, name))
    positive_roots = [(root, name) for root, name in roots if root > 0]
    if not positive_roots:
        raise AssertionError("No finite patient-atom boundary was found")
    return min(positive_roots)


def actual_values(eta: Q) -> Dict[str, object]:
    values = distribution_values(eta)
    base_result = base.run_audit()
    counter_bound = base_result["seller_values"]["counter_bound"]

    c_q = {
        state: values["c_q_numerator"][state] / values["z_q"]
        for state in ("L", "H")
    }
    c_p = {
        state: values["c_p_numerator"][state] / values["z_p"]
        for state in ("L", "H")
    }
    k_r = {
        "L": (
            base.P_REVISION * values["z_p"]
            + base.R_COUNTER * values["z_accept"]
        )
        / values["z_q"]
        - base.C_S,
        "H": (
            values["c_p_numerator"]["H"]
            + base.R_COUNTER * values["z_accept"]
        )
        / values["z_q"]
        - base.C_S,
    }
    margins = {
        "L chooses r": k_r["L"]
        - max(base.Q_INITIAL, c_q["L"], counter_bound["L"]),
        "H chooses r": k_r["H"]
        - max(base.Q_INITIAL, c_q["H"], counter_bound["H"]),
        "L accepts p": base.P_REVISION
        - max(c_p["L"], counter_bound["L"]),
        "H auctions after p": c_p["H"]
        - max(base.P_REVISION, counter_bound["H"]),
    }
    return {
        **values,
        "c_q": c_q,
        "c_p": c_p,
        "k_r": k_r,
        "margins": margins,
    }


def run_audit() -> Dict[str, object]:
    inequalities = seller_inequality_affines()
    eta_star, binding = exact_window(inequalities)
    expected_eta_star = Q(175277, 276959)
    if eta_star != expected_eta_star:
        raise AssertionError("The exact patient-atom window changed")
    if binding != "L: accept p versus auction":
        raise AssertionError("The wrong seller inequality binds first")

    # Certify every affine seller inequality throughout [0,eta_star).
    for name, (intercept, slope) in inequalities.items():
        at_boundary = intercept + slope * eta_star
        if name == binding:
            if at_boundary != 0:
                raise AssertionError("The binding inequality misses zero")
        elif at_boundary <= 0:
            raise AssertionError(f"Another inequality fails in the window: {name}")

    # Buyer incentives and all off-path envelopes are type-by-type and do not
    # depend on the urgency distribution.  The new atom follows strict actions
    # except at the null b=beta boundary.
    if not base.evaluate(base.X_THRESHOLD, base.BETA) == 0:
        raise AssertionError("The patient initiation boundary changed")
    if not base.evaluate(base.Y_THRESHOLD, base.BETA) > 0:
        raise AssertionError("A patient initiator could accept r at beta")
    if not (
        base.evaluate(base.X_THRESHOLD, base.BETA)
        - base.KAPPA / base.A
        < 0
    ):
        raise AssertionError("A patient initiator could terminate after r")

    example_eta = Q(1, 100)
    example = actual_values(example_eta)
    if min(example["margins"].values()) <= 0:
        raise AssertionError("The one-percent atom example is not strict")

    patient_attempt = example_eta * (1 - base.BETA)
    patient_failure = base.PI * patient_attempt
    patient_agreement = base.A * patient_attempt
    outcomes = {
        "no_attempt": example["z_wait"],
        "attempt_then_auction": base.PI * example["z_p"],
        "early_agreement": (
            base.A * example["z_p"] + example["z_accept"]
        ),
    }
    if sum(outcomes.values()) != 1:
        raise AssertionError("The atom outcomes do not sum to one")
    if min(patient_attempt, patient_failure, patient_agreement) <= 0:
        raise AssertionError("Literal patient outcomes must have positive mass")

    return {
        "eta_star": eta_star,
        "binding": binding,
        "example_eta": example_eta,
        "example": example,
        "outcomes": outcomes,
        "patient": {
            "attempt": patient_attempt,
            "failure": patient_failure,
            "agreement": patient_agreement,
        },
    }


def decimal(value: Q) -> str:
    return f"{float(value):.12f}"


def print_report(result: Dict[str, object]) -> None:
    print("PATIENT-ATOM PERSISTENCE AUDIT: PASS")
    print(
        "  strict PBE window: 0 < eta < "
        f"{result['eta_star']} ({decimal(result['eta_star'])})"
    )
    print(f"  first binding inequality: {result['binding']}")
    print(
        "  example atom: "
        f"eta={result['example_eta']} ({decimal(result['example_eta'])})"
    )
    print("  total outcomes")
    for name, value in result["outcomes"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  literal d=0 outcomes")
    for name, value in result["patient"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  seller margins at the example atom")
    for name, value in result["example"]["margins"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  buyer deviations and recursive off-path envelopes: unchanged")


if __name__ == "__main__":
    print_report(run_audit())
