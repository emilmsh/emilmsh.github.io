"""Exact audit of the posterior-consistent recursive tail repair.

The raw PBE in notes 64 and 68 used a low-type belief after a common buyer
tail response.  This audit instead uses, at each on-path buyer history h,

    tau_h = E[C_L(b) | mu_h] + epsilon,

where epsilon=(c_S-c_B)/2.  All types in the h-posterior pool on tau_h after
a sufficiently high unexpected seller price.  The pooling posterior is
therefore mu_h, seller L strictly accepts, and seller H strictly auctions.

Every interval claim is checked with exact affine numerators at eta=0 and at
the patient-atom boundary eta_star.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Dict

import audit_common_uniform_continuous_types as base
import audit_patient_atom_persistence as atom


Q = Fraction
EPSILON = (base.C_S - base.C_B) / 2
ETA_STAR = Q(175277, 276959)


def history_values(eta: Q, history: str) -> Dict[str, Q]:
    values = atom.distribution_values(eta)
    if history == "q":
        denominator = values["z_q"]
        numerators = values["c_q_numerator"]
    elif history == "p":
        denominator = values["z_p"]
        numerators = values["c_p_numerator"]
    else:
        raise ValueError(f"Unknown history: {history}")

    c_l = numerators["L"] / denominator
    c_h = numerators["H"] / denominator
    tail = c_l + EPSILON
    threshold = tail + base.C_B
    return {
        "denominator": denominator,
        "c_l": c_l,
        "c_h": c_h,
        "tail": tail,
        "threshold": threshold,
        "active_gap": base.W_L_BETA - threshold,
        "h_rejection_gap": c_h - tail,
        "h_auction_over_acceptance_threshold": c_h - threshold,
        "tail_below_high_b_threshold": base.evaluate(base.C_L, Q(1)) - tail,
        "l_acceptance_margin": EPSILON,
        "l_counter_margin": base.C_S - base.C_B - EPSILON,
        "h_counter_margin": base.C_S,
    }


def affine_numerators(eta: Q, history: str) -> Dict[str, Q]:
    values = atom.distribution_values(eta)
    if history == "q":
        denominator = values["z_q"]
        numerators = values["c_q_numerator"]
    elif history == "p":
        denominator = values["z_p"]
        numerators = values["c_p_numerator"]
    else:
        raise ValueError(f"Unknown history: {history}")

    return {
        "all active types pool": (
            (base.W_L_BETA - EPSILON - base.C_B) * denominator
            - numerators["L"]
        ),
        "H rejects repaired tail": (
            numerators["H"]
            - numerators["L"]
            - EPSILON * denominator
        ),
        "H auction exceeds acceptance threshold": (
            numerators["H"]
            - numerators["L"]
            - (EPSILON + base.C_B) * denominator
        ),
        "tail cheaper than any other L-accepted buyer offer": (
            (base.evaluate(base.C_L, Q(1)) - EPSILON) * denominator
            - numerators["L"]
        ),
    }


def run_audit() -> Dict[str, object]:
    if not Q(0) < EPSILON < base.C_S - base.C_B:
        raise AssertionError("epsilon must be below the proposal-cost gap")

    endpoints: Dict[str, Dict[Q, Dict[str, Q]]] = {}
    for history in ("q", "p"):
        endpoints[history] = {}
        for eta in (Q(0), ETA_STAR):
            numerators = affine_numerators(eta, history)
            failures = {
                name: value for name, value in numerators.items() if value <= 0
            }
            if failures:
                raise AssertionError(
                    f"Tail repair failed at {history}, eta={eta}: {failures}"
                )
            endpoint_values = history_values(eta, history)
            if endpoint_values["denominator"] <= 0:
                raise AssertionError("A repaired-tail posterior is undefined")
            endpoints[history][eta] = endpoint_values

    # Each checked numerator is affine in eta.  Strict positivity at both
    # endpoints certifies the complete closed interval [0,eta_star].

    # At every repaired tail node, L strictly accepts and H strictly auctions.
    for history in ("q", "p"):
        for eta in (Q(0), ETA_STAR):
            values = endpoints[history][eta]
            if values["l_acceptance_margin"] != EPSILON:
                raise AssertionError("L's repaired-tail margin changed")
            if values["l_counter_margin"] <= 0:
                raise AssertionError("A further L counter can be profitable")
            if values["h_counter_margin"] <= 0:
                raise AssertionError("A further H counter can be profitable")

    # The high-b off-path posterior uses the cheapest L-accepted tail C_L(1).
    # Taking d=2 leaves the direct-acceptance thresholds unchanged.  L is
    # indifferent at this auxiliary tail; every further counter is strict.
    c_l_one = base.evaluate(base.C_L, Q(1))
    c_h_one = base.evaluate(base.C_H, Q(1))
    w_l_one = base.evaluate(base.W_L, Q(1))
    high_tail = c_l_one
    high_threshold = high_tail + base.C_B
    high_b_checks = {
        "believed high type can pool": w_l_one + Q(2) - high_threshold,
        "H rejects high-b tail": c_h_one - high_tail,
        "H auction exceeds high-b acceptance threshold": (
            c_h_one - high_threshold
        ),
        "L counter remains below auction": (
            c_l_one - (high_threshold - base.C_S)
        ),
        "H counter remains below auction": base.C_S,
        "tail is cheapest L-accepted buyer offer": c_l_one - high_tail,
    }
    strictly_positive_high_b = {
        name: value
        for name, value in high_b_checks.items()
        if name != "tail is cheapest L-accepted buyer offer"
    }
    if min(strictly_positive_high_b.values()) <= 0:
        raise AssertionError("The high-b recursive completion failed")
    if high_b_checks["tail is cheapest L-accepted buyer offer"] != 0:
        raise AssertionError("The high-b tail is not the direct threshold")

    # The repaired counter envelope never exceeds the posterior auction value.
    # Hence the pre-existing on-path seller comparisons remain sufficient.
    baseline = base.run_audit()
    atom_audit = atom.run_audit()
    if baseline["minimum_strict_margin"] <= 0:
        raise AssertionError("The eta=0 on-path equilibrium is not strict")
    if atom_audit["eta_star"] != ETA_STAR:
        raise AssertionError("The patient-atom window changed")

    return {
        "epsilon": EPSILON,
        "eta_star": ETA_STAR,
        "endpoints": endpoints,
        "high_b_checks": high_b_checks,
    }


def decimal(value: Q) -> str:
    return f"{float(value):.12f}"


def print_report(result: Dict[str, object]) -> None:
    print("POSTERIOR-CONSISTENT TAIL REPAIR AUDIT: PASS")
    print(
        "  epsilon="
        f"{result['epsilon']} ({decimal(result['epsilon'])}), "
        "strictly below c_S-c_B"
    )
    for history in ("q", "p"):
        print(f"  history {history}")
        for eta in (Q(0), result["eta_star"]):
            values = result["endpoints"][history][eta]
            print(
                f"    eta={decimal(eta)}: "
                f"C_L={decimal(values['c_l'])}, "
                f"tau={decimal(values['tail'])}, "
                f"C_H={decimal(values['c_h'])}, "
                f"active gap={decimal(values['active_gap'])}, "
                f"H gap={decimal(values['h_rejection_gap'])}"
            )
    print("  high-b recursive completion")
    for name, value in result["high_b_checks"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  recursive seller counters are strictly dominated")
    print("  complete patient-atom interval endpoints: certified exactly")


if __name__ == "__main__":
    print_report(run_audit())
