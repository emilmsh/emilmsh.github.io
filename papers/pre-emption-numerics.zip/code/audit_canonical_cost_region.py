"""Exact audit of a positive-cost region for the canonical renegotiation path.

The primitives and fixed path are those of note 71:

    n_L=2, n_H=5, pi=3/10, beta=9/10, q=1/2,
    b and late values U[0,1],
    d ~ eta*delta_0 + (1-eta)*U[0,1].

For arbitrary positive proposal costs, prices are adjusted according to

    p = w_L(beta) - (c_B+kappa)/(1-pi),
    r = (1-pi)w_L(beta) - kappa + pi.

These adjustments leave the on-path thresholds x and y, action weights, and
on-path posteriors unchanged.  The tremble-only termination cutoff a moves
with kappa.  This script derives those objects independently,
checks the complete finite list of cost-dependent inequalities, certifies a
simple rational cost box by exact corner enumeration, and verifies the
patient-buyer rent capitalization identity.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import product
from typing import Dict, Iterable, List, Tuple


Q = Fraction
Poly = List[Q]
Affine = Tuple[Q, Q]

A = Q(7, 10)
PI = Q(3, 10)
BETA = Q(9, 10)
Q_INITIAL = Q(1, 2)
W_L_BETA = Q(657, 1000)
C_L_ONE = Q(2, 3)
C_H_ONE = Q(5, 6)


def trim(poly: Poly) -> Poly:
    result = list(poly)
    while len(result) > 1 and result[-1] == 0:
        result.pop()
    return result


def add(left: Poly, right: Poly) -> Poly:
    size = max(len(left), len(right))
    return trim(
        [
            (left[i] if i < len(left) else Q(0))
            + (right[i] if i < len(right) else Q(0))
            for i in range(size)
        ]
    )


def scale(poly: Poly, scalar: Q) -> Poly:
    return trim([scalar * coefficient for coefficient in poly])


def multiply(left: Poly, right: Poly) -> Poly:
    result = [Q(0)] * (len(left) + len(right) - 1)
    for i, left_coefficient in enumerate(left):
        for j, right_coefficient in enumerate(right):
            result[i + j] += left_coefficient * right_coefficient
    return trim(result)


def evaluate(poly: Poly, point: Q) -> Q:
    return sum(
        coefficient * point**power
        for power, coefficient in enumerate(poly)
    )


def integrate(poly: Poly, lower: Q, upper: Q) -> Q:
    return sum(
        coefficient
        * (upper ** (power + 1) - lower ** (power + 1))
        / Q(power + 1)
        for power, coefficient in enumerate(poly)
    )


ONE: Poly = [Q(1)]
ZERO: Poly = [Q(0)]
W_L: Poly = [Q(0), Q(1), Q(0), -Q(1, 3)]
W_H: Poly = [
    Q(0),
    Q(1),
    Q(0),
    Q(0),
    Q(0),
    Q(0),
    -Q(1, 6),
]
C_L: Poly = [Q(1, 3), Q(0), Q(1), -Q(2, 3)]
C_H: Poly = [
    Q(2, 3),
    Q(0),
    Q(0),
    Q(0),
    Q(0),
    Q(1),
    -Q(5, 6),
]

X = add([W_L_BETA], scale(W_L, -1))
Y = add(ONE, scale(W_H, -1))

# Continuous-component action weights below and above beta.
WEIGHTS_0 = {
    "wait": (X, ZERO),
    "p": (add(Y, scale(X, -1)), Y),
    "accept": (W_H, W_H),
    "q": (add(ONE, scale(X, -1)), ONE),
}

# Patient-atom action weights below and above beta.
WEIGHTS_PATIENT = {
    "wait": (ONE, ZERO),
    "p": (ZERO, ONE),
    "accept": (ZERO, ZERO),
    "q": (ZERO, ONE),
}


def piecewise_integral(parts: Tuple[Poly, Poly]) -> Q:
    lower, upper = parts
    return integrate(lower, Q(0), BETA) + integrate(upper, BETA, Q(1))


def weighted_integral(parts: Tuple[Poly, Poly], value: Poly) -> Q:
    lower, upper = parts
    return integrate(multiply(lower, value), Q(0), BETA) + integrate(
        multiply(upper, value), BETA, Q(1)
    )


def affine_from_components(continuous: Q, patient: Q) -> Affine:
    return continuous, patient - continuous


MASS_AFFINES: Dict[str, Affine] = {
    name: affine_from_components(
        piecewise_integral(WEIGHTS_0[name]),
        piecewise_integral(WEIGHTS_PATIENT[name]),
    )
    for name in WEIGHTS_0
}

NUMERATOR_AFFINES: Dict[Tuple[str, str], Affine] = {}
for history in ("q", "p"):
    for state, continuation in (("L", C_L), ("H", C_H)):
        NUMERATOR_AFFINES[(state, history)] = affine_from_components(
            weighted_integral(WEIGHTS_0[history], continuation),
            weighted_integral(WEIGHTS_PATIENT[history], continuation),
        )


def at_eta(affine: Affine, eta: Q) -> Q:
    return affine[0] + affine[1] * eta


def distribution_values(eta: Q) -> Dict[str, object]:
    return {
        "Z": {name: at_eta(value, eta) for name, value in MASS_AFFINES.items()},
        "N": {
            key: at_eta(value, eta)
            for key, value in NUMERATOR_AFFINES.items()
        },
    }


def prices(kappa: Q, c_b: Q) -> Tuple[Q, Q]:
    p = W_L_BETA - (c_b + kappa) / A
    r = A * W_L_BETA - kappa + PI
    return p, r


def equilibrium_margins(
    eta: Q,
    kappa: Q,
    c_b: Q,
    c_s: Q,
    epsilon: Q | None = None,
) -> Dict[str, Q]:
    """Return unnormalized strict margins for the fixed path.

    The default tail choice epsilon=(c_S-c_B)/2 is convenient for auditing a
    cost box.  The theorem in note 74 allows any epsilon satisfying the same
    listed inequalities.
    """

    if epsilon is None:
        epsilon = (c_s - c_b) / 2

    values = distribution_values(eta)
    z = values["Z"]
    n = values["N"]
    p, r = prices(kappa, c_b)

    v_l = p * z["p"] + r * z["accept"]
    v_h = n[("H", "p")] + r * z["accept"]

    margins: Dict[str, Q] = {
        # Multiplication by A preserves the sign and removes a denominator.
        "price: q below p": A * (p - Q_INITIAL),
        "price: p below r": r - p,
        "price: r below one": Q(1) - r,
        "buyer: initial L-only deviation": (
            A * (C_L_ONE - p) - c_b
        ),
        "buyer: initial both-state deviation": C_H_ONE - r,
        "buyer: revised L-only deviation": A * (C_L_ONE - p),
        "buyer: revised both-state deviation": C_H_ONE + c_b - r,
        "seller L: r versus q": v_l - (Q_INITIAL + c_s) * z["q"],
        "seller L: r versus auction": (
            v_l - c_s * z["q"] - n[("L", "q")]
        ),
        "seller H: r versus q": v_h - (Q_INITIAL + c_s) * z["q"],
        "seller H: r versus auction": (
            v_h - c_s * z["q"] - n[("H", "q")]
        ),
        "seller L: p versus auction": p * z["p"] - n[("L", "p")],
        "seller H: auction versus p": n[("H", "p")] - p * z["p"],
        "tail: epsilon positive": epsilon,
        "tail: seller cost gap": c_s - c_b - epsilon,
        "tail: high-history H cutoff": C_H_ONE - C_L_ONE - c_b,
    }

    for history in ("q", "p"):
        denominator = z[history]
        n_l = n[("L", history)]
        n_h = n[("H", history)]
        margins[f"tail {history}: all active types pool"] = (
            (W_L_BETA - c_b - epsilon) * denominator - n_l
        )
        margins[f"tail {history}: H auction above buyer cutoff"] = (
            n_h - n_l - (c_b + epsilon) * denominator
        )
        margins[f"tail {history}: below other L-accepted offers"] = (
            (C_L_ONE - epsilon) * denominator - n_l
        )

    return margins


def first_eta_root(
    kappa: Q, c_b: Q, c_s: Q
) -> Tuple[Q, str, Dict[str, Affine]]:
    """Find the endpoint of the strict interval starting at eta=0."""

    affines: Dict[str, Affine] = {}
    at_zero = equilibrium_margins(Q(0), kappa, c_b, c_s)
    at_one = equilibrium_margins(Q(1), kappa, c_b, c_s)
    for name in at_zero:
        affines[name] = (at_zero[name], at_one[name] - at_zero[name])

    roots: List[Tuple[Q, str]] = []
    for name, (intercept, slope) in affines.items():
        if intercept <= 0:
            raise AssertionError(f"Condition already fails at eta=0: {name}")
        if slope < 0:
            root = -intercept / slope
            if root > 0:
                roots.append((root, name))
    if not roots:
        raise AssertionError("No positive eta root found")
    eta_star, binding = min(roots)
    return eta_star, binding, affines


def vertices(bounds: Iterable[Tuple[Q, Q]]) -> Iterable[Tuple[Q, ...]]:
    return product(*[(lower, upper) for lower, upper in bounds])


def certify_box() -> Dict[str, object]:
    """Certify a simple positive-cost box by exact corner enumeration.

    Every margin is multi-affine in (eta,kappa,c_B,c_S) under the default
    epsilon.  Its minimum over a rectangle is therefore attained at a corner.
    """

    box = {
        "eta": (Q(0), Q(9, 10)),
        "kappa": (Q(1, 10000), Q(1, 1000)),
        "c_B": (Q(1, 2000), Q(1, 800)),
        "c_S": (Q(3, 2000), Q(1, 400)),
    }
    minima: Dict[str, Tuple[Q, Tuple[Q, ...]]] = {}
    for corner in vertices(box.values()):
        eta, kappa, c_b, c_s = corner
        for name, value in equilibrium_margins(
            eta, kappa, c_b, c_s
        ).items():
            if name not in minima or value < minima[name][0]:
                minima[name] = value, corner

    failures = {
        name: result for name, result in minima.items() if result[0] <= 0
    }
    if failures:
        raise AssertionError(f"The advertised cost box fails: {failures}")

    # This box enforces c_S>c_B without an additional nonrectangular
    # restriction, and contains the note-71 cost triple in its interior.
    if not box["c_S"][0] > box["c_B"][1]:
        raise AssertionError("The box does not uniformly imply c_S>c_B")
    baseline = (Q(1, 2000), Q(1, 1000), Q(1, 500))
    if not all(
        box[name][0] < value < box[name][1]
        for name, value in zip(("kappa", "c_B", "c_S"), baseline)
    ):
        raise AssertionError("The note-71 cost triple is not interior")

    return {"box": box, "minima": minima}


def audit_patient_rent() -> Dict[str, Q]:
    """Verify exact capitalization and integrate the patient private rent."""

    # For any patient initiator b>beta, the equilibrium gain over waiting is
    # A[w_L(b)-w_L(beta)], independently of all three costs.
    test_values = (BETA, Q(19, 20), Q(1))
    cost_values = (
        (Q(1, 10000), Q(1, 2000), Q(3, 2000)),
        (Q(1, 2000), Q(1, 1000), Q(1, 500)),
        (Q(1, 1000), Q(1, 800), Q(1, 400)),
    )
    for kappa, c_b, c_s in cost_values:
        p, _ = prices(kappa, c_b)
        for b in test_values:
            path_gain = A * (evaluate(W_L, b) - p) - c_b - kappa
            canonical_gain = A * (evaluate(W_L, b) - W_L_BETA)
            if path_gain != canonical_gain:
                raise AssertionError("Patient rent capitalization failed")

        # The expected reduction in the L-state payment exactly reimburses
        # kappa+c_B; c_S is instead borne by the seller.
        if A * (p - W_L_BETA) - c_s != -(kappa + c_b + c_s):
            raise AssertionError("Seller cost incidence identity failed")

    primitive = integrate(W_L, BETA, Q(1)) - (
        Q(1) - BETA
    ) * W_L_BETA
    conditional_mean = A * primitive / (Q(1) - BETA)
    population_per_unit_eta = A * primitive
    top_rent = A * (evaluate(W_L, Q(1)) - W_L_BETA)

    expected = {
        "top_rent": Q(203, 30000),
        "conditional_mean": Q(539, 120000),
        "population_per_unit_eta": Q(539, 1200000),
    }
    actual = {
        "top_rent": top_rent,
        "conditional_mean": conditional_mean,
        "population_per_unit_eta": population_per_unit_eta,
    }
    if actual != expected:
        raise AssertionError(f"Patient rent integrals changed: {actual}")
    return actual


def run_audit() -> Dict[str, object]:
    if evaluate(W_L, BETA) != W_L_BETA:
        raise AssertionError("w_L(beta) is wrong")
    if evaluate(C_L, Q(1)) != C_L_ONE:
        raise AssertionError("C_L(1) is wrong")
    if evaluate(C_H, Q(1)) != C_H_ONE:
        raise AssertionError("C_H(1) is wrong")

    expected_mass_affines = {
        "wait": (Q(9639, 40000), Q(26361, 40000)),
        "p": (Q(237581, 840000), -Q(153581, 840000)),
        "accept": (Q(10, 21), -Q(10, 21)),
        "q": (Q(30361, 40000), -Q(26361, 40000)),
    }
    expected_numerator_affines = {
        ("L", "q"): (
            Q(56394727, 140000000),
            -Q(47105727, 140000000),
        ),
        ("H", "q"): (
            Q(2758384873, 5000000000),
            -Q(16415862861, 35000000000),
        ),
        ("L", "p"): (
            Q(509657629, 3780000000),
            -Q(258854629, 3780000000),
        ),
        ("H", "p"): (
            Q(813804710987, 4095000000000),
            -Q(475343454737, 4095000000000),
        ),
    }
    if MASS_AFFINES != expected_mass_affines:
        raise AssertionError("Action-mass affines changed")
    if NUMERATOR_AFFINES != expected_numerator_affines:
        raise AssertionError("Posterior-numerator affines changed")

    # Directly re-derive the canonical on-path thresholds x and y for
    # several cost triples; the tremble-only cutoff a is allowed to move.
    for kappa, c_b in (
        (Q(1, 10000), Q(1, 2000)),
        (Q(1, 2000), Q(1, 1000)),
        (Q(1, 1000), Q(1, 800)),
    ):
        p, r = prices(kappa, c_b)
        a = add([p + c_b / A], scale(W_L, -1))
        x_from_payoffs = add(a, [kappa / A])
        y_from_payoffs = add(
            [(r - A * p - c_b) / PI], scale(W_H, -1)
        )
        if x_from_payoffs != X or y_from_payoffs != Y:
            raise AssertionError("Cost-adjusted on-path thresholds x or y changed")

    baseline = (Q(1, 2000), Q(1, 1000), Q(1, 500))
    eta_star, binding, affines = first_eta_root(*baseline)
    expected_eta_star = Q(117204341, 120480341)
    if eta_star != expected_eta_star:
        raise AssertionError("The note-71 eta boundary was not reproduced")
    if binding != "seller H: r versus auction":
        raise AssertionError("The note-71 first binding condition changed")
    for name, affine in affines.items():
        value = at_eta(affine, eta_star)
        if name == binding:
            if value != 0:
                raise AssertionError("The binding condition misses zero")
        elif value <= 0:
            raise AssertionError(f"Another condition binds too early: {name}")

    box = certify_box()
    patient_rent = audit_patient_rent()

    return {
        "eta_star": eta_star,
        "binding": binding,
        "box": box,
        "patient_rent": patient_rent,
    }


def decimal(value: Q) -> str:
    return f"{float(value):.12f}"


def print_report(result: Dict[str, object]) -> None:
    print("CANONICAL POSITIVE-COST REGION AUDIT: PASS")
    print(
        "  note-71 slice: eta*="
        f"{result['eta_star']} ({decimal(result['eta_star'])})"
    )
    print(f"  first binding condition: {result['binding']}")
    print("  certified multi-affine box:")
    for name, (lower, upper) in result["box"]["box"].items():
        print(
            f"    {name}: [{lower}, {upper}] "
            f"= [{decimal(lower)}, {decimal(upper)}]"
        )

    seller_names = [
        name
        for name in result["box"]["minima"]
        if name.startswith("seller")
    ]
    tail_names = [
        name
        for name in result["box"]["minima"]
        if name.startswith("tail")
    ]
    min_seller = min(
        (result["box"]["minima"][name][0], name) for name in seller_names
    )
    min_tail = min(
        (result["box"]["minima"][name][0], name) for name in tail_names
    )
    print(
        "  smallest seller margin in box: "
        f"{min_seller[1]} = {min_seller[0]} "
        f"({decimal(min_seller[0])})"
    )
    print(
        "  smallest tail margin in box: "
        f"{min_tail[1]} = {min_tail[0]} "
        f"({decimal(min_tail[0])})"
    )
    print("  patient private rent:")
    for name, value in result["patient_rent"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  all calculations use exact rational arithmetic")


if __name__ == "__main__":
    print_report(run_audit())
