"""Exact audit of a common-F continuous-type bargaining PBE.

The early buyer's match value and every late bidder's value are drawn from
the same U[0,1] distribution.  Buyer urgency is independently U[0,2].
Demand states differ only in the number of late bidders.  The audit derives
the b-dependent urgency thresholds, integrates the on-path posteriors exactly,
and checks the continuous-price and recursive-history envelopes.

All arithmetic uses fractions and exact polynomial integration.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Dict, Iterable, List, Tuple


Q = Fraction
Poly = List[Q]

A = Q(7, 10)
PI = Q(3, 10)
KAPPA = Q(1, 2000)
C_B = Q(1, 1000)
C_S = Q(1, 500)

D_BAR = Q(2)
N_L = 2
N_H = 5
BETA = Q(7, 10)

Q_INITIAL = Q(1, 2)
R_COUNTER = Q(79, 100)


def trim(poly: Poly) -> Poly:
    while len(poly) > 1 and poly[-1] == 0:
        poly.pop()
    return poly


def add(left: Poly, right: Poly) -> Poly:
    size = max(len(left), len(right))
    return trim(
        [
            (left[i] if i < len(left) else Q(0))
            + (right[i] if i < len(right) else Q(0))
            for i in range(size)
        ]
    )


def scale(poly: Poly, scalar: Q) -> Poly:
    return trim([coefficient * scalar for coefficient in poly])


def multiply(left: Poly, right: Poly) -> Poly:
    result = [Q(0)] * (len(left) + len(right) - 1)
    for i, left_coefficient in enumerate(left):
        for j, right_coefficient in enumerate(right):
            result[i + j] += left_coefficient * right_coefficient
    return trim(result)


def derivative(poly: Poly) -> Poly:
    if len(poly) == 1:
        return [Q(0)]
    return trim([i * poly[i] for i in range(1, len(poly))])


def evaluate(poly: Poly, point: Q) -> Q:
    return sum(coefficient * point**power for power, coefficient in enumerate(poly))


def integrate(poly: Poly, lower: Q, upper: Q) -> Q:
    return sum(
        coefficient
        * (upper ** (power + 1) - lower ** (power + 1))
        / Q(power + 1)
        for power, coefficient in enumerate(poly)
    )


ONE: Poly = [Q(1)]
ZERO: Poly = [Q(0)]

# For n late U[0,1] values,
# w_n(b)=b-b^(n+1)/(n+1) and
# C_n(b)=(n-1)/(n+1)+b^n-n*b^(n+1)/(n+1).
W_L: Poly = [Q(0), Q(1), Q(0), -Q(1, 3)]
W_H: Poly = [Q(0), Q(1), Q(0), Q(0), Q(0), Q(0), -Q(1, 6)]
C_L: Poly = [Q(1, 3), Q(0), Q(1), -Q(2, 3)]
C_H: Poly = [Q(2, 3), Q(0), Q(0), Q(0), Q(0), Q(1), -Q(5, 6)]

W_L_BETA = evaluate(W_L, BETA)
P_REVISION = W_L_BETA - (C_B + KAPPA) / A

# The unclipped initiation threshold is x(b).  By construction x(beta)=0.
X_THRESHOLD = add([W_L_BETA], scale(W_L, -1))
Y_THRESHOLD = add(
    [(R_COUNTER - A * P_REVISION - C_B) / PI],
    scale(W_H, -1),
)

# G=U[0,2].  On [0,beta], x is positive; on [beta,1], x is negative and
# every urgency type initiates.  The acceptance threshold y stays in (0,2).
G_X_LOWER = scale(X_THRESHOLD, 1 / D_BAR)
G_Y = scale(Y_THRESHOLD, 1 / D_BAR)
WAIT_LOWER = G_X_LOWER
WAIT_UPPER = ZERO
REVISE_LOWER = add(G_Y, scale(G_X_LOWER, -1))
REVISE_UPPER = G_Y
ACCEPT = add(ONE, scale(G_Y, -1))
ATTEMPT_LOWER = add(ONE, scale(G_X_LOWER, -1))
ATTEMPT_UPPER = ONE


def expectation(lower_poly: Poly, upper_poly: Poly) -> Q:
    """Integrate against the common U[0,1] value distribution."""

    return integrate(lower_poly, Q(0), BETA) + integrate(
        upper_poly, BETA, Q(1)
    )


def run_audit() -> Dict[str, object]:
    if P_REVISION != Q(6127, 10500):
        raise AssertionError("The constructive revision price is wrong")
    if not Q_INITIAL < P_REVISION < R_COUNTER:
        raise AssertionError("The on-path price ordering is wrong")

    # Threshold geometry.  The top-value competition wedge is zero, so the
    # construction deliberately permits x(b)<0 near b=1: all urgency types
    # then initiate.  It does not try to preserve a common d0 action at the
    # top of support.
    if evaluate(X_THRESHOLD, BETA) != 0:
        raise AssertionError("The initiation threshold does not cross at beta")
    if not evaluate(X_THRESHOLD, Q(0)) > 0:
        raise AssertionError("Low values must have a positive waiting region")
    if not evaluate(X_THRESHOLD, Q(1)) < 0:
        raise AssertionError("Top values must initiate at every urgency")
    if not Q(0) < evaluate(Y_THRESHOLD, Q(1)):
        raise AssertionError("The acceptance threshold can cross zero")
    if not evaluate(Y_THRESHOLD, Q(0)) < D_BAR:
        raise AssertionError("The acceptance threshold can exceed urgency support")

    difference_derivative = derivative(
        add(Y_THRESHOLD, scale(X_THRESHOLD, -1))
    )
    expected_derivative = [Q(0), Q(0), -Q(1), Q(0), Q(0), Q(1)]
    if difference_derivative != expected_derivative:
        raise AssertionError("The threshold-gap derivative is wrong")
    if not evaluate(Y_THRESHOLD, BETA) > 0:
        raise AssertionError("x(b)<y(b) is not certified at the crossing")

    z_q = expectation(ATTEMPT_LOWER, ATTEMPT_UPPER)
    z_p = expectation(REVISE_LOWER, REVISE_UPPER)
    z_accept = expectation(ACCEPT, ACCEPT)
    z_wait = expectation(WAIT_LOWER, WAIT_UPPER)
    if z_wait + z_p + z_accept != 1:
        raise AssertionError("The action masses do not sum to one")
    if min(z_wait, z_p, z_accept) <= 0:
        raise AssertionError("Every buyer action must have positive mass")

    c_q = {
        "L": expectation(
            multiply(ATTEMPT_LOWER, C_L),
            multiply(ATTEMPT_UPPER, C_L),
        )
        / z_q,
        "H": expectation(
            multiply(ATTEMPT_LOWER, C_H),
            multiply(ATTEMPT_UPPER, C_H),
        )
        / z_q,
    }
    c_p = {
        "L": expectation(
            multiply(REVISE_LOWER, C_L),
            multiply(REVISE_UPPER, C_L),
        )
        / z_p,
        "H": expectation(
            multiply(REVISE_LOWER, C_H),
            multiply(REVISE_UPPER, C_H),
        )
        / z_p,
    }
    k_r = {
        "L": (P_REVISION * z_p + R_COUNTER * z_accept) / z_q - C_S,
        "H": (
            expectation(
                multiply(REVISE_LOWER, C_H),
                multiply(REVISE_UPPER, C_H),
            )
            + R_COUNTER * z_accept
        )
        / z_q
        - C_S,
    }

    tail = evaluate(C_L, Q(0))
    tail_threshold = tail + C_B
    counter_bound = {
        "L": max(tail_threshold, tail) - C_S,
        "H": max(tail_threshold, evaluate(C_H, Q(0))) - C_S,
    }
    direct_threshold = {
        "L": evaluate(C_L, Q(1)),
        "H": evaluate(C_H, Q(1)),
    }

    margins: Dict[str, Q] = {
        # Global buyer-price deviations.
        "initial_path_vs_L_only": A
        * (direct_threshold["L"] - P_REVISION)
        - C_B,
        "initial_path_vs_both": direct_threshold["H"] - R_COUNTER,
        "revision_vs_unexpected_L_only": A
        * (direct_threshold["L"] - P_REVISION),
        "acceptance_vs_unexpected_both": (
            direct_threshold["H"] + C_B - R_COUNTER
        ),
        # On-path seller behavior.
        "seller_L_chooses_r": k_r["L"]
        - max(Q_INITIAL, c_q["L"], counter_bound["L"]),
        "seller_H_chooses_r": k_r["H"]
        - max(Q_INITIAL, c_q["H"], counter_bound["H"]),
        "seller_L_accepts_p": P_REVISION
        - max(c_p["L"], counter_bound["L"]),
        "seller_H_terminates_p": c_p["H"]
        - max(P_REVISION, counter_bound["H"]),
        # Uniform off-path tail and direct-offer thresholds.
        "all_active_types_can_use_tail": W_L_BETA - tail - C_B,
        "top_zero_urgency_can_use_tail": evaluate(W_L, Q(1))
        - tail
        - C_B,
        "tail_low_type_is_below_global_threshold": tail_threshold
        - evaluate(W_L, Q(0)),
        "unexpected_L_terminates_vs_counter": direct_threshold["L"]
        - counter_bound["L"],
        "unexpected_H_terminates_vs_counter": direct_threshold["H"]
        - counter_bound["H"],
        # A recounter after the exact tail strictly loses c_S.
        "tail_L_no_recounter": tail
        - max(evaluate(W_L, Q(0)) - C_S, tail - C_S),
        "tail_H_no_recounter": evaluate(C_H, Q(0))
        - max(
            tail,
            evaluate(W_L, Q(0)) - C_S,
            evaluate(C_H, Q(0)) - C_S,
        ),
    }
    failures = {name: value for name, value in margins.items() if value <= 0}
    if failures:
        raise AssertionError(f"A strict equilibrium margin failed: {failures}")

    outcomes = {
        "no_attempt": z_wait,
        "attempt_then_auction": PI * z_p,
        "early_agreement": A * z_p + z_accept,
    }
    if sum(outcomes.values()) != 1 or any(value <= 0 for value in outcomes.values()):
        raise AssertionError("The outcome probabilities are invalid")

    expected_values = {
        "wait_mass": Q(7399, 80000),
        "revision_mass": Q(1530343, 5040000),
        "acceptance_mass": Q(9511, 15750),
        "C_q_L": Q(167131963, 326704500),
        "C_q_H": Q(616405928429, 857599312500),
        "C_p_L": Q(1114131223, 2295514500),
        "C_p_H": Q(2635608319577, 3730211062500),
        "K_r_L": Q(17263179419, 24012780750),
        "K_r_H": Q(2118497234363, 2787197765625),
    }
    actual_values = {
        "wait_mass": z_wait,
        "revision_mass": z_p,
        "acceptance_mass": z_accept,
        "C_q_L": c_q["L"],
        "C_q_H": c_q["H"],
        "C_p_L": c_p["L"],
        "C_p_H": c_p["H"],
        "K_r_L": k_r["L"],
        "K_r_H": k_r["H"],
    }
    if actual_values != expected_values:
        raise AssertionError("An exact posterior or payoff value changed")

    return {
        "prices": {
            "q": Q_INITIAL,
            "r": R_COUNTER,
            "p": P_REVISION,
        },
        "thresholds": {
            "beta": BETA,
            "x_0": evaluate(X_THRESHOLD, Q(0)),
            "x_1": evaluate(X_THRESHOLD, Q(1)),
            "y_0": evaluate(Y_THRESHOLD, Q(0)),
            "y_1": evaluate(Y_THRESHOLD, Q(1)),
        },
        "action_masses": {
            "wait": z_wait,
            "revise": z_p,
            "accept": z_accept,
        },
        "seller_values": {
            "C_q": c_q,
            "C_p": c_p,
            "K_r": k_r,
            "counter_bound": counter_bound,
        },
        "margins": margins,
        "outcomes": outcomes,
        "minimum_strict_margin": min(margins.values()),
    }


def decimal(value: Q) -> str:
    return f"{float(value):.12f}"


def print_report(result: Dict[str, object]) -> None:
    print("COMMON-UNIFORM CONTINUOUS-TYPE BARGAINING AUDIT: PASS")
    print("  common value distribution: early and late values U[0,1]")
    print("  urgency distribution: U[0,2]")
    print("  late bidder counts: n_L=2, n_H=5")
    print(
        "  prices: "
        + ", ".join(
            f"{name}={value} ({decimal(value)})"
            for name, value in result["prices"].items()
        )
    )
    print("  threshold geometry")
    for name, value in result["thresholds"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  action masses")
    for name, value in result["action_masses"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  seller values")
    for state in ("L", "H"):
        values = result["seller_values"]
        print(
            f"    {state}: C(q)={decimal(values['C_q'][state])}, "
            f"K(r)={decimal(values['K_r'][state])}, "
            f"C(p)={decimal(values['C_p'][state])}, "
            f"off-path bound={decimal(values['counter_bound'][state])}"
        )
    print("  outcomes")
    for name, value in result["outcomes"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print(
        "  minimum strict margin: "
        f"{result['minimum_strict_margin']} "
        f"({decimal(result['minimum_strict_margin'])})"
    )
    print("  continuous buyer/seller prices and recursive histories: exhausted")


if __name__ == "__main__":
    print_report(run_audit())
