"""Audit the public-reserve/no-sale one-offer benchmark.

The benchmark uses common U[0,1] buyer values, a public reserve ``ell``, and
the same money-metric value ``ell`` when the seller retains the dwelling.  It
therefore permits a genuine no-sale outcome while preserving a nonnegative
competition wedge.

All posterior integrals are evaluated piecewise.  The quadrature intervals
split at the reserve and at every endogenous point where an urgency cutoff
crosses zero or the upper urgency bound.  This matters for the probing
calibration: a fixed full-support Gauss rule can miss the kink where the offer
mass first becomes positive and can report a spuriously tiny fixed-point
residual.  Reported roots are rechecked with an independent, higher-order
piecewise rule.

This is a numerical audit, not a substitute for the analytical equilibrium
and D1 proofs.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import expm1

import numpy as np
from numpy.polynomial.legendre import leggauss

from explore_continuous_regime_map import (
    D_SELLER,
    N_H,
    N_L,
    PI,
    Primitives,
)


ELL = 0.4
A = 1.0 - PI
QUAD_N = 120
VALIDATION_QUAD_N = 220
ROOT_TOL = 2e-13

PROBING_PRIMITIVES = Primitives(0.05, 0.15, 10.0)
FULL_MENU_PRIMITIVES = Primitives(0.12, 1.2, 10.0)


def w_uniform_reserve(
    n: int, b: np.ndarray | float, ell: float
) -> np.ndarray | float:
    """Patient early willingness with a public reserve."""

    value = np.asarray(b)
    result = np.where(
        value <= ell,
        value,
        value - (value ** (n + 1) - ell ** (n + 1)) / (n + 1),
    )
    return float(result) if np.ndim(value) == 0 else result


def revenue_uniform_reserve(
    n: int, b: np.ndarray | float, ell: float
) -> np.ndarray | float:
    """Seller payoff including retention of a dwelling worth ``ell``."""

    value = np.asarray(b)
    below = (
        (n - 1) / (n + 1)
        + ell**n
        - (n - 1) * ell ** (n + 1) / (n + 1)
    )
    above = (
        (n - 1) / (n + 1)
        + value**n
        - n * value ** (n + 1) / (n + 1)
        + ell ** (n + 1) / (n + 1)
    )
    result = np.where(value <= ell, below, above)
    return float(result) if np.ndim(value) == 0 else result


def wedge_uniform_reserve(
    n: int, b: np.ndarray | float, ell: float
) -> np.ndarray | float:
    """Reserve-adjusted competition wedge in closed form."""

    value = np.asarray(b)
    threshold = np.maximum(value, ell)
    second_tail = (
        (n - 1) / (n + 1)
        - threshold
        + threshold**n
        - (n - 1) * threshold ** (n + 1) / (n + 1)
    )
    result = np.maximum(ell - value, 0.0) + second_tail
    return float(result) if np.ndim(value) == 0 else result


def allocation_gain_uniform_reserve(
    n: int, b: np.ndarray | float, ell: float
) -> np.ndarray | float:
    """Allocative gain from retaining or auctioning rather than selling early."""

    value = np.asarray(b)
    threshold = np.maximum(value, ell)
    first_tail = (
        n / (n + 1)
        - threshold
        + threshold ** (n + 1) / (n + 1)
    )
    result = np.maximum(ell - value, 0.0) + first_tail
    return float(result) if np.ndim(value) == 0 else result


def _crossing_point(function, target: float) -> float | None:
    """Return the unique crossing of a continuous monotone function on [0,1]."""

    left, right = 0.0, 1.0
    f_left = float(function(left) - target)
    f_right = float(function(right) - target)
    if abs(f_left) <= 1e-14:
        return left
    if abs(f_right) <= 1e-14:
        return right
    if f_left * f_right > 0.0:
        return None
    for _ in range(100):
        middle = 0.5 * (left + right)
        f_middle = float(function(middle) - target)
        if f_left * f_middle <= 0.0:
            right = middle
        else:
            left = middle
            f_left = f_middle
    return 0.5 * (left + right)


class PiecewiseReserveModel:
    """Reserve-adjusted equilibrium maps with breakpoint-aware quadrature."""

    def __init__(
        self,
        primitives: Primitives,
        ell: float = ELL,
        quad_n: int = QUAD_N,
    ) -> None:
        self.pr = primitives
        self.ell = ell
        self.nodes, self.weights = leggauss(quad_n)

    def w_l(self, b: np.ndarray | float) -> np.ndarray | float:
        return w_uniform_reserve(N_L, b, self.ell)

    def w_h(self, b: np.ndarray | float) -> np.ndarray | float:
        return w_uniform_reserve(N_H, b, self.ell)

    def c_l(self, b: np.ndarray | float) -> np.ndarray | float:
        return revenue_uniform_reserve(N_L, b, self.ell) - D_SELLER

    def c_h(self, b: np.ndarray | float) -> np.ndarray | float:
        return revenue_uniform_reserve(N_H, b, self.ell) - D_SELLER

    def urgency_cdf(self, cutoff: np.ndarray | float) -> np.ndarray | float:
        value = np.asarray(cutoff)
        d_bar = self.pr.d_bar
        raw = np.expm1(
            -self.pr.urgency_rate * np.clip(value, 0.0, d_bar)
        )
        interior = raw / expm1(-self.pr.urgency_rate * d_bar)
        result = np.where(
            value <= 0.0,
            0.0,
            np.where(value >= d_bar, 1.0, interior),
        )
        return float(result) if np.ndim(value) == 0 else result

    def rule(self, breakpoints: list[float | None]) -> tuple[np.ndarray, np.ndarray]:
        clean = sorted(
            value
            for value in {
                round(float(point), 15)
                for point in breakpoints
                if point is not None and 0.0 <= point <= 1.0
            }
        )
        if not clean or clean[0] != 0.0:
            clean.insert(0, 0.0)
        if clean[-1] != 1.0:
            clean.append(1.0)

        values: list[np.ndarray] = []
        weights: list[np.ndarray] = []
        for left, right in zip(clean[:-1], clean[1:]):
            if right - left <= 1e-14:
                continue
            values.append(left + 0.5 * (self.nodes + 1.0) * (right - left))
            weights.append(0.5 * (right - left) * self.weights)
        return np.concatenate(values), np.concatenate(weights)

    def probing_statistics(self, q_l: float) -> dict[str, float | np.ndarray]:
        def cutoff(value):
            return (
                q_l
                - self.w_l(value)
                + self.pr.kappa / A
            )

        breakpoints: list[float | None] = [0.0, self.ell, 1.0]
        for target in (0.0, self.pr.d_bar):
            breakpoints.append(_crossing_point(cutoff, target))
        b, weights = self.rule(breakpoints)
        mass_by_b = 1.0 - self.urgency_cdf(cutoff(b))
        mass = float(np.dot(weights, mass_by_b))
        if mass <= 0.0:
            raise AssertionError("The probing action has zero mass.")
        mapped = float(np.dot(weights, self.c_l(b) * mass_by_b) / mass)
        post_h = float(np.dot(weights, self.c_h(b) * mass_by_b) / mass)
        mean_b = float(np.dot(weights, b * mass_by_b) / mass)
        active_start = _crossing_point(cutoff, self.pr.d_bar)
        return {
            "mapped": mapped,
            "mass": mass,
            "post_h": post_h,
            "mean_b": mean_b,
            "active_start": 0.0 if active_start is None else active_start,
        }

    def probing_map(self, q_l: float) -> float:
        return float(self.probing_statistics(q_l)["mapped"])

    def two_price_statistics(
        self, q_l: float, q_h: float
    ) -> dict[str, object]:
        def d_l(value):
            return q_l - self.w_l(value) + self.pr.kappa / A

        def d_aux(value):
            return (
                q_h
                - A * self.w_l(value)
                - PI * self.w_h(value)
                + self.pr.kappa
            )

        def d_h(value):
            return (q_h - A * q_l) / PI - self.w_h(value)

        def z_gap(value):
            return (
                q_h
                - q_l
                - PI * (self.w_h(value) - self.w_l(value))
                - PI * self.pr.kappa / A
            )

        breakpoints: list[float | None] = [0.0, self.ell, 1.0]
        for cutoff in (d_l, d_aux, d_h):
            for target in (0.0, self.pr.d_bar):
                breakpoints.append(_crossing_point(cutoff, target))
        breakpoints.append(_crossing_point(z_gap, 0.0))
        b, weights = self.rule(breakpoints)

        d_l_values = d_l(b)
        d_aux_values = d_aux(b)
        d_h_values = d_h(b)
        screening = z_gap(b) > 0.0
        g_l = self.urgency_cdf(d_l_values)
        g_aux = self.urgency_cdf(d_aux_values)
        g_h = self.urgency_cdf(d_h_values)
        m_0 = np.where(screening, g_l, g_aux)
        m_l = np.where(screening, g_h - g_l, 0.0)
        m_h = np.where(screening, 1.0 - g_h, 1.0 - g_aux)
        masses = tuple(float(np.dot(weights, mass)) for mass in (m_0, m_l, m_h))
        if min(masses[1:]) <= 0.0:
            raise AssertionError("Both full-menu actions must have positive mass.")

        mapped_l = float(np.dot(weights, self.c_l(b) * m_l) / masses[1])
        mapped_h = float(np.dot(weights, self.c_h(b) * m_h) / masses[2])
        post_h_probe = float(np.dot(weights, self.c_h(b) * m_l) / masses[1])
        post_l_knockout = float(np.dot(weights, self.c_l(b) * m_h) / masses[2])
        mean_attempt = float(
            np.dot(weights, b * (m_l + m_h)) / (masses[1] + masses[2])
        )
        mean_probe = float(np.dot(weights, b * m_l) / masses[1])
        mean_knockout = float(np.dot(weights, b * m_h) / masses[2])
        return {
            "mapped": np.array([mapped_l, mapped_h]),
            "masses": masses,
            "post_h_probe": post_h_probe,
            "post_l_knockout": post_l_knockout,
            "means": (mean_attempt, mean_probe, mean_knockout),
        }

    def two_price_map(self, q: np.ndarray) -> np.ndarray:
        return np.asarray(self.two_price_statistics(float(q[0]), float(q[1]))["mapped"])


@dataclass(frozen=True)
class ProbeAudit:
    q_l: float
    masses: tuple[float, float]
    cutoff_range: tuple[float, float]
    active_value_start: float
    residual: float
    seller_h_rejection_slack: float
    knockout_deviation_gain: float
    d1_slack: float


@dataclass(frozen=True)
class FullMenuAudit:
    q_l: float
    q_h: float
    masses: tuple[float, float, float]
    cutoff_ranges: tuple[tuple[float, float], ...]
    residual: float
    seller_slacks: tuple[float, float]
    d1_slacks: tuple[float, float]
    conditional_means: tuple[float, float, float]
    box_interior_margins: tuple[float, float, float]
    box_face_margins: tuple[float, float, float, float]


@dataclass(frozen=True)
class TransitionAudit:
    d_bar: float
    q_l: float
    q_h_limit: float
    masses: tuple[float, float]
    residual: float


def _solve_scalar(mapping, bounds: tuple[float, float]) -> float:
    left, right = bounds
    f_left = mapping(left) - left
    f_right = mapping(right) - right
    if not (f_left > 0.0 and f_right < 0.0):
        raise AssertionError(
            f"Scalar fixed point is not bracketed: {f_left=}, {f_right=}"
        )
    for _ in range(100):
        middle = 0.5 * (left + right)
        f_middle = mapping(middle) - middle
        if f_middle > 0.0:
            left = middle
        else:
            right = middle
    return 0.5 * (left + right)


def _solve_vector(
    model: PiecewiseReserveModel,
    start: tuple[float, float],
) -> np.ndarray:
    q = np.array(start, dtype=float)
    for _ in range(100):
        mapped = model.two_price_map(q)
        residual = mapped - q
        if float(np.max(np.abs(residual))) < ROOT_TOL:
            return q

        step = 1e-7
        jacobian = np.empty((2, 2))
        for column in range(2):
            shifted = q.copy()
            shifted[column] += step
            shifted_residual = model.two_price_map(shifted) - shifted
            jacobian[:, column] = (shifted_residual - residual) / step
        delta = np.linalg.solve(jacobian, -residual)

        accepted = False
        old_norm = float(np.max(np.abs(residual)))
        for damping in (1.0, 0.5, 0.25, 0.1, 0.05, 0.01):
            trial = q + damping * delta
            try:
                trial_norm = float(
                    np.max(np.abs(model.two_price_map(trial) - trial))
                )
            except AssertionError:
                continue
            if trial_norm < old_norm:
                q = trial
                accepted = True
                break
        if not accepted:
            q = 0.8 * q + 0.2 * mapped
    raise AssertionError("The two-price fixed point did not converge.")


def theorem_thresholds(
    ell: float = ELL,
    primitives: Primitives = PROBING_PRIMITIVES,
) -> dict[str, float]:
    """Return the no-offer and probing-only theorem thresholds."""

    w_l_bar = float(w_uniform_reserve(N_L, 1.0, ell))
    w_h_bar = float(w_uniform_reserve(N_H, 1.0, ell))
    c_l_bar = float(revenue_uniform_reserve(N_L, 1.0, ell) - D_SELLER)
    c_h_bar = float(revenue_uniform_reserve(N_H, 1.0, ell) - D_SELLER)
    bar_w = A * w_l_bar + PI * w_h_bar
    bar_d_l = c_l_bar - w_l_bar + primitives.kappa / A
    bar_d_h = c_h_bar - bar_w + primitives.kappa
    delta_d = bar_d_h - bar_d_l
    return {
        "bar_D_L": bar_d_l,
        "bar_D_H": bar_d_h,
        "Delta_D": delta_d,
        "probing_upper": bar_d_l + delta_d / PI,
    }


def audit_closed_forms(ell: float = ELL) -> None:
    grid = np.linspace(0.0, 1.0, 4001)
    for n in (N_L, N_H):
        willingness = w_uniform_reserve(n, grid, ell)
        revenue = revenue_uniform_reserve(n, grid, ell)
        wedge = wedge_uniform_reserve(n, grid, ell)
        allocation_gain = allocation_gain_uniform_reserve(n, grid, ell)
        late_surplus = allocation_gain - wedge
        assert np.max(np.abs(revenue - willingness - wedge)) < 2e-14
        assert np.min(np.diff(willingness)) > 0.0
        assert np.min(np.diff(revenue)) >= -2e-14
        assert np.min(wedge) >= -2e-14
        assert np.min(late_surplus) >= -2e-14
        below = grid < ell
        assert np.max(np.abs(np.diff(revenue[below]))) < 2e-14
    assert np.min(
        revenue_uniform_reserve(N_H, grid, ell)
        - revenue_uniform_reserve(N_L, grid, ell)
    ) > 0.0
    assert abs(ell ** (N_L + 1) - 0.064) < 1e-15
    assert abs(ell ** (N_H + 1) - 0.00065536) < 1e-15


def solve_probing(
    ell: float = ELL,
    primitives: Primitives = PROBING_PRIMITIVES,
) -> ProbeAudit:
    model = PiecewiseReserveModel(primitives, ell, QUAD_N)
    validation = PiecewiseReserveModel(primitives, ell, VALIDATION_QUAD_N)
    bounds = (
        float(revenue_uniform_reserve(N_L, 0.0, ell) - D_SELLER),
        float(revenue_uniform_reserve(N_L, 1.0, ell) - D_SELLER),
    )
    q_l = _solve_scalar(model.probing_map, bounds)
    statistics = validation.probing_statistics(q_l)
    residual = abs(float(statistics["mapped"]) - q_l)

    w_l_bar = float(w_uniform_reserve(N_L, 1.0, ell))
    w_h_bar = float(w_uniform_reserve(N_H, 1.0, ell))
    c_l_bar = bounds[1]
    c_h_bar = float(revenue_uniform_reserve(N_H, 1.0, ell) - D_SELLER)
    d_l_bar = q_l - w_l_bar + primitives.kappa / A

    # For a knockout deviation at p=C_H(1), the gain is increasing in d.
    # At d=d_bar it is increasing in b below and above the probing cutoff:
    # the two slopes are bar_w'(b) and pi*w_H'(b), respectively.  The exact
    # global maximum is therefore the top-value endpoint.
    probe_payoff = A * (
        w_l_bar + primitives.d_bar - q_l
    ) - primitives.kappa
    knockout_payoff = (
        A * w_l_bar
        + PI * w_h_bar
        + primitives.d_bar
        - c_h_bar
        - primitives.kappa
    )
    deviation_gain = knockout_payoff - max(0.0, probe_payoff)
    d1_slack = c_l_bar - q_l if d_l_bar >= 0.0 else float("nan")

    assert residual < 2e-12
    assert deviation_gain < 0.0
    assert d1_slack > 0.0
    assert float(statistics["post_h"]) > q_l
    return ProbeAudit(
        q_l=q_l,
        masses=(1.0 - float(statistics["mass"]), float(statistics["mass"])),
        cutoff_range=(
            d_l_bar,
            q_l - float(w_uniform_reserve(N_L, 0.0, ell))
            + primitives.kappa / A,
        ),
        active_value_start=float(statistics["active_start"]),
        residual=residual,
        seller_h_rejection_slack=float(statistics["post_h"]) - q_l,
        knockout_deviation_gain=deviation_gain,
        d1_slack=d1_slack,
    )


def _audit_price_box(
    model: PiecewiseReserveModel,
    root: np.ndarray,
    width_l: float = 1e-3,
    width_h: float = 1e-4,
) -> tuple[tuple[float, float, float], tuple[float, float, float, float]]:
    lower_l, upper_l = root[0] - width_l, root[0] + width_l
    lower_h, upper_h = root[1] - width_h, root[1] + width_h
    w_l_bar = float(model.w_l(1.0))
    w_h_bar = float(model.w_h(1.0))
    interior = tuple(
        float(value)
        for value in (
            lower_l - w_l_bar + model.pr.kappa / A,
            model.pr.d_bar
            - (upper_h - A * lower_l) / PI
            + float(model.w_h(0.0)),
            lower_h
            - upper_l
            - PI * (w_h_bar - w_l_bar)
            - PI * model.pr.kappa / A,
        )
    )

    grid_h = np.linspace(lower_h, upper_h, 401)
    grid_l = np.linspace(lower_l, upper_l, 401)
    lower_l_face = [
        float(model.two_price_map(np.array([lower_l, q_h]))[0] - lower_l)
        for q_h in grid_h
    ]
    upper_l_face = [
        float(upper_l - model.two_price_map(np.array([upper_l, q_h]))[0])
        for q_h in grid_h
    ]
    lower_h_face = [
        float(model.two_price_map(np.array([q_l, lower_h]))[1] - lower_h)
        for q_l in grid_l
    ]
    upper_h_face = [
        float(upper_h - model.two_price_map(np.array([q_l, upper_h]))[1])
        for q_l in grid_l
    ]
    faces = (
        min(lower_l_face),
        min(upper_l_face),
        min(lower_h_face),
        min(upper_h_face),
    )
    assert min(interior) > 0.0
    assert min(faces) > 0.0
    return interior, faces


def solve_full_menu(
    ell: float = ELL,
    primitives: Primitives = FULL_MENU_PRIMITIVES,
    start: tuple[float, float] = (0.609, 0.829),
    audit_box: bool = True,
    require_global_interior: bool = True,
) -> FullMenuAudit:
    model = PiecewiseReserveModel(primitives, ell, QUAD_N)
    validation = PiecewiseReserveModel(primitives, ell, VALIDATION_QUAD_N)
    root = _solve_vector(model, start)
    statistics = validation.two_price_statistics(float(root[0]), float(root[1]))
    residual = float(
        np.max(np.abs(np.asarray(statistics["mapped"]) - root))
    )

    d_l = lambda value: (
        root[0] - w_uniform_reserve(N_L, value, ell) + primitives.kappa / A
    )
    d_aux = lambda value: (
        root[1]
        - A * w_uniform_reserve(N_L, value, ell)
        - PI * w_uniform_reserve(N_H, value, ell)
        + primitives.kappa
    )
    d_h = lambda value: (
        (root[1] - A * root[0]) / PI
        - w_uniform_reserve(N_H, value, ell)
    )
    cutoff_ranges = tuple(
        (float(cutoff(1.0)), float(cutoff(0.0)))
        for cutoff in (d_l, d_aux, d_h)
    )
    w_l_bar = float(w_uniform_reserve(N_L, 1.0, ell))
    w_h_bar = float(w_uniform_reserve(N_H, 1.0, ell))
    min_z = (
        root[1]
        - root[0]
        - PI * (w_h_bar - w_l_bar)
        - PI * primitives.kappa / A
    )
    c_l_bar = float(revenue_uniform_reserve(N_L, 1.0, ell) - D_SELLER)
    c_h_bar = float(revenue_uniform_reserve(N_H, 1.0, ell) - D_SELLER)
    d1_slacks = (
        float(c_l_bar - root[0]),
        float(c_h_bar - root[1]),
    )
    seller_slacks = (
        float(float(statistics["post_h_probe"]) - root[0]),
        float(root[1] - float(statistics["post_l_knockout"])),
    )
    if audit_box:
        interior, faces = _audit_price_box(validation, root)
    else:
        interior = (float("nan"),) * 3
        faces = (float("nan"),) * 4

    assert residual < 2e-12
    assert min_z > 0.0
    assert min(seller_slacks) > 0.0
    assert min(d1_slacks) > 0.0
    if require_global_interior:
        assert min(cutoff_ranges[0]) > 0.0
        assert max(cutoff_ranges[2]) < primitives.d_bar
    return FullMenuAudit(
        q_l=float(root[0]),
        q_h=float(root[1]),
        masses=tuple(float(value) for value in statistics["masses"]),
        cutoff_ranges=cutoff_ranges,
        residual=residual,
        seller_slacks=seller_slacks,
        d1_slacks=d1_slacks,
        conditional_means=tuple(float(value) for value in statistics["means"]),
        box_interior_margins=interior,
        box_face_margins=faces,
    )


def solve_menu_transition(ell: float = ELL) -> TransitionAudit:
    """Continue probing until the top buyer first wants knockout."""

    kappa = PROBING_PRIMITIVES.kappa
    rate = PROBING_PRIMITIVES.urgency_rate
    w_h_bar = float(w_uniform_reserve(N_H, 1.0, ell))
    c_h_bar = float(revenue_uniform_reserve(N_H, 1.0, ell) - D_SELLER)

    def d_bar_at_boundary(q_l: float) -> float:
        return (c_h_bar - A * q_l) / PI - w_h_bar

    def mapping(q_l: float, quad_n: int) -> float:
        d_bar = d_bar_at_boundary(q_l)
        primitives = Primitives(kappa, d_bar, rate)
        return PiecewiseReserveModel(primitives, ell, quad_n).probing_map(q_l)

    c_l_bounds = (
        float(revenue_uniform_reserve(N_L, 0.0, ell) - D_SELLER),
        float(revenue_uniform_reserve(N_L, 1.0, ell) - D_SELLER),
    )
    q_l = _solve_scalar(lambda price: mapping(price, QUAD_N), c_l_bounds)
    d_bar = d_bar_at_boundary(q_l)
    validation_model = PiecewiseReserveModel(
        Primitives(kappa, d_bar, rate), ell, VALIDATION_QUAD_N
    )
    statistics = validation_model.probing_statistics(q_l)
    residual = abs(float(statistics["mapped"]) - q_l)
    assert residual < 2e-12

    # Immediately above the boundary, the full-menu branch has positive
    # knockout mass and converges to (q_l,C_H(1)).
    witness_primitives = Primitives(kappa, 0.198, rate)
    witness = solve_full_menu(
        ell,
        witness_primitives,
        start=(q_l, c_h_bar),
        audit_box=False,
        require_global_interior=False,
    )
    assert witness.masses[2] > 0.0
    return TransitionAudit(
        d_bar=d_bar,
        q_l=q_l,
        q_h_limit=c_h_bar,
        masses=(1.0 - float(statistics["mass"]), float(statistics["mass"])),
        residual=residual,
    )


def main() -> None:
    audit_closed_forms()
    thresholds = theorem_thresholds()
    probing = solve_probing()
    full = solve_full_menu()
    transition = solve_menu_transition()

    print("reserve/no-sale closed forms: PASS")
    print(f"ell={ELL:.3f}")
    print(
        "ex-ante terminal no-sale probabilities: "
        f"L={ELL ** (N_L + 1):.9f}, H={ELL ** (N_H + 1):.9f}"
    )
    print(
        "theorem thresholds: "
        f"bar_D_L={thresholds['bar_D_L']:.9f}, "
        f"bar_D_H={thresholds['bar_D_H']:.9f}, "
        f"Delta_D={thresholds['Delta_D']:.9f}, "
        f"probing_upper={thresholds['probing_upper']:.9f}"
    )
    print(
        "probing-only: "
        f"q_L={probing.q_l:.12f}, masses={probing.masses}, "
        f"active_b_start={probing.active_value_start:.12f}, "
        f"cutoff={probing.cutoff_range}, residual={probing.residual:.3e}, "
        f"H-rejection slack={probing.seller_h_rejection_slack:.12f}, "
        f"knockout gain={probing.knockout_deviation_gain:.12f}, "
        f"D1 slack={probing.d1_slack:.12f}"
    )
    rejected = PI * full.masses[1]
    successful = A * full.masses[1] + full.masses[2]
    print(
        "full menu: "
        f"q=({full.q_l:.12f},{full.q_h:.12f}), masses={full.masses}, "
        f"rejected={rejected:.12f}, successful={successful:.12f}, "
        f"cutoff ranges={full.cutoff_ranges}, residual={full.residual:.3e}"
    )
    print(
        "full-menu seller slacks [H rejects probe, L accepts knockout]:",
        full.seller_slacks,
    )
    print("full-menu D1 endpoint slacks:", full.d1_slacks)
    print("full-menu conditional b means [attempt, probe, knockout]:", full.conditional_means)
    print("full-menu box interior margins:", full.box_interior_margins)
    print("full-menu box face margins:", full.box_face_margins)
    print(
        "canonical probing/full-menu transition: "
        f"d_bar={transition.d_bar:.12f}, q_L={transition.q_l:.12f}, "
        f"q_H_limit={transition.q_h_limit:.12f}, masses={transition.masses}, "
        f"residual={transition.residual:.3e}"
    )


if __name__ == "__main__":
    main()
