"""Cross-platform runner for the public computational result package.

The runner reads ``code/claims.json``, validates that every claim points to
Python-only tasks, executes either a bounded core or the complete publication
suite, and records logs, environment metadata, transitive source hashes, and
claim-level status.  Maintained figure generators run only in an isolated
copy; distributed figure files are never overwritten.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.metadata
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


CODE_DIR = Path(__file__).resolve().parent
REPOSITORY_ROOT = CODE_DIR.parent
DEFAULT_MANIFEST = CODE_DIR / "claims.json"
DEFAULT_RESULTS_BASE = CODE_DIR / "reproduction_outputs"
ALLOWED_CLASSIFICATIONS = {
    "interval_certificate",
    "exact_arithmetic_audit",
    "floating_point_audit",
    "diagnostic",
    "figure_roundtrip",
}
ALLOWED_MODES = {"core", "publication"}
REQUIRED_CLAIM_FIELDS = {
    "id",
    "title",
    "manuscript_refs",
    "displayed_or_pass_condition",
    "task_ids",
    "authoritative_scripts",
    "classification",
    "proof_notes",
    "fatal_to_working_paper",
}
REQUIRED_TASK_FIELDS = {
    "id",
    "title",
    "classification",
    "modes",
    "kind",
    "timeout_seconds",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalized_text(path: Path) -> str:
    """Decode UTF-8 and normalize platform line endings for exact comparison."""

    return path.read_text(encoding="utf-8").replace("\r\n", "\n").replace(
        "\r", "\n"
    )


def load_manifest(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def repository_path(relative: str) -> Path:
    candidate = (REPOSITORY_ROOT / relative).resolve()
    try:
        candidate.relative_to(REPOSITORY_ROOT.resolve())
    except ValueError as error:
        raise ValueError(f"Path leaves repository: {relative}") from error
    return candidate


def validate_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    if manifest.get("schema_version") != 1:
        errors.append("schema_version must equal 1")

    tasks = manifest.get("tasks")
    claims = manifest.get("claims")
    if not isinstance(tasks, list) or not tasks:
        errors.append("tasks must be a nonempty list")
        tasks = []
    if not isinstance(claims, list) or not claims:
        errors.append("claims must be a nonempty list")
        claims = []

    task_ids: set[str] = set()
    for index, task in enumerate(tasks):
        missing = REQUIRED_TASK_FIELDS - set(task)
        if missing:
            errors.append(f"task {index} lacks fields: {sorted(missing)}")
            continue
        task_id = task["id"]
        if task_id in task_ids:
            errors.append(f"duplicate task id: {task_id}")
        task_ids.add(task_id)
        if task["classification"] not in ALLOWED_CLASSIFICATIONS:
            errors.append(
                f"task {task_id} has unknown classification "
                f"{task['classification']}"
            )
        modes = set(task["modes"])
        if not modes or not modes <= ALLOWED_MODES:
            errors.append(f"task {task_id} has invalid modes: {sorted(modes)}")
        if not isinstance(task["timeout_seconds"], int) or (
            task["timeout_seconds"] <= 0
        ):
            errors.append(f"task {task_id} needs a positive integer timeout")

        if task["kind"] == "python":
            script = task.get("script", "")
            if not script.endswith(".py"):
                errors.append(f"task {task_id} is not Python-only: {script}")
            elif not repository_path(script).is_file():
                errors.append(f"task {task_id} script is missing: {script}")
            if not isinstance(task.get("args"), list):
                errors.append(f"task {task_id} args must be a list")
        elif task["kind"] == "figure_roundtrip":
            scripts = task.get("scripts")
            outputs = task.get("outputs")
            if not isinstance(scripts, list) or not scripts:
                errors.append(f"task {task_id} needs figure scripts")
                scripts = []
            if not isinstance(outputs, list) or not outputs:
                errors.append(f"task {task_id} needs figure outputs")
                outputs = []
            for script in scripts:
                if not script.endswith(".py"):
                    errors.append(
                        f"figure task {task_id} is not Python-only: {script}"
                    )
                elif not repository_path(script).is_file():
                    errors.append(
                        f"figure task {task_id} script is missing: {script}"
                    )
            for output in outputs:
                if not repository_path(output).is_file():
                    errors.append(
                        f"figure task {task_id} output is missing: {output}"
                    )
        else:
            errors.append(f"task {task_id} has invalid kind: {task['kind']}")

    claim_ids: set[str] = set()
    referenced_tasks: set[str] = set()
    for index, claim in enumerate(claims):
        missing = REQUIRED_CLAIM_FIELDS - set(claim)
        if missing:
            errors.append(f"claim {index} lacks fields: {sorted(missing)}")
            continue
        claim_id = claim["id"]
        if claim_id in claim_ids:
            errors.append(f"duplicate claim id: {claim_id}")
        claim_ids.add(claim_id)
        if claim["classification"] not in ALLOWED_CLASSIFICATIONS:
            errors.append(
                f"claim {claim_id} has unknown classification "
                f"{claim['classification']}"
            )
        if not claim["task_ids"]:
            errors.append(f"claim {claim_id} has no task")
        for task_id in claim["task_ids"]:
            referenced_tasks.add(task_id)
            if task_id not in task_ids:
                errors.append(
                    f"claim {claim_id} references unknown task {task_id}"
                )
        for script in claim["authoritative_scripts"]:
            if not script.endswith(".py"):
                errors.append(
                    f"claim {claim_id} has non-Python authoritative source "
                    f"{script}"
                )
            elif not repository_path(script).is_file():
                errors.append(
                    f"claim {claim_id} source is missing: {script}"
                )
        for note in claim["proof_notes"]:
            if not repository_path(note).is_file():
                errors.append(f"claim {claim_id} note is missing: {note}")

    unreferenced = task_ids - referenced_tasks
    if unreferenced:
        errors.append(f"unreferenced tasks: {sorted(unreferenced)}")

    report = {
        "status": "pass" if not errors else "fail",
        "schema_version": manifest.get("schema_version"),
        "task_count": len(tasks),
        "claim_count": len(claims),
        "errors": errors,
    }
    if errors:
        raise ValueError("Manifest validation failed:\n- " + "\n- ".join(errors))
    return report


def local_python_dependencies(paths: set[Path]) -> set[Path]:
    """Return transitive local-module dependencies for selected Python files."""

    discovered = {path.resolve() for path in paths}
    queue = list(discovered)
    while queue:
        path = queue.pop()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (SyntaxError, UnicodeDecodeError):
            continue
        module_names: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                module_names.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                module_names.add(node.module.split(".")[0])
        for name in module_names:
            candidate = CODE_DIR / f"{name}.py"
            if candidate.is_file() and candidate.resolve() not in discovered:
                discovered.add(candidate.resolve())
                queue.append(candidate.resolve())
    return discovered


def selected_tasks(
    manifest: dict[str, Any], mode: str
) -> list[dict[str, Any]]:
    return [task for task in manifest["tasks"] if mode in task["modes"]]


def task_claim_map(manifest: dict[str, Any]) -> dict[str, list[str]]:
    mapping = {task["id"]: [] for task in manifest["tasks"]}
    for claim in manifest["claims"]:
        for task_id in claim["task_ids"]:
            mapping[task_id].append(claim["id"])
    return mapping


def collect_sources(
    manifest_path: Path,
    tasks: list[dict[str, Any]],
) -> list[Path]:
    python_sources: set[Path] = {Path(__file__).resolve()}
    artifact_sources: set[Path] = {
        manifest_path.resolve(),
        (CODE_DIR / "requirements-publication.txt").resolve(),
    }
    for task in tasks:
        if task["kind"] == "python":
            python_sources.add(repository_path(task["script"]))
        else:
            for script in task["scripts"]:
                python_sources.add(repository_path(script))
            for output in task["outputs"]:
                artifact_sources.add(repository_path(output))
    return sorted(
        local_python_dependencies(python_sources) | artifact_sources,
        key=lambda path: str(path).lower(),
    )


def environment_report() -> dict[str, Any]:
    packages: dict[str, str | None] = {}
    for package in ("numpy", "python-flint"):
        try:
            packages[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            packages[package] = None
    flint_runtime: dict[str, Any] = {}
    try:
        import flint  # type: ignore

        flint_runtime["python_flint_version"] = getattr(
            flint, "__version__", None
        )
        flint_runtime["module_path"] = str(Path(flint.__file__).resolve())
    except Exception as error:  # pragma: no cover - recorded, then tasks fail
        flint_runtime["import_error"] = repr(error)
    return {
        "recorded_at_utc": utc_now(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "working_directory": str(REPOSITORY_ROOT),
        "packages": packages,
        "flint_runtime": flint_runtime,
    }


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)


def run_python_task(
    task: dict[str, Any],
    run_directory: Path,
) -> dict[str, Any]:
    task_id = task["id"]
    stdout_path = run_directory / f"{safe_name(task_id)}.stdout.txt"
    stderr_path = run_directory / f"{safe_name(task_id)}.stderr.txt"
    command = [
        sys.executable,
        str(repository_path(task["script"])),
        *[str(argument) for argument in task["args"]],
    ]
    started = time.monotonic()
    try:
        result = subprocess.run(
            command,
            cwd=REPOSITORY_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=task["timeout_seconds"],
            check=False,
        )
        stdout = result.stdout
        stderr = result.stderr
        exit_code = result.returncode
        status = "pass" if exit_code == 0 else "fail"
        error = None
    except subprocess.TimeoutExpired as timeout:
        stdout = timeout.stdout or ""
        stderr = timeout.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", errors="replace")
        exit_code = None
        status = "fail"
        error = f"timeout after {task['timeout_seconds']} seconds"
    duration = time.monotonic() - started
    stdout_path.write_text(stdout, encoding="utf-8")
    stderr_path.write_text(stderr, encoding="utf-8")

    parsed_json_path: str | None = None
    if status == "pass" and task.get("json_stdout"):
        json_source = stdout
        if task.get("json_from_first_object"):
            object_start = stdout.find("{")
            if object_start < 0:
                status = "fail"
                error = "stdout did not contain a JSON object"
                json_source = ""
            else:
                json_source = stdout[object_start:]
        try:
            parsed = json.loads(json_source)
        except json.JSONDecodeError as parse_error:
            status = "fail"
            error = f"stdout was not valid JSON: {parse_error}"
        else:
            json_path = run_directory / f"{safe_name(task_id)}.json"
            json_path.write_text(
                json.dumps(parsed, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            parsed_json_path = str(json_path.relative_to(run_directory))

    return {
        "id": task_id,
        "title": task["title"],
        "classification": task["classification"],
        "status": status,
        "command": command,
        "duration_seconds": round(duration, 6),
        "exit_code": exit_code,
        "error": error,
        "stdout": str(stdout_path.relative_to(run_directory)),
        "stderr": str(stderr_path.relative_to(run_directory)),
        "parsed_json": parsed_json_path,
    }


def run_figure_roundtrip(
    task: dict[str, Any],
    run_directory: Path,
) -> dict[str, Any]:
    task_id = task["id"]
    workspace = run_directory / f"{safe_name(task_id)}_workspace"
    copied_code = workspace / "code"
    copied_figures = workspace / "figures"
    copied_code.mkdir(parents=True)
    copied_figures.mkdir(parents=True)

    script_paths = [repository_path(script) for script in task["scripts"]]
    dependencies = local_python_dependencies(set(script_paths))
    for source in dependencies:
        shutil.copy2(source, copied_code / source.name)

    commands: list[list[str]] = []
    stdout_parts: list[str] = []
    stderr_parts: list[str] = []
    started = time.monotonic()
    status = "pass"
    error: str | None = None
    exit_code: int | None = 0
    deadline = started + task["timeout_seconds"]
    for script in script_paths:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            status = "fail"
            exit_code = None
            error = f"timeout after {task['timeout_seconds']} seconds"
            break
        copied_script = copied_code / script.name
        command = [sys.executable, str(copied_script)]
        commands.append(command)
        try:
            result = subprocess.run(
                command,
                cwd=workspace,
                env=os.environ.copy(),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=remaining,
                check=False,
            )
        except subprocess.TimeoutExpired as timeout:
            stdout_parts.append(str(timeout.stdout or ""))
            stderr_parts.append(str(timeout.stderr or ""))
            status = "fail"
            exit_code = None
            error = f"timeout after {task['timeout_seconds']} seconds"
            break
        stdout_parts.append(result.stdout)
        stderr_parts.append(result.stderr)
        exit_code = result.returncode
        if result.returncode != 0:
            status = "fail"
            error = f"figure generator exited with {result.returncode}"
            break

    comparisons: list[dict[str, Any]] = []
    if status == "pass":
        for relative in task["outputs"]:
            distributed = repository_path(relative)
            generated = workspace / relative
            byte_equal = generated.is_file() and (
                generated.read_bytes() == distributed.read_bytes()
            )
            normalized_equal = generated.is_file() and (
                normalized_text(generated) == normalized_text(distributed)
            )
            same = normalized_equal
            comparisons.append(
                {
                    "path": relative,
                    "status": "pass" if same else "fail",
                    "comparison": "exact_utf8_text_after_newline_normalization",
                    "byte_equal": byte_equal,
                    "normalized_equal": normalized_equal,
                    "distributed_sha256": sha256(distributed),
                    "generated_sha256": (
                        sha256(generated) if generated.is_file() else None
                    ),
                }
            )
            if not same:
                status = "fail"
                error = f"figure round-trip mismatch: {relative}"
                break

    duration = time.monotonic() - started
    stdout_path = run_directory / f"{safe_name(task_id)}.stdout.txt"
    stderr_path = run_directory / f"{safe_name(task_id)}.stderr.txt"
    comparison_path = run_directory / f"{safe_name(task_id)}.json"
    stdout_path.write_text("\n".join(stdout_parts), encoding="utf-8")
    stderr_path.write_text("\n".join(stderr_parts), encoding="utf-8")
    comparison_path.write_text(
        json.dumps(comparisons, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return {
        "id": task_id,
        "title": task["title"],
        "classification": task["classification"],
        "status": status,
        "command": commands,
        "duration_seconds": round(duration, 6),
        "exit_code": exit_code,
        "error": error,
        "stdout": str(stdout_path.relative_to(run_directory)),
        "stderr": str(stderr_path.relative_to(run_directory)),
        "parsed_json": str(comparison_path.relative_to(run_directory)),
        "comparisons": comparisons,
    }


def write_summary(
    summary: dict[str, Any],
    run_directory: Path,
) -> None:
    (run_directory / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    lines = [
        "Pre-emptive-bids reproduction summary",
        f"status: {summary['status']}",
        f"mode: {summary['mode']}",
        f"started: {summary['started_at_utc']}",
        f"finished: {summary['finished_at_utc']}",
        "",
        "Tasks:",
    ]
    for task in summary["tasks"]:
        lines.append(
            f"- {task['id']}: {task['status']} "
            f"[{task['classification']}] "
            f"({task['duration_seconds']:.3f}s)"
        )
        if task.get("error"):
            lines.append(f"  error: {task['error']}")
    lines.extend(["", "Claims:"])
    for claim in summary["claims"]:
        lines.append(
            f"- {claim['id']}: {claim['status']} "
            f"[{claim['classification']}]"
        )
    (run_directory / "summary.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def run_suite(
    manifest: dict[str, Any],
    manifest_path: Path,
    mode: str,
    results_base: Path,
    run_name: str | None,
) -> tuple[int, Path]:
    if run_name is None:
        run_name = datetime.now(timezone.utc).strftime("run-%Y%m%dT%H%M%SZ")
    run_name = safe_name(run_name)
    run_directory = results_base.resolve() / run_name
    if run_directory.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing result directory: {run_directory}"
        )
    run_directory.mkdir(parents=True)

    validation = validate_manifest(manifest)
    (run_directory / "manifest_validation.json").write_text(
        json.dumps(validation, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    shutil.copy2(manifest_path, run_directory / "claims.json")
    environment = environment_report()
    (run_directory / "environment.json").write_text(
        json.dumps(environment, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    tasks = selected_tasks(manifest, mode)
    sources = collect_sources(manifest_path, tasks)
    source_hashes = []
    for path in sources:
        try:
            relative = path.relative_to(REPOSITORY_ROOT)
            label = relative.as_posix()
        except ValueError:
            label = str(path)
        source_hashes.append({"path": label, "sha256": sha256(path)})
    (run_directory / "source_hashes.json").write_text(
        json.dumps(source_hashes, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    task_to_claims = task_claim_map(manifest)
    started_at = utc_now()
    task_results: list[dict[str, Any]] = []
    failed = False
    for task in tasks:
        print(f"[{task['classification']}] {task['title']}", flush=True)
        if task["kind"] == "python":
            result = run_python_task(task, run_directory)
        else:
            result = run_figure_roundtrip(task, run_directory)
        result["claim_ids"] = task_to_claims[task["id"]]
        task_results.append(result)
        print(f"  {result['status']}", flush=True)
        if result["status"] != "pass":
            failed = True
            break

    completed_ids = {result["id"] for result in task_results}
    result_by_id = {result["id"]: result for result in task_results}
    claim_results = []
    for claim in manifest["claims"]:
        relevant = [
            task_id
            for task_id in claim["task_ids"]
            if task_id in {task["id"] for task in tasks}
        ]
        if not relevant:
            status = "not_run"
        elif any(task_id not in completed_ids for task_id in relevant):
            status = "not_run"
        elif all(result_by_id[task_id]["status"] == "pass" for task_id in relevant):
            status = "pass"
        else:
            status = "fail"
        claim_results.append(
            {
                "id": claim["id"],
                "title": claim["title"],
                "classification": claim["classification"],
                "status": status,
                "task_ids": relevant,
                "fatal_to_working_paper": claim["fatal_to_working_paper"],
            }
        )

    summary = {
        "schema_version": 1,
        "status": "fail" if failed else "pass",
        "mode": mode,
        "started_at_utc": started_at,
        "finished_at_utc": utc_now(),
        "manifest": str(manifest_path.resolve()),
        "manifest_sha256": sha256(manifest_path),
        "results_directory": str(run_directory),
        "tasks": task_results,
        "claims": claim_results,
    }
    write_summary(summary, run_directory)
    return (1 if failed else 0), run_directory


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Validate and run the Python-only reproduction package. "
            "The core mode runs the maintained interval certificates, their "
            "registered floating-point cross-checks, the ban-welfare audit, "
            "and safe figure round-trip; publication mode runs every "
            "claim-bearing task in claims.json."
        )
    )
    parser.add_argument(
        "--mode",
        choices=sorted(ALLOWED_MODES),
        default="core",
        help="bounded core checks or the complete publication suite",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=DEFAULT_MANIFEST,
        help="claim manifest (default: code/claims.json)",
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=DEFAULT_RESULTS_BASE,
        help="base directory for a new, never-overwritten run directory",
    )
    parser.add_argument(
        "--run-name",
        help="optional unique child directory name; defaults to a UTC timestamp",
    )
    parser.add_argument(
        "--validate-manifest",
        action="store_true",
        help="validate claims and referenced files without running calculations",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="list tasks selected by --mode and exit",
    )
    return parser.parse_args()


def main() -> int:
    arguments = parse_arguments()
    manifest_path = arguments.manifest.resolve()
    manifest = load_manifest(manifest_path)
    try:
        validation = validate_manifest(manifest)
    except (ValueError, FileNotFoundError) as error:
        print(error, file=sys.stderr)
        return 2
    if arguments.validate_manifest:
        print(json.dumps(validation, indent=2, sort_keys=True))
        return 0
    tasks = selected_tasks(manifest, arguments.mode)
    if arguments.list:
        for task in tasks:
            print(
                f"{task['id']}\t{task['classification']}\t{task['title']}"
            )
        return 0
    try:
        exit_code, run_directory = run_suite(
            manifest,
            manifest_path,
            arguments.mode,
            arguments.results_dir,
            arguments.run_name,
        )
    except (FileExistsError, OSError, ValueError) as error:
        print(error, file=sys.stderr)
        return 2
    print(f"results: {run_directory}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
