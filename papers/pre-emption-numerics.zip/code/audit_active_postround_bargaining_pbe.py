"""Audit a pure active post-round bargaining PBE.

The environment and assessment are stated in
``notes/152-active-postround-bargaining-pbe.md``.  The script checks:

1. buyer response cutoffs after the pooled seller demand;
2. both seller types' low-clock pooling incentives against every initial
   price deviation;
3. the separating monopoly demands and endogenous seller clock cutoffs;
4. buyer clock incentives on an endpoint-inclusive grid;
5. seller recounter deviations after the active buyer proposal; and
6. the positive masses of active revision, agreement, and breakdown.

This is a dense numerical audit of an analytically specified raw PBE.  It is
not a refinement, interval-arithmetic certificate, or coupled early-offer
equilibrium.
"""

from __future__ import annotations

import json
import math


# Primitives and selected equilibrium prices.
THETA = 0.5
V_L = 0.2
V_H = 0.6
C_BUYER = 0.003
C_SELLER = 0.002
P = 0.5
R = 0.7
Y = 0.3
R_L = 0.6
R_H = 0.8
TAU = V_L
VALUE_MAX = 1.0
TOTAL_BIDDERS = 3

B_COUNTER = P + C_BUYER / (1.0 - THETA)
B_ACCEPT = (R - (1.0 - THETA) * P - C_BUYER) / THETA
UNUSED_DEMAND_CUTOFF = P + C_BUYER
TAIL_ACCEPT = TAU + C_BUYER


def seller_demand_payoff(v: float, demand: float, x: float) -> float:
    """Payoff from a direct accept-or-exit demand at clock price x."""
    if demand <= x:
        return demand - C_SELLER
    return (
        v
        + (demand - v) * (1.0 - demand) / (1.0 - x)
        - C_SELLER
    )


def clock_cutoff(v: float, demand: float) -> float:
    """Unique x below demand at which demanding and accepting x tie."""
    lo, hi = v, demand
    for _ in range(120):
        mid = 0.5 * (lo + hi)
        if seller_demand_payoff(v, demand, mid) > mid:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


CHI_L = clock_cutoff(V_L, R_L)
CHI_H = clock_cutoff(V_H, R_H)


def pooled_seller_payoff(v: float, x: float) -> float:
    """Seller payoff from R at an on-path low-clock history."""
    if math.isclose(v, V_L):
        numerator = (
            V_L * (B_COUNTER - x)
            + P * (B_ACCEPT - B_COUNTER)
            + R * (1.0 - B_ACCEPT)
        )
    else:
        numerator = V_H * (B_ACCEPT - x) + R * (1.0 - B_ACCEPT)
    return numerator / (1.0 - x) - C_SELLER


def low_clock_deviation_payoff(v: float, x: float, z: float) -> float:
    """Payoff from an unused initial seller demand at x<Y.

    The winner assigns probability one to L.  At z<=P+C_BUYER it accepts
    exactly when b>=z.  Above that cutoff every b>=P+C_BUYER counters at P;
    L accepts and H exits.
    """
    if z <= x:
        return z - C_SELLER
    if z <= UNUSED_DEMAND_CUTOFF:
        return (
            v * (z - x) + z * (1.0 - z)
        ) / (1.0 - x) - C_SELLER
    if math.isclose(v, V_L):
        return (
            V_L * (UNUSED_DEMAND_CUTOFF - x)
            + P * (1.0 - UNUSED_DEMAND_CUTOFF)
        ) / (1.0 - x) - C_SELLER
    return V_H - C_SELLER


def terminal_buyer_payoff(b: float, x: float) -> float:
    """Expected payoff from becoming provisional winner at standing x."""
    if x < Y:
        if b < B_COUNTER:
            return 0.0
        if b < B_ACCEPT:
            return (1.0 - THETA) * (b - P) - C_BUYER
        return b - R
    if x < CHI_L:
        if b < R_L:
            return 0.0
        if b < R_H:
            return (1.0 - THETA) * (b - R_L)
        return (1.0 - THETA) * (b - R_L) + THETA * (b - R_H)
    if x < CHI_H:
        if b < R_H:
            return (1.0 - THETA) * (b - x)
        return (1.0 - THETA) * (b - x) + THETA * (b - R_H)
    return b - x


def max_abs(items: list[float]) -> float:
    return max(abs(x) for x in items)


def main() -> None:
    grid_n = 1601
    price_n = 2001
    xs_low = [Y * i / (grid_n - 1) for i in range(grid_n)]
    prices = [VALUE_MAX * j / (price_n - 1) for j in range(price_n)]

    # Low-clock seller pooling, including all initial demand prices.
    low_state_margins: dict[str, float] = {}
    low_price_margins: dict[str, float] = {}
    for label, v in (("L", V_L), ("H", V_H)):
        outside_margins = []
        price_margins = []
        for x in xs_low:
            on_path = pooled_seller_payoff(v, x)
            outside_margins.append(on_path - max(v, x))
            best_deviation = max(
                low_clock_deviation_payoff(v, x, z)
                for z in prices
                if not math.isclose(z, R, abs_tol=1e-12)
            )
            price_margins.append(on_path - best_deviation)
        low_state_margins[label] = min(outside_margins)
        low_price_margins[label] = min(price_margins)

    # At x>=Y, each type's direct demand is its global price optimum while
    # countering, and accepting x is optimal above its endogenous cutoff.
    separating_price_margins: dict[str, float] = {}
    separating_accept_margins: dict[str, float] = {}
    separating_demand_outside_margins: dict[str, float] = {}
    for label, v, demand, chi in (
        ("L", V_L, R_L, CHI_L),
        ("H", V_H, R_H, CHI_H),
    ):
        price_margin = math.inf
        accept_margin = math.inf
        demand_outside_margin = math.inf
        for i in range(grid_n):
            x = Y + (1.0 - Y) * i / (grid_n - 1)
            demand_payoff = seller_demand_payoff(v, demand, x)
            best_price = max(seller_demand_payoff(v, z, x) for z in prices)
            # The dense grid contains the selected rational demands exactly.
            if x < chi - 1e-7:
                price_margin = min(price_margin, demand_payoff - best_price)
                demand_outside_margin = min(
                    demand_outside_margin, demand_payoff - max(v, x)
                )
            elif x > chi + 1e-7:
                accept_margin = min(accept_margin, x - max(v, best_price))
        separating_price_margins[label] = price_margin
        separating_accept_margins[label] = accept_margin
        separating_demand_outside_margins[label] = demand_outside_margin

    # Seller recounters after P.  At z<=TAIL_ACCEPT the buyer accepts; above
    # it the buyer counters at TAU.  L accepts TAU and H exits.
    recounter_best_l = max(
        (z - C_SELLER) if z <= TAIL_ACCEPT else (TAU - C_SELLER)
        for z in prices
    )
    recounter_best_h = max(
        (z - C_SELLER) if z <= TAIL_ACCEPT else (V_H - C_SELLER)
        for z in prices
    )
    recounter_margins = {
        "L_accept_P": P - recounter_best_l,
        "H_exit": V_H - recounter_best_h,
    }

    # The top-value completion deters every nonspecial buyer proposal.
    cheapest_top_completion_expenditure = (
        VALUE_MAX - C_SELLER + C_BUYER
    )
    top_completion_margin = (
        cheapest_top_completion_expenditure - VALUE_MAX
    )

    # Clock incentives: winning payoff must be weakly positive below b and
    # weakly negative above b.  Endpoint ties are allowed.
    clock_lower_min = math.inf
    clock_upper_max = -math.inf
    clock_grid = 1001
    for ib in range(clock_grid):
        b = ib / (clock_grid - 1)
        for ix in range(clock_grid):
            x = ix / (clock_grid - 1)
            payoff = terminal_buyer_payoff(b, x)
            if x < b - 1e-12:
                clock_lower_min = min(clock_lower_min, payoff)
            elif x > b + 1e-12:
                clock_upper_max = max(clock_upper_max, payoff)

    # Positive-probability active path under three iid U[0,1] bidders.
    low_clock_mass = (
        TOTAL_BIDDERS * Y ** (TOTAL_BIDDERS - 1)
        - (TOTAL_BIDDERS - 1) * Y ** TOTAL_BIDDERS
    )
    active_counter_mass = (
        TOTAL_BIDDERS
        * (B_ACCEPT - B_COUNTER)
        * Y ** (TOTAL_BIDDERS - 1)
    )
    direct_accept_mass = (
        TOTAL_BIDDERS
        * (1.0 - B_ACCEPT)
        * Y ** (TOTAL_BIDDERS - 1)
    )
    low_buyer_exit_mass = (
        low_clock_mass - active_counter_mass - direct_accept_mass
    )

    output = {
        "status": "raw-pbe-dense-audit-not-refinement",
        "primitives": {
            "seller_prior_H": THETA,
            "fallback_values": [V_L, V_H],
            "proposal_costs": {
                "buyer": C_BUYER,
                "seller": C_SELLER,
            },
            "total_bidders": TOTAL_BIDDERS,
            "values": "iid U[0,1]",
        },
        "selected_prices": {
            "low_clock_pool_demand_R": R,
            "active_buyer_counter_P": P,
            "clock_regime_switch_y": Y,
            "separating_demands": [R_L, R_H],
        },
        "buyer_cutoffs_after_R": {
            "exit_to_counter": B_COUNTER,
            "counter_to_accept": B_ACCEPT,
        },
        "buyer_cutoff_after_unused_low_clock_demand": UNUSED_DEMAND_CUTOFF,
        "seller_clock_cutoffs": {
            "L": CHI_L,
            "H": CHI_H,
        },
        "low_clock_min_margins": {
            "pool_over_outside": low_state_margins,
            "pool_over_all_unused_prices": low_price_margins,
        },
        "separating_region_checks": {
            "selected_demand_minus_dense_price_max": separating_price_margins,
            "demand_over_outside_away_from_cutoffs": (
                separating_demand_outside_margins
            ),
            "accept_x_over_all_demands_away_from_cutoffs": (
                separating_accept_margins
            ),
        },
        "post_P_recounter_margins": recounter_margins,
        "top_completion": {
            "cheapest_effective_expenditure": cheapest_top_completion_expenditure,
            "margin_above_value_support": top_completion_margin,
            "history_rule": (
                "P is special only as the first buyer response to R or to an "
                "unused low-clock initial demand; the same numeric P after a "
                "later/top-completion history is nonspecial"
            ),
        },
        "truthful_clock_sign_check": {
            "minimum_payoff_when_x_below_b": clock_lower_min,
            "maximum_payoff_when_x_above_b": clock_upper_max,
            "max_absolute_violation": max(
                max(0.0, -clock_lower_min),
                max(0.0, clock_upper_max),
            ),
        },
        "positive_probability_low_clock_outcomes": {
            "low_clock_history": low_clock_mass,
            "active_buyer_counter": active_counter_mass,
            "counter_then_L_sale": (1.0 - THETA) * active_counter_mass,
            "counter_then_H_breakdown": THETA * active_counter_mass,
            "accept_R": direct_accept_mass,
            "exit_after_R": low_buyer_exit_mass,
        },
        "classification": {
            "isolated_bidding_plus_postround_game": "raw pure PBE",
            "active_counter_on_path": True,
            "early_preemption_coupling": False,
            "interim_D1": "not established",
            "global_or_unique": False,
        },
    }

    assert Y < B_COUNTER < B_ACCEPT < 1.0
    assert P < UNUSED_DEMAND_CUTOFF < B_COUNTER
    assert Y < CHI_L < R_L < CHI_H < R_H
    assert all(value > 1e-5 for value in low_state_margins.values())
    assert all(value > 1e-5 for value in low_price_margins.values())
    assert all(value >= -2e-7 for value in separating_price_margins.values())
    assert all(
        value > 0.0 for value in separating_demand_outside_margins.values()
    )
    assert all(value > 0.0 for value in separating_accept_margins.values())
    assert min(recounter_margins.values()) > 1e-3
    assert top_completion_margin > 0.0
    assert clock_lower_min >= -1e-12
    assert clock_upper_max <= 1e-12
    assert active_counter_mass > 0.0
    assert (1.0 - THETA) * active_counter_mass > 0.0
    assert THETA * active_counter_mass > 0.0

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
