"""Rigorous Arb certificate for the eta=1 terminal-counteroffer equilibrium.

Requires python-flint==0.9.0.  Arb supplies outward-rounded real/complex ball
arithmetic and validated adaptive integration.  The script certifies:

1. a unique root of the three perfect-recall probing equations in the stated
   small box, via the Krawczyk operator;
2. global optimality of both action-selected terminal reserves;
3. the strict on-path PBE margins; and
4. the strict numerical endpoint inequalities used by the analytical
   interim-D1 proof in Note 143, including the complete high-price
   one-counteroffer bound.

It does not search globally, certify a full menu, vary eta, or allow buyer
revision or repeated terminal bargaining.
"""

import flint
from flint import arb, acb, arb_mat, ctx

ctx.dps = 60

V = arb("2/5")
K = arb("1/100")
DB = arb("3/20")
DS = arb("1/100")
LAM = arb(10)
E_DB = (-LAM * DB).exp()
DEN = 1 - E_DB


class AD:
    __slots__ = ("v", "g")

    def __init__(self, v, g=None):
        self.v = v if isinstance(v, acb) else acb(v)
        self.g = [acb(0), acb(0), acb(0)] if g is None else g

    def __add__(self, other):
        other = asad(other)
        return AD(self.v + other.v, [a + b for a, b in zip(self.g, other.g)])

    __radd__ = __add__

    def __neg__(self):
        return AD(-self.v, [-a for a in self.g])

    def __sub__(self, other):
        return self + (-asad(other))

    def __rsub__(self, other):
        return asad(other) - self

    def __mul__(self, other):
        other = asad(other)
        return AD(
            self.v * other.v,
            [a * other.v + self.v * b for a, b in zip(self.g, other.g)],
        )

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = asad(other)
        return AD(
            self.v / other.v,
            [
                (a * other.v - self.v * b) / (other.v * other.v)
                for a, b in zip(self.g, other.g)
            ],
        )

    def __rtruediv__(self, other):
        return asad(other) / self

    def __pow__(self, n):
        if n == 0:
            return AD(1)
        return AD(self.v**n, [n * self.v ** (n - 1) * a for a in self.g])

    def exp(self):
        ev = self.v.exp()
        return AD(ev, [ev * a for a in self.g])


def asad(x):
    return x if isinstance(x, AD) else AD(x)


def var(x, j):
    g = [acb(0), acb(0), acb(0)]
    g[j] = acb(1)
    return AD(acb(x), g)


def aprob(b, q, rp, rw, piece):
    if piece == 1:
        d = q + 2 * K - b
    elif piece == 2:
        d = q + 2 * K - b + (b**3 - rw**3) / 3 + (b**4 - rw**4) / 4
    elif piece == 3:
        d = q + 2 * K - b + (b**3 - rw**3) / 3 + (rp**4 - rw**4) / 4
    else:
        raise ValueError(piece)
    return ((-LAM * d).exp() - E_DB) / DEN


def cl(b, rp, piece):
    if piece == 1:
        return AD(arb("69/125"))  # 0.562 gross minus 0.01
    if piece == 2:
        return AD(arb(1) / 3) + arb("7/5") * b**2 - arb(4) / 3 * b**3 - DS
    if piece == 3:
        return (
            AD(arb(1) / 3)
            + b**2
            - arb(2) / 3 * b**3
            + rp**3 / 3
            - DS
        )
    raise ValueError(piece)


def integrate_ad(fun, lo, hi, tol="1e-45"):
    length = hi - lo

    def evaluated(t):
        return length * fun(lo + length * AD(t))

    out = []
    atol = arb(tol)
    for j in range(4):
        def component(t, analytic, j=j):
            value = evaluated(t)
            return value.v if j == 0 else value.g[j - 1]

        out.append(
            acb.integral(
                component,
                0,
                1,
                abs_tol=atol,
                rel_tol=atol,
                deg_limit=20,
                eval_limit=100000,
                depth_limit=40,
                use_heap=True,
            )
        )
    return AD(out[0], out[1:])


def residual_ad(x):
    q, rp, rw = [var(x[j], j) for j in range(3)]
    b0 = q + 2 * K - DB
    seven = AD(arb("7/10"))
    one = AD(1)

    f1 = AD(0)
    f1 += integrate_ad(lambda b: aprob(b, q, rp, rw, 1) * (cl(b, rp, 1) - q), b0, rw)
    f1 += integrate_ad(lambda b: aprob(b, q, rp, rw, 2) * (cl(b, rp, 1) - q), rw, seven)
    f1 += integrate_ad(lambda b: aprob(b, q, rp, rw, 2) * (cl(b, rp, 2) - q), seven, rp)
    f1 += integrate_ad(lambda b: aprob(b, q, rp, rw, 3) * (cl(b, rp, 3) - q), rp, one)

    tailp = integrate_ad(lambda b: aprob(b, q, rp, rw, 3), rp, one)
    f2 = tailp - (rp - V) * aprob(rp, q, rp, rw, 3)

    tailw = integrate_ad(lambda b: 1 - aprob(b, q, rp, rw, 2), rw, rp)
    tailw += integrate_ad(lambda b: 1 - aprob(b, q, rp, rw, 3), rp, one)
    f3 = tailw - (rw - V) * (1 - aprob(rw, q, rp, rw, 2))
    return [f1, f2, f3]


def values_and_jac(x):
    f = residual_ad(x)
    vals = [z.v.real for z in f]
    jac = arb_mat(3, 3, [f[i].g[j].real for i in range(3) for j in range(3)])
    return vals, jac


ROOT_CENTER = (
    "0.7384064140054715464089558002230825229715598993286023699",
    "0.7809572231735911264888021089532064181157569362323653136",
    "0.6611403199398241446785275256971964601549936252272973861",
)
ROOT_RADIUS = arb("1e-10")


def certify_root():
    x0 = [arb(value).mid() for value in ROOT_CENTER]
    box = [arb(x0[i], ROOT_RADIUS) for i in range(3)]
    f0, j0 = values_and_jac(x0)
    _, j_box = values_and_jac(box)
    Rball = j0.inv()
    R = arb_mat(3, 3, [Rball[i, j].mid() for i in range(3) for j in range(3)])
    R.inv()  # The exact dyadic preconditioner is nonsingular.
    I = arb_mat(3, 3, [1 if i == j else 0 for i in range(3) for j in range(3)])
    Fvec = arb_mat(3, 1, f0)
    Dvec = arb_mat(3, 1, [box[i] - x0[i] for i in range(3)])
    base = arb_mat(3, 1, x0) - R * Fvec
    krawczyk = base + (I - R * j_box) * Dvec
    if not all(
        box[i].contains_interior(krawczyk[i, 0]) for i in range(3)
    ):
        raise AssertionError(("Krawczyk inclusion", box, krawczyk))
    return {
        "box": box,
        "krawczyk": [krawczyk[i, 0] for i in range(3)],
        "center_residual": f0,
        "jacobian_box": j_box,
    }


def aprob_real(b, q, rp, rw, piece):
    if piece == 1:
        d = q + 2 * K - b
        dp = -1
    elif piece == 2:
        d = q + 2 * K - b + (b**3 - rw**3) / 3 + (b**4 - rw**4) / 4
        dp = -1 + b**2 + b**3
    elif piece == 3:
        d = q + 2 * K - b + (b**3 - rw**3) / 3 + (rp**4 - rw**4) / 4
        dp = -1 + b**2
    else:
        raise ValueError(piece)
    e = (-LAM * d).exp()
    a = (e - E_DB) / DEN
    ap = -LAM * dp * e / DEN
    return a, ap, d


def cells(lo, hi, n):
    step = (hi - lo) / n
    for k in range(n):
        left = lo + k * step
        right = lo + (k + 1) * step
        yield left.union(right)


def certify_revenue_derivatives(X):
    q, rp, rw = X
    b0 = q + 2 * K - DB
    start_pad = arb("1e-9")
    intervals = [
        (b0.upper() + start_pad, rw.lower(), 1),
        (rw.lower(), rw.upper(), 1),
        (rw.lower(), rw.upper(), 2),
        (rw.upper(), rp.lower(), 2),
        (rp.lower(), rp.upper(), 2),
        (rp.lower(), rp.upper(), 3),
        (rp.upper(), arb(1), 3),
    ]
    # On the thin uncertain start band, use y=b-b0 to retain the exact
    # relation d=DB-y rather than losing it to interval dependency.
    y = arb(0).union(b0.upper() - b0.lower() + start_pad)
    b_start = b0 + y
    e_start = (-LAM * (DB - y)).exp()
    a_start = (e_start - E_DB) / DEN
    ap_start = LAM * e_start / DEN
    hp_start = -2 * a_start - (b_start - V) * ap_start
    hw_start = -2 * (1 - a_start) + (b_start - V) * ap_start
    if not hp_start < 0 or not hw_start < 0:
        raise AssertionError(("start derivative", hp_start, hw_start))
    worst_p_upper = hp_start.upper()
    worst_w_upper = hw_start.upper()
    a_start_upper = ((-LAM * (DB - y.upper())).exp() - E_DB) / DEN
    if not a_start_upper > 0 or not a_start_upper < 1:
        raise AssertionError(("start probability", a_start_upper))
    for lo, hi, piece in intervals:
        for b in cells(lo, hi, 120):
            a, ap, d = aprob_real(b, q, rp, rw, piece)
            hp = -2 * a - (b - V) * ap
            hw = -2 * (1 - a) + (b - V) * ap
            if not hp < 0:
                raise AssertionError(("probe derivative", piece, b, hp))
            if not hw < 0:
                raise AssertionError(("wait derivative", piece, b, hw))
            if not d > 0 or not d <= DB:
                raise AssertionError(("cutoff support", piece, b, d))
            if not a >= 0 or not a <= 1:
                raise AssertionError(("probability", piece, b, a))
            if hp.upper() > worst_p_upper:
                worst_p_upper = hp.upper()
            if hw.upper() > worst_w_upper:
                worst_w_upper = hw.upper()
    order = [
        V < b0,
        b0 < rw,
        rw < arb("7/10"),
        arb("7/10") < rp,
        rp < 1,
    ]
    if not all(order):
        raise AssertionError(("ordering", b0, rw, rp, order))
    return {
        "active_start": b0,
        "probe_revenue_second_derivative_upper": worst_p_upper,
        "wait_revenue_second_derivative_upper": worst_w_upper,
    }


def integrate_real(fun, lo, hi, tol="1e-40"):
    length = hi - lo
    result = acb.integral(
        lambda t, analytic: acb(length) * fun(acb(lo) + acb(length) * t),
        0,
        1,
        abs_tol=arb(tol),
        rel_tol=arb(tol),
        deg_limit=20,
        eval_limit=100000,
        depth_limit=40,
        use_heap=True,
    )
    if not result.imag.contains(0):
        raise AssertionError(("imaginary integral", result))
    return result.real


def aprob_scalar(b, q, rp, rw, piece):
    q = acb(q); rp = acb(rp); rw = acb(rw)
    if piece == 1:
        d = q + 2 * acb(K) - b
    elif piece == 2:
        d = q + 2 * acb(K) - b + (b**3 - rw**3) / 3 + (b**4 - rw**4) / 4
    elif piece == 3:
        d = q + 2 * acb(K) - b + (b**3 - rw**3) / 3 + (rp**4 - rw**4) / 4
    else:
        raise ValueError(piece)
    return ((-acb(LAM) * d).exp() - acb(E_DB)) / acb(DEN)


def seller_h_net(b, rp, piece):
    rp = acb(rp)
    if piece == 1:
        return acb(arb("12201/20000"))
    if piece == 2:
        return acb(arb("49/100")) + acb(arb("7/5")) * b**3 - acb(arb("3/2")) * b**4
    if piece == 3:
        return acb(arb("49/100")) + b**3 - acb(arb("3/4")) * b**4 + rp**4 / 4
    raise ValueError(piece)


def pbe_quantities(X):
    q, rp, rw = X
    b0 = q + 2 * K - DB
    mass = integrate_real(lambda b: aprob_scalar(b, q, rp, rw, 1), b0, rw)
    mass += integrate_real(lambda b: aprob_scalar(b, q, rp, rw, 2), rw, rp)
    mass += integrate_real(lambda b: aprob_scalar(b, q, rp, rw, 3), rp, arb(1))

    hn = integrate_real(
        lambda b: aprob_scalar(b, q, rp, rw, 1) * (seller_h_net(b, rp, 1) - acb(q)),
        b0,
        rw,
    )
    hn += integrate_real(
        lambda b: aprob_scalar(b, q, rp, rw, 2) * (seller_h_net(b, rp, 1) - acb(q)),
        rw,
        arb("7/10"),
    )
    hn += integrate_real(
        lambda b: aprob_scalar(b, q, rp, rw, 2) * (seller_h_net(b, rp, 2) - acb(q)),
        arb("7/10"),
        rp,
    )
    hn += integrate_real(
        lambda b: aprob_scalar(b, q, rp, rw, 3) * (seller_h_net(b, rp, 3) - acb(q)),
        rp,
        arb(1),
    )
    h_slack = hn / mass
    if not mass > 0 or not mass < 1 or not h_slack > 0:
        raise AssertionError(("pbe quantities", mass, h_slack))

    d1 = (
        q + 2 * K - 1 + (1 - rw**3) / 3 + (rp**4 - rw**4) / 4
    )
    if not d1 > 0 or not d1 < DB:
        raise AssertionError(("top cutoff", d1))
    s2w = (1 - rw**3) / 3
    s3w = (1 - rw**4) / 4
    s3p = (1 - rp**4) / 4
    uw = (s2w + s3w) / 2 - DB
    up = (1 - q) / 2 + (s3p - DB) / 2 - K
    if not uw > 0 or not up > uw:
        raise AssertionError(("top payoff branch", uw, up))
    pdag = 1 - K - up
    return {
        "mass": mass,
        "h_slack": h_slack,
        "D1": d1,
        "uw_top": uw,
        "up_top": up,
        "pdag": pdag,
    }


RHO = arb("7/10")


def second_late(n, t):
    return (
        n * (1 - t) * t**n
        + (n - 1) * (1 - t**n)
        - arb(n * (n - 1)) / (n + 1) * (1 - t ** (n + 1))
    )


def seller_gross_above(n, b, r, below_rho):
    b = acb(b); r = acb(r)
    early = acb(n) / (n + 1) * b ** (n + 1) + r ** (n + 1) / (n + 1)
    if below_rho:
        late = acb(V) * (acb(RHO) ** n - b**n) + acb(second_late(n, RHO))
    else:
        late = (
            acb(n) * (1 - b) * b**n
            + acb(n - 1) * (1 - b**n)
            - acb(arb(n * (n - 1)) / (n + 1)) * (1 - b ** (n + 1))
        )
    return early + late


def er_continuation_point(n, r):
    def split_integral(fun, lo, hi, parts=16):
        total = arb(0)
        step = (hi - lo) / parts
        for j in range(parts):
            total += integrate_real(fun, lo + j * step, lo + (j + 1) * step)
        return total

    if r < RHO:
        integral = split_integral(
            lambda b: seller_gross_above(n, b, r, True)
            * acb(r - V)
            / (b - acb(V)) ** 2,
            r,
            RHO,
        )
        integral += split_integral(
            lambda b: seller_gross_above(n, b, r, False)
            * acb(r - V)
            / (b - acb(V)) ** 2,
            RHO,
            arb(1),
        )
    elif r > RHO:
        integral = split_integral(
            lambda b: seller_gross_above(n, b, r, False)
            * acb(r - V)
            / (b - acb(V)) ** 2,
            r,
            arb(1),
        )
    else:
        raise AssertionError(("reserve overlaps rho", r))
    atom = (r - V) / (1 - V)
    top = seller_gross_above(n, acb(1), r, False).real
    return integral + atom * top - DS


def er_continuation(n, r):
    """Envelope with a rigorous local Lipschitz enlargement.

    For r in [.6,.9], direct differentiation of (15) gives |K'(r)|<20:
    0<=R<=1, 0<=R_r=r^n<=1, r-v>=.2, and 1-v=.6.
    """
    if not r > arb("3/5") or not r < arb("9/10"):
        raise AssertionError(("ER Lipschitz domain", r))
    point = er_continuation_point(n, r.mid())
    return arb(point.mid(), point.rad() + 20 * r.rad())


def point_continuation(n, b, r):
    if b < RHO:
        return seller_gross_above(n, acb(b), r, True).real - DS
    if b > RHO:
        return seller_gross_above(n, acb(b), r, False).real - DS
    raise AssertionError(("point overlaps rho", b))


def r0_residual(r0, rw):
    return (rw**3 - r0**3) / 6 + (rw**4 - r0**4) / 8 - K


def enclose_r0(rw):
    candidate = arb("0.63209954945", "2e-9")
    if not r0_residual(candidate.lower(), rw) > 0:
        raise AssertionError(("r0 lower", candidate, r0_residual(candidate.lower(), rw)))
    if not r0_residual(candidate.upper(), rw) < 0:
        raise AssertionError(("r0 upper", candidate, r0_residual(candidate.upper(), rw)))
    return candidate


def w_top(n, r):
    return 1 - (1 - r ** (n + 1)) / (n + 1)


def x_marginal(p, r, q, rp, rw):
    dl = w_top(2, rw) - w_top(2, r)
    dh = w_top(3, rw) - w_top(3, r)
    dp = w_top(3, rp) - w_top(3, rw)
    constant = -K + (dl + dh) / 2
    slope = (q - p) / 2 + K - dl / 2 + dp / 2
    return -constant / slope


def xi_value(r, x, rp, rw):
    dl = w_top(2, rw) - w_top(2, r)
    dh = w_top(3, rw) - w_top(3, r)
    dp = w_top(3, rp) - w_top(3, rw)
    return (1 - x) * dl / 2 + dh / 2 + x * dp / 2


def x_top(p, r, q, rp):
    sr = (1 - r**4) / 4
    sp = (1 - rp**4) / 4
    constant = (q - p) / 2 + sr / 2 - sp / 2
    slope = (1 - p + DB - sr) / 2
    return -constant / slope


def d1_endpoint_quantities(X, pbe):
    q, rp, rw = X
    r0 = enclose_r0(rw)
    p0 = point_continuation(2, r0, r0)
    h0 = point_continuation(3, r0, r0)
    pbar = er_continuation(2, rw)
    khwait = er_continuation(3, rw)
    r678 = arb("339/500")
    kl678 = er_continuation(2, r678)
    kh678 = er_continuation(3, r678)
    khprobe = er_continuation(3, rp)
    r85 = arb("17/20")
    kh85 = er_continuation(3, r85)
    pdag = pbe["pdag"]

    strict = [
        p0 < h0,
        p0 < pbar,
        pbar < q,
        q < kl678,
        arb("4/5") < khprobe,
        pdag < kh85,
    ]
    if not all(strict):
        raise AssertionError(
            ("D1 ordering", strict, p0, h0, pbar, q, kl678, khprobe, pdag, kh85)
        )

    x_rw_lo = x_marginal(p0, rw, q, rp, rw)
    x_rw_hi = x_marginal(pbar, rw, q, rp, rw)
    x_678_lo = x_marginal(pbar, r678, q, rp, rw)
    x_678_hi = x_marginal(q, r678, q, rp, rw)
    xis = [xi_value(r678, x_678_lo, rp, rw), xi_value(r678, x_678_hi, rp, rw)]
    for name, value in (
        ("x_rw_lo", x_rw_lo),
        ("x_rw_hi", x_rw_hi),
        ("x_678_lo", x_678_lo),
        ("x_678_hi", x_678_hi),
    ):
        if not value > 0 or not value < 1:
            raise AssertionError((name, value))
    if not all(x > 0 for x in xis):
        raise AssertionError(("xi", xis))

    x80 = x_top(arb("4/5"), r85, q, rp)
    xdag = x_top(pdag, r85, q, rp)
    if not x80 > 0 or not x80 < 1 or not xdag.contains(1):
        raise AssertionError(("upper x", x80, xdag))
    bc80 = x80.root(3)
    if not bc80 < rp:
        raise AssertionError(("lower local point", bc80, rp))
    local80 = (q - arb("4/5")) / 2 + x80 * (rp - arb("4/5") + DB) / 2
    if not local80 < 0:
        raise AssertionError(("local competitor", local80))
    monotone_sign = r85 - 1 + (1 - r85**4) / 4
    if not monotone_sign < 0:
        raise AssertionError(("upper monotonicity", monotone_sign))

    return {
        "r0": r0,
        "p0": p0,
        "h0": h0,
        "pbar": pbar,
        "kl678": kl678,
        "khprobe": khprobe,
        "kh85": kh85,
        "local80": local80,
        "xi_min": xis[0] if xis[0] < xis[1] else xis[1],
        "x80": x80,
        "xdag": xdag,
    }


def surplus_iv(n, b, r):
    if b < r:
        return arb(0)
    formula = (b ** (n + 1) - r ** (n + 1)) / (n + 1)
    if b > r:
        return formula
    return arb(0).union(formula)


def cutoff_iv(b, q, rp, rw, pieces):
    vals = []
    for piece in pieces:
        if piece == 1:
            d = q + 2 * K - b
        elif piece == 2:
            d = q + 2 * K - b + (b**3 - rw**3) / 3 + (b**4 - rw**4) / 4
        elif piece == 3:
            d = q + 2 * K - b + (b**3 - rw**3) / 3 + (rp**4 - rw**4) / 4
        else:
            raise ValueError(piece)
        vals.append(d)
    out = vals[0]
    for value in vals[1:]:
        out = out.union(value)
    return out


def equilibrium_wait(b, d, rw):
    return (surplus_iv(2, b, rw) + surplus_iv(3, b, rw)) / 2 - d


def equilibrium_probe(b, d, q, rp):
    return (b - q) / 2 + (surplus_iv(3, b, rp) - d) / 2 - K


def deviation_payoff(b, d, p, r, a_l, a_h):
    return (
        (
            a_l * (b - p)
            + (1 - a_l) * (surplus_iv(2, b, r) - d)
        )
        / 2
        + (
            a_h * (b - p)
            + (1 - a_h) * (surplus_iv(3, b, r) - d)
        )
        / 2
        - K
    )


def max_upper(current, value):
    upper = value.upper()
    if current is None or upper > current:
        return upper
    return current


def audit_corner_gain(q, rp, rw, p, r, a_l, a_h):
    b0 = q + 2 * K - DB
    segments = [
        (arb(0), b0.lower(), (1,), "wait"),
        (b0.lower(), b0.upper(), (1,), "both"),
        (b0.upper(), rw.lower(), (1,), "probe"),
        (rw.lower(), rw.upper(), (1, 2), "probe"),
        (rw.upper(), rp.lower(), (2,), "probe"),
        (rp.lower(), rp.upper(), (2, 3), "probe"),
        (rp.upper(), arb(1), (3,), "probe"),
    ]
    largest = None
    for lo, hi, pieces, mode in segments:
        for b in cells(lo, hi, 160):
            # d=0 is in the waiting region because D(b)>0 everywhere.
            dev0 = deviation_payoff(b, arb(0), p, r, a_l, a_h)
            largest = max_upper(largest, dev0 - equilibrium_wait(b, arb(0), rw))

            devbar = deviation_payoff(b, DB, p, r, a_l, a_h)
            if mode in ("wait", "both"):
                largest = max_upper(largest, devbar - equilibrium_wait(b, DB, rw))
            if mode in ("probe", "both"):
                largest = max_upper(largest, devbar - equilibrium_probe(b, DB, q, rp))

            if mode != "wait":
                dcut = cutoff_iv(b, q, rp, rw, pieces)
                devcut = deviation_payoff(b, dcut, p, r, a_l, a_h)
                largest = max_upper(
                    largest,
                    devcut - equilibrium_wait(b, dcut, rw),
                )
    return largest


def high_price_corners(X, pbe):
    q, rp, rw = X
    pdag = pbe["pdag"]
    lam_l = arb("281/500")
    lam_h = arb("12401/20000")
    r_l = pdag - lam_l + V + DS
    r_h = pdag - lam_h + V + DS
    if not V < r_h or not r_h < r_l or not r_l < 1:
        raise AssertionError(("reserve floors", r_l, r_h))

    l_accept = audit_corner_gain(q, rp, rw, pdag, r_h, 1, 0)
    h_accept = audit_corner_gain(q, rp, rw, pdag, r_l, 0, 1)
    both_reject = audit_corner_gain(q, rp, rw, pdag, r_l, 0, 0)
    if not l_accept < arb("-0.03"):
        raise AssertionError(("L accepts corner", l_accept))
    if not h_accept < arb("-0.03"):
        raise AssertionError(("H accepts corner", h_accept))
    if not both_reject < arb("-0.005"):
        raise AssertionError(("both reject corner", both_reject))

    # Full acceptance is maximized at (b,d)=(1,DB): gain rises with urgency,
    # and its b derivative is 1-(b^2+b^3)/2>=0 while waiting and
    # (1-b^3)/2>=0 while probing.  Its gain is zero by pdag's definition.
    both_accept = 1 - pdag - K - pbe["up_top"]
    if not both_accept.contains(0):
        raise AssertionError(("both accept identity", both_accept))
    return {
        "r_l": r_l,
        "r_h": r_h,
        "both_accept": both_accept,
        "l_accept": l_accept,
        "h_accept": h_accept,
        "both_reject": both_reject,
    }


def main():
    root = certify_root()
    box = root["box"]
    revenue = certify_revenue_derivatives(box)
    pbe = pbe_quantities(box)
    d1 = d1_endpoint_quantities(box, pbe)
    corners = high_price_corners(box, pbe)

    print("full-linkage Arb existence and interim-D1 certificate: PASS")
    print("python-flint", flint.__version__, "precision", ctx.dps, "digits")
    print("root box q,r_probe,r_wait")
    for value in box:
        print(" ", value.str(28))
    print("Krawczyk image")
    for value in root["krawczyk"]:
        print(" ", value.str(28))
    print(
        "active revenue-curvature upper bounds",
        revenue["probe_revenue_second_derivative_upper"].str(16),
        revenue["wait_revenue_second_derivative_upper"].str(16),
    )
    print("probe mass", pbe["mass"].str(18))
    print(
        "outcomes no-offer,rejection,success",
        (1 - pbe["mass"]).str(18),
        (pbe["mass"] / 2).str(18),
        (pbe["mass"] / 2).str(18),
    )
    print("H rejection slack", pbe["h_slack"].str(18))
    print("top cutoff", pbe["D1"].str(18))
    print("p_dagger", pbe["pdag"].str(18))
    print(
        "top-belief rejected/accepted deviation upper bounds",
        (-K).str(16),
        (-pbe["up_top"]).str(16),
    )
    print(
        "D1 endpoint margins q-pbar, K_L(.678)-q, xi, "
        "K_H(.85)-pdag, local-upper",
        (box[0] - d1["pbar"]).str(16),
        (d1["kl678"] - box[0]).str(16),
        d1["xi_min"].str(16),
        (d1["kh85"] - pbe["pdag"]).str(16),
        d1["local80"].str(16),
    )
    print(
        "unrestricted high-price corner upper bounds both,L,H,reject",
        corners["both_accept"].str(16),
        corners["l_accept"].str(16),
        corners["h_accept"].str(16),
        corners["both_reject"].str(16),
    )


if __name__ == "__main__":
    main()
