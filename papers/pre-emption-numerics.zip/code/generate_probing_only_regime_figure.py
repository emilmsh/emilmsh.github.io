"""Generate the aligned-composite probing-only theorem figure and its data.

The numerical inputs are re-derived from
``audit_aligned_composite_calibration.py``.  Running this file rewrites only
the probing-regime figure, its two CSV inputs, and the probing entry in the
shared theory-figure metadata file.  The figure deliberately stops at the
boundary of the sufficient probing-only theorem; it is not a numerical phase
map beyond that boundary.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from audit_aligned_composite_calibration import (
    PI,
    OfferPrimitives,
    StatePrimitives,
    solve_probe,
)


ROOT = Path(__file__).resolve().parents[1]
FIGURE_DIR = ROOT / "figures"
DISPLAY_CAP = 0.11
DISPLAY_WIDTH = 14.4

STATE = StatePrimitives(
    n_l=2,
    n_h=3,
    v_l=0.38,
    v_h=0.42,
    d_s_l=0.02,
    d_s_h=0.0,
)
OFFER = OfferPrimitives(kappa=0.02, d_bar=0.045, urgency_rate=10.0)
EXPECTED_THRESHOLDS = (
    0.02,
    0.056410953333333,
    0.036410953333333,
    0.092821906666667,
)


def probing_payload() -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[str, Any],
    str,
]:
    """Return regime rows, outcome rows, metadata, and rendered TikZ."""

    probing = solve_probe(STATE, OFFER)
    bar_d_l, bar_d_h, delta_d, probing_upper = probing.theorem_thresholds
    bar_d_l_output = round(bar_d_l, 12)
    probing_upper_output = round(probing_upper, 12)
    for label, value, expected in zip(
        ("bar_D_L", "bar_D_H", "Delta_D", "probing_upper"),
        probing.theorem_thresholds,
        EXPECTED_THRESHOLDS,
    ):
        if abs(value - expected) > 5e-12:
            raise AssertionError(
                f"Aligned-composite theorem threshold changed at {label}: "
                f"{value:.12g}"
            )
    if not bar_d_l < OFFER.d_bar <= probing_upper:
        raise AssertionError("The example left the certified probing window.")

    no_offer, rejected, successful = probing.outcomes
    if abs(no_offer + rejected + successful - 1.0) > 2e-12:
        raise AssertionError("The probing outcomes do not sum to one.")

    regions = [
        {
            "region": "no_early_offer_pbe_exists",
            "start": 0.0,
            "end": bar_d_l_output,
            "start_closed": 1,
            "end_closed": 1,
            "continues_right": 0,
        },
        {
            "region": "probing_only_pbe_certified_no_early_offer_impossible",
            "start": bar_d_l_output,
            "end": probing_upper_output,
            "start_closed": 0,
            "end_closed": 1,
            "continues_right": 0,
        },
        {
            "region": "not_classified_by_proposition",
            "start": probing_upper_output,
            "end": DISPLAY_CAP,
            "start_closed": 0,
            "end_closed": 0,
            "continues_right": 1,
        },
    ]
    outcomes = [
        {"outcome": "no_early_offer", "probability": no_offer},
        {"outcome": "rejected_attempt", "probability": rejected},
        {"outcome": "successful_preemption", "probability": successful},
    ]
    metadata: dict[str, Any] = {
        "source": "code/audit_aligned_composite_calibration.py",
        "calibration": {
            "state_interpretation": "aligned_composite_continuation_state",
            "value_distribution": "U[0,1]",
            "n_L": STATE.n_l,
            "n_H": STATE.n_h,
            "v_L": STATE.v_l,
            "v_H": STATE.v_h,
            "pi": PI,
            "d_S_L": STATE.d_s_l,
            "d_S_H": STATE.d_s_h,
            "kappa": OFFER.kappa,
            "urgency_distribution": "truncated_exponential",
            "urgency_rate": OFFER.urgency_rate,
            "example_d_bar": OFFER.d_bar,
        },
        "boundaries": {
            "bar_D_L": bar_d_l,
            "bar_D_H": bar_d_h,
            "Delta_D": delta_d,
            "probing_upper": probing_upper,
        },
        "example": {
            "q_L": probing.q_l,
            "attempt": probing.masses[1],
            "no_early_offer": no_offer,
            "rejected_attempt": rejected,
            "successful_preemption": successful,
            "active_value_start": probing.active_b_start,
            "state_conditional_terminal_no_sale": list(probing.no_sale),
            "prior_weighted_equilibrium_no_sale": (
                probing.equilibrium_no_sale[2]
            ),
        },
        "certificate_margins": {
            "root_residual": probing.residual,
            "seller_H_rejection_slack": probing.seller_h_rejection_slack,
            "knockout_deviation_gain": probing.knockout_deviation_gain,
            "D1_slack": probing.d1_slack,
        },
        "caveat": (
            "The displayed interval is sufficient, not necessary. The figure "
            "makes no claim about equilibrium behavior to its right."
        ),
    }

    no_offer_x = bar_d_l / DISPLAY_CAP * DISPLAY_WIDTH
    theorem_x = probing_upper / DISPLAY_CAP * DISPLAY_WIDTH
    example_x = OFFER.d_bar / DISPLAY_CAP * DISPLAY_WIDTH
    theorem_middle = 0.5 * (no_offer_x + theorem_x)
    theorem_right = 0.5 * (theorem_x + DISPLAY_WIDTH)

    template = r"""\begin{figure}[htbp]
\centering
\resizebox{0.94\textwidth}{!}{%
\begin{tikzpicture}[font=\small]
  \fill[black!8] (0,1.20) rectangle (__NO_OFFER_X__,2.50);
  \fill[NHHblue!10] (__NO_OFFER_X__,1.20) rectangle (__THEOREM_X__,2.50);
  \fill[black!3] (__THEOREM_X__,1.20) rectangle (14.4,2.50);
  \draw[black!45] (0,1.20) rectangle (14.4,2.50);
  \draw[darkred,semithick] (__NO_OFFER_X__,1.10) -- (__NO_OFFER_X__,2.60);
  \draw[NHHblue,semithick] (__THEOREM_X__,1.10) -- (__THEOREM_X__,2.60);

  \node[align=center,text width=4.0cm] at (__NO_OFFER_CENTER__,1.85)
    {No-early-offer\\PBE exists};
  \node[align=center,text width=5.10cm,inner sep=1pt,text=NHHblue]
    at (__THEOREM_MIDDLE__,1.85)
    {Probing-only PBE;\\no-early-offer PBE impossible};
  \node[align=center,text width=2.70cm,inner sep=1pt,text=black!60,font=\scriptsize]
    at (__THEOREM_RIGHT__,1.85)
    {Not classified\\by the proposition};

  \draw[densely dashed,black!60] (__EXAMPLE_X__,2.50) -- (__EXAMPLE_X__,3.08);
  \node[above,align=center,font=\scriptsize] at (__EXAMPLE_X__,3.08)
    {example: \(\bar d=0.045\)};

  \draw[->] (0,0.35) -- (14.75,0.35) node[right] {\(\bar d\)};
  \draw (0,0.43) -- (0,0.27) node[below] {\(0\)};
  \draw (__NO_OFFER_X__,0.43) -- (__NO_OFFER_X__,0.27)
    node[below,align=center] {\(\bar D_L=0.020\)};
  \draw (__THEOREM_X__,0.43) -- (__THEOREM_X__,0.27)
    node[below,align=center] {\(0.0928\)};
\end{tikzpicture}%
}
\caption{A sufficient parameter region for the aligned composite continuation state \((n_L,v_L,d_{S,L})=(2,0.38,0.02)\) and \((n_H,v_H,d_{S,H})=(3,0.42,0)\), with \(F=U[0,1]\), \(\pi=1/2\), and \(\kappa=0.02\). For \(\bar d\leq\bar D_L=0.02\), a no-early-offer PBE exists. For \(0.02<\bar d\leq0.092821907\), the proposition certifies a probing-only PBE and rules out a no-early-offer PBE. The marked calibration lies strictly inside this region and generates no early offer, a rejected attempt, and successful pre-emption with positive probability. The proposition does not classify the region to the right.}
\label{fig:probingregimeoutcomes}
\end{figure}
"""
    replacements = {
        "__NO_OFFER_X__": f"{no_offer_x:.6f}",
        "__NO_OFFER_CENTER__": f"{0.5 * no_offer_x:.6f}",
        "__THEOREM_X__": f"{theorem_x:.6f}",
        "__THEOREM_MIDDLE__": f"{theorem_middle:.6f}",
        "__THEOREM_RIGHT__": f"{theorem_right:.6f}",
        "__EXAMPLE_X__": f"{example_x:.6f}",
    }
    rendered = template
    for token, value in replacements.items():
        rendered = rendered.replace(token, value)
    if "__" in rendered:
        raise AssertionError("An unresolved figure-template token remains.")
    return regions, outcomes, metadata, rendered


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"No rows supplied for {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    FIGURE_DIR.mkdir(exist_ok=True)
    regimes, outcomes, probing_metadata, figure = probing_payload()
    write_csv(FIGURE_DIR / "probing_only_regime_strip.csv", regimes)
    write_csv(FIGURE_DIR / "probing_only_outcomes.csv", outcomes)
    (FIGURE_DIR / "probing_only_regime_figure.tex").write_text(
        figure, encoding="utf-8"
    )

    metadata_path = FIGURE_DIR / "theory_figure_metadata.json"
    metadata = (
        json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata_path.exists()
        else {}
    )
    metadata["probing_only_figure"] = probing_metadata
    metadata_path.write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8"
    )
    print("ALIGNED-COMPOSITE PROBING FIGURE: PASS")
    print(f"  wrote {FIGURE_DIR / 'probing_only_regime_figure.tex'}")
    print(f"  no-early-offer boundary = {EXPECTED_THRESHOLDS[0]:.9f}")
    print(f"  probing theorem upper = {EXPECTED_THRESHOLDS[3]:.10f}")
    print("  no numerical continuation row generated")


if __name__ == "__main__":
    main()
