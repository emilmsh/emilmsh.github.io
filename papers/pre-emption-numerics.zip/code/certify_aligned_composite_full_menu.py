"""Rigorous Arb certificate for the Section 7 aligned-composite full menu.

Requires ``python-flint==0.9.0``.  Arb supplies outward-rounded ball
arithmetic and validated adaptive integration.  The exact displayed
calibration is

    (n_L,v_L)=(2,19/50), (n_H,v_H)=(3,21/50),
    pi=1/2, (d_{S,L},d_{S,H})=(1/50,0), kappa=1/20,
    d_bar=1, lambda=10.

The script certifies:

1. the Poincare--Miranda premises on the price rectangle displayed in
   Section 7;
2. existence and local uniqueness of a fixed point in a much smaller box,
   using the Krawczyk operator;
3. every strict ordering, cutoff, action-mass, seller-response, and endpoint
   inequality used to turn that root into the full-menu PBE and its
   contingent-plan D1 completion; and
4. the reported action and outcome probabilities.

The price-face reduction is analytical: under global interiority, the
truncated-exponential weights and the weakly increasing willingness gap make
T_L weakly increasing in q_H and T_H weakly decreasing in q_L.  Arb therefore
needs to certify only the four relevant corners, not a finite face grid.

This is a local existence certificate.  It does not establish global
uniqueness, select the boundary-price equilibrium among positive-rent PBEs,
or classify mixed seller responses or richer signaling menus.

Install the pinned public dependencies and run from the repository root:

    python -m pip install -r code/requirements-publication.txt
    python code/certify_aligned_composite_full_menu.py

Add ``--json`` for deterministic machine-readable interval output.
"""

from __future__ import annotations

import argparse
import json

import flint
from flint import acb, arb, arb_mat, ctx


ctx.dps = 60

PI = arb("1/2")
A = 1 - PI
V_L = arb("19/50")
V_H = arb("21/50")
D_SELLER_L = arb("1/50")
D_SELLER_H = arb(0)
KAPPA = arb("1/20")
D_BAR = arb(1)
LAMBDA = arb(10)
EXP_BAR = (-LAMBDA * D_BAR).exp()
URGENCY_DENOMINATOR = 1 - EXP_BAR

SEGMENTS = (
    (arb(0), V_L, 1),
    (V_L, V_H, 2),
    (V_H, arb(1), 3),
)


class AD:
    """Two-variable complex-ball automatic differentiation."""

    __slots__ = ("v", "g")

    def __init__(self, value, gradient=None):
        self.v = value if isinstance(value, acb) else acb(value)
        self.g = [acb(0), acb(0)] if gradient is None else gradient

    def __add__(self, other):
        other = as_ad(other)
        return AD(self.v + other.v, [x + y for x, y in zip(self.g, other.g)])

    __radd__ = __add__

    def __neg__(self):
        return AD(-self.v, [-x for x in self.g])

    def __sub__(self, other):
        return self + (-as_ad(other))

    def __rsub__(self, other):
        return as_ad(other) - self

    def __mul__(self, other):
        other = as_ad(other)
        return AD(
            self.v * other.v,
            [
                x * other.v + self.v * y
                for x, y in zip(self.g, other.g)
            ],
        )

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_ad(other)
        denominator = other.v * other.v
        return AD(
            self.v / other.v,
            [
                (x * other.v - self.v * y) / denominator
                for x, y in zip(self.g, other.g)
            ],
        )

    def __rtruediv__(self, other):
        return as_ad(other) / self

    def __pow__(self, exponent):
        if exponent == 0:
            return AD(1)
        return AD(
            self.v**exponent,
            [
                exponent * self.v ** (exponent - 1) * x
                for x in self.g
            ],
        )

    def exp(self):
        value = self.v.exp()
        return AD(value, [value * x for x in self.g])


def as_ad(value):
    return value if isinstance(value, AD) else AD(value)


def variable(value, index):
    gradient = [acb(0), acb(0)]
    gradient[index] = acb(1)
    return AD(acb(value), gradient)


def require(condition, message):
    """Certificate gate that remains active under ``python -O``."""

    if not condition:
        raise AssertionError(message)


def w_l(b, piece):
    if piece == 1:
        return b
    return b - (b**3 - V_L**3) / 3


def w_h(b, piece):
    if piece in (1, 2):
        return b
    return b - (b**4 - V_H**4) / 4


def c_l(b, piece):
    if piece == 1:
        return (
            arb(1) / 3 + V_L**2 - V_L**3 / 3 - D_SELLER_L
        )
    return (
        arb(1) / 3
        + b**2
        - arb(2) * b**3 / 3
        + V_L**3 / 3
        - D_SELLER_L
    )


def c_h(b, piece):
    if piece in (1, 2):
        return (
            arb(1) / 2 + V_H**3 - V_H**4 / 2 - D_SELLER_H
        )
    return (
        arb(1) / 2
        + b**3
        - arb(3) * b**4 / 4
        + V_H**4 / 4
        - D_SELLER_H
    )


def weights(b, q_l, q_h, piece):
    """Unnormalised waiting, probing, and knockout probabilities."""

    d_l = q_l - w_l(b, piece) + KAPPA / A
    d_h = (q_h - A * q_l) / PI - w_h(b, piece)
    e_l = (-LAMBDA * d_l).exp()
    e_h = (-LAMBDA * d_h).exp()
    return 1 - e_l, e_l - e_h, e_h - EXP_BAR, d_l, d_h


def integrate_ad(function, lower, upper, tolerance="1e-45"):
    """Validated integration of a value and its two q-derivatives."""

    length = upper - lower

    def evaluated(t):
        return length * function(AD(acb(lower) + acb(length) * t))

    output = []
    absolute_tolerance = arb(tolerance)
    for component_index in range(3):

        def component(t, analytic, component_index=component_index):
            value = evaluated(t)
            if component_index == 0:
                return value.v
            return value.g[component_index - 1]

        output.append(
            acb.integral(
                component,
                0,
                1,
                abs_tol=absolute_tolerance,
                rel_tol=absolute_tolerance,
                deg_limit=20,
                eval_limit=100000,
                depth_limit=40,
                use_heap=True,
            )
        )
    return AD(output[0], output[1:])


def integrate_quantity(q_l, q_h, selector):
    total = AD(0)
    for lower, upper, piece in SEGMENTS:
        total += integrate_ad(
            lambda b, piece=piece: selector(
                b,
                *weights(b, q_l, q_h, piece),
                c_l(b, piece),
                c_h(b, piece),
            ),
            lower,
            upper,
        )
    return total


def residual_ad(x):
    q_l = variable(x[0], 0)
    q_h = variable(x[1], 1)
    f_l = integrate_quantity(
        q_l,
        q_h,
        lambda b, m0, ml, mh, dl, dh, cl, ch: ml * (cl - q_l),
    )
    f_h = integrate_quantity(
        q_l,
        q_h,
        lambda b, m0, ml, mh, dl, dh, cl, ch: mh * (ch - q_h),
    )
    return [f_l, f_h]


def values_and_jacobian(x):
    residuals = residual_ad(x)
    values = [entry.v.real for entry in residuals]
    jacobian = arb_mat(
        2,
        2,
        [
            residuals[row].g[column].real
            for row in range(2)
            for column in range(2)
        ],
    )
    return values, jacobian


ROOT_CENTER = (
    "0.609022919152067",
    "0.715349726668132",
)
ROOT_RADIUS = arb("1e-12")


def certify_root():
    center = [arb(value).mid() for value in ROOT_CENTER]
    box = [arb(center[index], ROOT_RADIUS) for index in range(2)]
    residual_center, jacobian_center = values_and_jacobian(center)
    _, jacobian_box = values_and_jacobian(box)

    inverse_ball = jacobian_center.inv()
    preconditioner = arb_mat(
        2,
        2,
        [
            inverse_ball[row, column].mid()
            for row in range(2)
            for column in range(2)
        ],
    )
    preconditioner.inv()
    identity = arb_mat(2, 2, [1, 0, 0, 1])
    residual_vector = arb_mat(2, 1, residual_center)
    displacement = arb_mat(
        2, 1, [box[index] - center[index] for index in range(2)]
    )
    base = arb_mat(2, 1, center) - preconditioner * residual_vector
    krawczyk = (
        base
        + (identity - preconditioner * jacobian_box) * displacement
    )
    require(
        all(
            box[index].contains_interior(krawczyk[index, 0])
            for index in range(2)
        ),
        ("Krawczyk inclusion failed", box, krawczyk),
    )
    determinant = (
        jacobian_box[0, 0] * jacobian_box[1, 1]
        - jacobian_box[0, 1] * jacobian_box[1, 0]
    )
    require(not determinant.contains(0), ("singular Jacobian box", determinant))
    return {
        "center": center,
        "box": box,
        "krawczyk": [krawczyk[index, 0] for index in range(2)],
        "center_residual": residual_center,
        "jacobian_box": jacobian_box,
        "determinant": determinant,
    }


def real_part(value):
    require(value.v.imag.contains(0), ("nonreal integral", value.v))
    return value.v.real


def point_statistics(q_l, q_h):
    q_l_ad, q_h_ad = AD(q_l), AD(q_h)
    mass_0_raw = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: m0,
        )
    )
    mass_l_raw = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: ml,
        )
    )
    mass_h_raw = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: mh,
        )
    )
    cl_probe = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: ml * cl,
        )
    )
    ch_probe = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: ml * ch,
        )
    )
    cl_knockout = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: mh * cl,
        )
    )
    ch_knockout = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: mh * ch,
        )
    )
    r_l_wait = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: (
                m0 * (cl + D_SELLER_L)
            ),
        )
    )
    r_h_auction = real_part(
        integrate_quantity(
            q_l_ad,
            q_h_ad,
            lambda b, m0, ml, mh, dl, dh, cl, ch: (
                (m0 + ml) * (ch + D_SELLER_H)
            ),
        )
    )
    return {
        "mass_0_raw": mass_0_raw,
        "mass_l_raw": mass_l_raw,
        "mass_h_raw": mass_h_raw,
        "t_l": cl_probe / mass_l_raw,
        "t_h": ch_knockout / mass_h_raw,
        "post_h_probe": ch_probe / mass_l_raw,
        "post_l_knockout": cl_knockout / mass_h_raw,
        "r_l_wait_raw": r_l_wait,
        "r_h_auction_raw": r_h_auction,
    }


PRICE_BOX = (
    arb("0.605022919"),
    arb("0.613022919"),
    arb("0.711349727"),
    arb("0.719349727"),
)


def certify_root_box_containment(root_box):
    """Certify that the local Krawczyk box lies inside the large price box."""

    low_l, high_l, low_h, high_h = PRICE_BOX
    containment_margins = (
        root_box[0] - low_l,
        high_l - root_box[0],
        root_box[1] - low_h,
        high_h - root_box[1],
    )
    require(
        all(margin > 0 for margin in containment_margins),
        ("root box outside large price rectangle", containment_margins),
    )
    return containment_margins


def certify_price_rectangle():
    low_l, high_l, low_h, high_h = PRICE_BOX

    corner_ll = point_statistics(low_l, low_h)
    corner_hh = point_statistics(high_l, high_h)
    corner_hl = point_statistics(high_l, low_h)
    corner_lh = point_statistics(low_l, high_h)

    # The exact analytical corner reduction gives the minima on each face.
    face_margins = (
        corner_ll["t_l"] - low_l,
        high_l - corner_hh["t_l"],
        corner_hl["t_h"] - low_h,
        high_h - corner_lh["t_h"],
    )
    require(
        all(margin > 0 for margin in face_margins),
        ("price-face sign failed", face_margins),
    )

    w_l_1 = arb(1) - (1 - V_L**3) / 3
    w_h_1 = arb(1) - (1 - V_H**4) / 4
    delta_w_1 = w_h_1 - w_l_1
    interior_margins = (
        low_l - w_l_1 + KAPPA / A,
        D_BAR - ((high_h - A * low_l) / PI),
        low_h
        - high_l
        - PI * delta_w_1
        - PI * KAPPA / A,
    )
    require(
        all(margin > 0 for margin in interior_margins),
        ("global price-box interiority failed", interior_margins),
    )

    cl_0 = c_l(arb(0), 1)
    cl_1 = c_l(arb(1), 3)
    ch_0 = c_h(arb(0), 1)
    ch_1 = c_h(arb(1), 3)
    price_domain_margins = (
        low_l - cl_0,
        cl_1 - high_l,
        low_h - ch_0,
        ch_1 - high_h,
    )
    require(
        all(margin > 0 for margin in price_domain_margins),
        ("price box outside Q", price_domain_margins),
    )
    return {
        "face_margins": face_margins,
        "interior_margins": interior_margins,
        "price_domain_margins": price_domain_margins,
    }


def cells(lower, upper, count):
    step = (upper - lower) / count
    for index in range(count):
        left = lower + index * step
        right = lower + (index + 1) * step
        yield left.union(right)


def certify_state_ordering():
    """Interval-check the only nontrivial strict state ordering."""

    minimum_gap = None
    for lower, upper, piece in SEGMENTS:
        for b in cells(lower, upper, 160):
            gap = c_h(b, piece) - c_l(b, piece)
            require(gap > 0, ("C_H-C_L state ordering failed", piece, b, gap))
            if minimum_gap is None or gap.lower() < minimum_gap:
                minimum_gap = gap.lower()

    # The remaining shape claims are exact polynomial facts:
    # Delta w'=0, b^2, b^2-b^3 on the three pieces;
    # C_s'=0 below v_s and n*b^(n-1)*(1-b) above it;
    # Gamma_L'=-1 below v_L and -(1-b)^2 above it.
    require(V_H > V_L, "standing values not ordered")
    require(arb(3) > arb(2), "late participation not ordered")
    require(c_l(arb(0), 1) > 0, "lowest continuation value not positive")
    return arb(minimum_gap)


def certify_equilibrium(root_box):
    q_l, q_h = root_box
    statistics = point_statistics(q_l, q_h)

    w_l_1 = arb(1) - (1 - V_L**3) / 3
    w_h_1 = arb(1) - (1 - V_H**4) / 4
    delta_w_1 = w_h_1 - w_l_1

    d_l_min = q_l - w_l_1 + KAPPA / A
    d_l_max = q_l + KAPPA / A
    d_h_min = (q_h - A * q_l) / PI - w_h_1
    d_h_max = (q_h - A * q_l) / PI
    d_aux_min = A * d_l_min + PI * d_h_min
    d_aux_max = A * d_l_max + PI * d_h_max
    z_min = q_h - q_l - PI * delta_w_1 - PI * KAPPA / A
    require(
        d_l_min > 0
        and d_h_max < D_BAR
        and z_min > 0
        and d_aux_min > 0
        and d_aux_max < D_BAR,
        (
            "root cutoff interiority failed",
            d_l_min,
            d_h_max,
            z_min,
            d_aux_min,
            d_aux_max,
        ),
    )

    mass_0 = statistics["mass_0_raw"] / URGENCY_DENOMINATOR
    mass_l = statistics["mass_l_raw"] / URGENCY_DENOMINATOR
    mass_h = statistics["mass_h_raw"] / URGENCY_DENOMINATOR
    require(
        mass_0 > 0 and mass_l > 0 and mass_h > 0,
        ("nonpositive action mass", mass_0, mass_l, mass_h),
    )

    seller_slacks = (
        statistics["post_h_probe"] - q_l,
        q_h - statistics["post_l_knockout"],
    )
    require(
        all(slack > 0 for slack in seller_slacks),
        ("off-diagonal seller response failed", seller_slacks),
    )

    cl_1 = c_l(arb(1), 3)
    ch_1 = c_h(arb(1), 3)
    d1_slacks = (cl_1 - q_l, ch_1 - q_h)
    require(
        KAPPA > 0 and all(slack > 0 for slack in d1_slacks),
        ("D1 endpoint slack failed", d1_slacks),
    )

    outcomes = (
        mass_0,
        PI * mass_l,
        A * mass_l + mass_h,
    )
    mass_sum = mass_0 + mass_l + mass_h
    require(
        mass_sum.contains(1),
        ("action masses do not sum to one", mass_sum),
    )

    # Equilibrium no-sale: in L only waiting buyers below v_L reach no sale;
    # in H both waiting and probing buyers below v_H reach the bidding round.
    ns_l_integral = real_part(
        integrate_ad(
            lambda b: weights(b, AD(q_l), AD(q_h), 1)[0],
            arb(0),
            V_L,
        )
    )
    ns_h_first = real_part(
        integrate_ad(
            lambda b: (
                weights(b, AD(q_l), AD(q_h), 1)[0]
                + weights(b, AD(q_l), AD(q_h), 1)[1]
            ),
            arb(0),
            V_L,
        )
    )
    ns_h_second = real_part(
        integrate_ad(
            lambda b: (
                weights(b, AD(q_l), AD(q_h), 2)[0]
                + weights(b, AD(q_l), AD(q_h), 2)[1]
            ),
            V_L,
            V_H,
        )
    )
    no_sale_l = V_L**2 * ns_l_integral / URGENCY_DENOMINATOR
    no_sale_h = (
        V_H**3
        * (ns_h_first + ns_h_second)
        / URGENCY_DENOMINATOR
    )
    no_sale_prior = A * no_sale_l + PI * no_sale_h
    no_sale_l_raw = V_L**2 * ns_l_integral
    no_sale_h_raw = V_H**3 * (ns_h_first + ns_h_second)
    mean_early_price = (
        A * q_l * mass_l + q_h * mass_h
    ) / (A * mass_l + mass_h)
    auction_sale_mass_raw = (
        A * (statistics["mass_0_raw"] - no_sale_l_raw)
        + PI
        * (
            statistics["mass_0_raw"]
            + statistics["mass_l_raw"]
            - no_sale_h_raw
        )
    )
    auction_price_numerator_raw = (
        A
        * (
            statistics["r_l_wait_raw"]
            - V_L * no_sale_l_raw
        )
        + PI
        * (
            statistics["r_h_auction_raw"]
            - V_H * no_sale_h_raw
        )
    )
    mean_auction_sale_price = (
        auction_price_numerator_raw / auction_sale_mass_raw
    )
    conditional_price_gap = mean_early_price - mean_auction_sale_price
    require(
        conditional_price_gap > 0,
        ("conditional price moment changed sign", conditional_price_gap),
    )

    return {
        "statistics": statistics,
        "cutoff_ranges": (
            (d_l_min, d_l_max),
            (d_aux_min, d_aux_max),
            (d_h_min, d_h_max),
        ),
        "z_min": z_min,
        "masses": (mass_0, mass_l, mass_h),
        "outcomes": outcomes,
        "seller_slacks": seller_slacks,
        "d1_slacks": d1_slacks,
        "no_sale": (no_sale_l, no_sale_h, no_sale_prior),
        "conditional_mean_prices": (
            mean_early_price,
            mean_auction_sale_price,
            conditional_price_gap,
        ),
    }


def display(label, value, digits=18):
    print(f"{label:38s}", value.str(digits))


def run_certificate():
    require(
        flint.__version__ == "0.9.0",
        (
            "certificate audited only under python-flint 0.9.0; found ",
            flint.__version__,
        ),
    )
    ordering_margin = certify_state_ordering()
    price_rectangle = certify_price_rectangle()
    root = certify_root()
    root["price_rectangle_containment_margins"] = certify_root_box_containment(
        root["box"]
    )
    equilibrium = certify_equilibrium(root["box"])
    return {
        "ordering_margin": ordering_margin,
        "price_rectangle": price_rectangle,
        "root": root,
        "equilibrium": equilibrium,
    }


def interval_record(value, digits=35):
    """JSON-safe outward interval record.

    ``arb`` is the full outward enclosure.  ``lower`` and ``upper`` are Arb
    ball strings enclosing the directed endpoint computations; they are not
    plain scalar decimal bounds.
    """

    return {
        "arb": value.str(digits),
        "lower": value.lower().str(digits),
        "upper": value.upper().str(digits),
    }


def json_payload(certificate):
    price_rectangle = certificate["price_rectangle"]
    root = certificate["root"]
    equilibrium = certificate["equilibrium"]
    return {
        "certificate": "aligned-composite full-menu",
        "status": "PASS",
        "dependency": {
            "python_flint": flint.__version__,
            "precision_decimal_digits": ctx.dps,
        },
        "interval_encoding": {
            "arb": "full outward Arb enclosure",
            "lower": (
                "Arb ball enclosing the directed lower-endpoint computation; "
                "not a scalar decimal"
            ),
            "upper": (
                "Arb ball enclosing the directed upper-endpoint computation; "
                "not a scalar decimal"
            ),
        },
        "exact_primitives": {
            "n_L": 2,
            "n_H": 3,
            "v_L": "19/50",
            "v_H": "21/50",
            "pi": "1/2",
            "d_S_L": "1/50",
            "d_S_H": "0",
            "kappa": "1/20",
            "d_bar": "1",
            "lambda": "10",
        },
        "root_box": [interval_record(value) for value in root["box"]],
        "krawczyk_image": [
            interval_record(value) for value in root["krawczyk"]
        ],
        "jacobian_determinant": interval_record(root["determinant"]),
        "interval_jacobian": [
            [interval_record(root["jacobian_box"][i, j]) for j in range(2)]
            for i in range(2)
        ],
        "minimum_C_H_minus_C_L_cell_bound": interval_record(
            certificate["ordering_margin"]
        ),
        "large_price_rectangle": [
            interval_record(value) for value in PRICE_BOX
        ],
        "root_box_inside_large_rectangle_margins": [
            interval_record(value)
            for value in root["price_rectangle_containment_margins"]
        ],
        "price_box_domain_margins": [
            interval_record(value)
            for value in price_rectangle["price_domain_margins"]
        ],
        "price_box_interior_margins": [
            interval_record(value)
            for value in price_rectangle["interior_margins"]
        ],
        "price_box_face_margins": [
            interval_record(value)
            for value in price_rectangle["face_margins"]
        ],
        "cutoff_ranges": {
            label: [interval_record(value) for value in bounds]
            for label, bounds in zip(
                ("D_L", "D_aux", "D_H"),
                equilibrium["cutoff_ranges"],
            )
        },
        "minimum_Z": interval_record(equilibrium["z_min"]),
        "action_masses": {
            label: interval_record(value)
            for label, value in zip(
                ("waiting", "probing", "knockout"),
                equilibrium["masses"],
            )
        },
        "observed_outcomes": {
            label: interval_record(value)
            for label, value in zip(
                ("no_early_offer", "attempt_rejected", "pre_emption_success"),
                equilibrium["outcomes"],
            )
        },
        "seller_response_slacks": [
            interval_record(value) for value in equilibrium["seller_slacks"]
        ],
        "D1_endpoint_slacks": [
            interval_record(value) for value in equilibrium["d1_slacks"]
        ],
        "equilibrium_no_sale": {
            label: interval_record(value)
            for label, value in zip(
                ("L", "H", "prior_weighted"),
                equilibrium["no_sale"],
            )
        },
        "conditional_price_moment": {
            label: interval_record(value)
            for label, value in zip(
                (
                    "completed_pre_emption_mean",
                    "completed_bidding_round_mean",
                    "difference",
                ),
                equilibrium["conditional_mean_prices"],
            )
        },
    }


def print_human(certificate):
    ordering_margin = certificate["ordering_margin"]
    price_rectangle = certificate["price_rectangle"]
    root = certificate["root"]
    equilibrium = certificate["equilibrium"]

    print("aligned-composite full-menu Arb certificate: PASS")
    print(
        "python-flint",
        flint.__version__,
        "precision",
        ctx.dps,
        "digits",
    )
    print("root box q_L,q_H")
    for value in root["box"]:
        print(" ", value.str(30))
    print("Krawczyk image")
    for value in root["krawczyk"]:
        print(" ", value.str(30))
    display("det D_q residual on root box", root["determinant"])
    display("minimum C_H-C_L cell bound", ordering_margin)

    print("large price rectangle")
    for value in PRICE_BOX:
        print(" ", value.str(18))
    for index, margin in enumerate(
        root["price_rectangle_containment_margins"], start=1
    ):
        display(f"root-box containment margin {index}", margin)
    for index, margin in enumerate(
        price_rectangle["price_domain_margins"], start=1
    ):
        display(f"price-box domain margin {index}", margin)
    for index, margin in enumerate(
        price_rectangle["interior_margins"], start=1
    ):
        display(f"price-box interior margin {index}", margin)
    for index, margin in enumerate(
        price_rectangle["face_margins"], start=1
    ):
        display(f"price-box inward face margin {index}", margin)

    labels = ("D_L", "D_aux", "D_H")
    for label, bounds in zip(labels, equilibrium["cutoff_ranges"]):
        display(f"{label} lower endpoint", bounds[0])
        display(f"{label} upper endpoint", bounds[1])
    display("minimum Z", equilibrium["z_min"])

    for label, value in zip(
        ("waiting mass", "probing mass", "knockout mass"),
        equilibrium["masses"],
    ):
        display(label, value)
    for label, value in zip(
        ("no early offer", "attempt and rejection", "successful pre-emption"),
        equilibrium["outcomes"],
    ):
        display(label, value)
    display("H rejection slack after probe", equilibrium["seller_slacks"][0])
    display(
        "L acceptance slack at knockout",
        equilibrium["seller_slacks"][1],
    )
    display("D1 C_L(1)-q_L", equilibrium["d1_slacks"][0])
    display("D1 C_H(1)-q_H", equilibrium["d1_slacks"][1])
    display("equilibrium no sale in L", equilibrium["no_sale"][0])
    display("equilibrium no sale in H", equilibrium["no_sale"][1])
    display("prior-weighted no sale", equilibrium["no_sale"][2])
    display(
        "mean price completed pre-emption",
        equilibrium["conditional_mean_prices"][0],
    )
    display(
        "mean price completed bidding round",
        equilibrium["conditional_mean_prices"][1],
    )
    display(
        "conditional mean price difference",
        equilibrium["conditional_mean_prices"][2],
    )


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Outward-rounded interval certificate for the Section 7 "
            "aligned-composite full-menu calibration."
        )
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="emit the certified intervals as deterministic JSON",
    )
    arguments = parser.parse_args()
    certificate = run_certificate()
    if arguments.json:
        print(json.dumps(json_payload(certificate), indent=2, sort_keys=True))
    else:
        print_human(certificate)


if __name__ == "__main__":
    main()
