"""High-order audit of the paired common-F full-menu ban examples.

The two rows use the baseline protocol, continuous early values, continuous
urgency, and all three buyer actions.  Early and late values share the same
distribution within each row.  The rows differ only in a mean-matched common
value distribution: a symmetric benchmark and an upper-tail mixture.

This is a deterministic floating-point audit, not an interval certificate.
It solves each price fixed point at two quadrature resolutions, checks the
global-interior action regions, seller responses, D1 endpoint inequalities,
incidence, and two independent welfare decompositions.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import comb, lgamma

import numpy as np
from numpy.polynomial.legendre import leggauss


N_L, N_H = 2, 6
V_L, V_H = 0.2, 0.4
PI = 0.5
A = 1 - PI
KAPPA = 0.02
KAPPA_RESOURCE = KAPPA
D_BAR = 1.0
VALUE_UNIFORM_WEIGHT = 0.01
URGENCY_UNIFORM_WEIGHT = 0.0001
URGENCY_SHAPE = 30


def beta_cdf(x, alpha, beta):
    values = np.clip(np.asarray(x), 0.0, 1.0)
    degree = alpha + beta - 1
    output = np.zeros_like(values, dtype=float)
    for success in range(alpha, degree + 1):
        output += (
            comb(degree, success)
            * values**success
            * (1 - values) ** (degree - success)
        )
    return output


def beta_pdf(x, alpha, beta):
    values = np.asarray(x)
    normalizer = np.exp(lgamma(alpha + beta) - lgamma(alpha) - lgamma(beta))
    return (
        normalizer
        * np.maximum(values, 1e-300) ** (alpha - 1)
        * np.maximum(1 - values, 1e-300) ** (beta - 1)
    )


@dataclass(frozen=True)
class ValueDistribution:
    label: str
    components: tuple
    start: tuple

    def cdf(self, x):
        values = np.asarray(x)
        output = np.zeros_like(values, dtype=float)
        for weight, alpha, beta in self.components:
            output += weight * (
                np.clip(values, 0.0, 1.0)
                if alpha is None
                else beta_cdf(values, alpha, beta)
            )
        return output

    def pdf(self, x):
        values = np.asarray(x)
        output = np.zeros_like(values, dtype=float)
        for weight, alpha, beta in self.components:
            output += weight * (
                np.ones_like(values)
                if alpha is None
                else beta_pdf(values, alpha, beta)
            )
        return output

    def mean(self):
        return sum(
            weight * (0.5 if alpha is None else alpha / (alpha + beta))
            for weight, alpha, beta in self.components
        )


def urgency_cdf(d):
    values = np.asarray(d)
    clipped = np.clip(values, 0.0, D_BAR)
    raw = (
        URGENCY_UNIFORM_WEIGHT * clipped
        + (1 - URGENCY_UNIFORM_WEIGHT)
        * (1 - (1 - clipped) ** URGENCY_SHAPE)
    )
    return np.where(values <= 0, 0.0, np.where(values >= D_BAR, 1.0, raw))


def urgency_tail_first_moment(d):
    values = np.asarray(d)
    clipped = np.clip(values, 0.0, D_BAR)
    complement = 1 - clipped
    raw = URGENCY_UNIFORM_WEIGHT * (1 - clipped**2) / 2 + (
        1 - URGENCY_UNIFORM_WEIGHT
    ) * (
        complement**URGENCY_SHAPE
        - URGENCY_SHAPE
        / (URGENCY_SHAPE + 1)
        * complement ** (URGENCY_SHAPE + 1)
    )
    mean = URGENCY_UNIFORM_WEIGHT / 2 + (
        1 - URGENCY_UNIFORM_WEIGHT
    ) / (URGENCY_SHAPE + 1)
    return np.where(values <= 0, mean, np.where(values >= D_BAR, 0.0, raw))


def urgency_excess(d):
    values = np.asarray(d)
    return urgency_tail_first_moment(values) - values * (1 - urgency_cdf(values))


class TerminalState:
    def __init__(self, distribution, bidders, fallback, grid_size):
        self.distribution = distribution
        self.bidders = bidders
        self.fallback = fallback
        self.grid = np.linspace(0.0, 1.0, grid_size)
        cdf = distribution.cdf(self.grid)
        first_survival = 1 - cdf**bidders
        second_survival = (
            1
            - cdf**bidders
            - bidders * (1 - cdf) * cdf ** (bidders - 1)
        )
        excluded = bidders * (1 - cdf) * cdf ** (bidders - 1)
        self.first_integral = self._cumulative(first_survival)
        self.second_integral = self._cumulative(second_survival)
        self.excluded_integral = self._cumulative(excluded)

    def _cumulative(self, values):
        return np.concatenate(
            ([0.0], np.cumsum((values[:-1] + values[1:]) * np.diff(self.grid) / 2))
        )

    def integral(self, cumulative, lower, upper):
        return np.interp(upper, self.grid, cumulative) - np.interp(
            lower, self.grid, cumulative
        )

    def w(self, b):
        values = np.asarray(b)
        return np.where(
            values <= self.fallback,
            values,
            self.fallback
            + self.integral(self.first_integral, self.fallback, values),
        )

    def gamma(self, b):
        values = np.asarray(b)
        lower = np.maximum(values, self.fallback)
        return np.maximum(self.fallback - values, 0) + self.integral(
            self.second_integral, lower, 1.0
        )

    def excluded(self, b):
        values = np.asarray(b)
        return self.integral(
            self.excluded_integral, np.maximum(values, self.fallback), 1.0
        )

    def continuation(self, b):
        return self.w(b) + self.gamma(b)


def quadrature(order):
    nodes, weights = leggauss(order)
    values, combined_weights = [], []
    for lower, upper in ((0.0, V_L), (V_L, V_H), (V_H, 1.0)):
        values.append(lower + (upper - lower) * (nodes + 1) / 2)
        combined_weights.append((upper - lower) * weights / 2)
    return np.concatenate(values), np.concatenate(combined_weights)


def solve(distribution, grid_size, order, start):
    low = TerminalState(distribution, N_L, V_L, grid_size)
    high = TerminalState(distribution, N_H, V_H, grid_size)
    b, weights = quadrature(order)
    density = distribution.pdf(b)

    def statistics(q):
        q_l, q_h = q
        d_l = q_l - low.w(b) + KAPPA / A
        d_h = (q_h - A * q_l) / PI - high.w(b)
        probe = urgency_cdf(d_h) - urgency_cdf(d_l)
        knockout = 1 - urgency_cdf(d_h)
        mass_l = float(weights @ (density * probe))
        mass_h = float(weights @ (density * knockout))
        mapped = np.array(
            (
                weights @ (density * probe * low.continuation(b)) / mass_l,
                weights @ (density * knockout * high.continuation(b)) / mass_h,
            )
        )
        return mapped, d_l, d_h, probe, knockout, mass_l, mass_h

    q = np.array(start, dtype=float)
    for _ in range(80):
        mapped, *_ = statistics(q)
        residual = mapped - q
        if np.max(np.abs(residual)) < 2e-14:
            break
        step = 2e-6
        jacobian = np.empty((2, 2))
        for index in range(2):
            shifted = q.copy()
            shifted[index] += step
            shifted_map, *_ = statistics(shifted)
            jacobian[:, index] = (shifted_map - shifted - residual) / step
        direction = np.linalg.solve(jacobian, -residual)
        for damping in (1.0, 0.5, 0.25, 0.1, 0.05, 0.01):
            candidate = q + damping * direction
            candidate_residual = statistics(candidate)[0] - candidate
            if np.max(np.abs(candidate_residual)) < np.max(np.abs(residual)):
                q = candidate
                break
        else:
            raise RuntimeError(f"Newton line search failed for {distribution.label}")

    mapped, d_l, d_h, probe, knockout, mass_l, mass_h = statistics(q)
    residual = mapped - q
    wait = urgency_cdf(d_l)
    attempts = mass_l + mass_h
    outcomes = (
        float(weights @ (density * wait)),
        PI * mass_l,
        A * mass_l + mass_h,
    )
    post_h_probe = float(
        weights @ (density * probe * high.continuation(b)) / mass_l
    )
    post_l_knockout = float(
        weights @ (density * knockout * low.continuation(b)) / mass_h
    )

    late_surplus = float(
        weights
        @ (
            density
            * (
                A * (probe + knockout) * low.excluded(b)
                + PI * knockout * high.excluded(b)
            )
        )
    )
    buyer_rent = float(
        weights @ (density * (A * urgency_excess(d_l) + PI * urgency_excess(d_h)))
    )
    seller_rent = float(
        weights
        @ (density * (A * knockout * (high.continuation(b) - low.continuation(b))))
    )
    attempt_resources = KAPPA_RESOURCE * attempts
    allocation_gain = float(
        weights
        @ (
            density
            * (
                A
                * (probe + knockout)
                * (low.gamma(b) + low.excluded(b))
                + PI * knockout * (high.gamma(b) + high.excluded(b))
            )
        )
    )
    timing_costs = float(
        weights
        @ (
            density
            * (
                A * urgency_tail_first_moment(d_l)
                + PI * urgency_tail_first_moment(d_h)
            )
        )
    )
    welfare_direct = attempt_resources + allocation_gain - timing_costs
    welfare_rents = late_surplus - buyer_rent - seller_rent

    grid = np.linspace(0.0, 1.0, 100001)
    d_l_grid = q[0] - low.w(grid) + KAPPA / A
    d_h_grid = (q[1] - A * q[0]) / PI - high.w(grid)
    z_grid = PI * (d_h_grid - d_l_grid)
    return {
        "q": tuple(float(value) for value in q),
        "residual": tuple(float(value) for value in residual),
        "masses": (1 - attempts, mass_l, mass_h),
        "outcomes": outcomes,
        "cutoffs": (
            float(np.min(d_l_grid)),
            float(np.max(d_l_grid)),
            float(np.min(d_h_grid)),
            float(np.max(d_h_grid)),
            float(np.min(z_grid)),
        ),
        "seller_slacks": (post_h_probe - q[0], q[1] - post_l_knockout),
        "d1_slacks": (
            float(low.continuation(1.0) - q[0]),
            float(high.continuation(1.0) - q[1]),
        ),
        "welfare": {
            "difference": welfare_direct,
            "rent_identity": welfare_rents,
            "attempt_resources": attempt_resources,
            "allocation_gain": allocation_gain,
            "timing_costs": timing_costs,
            "excluded_late_surplus": late_surplus,
            "excluded_per_completed_sale": late_surplus / outcomes[2],
            "buyer_rent": buyer_rent,
            "seller_rent": seller_rent,
        },
    }


CASES = (
    ValueDistribution(
        "symmetric",
        (
            (VALUE_UNIFORM_WEIGHT, None, None),
            (1 - VALUE_UNIFORM_WEIGHT, 40, 40),
        ),
        (0.51, 0.56),
    ),
    ValueDistribution(
        "upper_tail",
        (
            (VALUE_UNIFORM_WEIGHT, None, None),
            ((1 - VALUE_UNIFORM_WEIGHT) * 16 / 17, 38, 42),
            ((1 - VALUE_UNIFORM_WEIGHT) / 17, 9, 1),
        ),
        (0.52, 0.65),
    ),
)


def main():
    results = {}
    for case in CASES:
        low_order = solve(case, 50001, 260, case.start)
        high_order = solve(case, 180001, 560, low_order["q"])
        convergence = max(
            abs(low_order[group][index] - high_order[group][index])
            for group in ("q", "masses", "outcomes")
            for index in range(len(low_order[group]))
        )
        convergence = max(
            convergence,
            max(
                abs(low_order["welfare"][key] - high_order["welfare"][key])
                for key in high_order["welfare"]
            ),
        )
        assert abs(case.mean() - 0.5) < 1e-14
        assert np.min(case.pdf(np.linspace(0, 1, 200001))) >= 0.01 - 1e-13
        assert max(abs(value) for value in high_order["residual"]) < 5e-12
        assert convergence < 5e-9
        assert min(high_order["masses"]) > 0
        assert high_order["cutoffs"][0] > 0
        assert high_order["cutoffs"][3] < 1
        assert high_order["cutoffs"][4] > 0
        assert min(high_order["seller_slacks"]) > 0
        assert min(high_order["d1_slacks"]) > 0
        assert abs(
            high_order["welfare"]["difference"]
            - high_order["welfare"]["rent_identity"]
        ) < 5e-10
        results[case.label] = high_order
        print(f"\n{case.label.upper()}")
        print("components", case.components)
        print("mean", case.mean())
        print("Pr(value > .7)", float(1 - case.cdf(0.7)))
        print("q", high_order["q"])
        print("action masses", high_order["masses"])
        print("outcomes", high_order["outcomes"])
        print("cutoff checks", high_order["cutoffs"])
        print("seller slacks", high_order["seller_slacks"])
        print("D1 endpoint slacks", high_order["d1_slacks"])
        print("welfare", high_order["welfare"])
        print("low/high convergence", convergence)

    assert results["symmetric"]["welfare"]["difference"] < 0
    assert results["upper_tail"]["welfare"]["difference"] > 0
    assert (
        results["upper_tail"]["welfare"]["excluded_per_completed_sale"]
        > results["symmetric"]["welfare"]["excluded_per_completed_sale"]
    )
    print(
        "\nPASS: rich continuous common-F full-menu equilibria have opposite "
        "ban-welfare signs."
    )


if __name__ == "__main__":
    main()
