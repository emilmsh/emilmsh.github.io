"""Audit the coarse terminal-counteroffer protocol inside the one-offer game.

The terminal seller has a physical fallback value ``v``.  After observing only
the losing dropout price, it can extinguish the standing bid and make one
counteroffer.  With uniform values this implements the monopoly threshold
``rho(v)=(1+v)/2``.  The resulting terminal game is therefore a second-price
auction with a public common threshold and state-dependent bidder count,
except that no sale pays the seller ``v`` rather than ``rho(v)``.

This script substitutes the resulting buyer willingness and seller
continuation payoff into the demand-only specialization of the one-offer
audit.  It checks one probing-only and one full-menu equilibrium with endpoint
and strict-gain interim-D1 margins.  The calculations are numerical
certificates, not interval-arithmetic proofs.
"""

from __future__ import annotations

from dataclasses import asdict
import json

import numpy as np
from numpy.polynomial.legendre import leggauss

import audit_aligned_composite_calibration as baseline


PHYSICAL_V = (0.40, 0.40)
THRESHOLDS = tuple((1.0 + value) / 2.0 for value in PHYSICAL_V)
STATE = baseline.StatePrimitives(2, 3, *THRESHOLDS)


def counteroffer_revenue_uniform(
    n: int,
    b: np.ndarray | float,
    threshold: float,
    fallback: float,
) -> np.ndarray | float:
    """Seller payoff under a coarse-history monopoly counteroffer.

    ``baseline.revenue_uniform(n,b,threshold)`` treats the threshold as the
    seller payoff when nobody clears it.  Here the seller instead receives
    the physical fallback ``fallback``.  If the early buyer is below the
    threshold, no sale occurs precisely when all ``n`` late buyers are also
    below it, which has probability ``threshold**n``.  At equality the early
    buyer clears the threshold, hence the strict comparison below.
    """

    value = np.asarray(b)
    committed = baseline.revenue_uniform(n, value, threshold)
    correction = np.where(
        value < threshold,
        (threshold - fallback) * threshold**n,
        0.0,
    )
    result = committed - correction
    return float(result) if np.ndim(value) == 0 else result


class CounterofferModel(baseline.CompositeModel):
    """Demand-only one-offer model with a coarse counteroffer continuation."""

    def __init__(self, state, offer, quad_n):
        # The parent audit imposes v_L<v_H for its aligned calibration.  This
        # specialization deliberately holds the physical fallback, and hence
        # the counteroffer threshold, common across demand states.
        self.state = state
        self.offer = offer
        self.nodes, self.weights = leggauss(quad_n)

    def c_l(self, b):
        return counteroffer_revenue_uniform(
            self.state.n_l, b, self.state.v_l, PHYSICAL_V[0]
        ) - baseline.D_SELLER

    def c_h(self, b):
        return counteroffer_revenue_uniform(
            self.state.n_h, b, self.state.v_h, PHYSICAL_V[1]
        ) - baseline.D_SELLER


def _thresholds(model: CounterofferModel) -> tuple[float, float, float, float]:
    wl, wh = float(model.w_l(1.0)), float(model.w_h(1.0))
    cl, ch = float(model.c_l(1.0)), float(model.c_h(1.0))
    dl = cl - wl + model.offer.kappa / baseline.A
    dh = ch - baseline.A * wl - baseline.PI * wh + model.offer.kappa
    delta = dh - dl
    return dl, dh, delta, dl + delta / baseline.PI


def _reserve_endpoint_grid(points: int) -> np.ndarray:
    """Dense buyer grid with the reserve and both floating-point sides."""

    extras = []
    for threshold in THRESHOLDS:
        extras.extend(
            (
                np.nextafter(threshold, -np.inf),
                threshold,
                np.nextafter(threshold, np.inf),
            )
        )
    return np.unique(
        np.concatenate((np.linspace(0.0, 1.0, points), np.asarray(extras)))
    )


def _inactive_price_audit(
    model: CounterofferModel,
    on_path_prices: tuple[float, ...],
) -> dict[str, object]:
    """Audit every top-belief response region at its payoff-maximizing price.

    Under the off-path posterior concentrated on ``b=1``, prices below
    ``C_L(1)`` are rejected by both states, prices in
    ``[C_L(1),C_H(1))`` buy only L, and prices at or above ``C_H(1)`` buy
    both.  Buyer payoff is strictly decreasing in price within each response
    region, so its left endpoint exhausts the continuum of inactive prices.
    The adjacent floating-point values make the boundary convention explicit.
    """

    threshold_l = float(model.c_l(1.0))
    threshold_h = float(model.c_h(1.0))
    if not threshold_l < threshold_h:
        raise AssertionError((threshold_l, threshold_h))

    prices = np.unique(
        np.asarray(
            (
                0.0,
                np.nextafter(threshold_l, -np.inf),
                threshold_l,
                np.nextafter(threshold_l, np.inf),
                0.5 * (threshold_l + threshold_h),
                np.nextafter(threshold_h, -np.inf),
                threshold_h,
                np.nextafter(threshold_h, np.inf),
                1.0,
            )
        )
    )
    b_grid = _reserve_endpoint_grid(20001)
    w_l = model.w_l(b_grid)
    w_h = model.w_h(b_grid)

    if len(on_path_prices) == 1:
        q_l = on_path_prices[0]
        cutoff_l = q_l - w_l + model.offer.kappa / baseline.A
        d_grid = np.stack(
            (
                np.zeros_like(b_grid),
                np.full_like(b_grid, model.offer.d_bar),
                np.clip(cutoff_l, 0.0, model.offer.d_bar),
            )
        )
        equilibrium = np.maximum(
            0.0,
            baseline.A * (w_l[None, :] + d_grid - q_l)
            - model.offer.kappa,
        )
    elif len(on_path_prices) == 2:
        q_l, q_h = on_path_prices
        cutoff_l = q_l - w_l + model.offer.kappa / baseline.A
        cutoff_all = (
            q_h
            - baseline.A * w_l
            - baseline.PI * w_h
            + model.offer.kappa
        )
        cutoff_l_all = (q_h - baseline.A * q_l) / baseline.PI - w_h
        d_grid = np.stack(
            (
                np.zeros_like(b_grid),
                np.full_like(b_grid, model.offer.d_bar),
                np.clip(cutoff_l, 0.0, model.offer.d_bar),
                np.clip(cutoff_all, 0.0, model.offer.d_bar),
                np.clip(cutoff_l_all, 0.0, model.offer.d_bar),
            )
        )
        payoff_l = (
            baseline.A * (w_l[None, :] + d_grid - q_l)
            - model.offer.kappa
        )
        payoff_all = (
            baseline.A * w_l[None, :]
            + baseline.PI * w_h[None, :]
            + d_grid
            - q_h
            - model.offer.kappa
        )
        equilibrium = np.maximum(np.maximum(0.0, payoff_l), payoff_all)
    else:
        raise ValueError(on_path_prices)

    rows = []
    best = (-np.inf, 0.0, 0, 0.0, 0.0)
    for price in prices:
        if price < threshold_l:
            prefix = 0
            deviation = np.full_like(equilibrium, -model.offer.kappa)
        elif price < threshold_h:
            prefix = 1
            deviation = (
                baseline.A * (w_l[None, :] + d_grid - price)
                - model.offer.kappa
            )
        else:
            prefix = 2
            deviation = (
                baseline.A * w_l[None, :]
                + baseline.PI * w_h[None, :]
                + d_grid
                - price
                - model.offer.kappa
            )
        gain = deviation - equilibrium
        flat_index = int(np.argmax(gain))
        d_index, b_index = np.unravel_index(flat_index, gain.shape)
        maximum = float(gain[d_index, b_index])
        row = (
            float(price),
            prefix,
            maximum,
            float(b_grid[b_index]),
            float(d_grid[d_index, b_index]),
        )
        rows.append(row)
        if maximum > best[0]:
            best = (maximum, float(price), prefix, row[3], row[4])

    assert best[0] < -1e-8
    return {
        "top_belief_thresholds": (threshold_l, threshold_h),
        "price_rows": tuple(rows),
        "maximum_gain": best,
        "continuum_reduction": "payoff decreases in price within each response region",
    }


def audit_probe() -> dict[str, object]:
    offer = baseline.OfferPrimitives(kappa=0.01, d_bar=0.019)
    model = CounterofferModel(STATE, offer, baseline.QUAD_N)
    validation = CounterofferModel(STATE, offer, baseline.VALIDATION_QUAD_N)
    q_l = baseline._solve_scalar(model)
    stats = validation.probing_statistics(q_l)
    residual = abs(float(stats["mapped"]) - q_l)
    c_bounds = (float(model.c_l(0.0)), float(model.c_l(1.0)))
    bracket_signs = (
        float(validation.probing_statistics(c_bounds[0])["mapped"])
        - c_bounds[0],
        float(validation.probing_statistics(c_bounds[1])["mapped"])
        - c_bounds[1],
    )

    cutoff_at_top = q_l - float(model.w_l(1.0)) + offer.kappa / baseline.A
    if cutoff_at_top >= 0.0:
        marginal_b = 1.0
    else:
        root = baseline._crossing_point(
            lambda b: q_l - model.w_l(b) + offer.kappa / baseline.A,
            0.0,
        )
        if root is None:
            raise AssertionError("No wait--probe marginal buyer value.")
        marginal_b = root
    d1_slack = float(model.c_l(marginal_b)) - q_l

    wl1, wh1 = float(model.w_l(1.0)), float(model.w_h(1.0))
    probe_top = baseline.A * (wl1 + offer.d_bar - q_l) - offer.kappa
    knockout_top = (
        baseline.A * wl1
        + baseline.PI * wh1
        + offer.d_bar
        - float(model.c_h(1.0))
        - offer.kappa
    )
    knockout_gain = knockout_top - max(0.0, probe_top)
    b_grid = np.unique(
        np.concatenate((np.linspace(0.0, 1.0, 20001), THRESHOLDS))
    )
    cutoff_grid = q_l - model.w_l(b_grid) + offer.kappa / baseline.A
    d_grid = np.stack(
        (
            np.zeros_like(b_grid),
            np.full_like(b_grid, offer.d_bar),
            np.clip(cutoff_grid, 0.0, offer.d_bar),
        )
    )
    probe_payoff = baseline.A * (
        model.w_l(b_grid)[None, :] + d_grid - q_l
    ) - offer.kappa
    knockout_payoff = (
        baseline.A * model.w_l(b_grid)[None, :]
        + baseline.PI * model.w_h(b_grid)[None, :]
        + d_grid
        - float(model.c_h(1.0))
        - offer.kappa
    )
    grid_knockout_gain = float(
        np.max(knockout_payoff - np.maximum(0.0, probe_payoff))
    )
    theorem_thresholds = _thresholds(model)
    _, _, delta_d, upper = theorem_thresholds
    probe_mass = float(stats["mass"])
    outcomes = (
        1.0 - probe_mass,
        baseline.PI * probe_mass,
        baseline.A * probe_mass,
    )
    h_rejection_slack = float(stats["post_h"]) - q_l
    inactive_prices = _inactive_price_audit(model, (q_l,))

    baseline._two_kink_checks(STATE)
    assert residual < 3e-12
    assert bracket_signs[0] > 0.0 and bracket_signs[1] < 0.0
    assert 0.0 < probe_mass < 1.0
    assert h_rejection_slack > 0.0
    assert d1_slack > 0.0
    assert knockout_gain < 0.0
    assert abs(grid_knockout_gain - knockout_gain) < 2e-10
    assert delta_d > 0.0
    assert theorem_thresholds[0] < offer.d_bar <= upper

    return {
        "offer": asdict(offer),
        "q_l": q_l,
        "action_masses": (1.0 - probe_mass, probe_mass),
        "outcomes": outcomes,
        "fixed_point_residual": residual,
        "root_bracket_signs": bracket_signs,
        "seller_h_rejection_slack": h_rejection_slack,
        "knockout_deviation_gain": knockout_gain,
        "grid_knockout_deviation_gain": grid_knockout_gain,
        "d1_marginal_b": marginal_b,
        "d1_slack": d1_slack,
        "theorem_thresholds": theorem_thresholds,
        "inactive_price_audit": inactive_prices,
    }


def audit_full_menu() -> dict[str, object]:
    offer = baseline.OfferPrimitives(kappa=0.05, d_bar=1.0)
    model = CounterofferModel(STATE, offer, baseline.QUAD_N)
    validation = CounterofferModel(STATE, offer, baseline.VALIDATION_QUAD_N)
    root = baseline._solve_vector(model, (0.686, 0.753))
    stats = validation.two_price_statistics(*root)
    residuals = np.asarray(stats["mapped"]) - root

    d_l = lambda b: root[0] - model.w_l(b) + offer.kappa / baseline.A
    d_a = lambda b: (
        root[1]
        - baseline.A * model.w_l(b)
        - baseline.PI * model.w_h(b)
        + offer.kappa
    )
    d_h = lambda b: (
        (root[1] - baseline.A * root[0]) / baseline.PI - model.w_h(b)
    )
    cutoff_ranges = tuple(
        (float(function(1.0)), float(function(0.0)))
        for function in (d_l, d_a, d_h)
    )
    sorting_gap = (
        root[1]
        - root[0]
        - baseline.PI * (float(model.w_h(1.0)) - float(model.w_l(1.0)))
        - baseline.PI * offer.kappa / baseline.A
    )
    seller_slacks = (
        float(stats["post_h_probe"]) - float(root[0]),
        float(root[1]) - float(stats["post_l_knockout"]),
    )
    d1_slacks = (
        float(model.c_l(1.0)) - float(root[0]),
        float(model.c_h(1.0)) - float(root[1]),
    )
    interior_margins, face_margins = baseline._audit_price_box(
        validation, root, (1e-4, 1e-4)
    )
    masses = tuple(float(value) for value in stats["masses"])
    outcomes = (
        masses[0],
        baseline.PI * masses[1],
        baseline.A * masses[1] + masses[2],
    )
    inactive_prices = _inactive_price_audit(model, tuple(float(x) for x in root))

    baseline._two_kink_checks(STATE)
    assert float(np.max(np.abs(residuals))) < 3e-12
    assert min(cutoff_ranges[0]) > 0.0
    assert max(cutoff_ranges[2]) < offer.d_bar
    assert sorting_gap > 0.0
    assert min(masses) > 0.0
    assert min(seller_slacks) > 0.0
    assert min(d1_slacks) > 0.0
    assert min(interior_margins) > 0.0
    assert min(face_margins) > 0.0

    return {
        "offer": asdict(offer),
        "prices": tuple(float(value) for value in root),
        "cutoff_ranges": cutoff_ranges,
        "sorting_gap": float(sorting_gap),
        "action_masses": masses,
        "outcomes": outcomes,
        "fixed_point_residuals": tuple(float(value) for value in residuals),
        "seller_slacks": seller_slacks,
        "d1_slacks": d1_slacks,
        "price_box_interior_margins": interior_margins,
        "price_box_face_margins": face_margins,
        "inactive_price_audit": inactive_prices,
    }


def reduced_form_diagnostic() -> dict[str, object]:
    model = CounterofferModel(
        STATE, baseline.OfferPrimitives(kappa=0.01, d_bar=0.02), 80
    )
    grid = _reserve_endpoint_grid(200001)
    continuation_gap = model.c_h(grid) - model.c_l(grid)
    willingness_gap = model.w_h(grid) - model.w_l(grid)
    willingness_increments = np.diff(willingness_gap)
    reserve = THRESHOLDS[0]
    reserve_left = np.nextafter(reserve, -np.inf)
    reserve_right = np.nextafter(reserve, np.inf)
    c_l_sides = (
        float(model.c_l(reserve_left)),
        float(model.c_l(reserve)),
        float(model.c_l(reserve_right)),
    )
    c_h_sides = (
        float(model.c_h(reserve_left)),
        float(model.c_h(reserve)),
        float(model.c_h(reserve_right)),
    )
    expected_jumps = (
        (reserve - PHYSICAL_V[0]) * reserve ** STATE.n_l,
        (reserve - PHYSICAL_V[1]) * reserve ** STATE.n_h,
    )
    actual_jumps = (
        c_l_sides[1] - c_l_sides[0],
        c_h_sides[1] - c_h_sides[0],
    )
    assert float(np.min(continuation_gap)) > 0.0
    assert float(np.min(willingness_gap)) >= -5e-14
    assert float(np.min(willingness_increments)) >= -5e-14
    assert max(
        abs(actual_jumps[index] - expected_jumps[index]) for index in range(2)
    ) < 2e-14
    return {
        "minimum_continuation_gap": float(np.min(continuation_gap)),
        "minimum_willingness_gap": float(np.min(willingness_gap)),
        "minimum_delta_w_increment": float(np.min(willingness_increments)),
        "reserve_points": (reserve_left, reserve, reserve_right),
        "c_l_reserve_sides": c_l_sides,
        "c_h_reserve_sides": c_h_sides,
        "continuation_jumps": actual_jumps,
    }


def competition_wedge_diagnostic() -> dict[str, object]:
    grid = _reserve_endpoint_grid(100001)
    result: dict[str, object] = {}
    for label, n, fallback, threshold in (
        ("L", STATE.n_l, PHYSICAL_V[0], STATE.v_l),
        ("H", STATE.n_h, PHYSICAL_V[1], STATE.v_h),
    ):
        revenue = counteroffer_revenue_uniform(n, grid, threshold, fallback)
        willingness = baseline.w_uniform(n, grid, threshold)
        wedge = revenue - willingness
        # Ignore machine-zero values at the upper support endpoint.
        negative = grid[wedge < -1e-10]
        result[label] = {
            "minimum": float(np.min(wedge)),
            "argmin": float(grid[int(np.argmin(wedge))]),
            "reserve_sides": (
                float(
                    counteroffer_revenue_uniform(
                        n, np.nextafter(threshold, -np.inf), threshold, fallback
                    )
                    - baseline.w_uniform(
                        n, np.nextafter(threshold, -np.inf), threshold
                    )
                ),
                float(
                    counteroffer_revenue_uniform(n, threshold, threshold, fallback)
                    - baseline.w_uniform(n, threshold, threshold)
                ),
                float(
                    counteroffer_revenue_uniform(
                        n, np.nextafter(threshold, np.inf), threshold, fallback
                    )
                    - baseline.w_uniform(
                        n, np.nextafter(threshold, np.inf), threshold
                    )
                ),
            ),
            "negative_grid_interval": (
                float(negative[0]),
                float(negative[-1]),
            ) if len(negative) else None,
        }
    return result


def main() -> None:
    output = {
        "physical_fallbacks": PHYSICAL_V,
        "counteroffer_thresholds": THRESHOLDS,
        "reduced_form": reduced_form_diagnostic(),
        "probe": audit_probe(),
        "full_menu": audit_full_menu(),
        "competition_wedge": competition_wedge_diagnostic(),
    }
    print("terminal-counteroffer one-offer plug-in audit: PASS")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
