# Calculations for the short paper

The [numerical workbook source](NUMERICAL_WORKBOOK.md) supplies a single
reading order for the main paper, online appendix and separately identified
research diagnostics. Build the executed notebook, HTML and complete ZIP with
`python code/build_numerical_workbook.py` after installing
`code/requirements-workbook.txt`. The builder runs all 22 checks from a fresh
kernel, checks source hashes and certificate-table reproduction, and packages
the clean PDFs from `manuscripts/release/`. Outputs go to
`manuscripts/release/numerics/`. The website publisher checks this bundle
against its recorded sources before uploading it alongside the PDFs.

[paper_calculations.py](paper_calculations.py) is a single entry point for the
two numerical exercises used in the main paper. It checks the simple
participation example with exact fractions, then calls the existing ban-welfare
audit. An optional command adds the existing interval certificate. The
underlying solvers are unchanged.

The main result chain is participation uncertainty → probing → the welfare
effect of allowing early agreement. The calculations follow that order.
Additional online-appendix calculations are mapped below.

## Run the main calculations

Use Python 3.12 and the packages in
[requirements-publication.txt](requirements-publication.txt):

```text
python -m pip install -r code/requirements-publication.txt
python code/paper_calculations.py
```

Run these commands from the repository root. The default invocation takes
seconds on the tested machine. It checks the participation thresholds and
reproduces the two ban examples at two numerical resolutions.

For just the exact participation calculation, no third-party package is needed:

```text
python code/paper_calculations.py --probing-only
```

To add the interval certificate:

```text
python code/paper_calculations.py --certify
```

For machine-readable output:

```text
python code/paper_calculations.py --certify --json
```

The JSON includes the environment, exact fractions, executed script names,
elapsed times, the floating-point audit's full text output, and the certificate's
structured results. Omitted tasks are explicitly marked `not_run`. The entry
point writes no manuscript or result files; save the output separately if needed.
A failed calculation or missing pinned dependency gives a nonzero exit status.
The audit subprocesses run with assertions enabled.

The analytic example uses only the standard library. The ban point audit
requires `numpy==2.3.5`; certification additionally requires
`python-flint==0.9.0`. Arb, through python-flint, encloses rounding and
integration error in intervals. It does not replace the paper's analytical
proofs or certify global equilibrium uniqueness.

## 1. Why participation information suffices for probing

The main-paper example uses

```text
buyer values:                       U[0,1]
late-buyer counts (n_L,n_H):         (2,6)
seller value in both states:        0.4
seller resolution benefit:          0 in both states
Pr(s=H):                            0.5
offer cost:                         0.02
support of buyer resolution benefit:[0,0.1]
```

The seller state changes only the number of later participants. It does not
change seller preferences. The paper's distribution and regularity assumptions
for buyer types remain in force.

At the highest buyer value, b=1, the competition wedge is zero. The uniform
payoff formulas in the paper therefore give

```text
C_s(1) = R_s(1) = w_s(1) = 1 - (1 - v^(n_s+1))/(n_s+1).
```

The script evaluates the entry thresholds

```text
bar_D_L = C_L(1) - w_L(1) + kappa/(1-pi)
bar_D_H = C_H(1) - [(1-pi)w_L(1) + pi*w_H(1)] + kappa
Delta_D = bar_D_H - bar_D_L
```

with exact rational arithmetic. The results are:

| Quantity | Exact value | Decimal |
|---|---:|---:|
| w_L(1)=C_L(1) | 86/125 | .688 |
| w_H(1)=C_H(1) | 468878/546875 | .857376914286 |
| C_L(0) | 59/125 | .472 |
| bar_D_L | 1/25 | .04 |
| bar_D_H | 114503/1093750 | .104688457143 |
| Delta_D | 70753/1093750 | .064688457143 |
| bar_D_L + Delta_D/pi | 92628/546875 | .169376914286 |

Thus the support limit .1 lies in the sufficient probing window

```text
.04 < .1 <= .169376914286.
```

The remaining lower-type inequality equals .512 and is positive. The sufficient
D1 condition bar_D_L≥0 also holds. The paper's analytical proposition then
provides an equilibrium with waiting, accepted probes and rejected probes.
The exact arithmetic checks the numerical premises of that proposition; it is
not a separate proof of the proposition.

**Why no numerical probing price is reported.** The example specifies the support
of the resolution benefit, not a particular distribution G on that support.
The existence result applies to the maintained class of G. A price, an attempt
rate or a posterior density would require choosing G. This walkthrough does
not silently add that extra assumption. The older composite example below
does choose a truncated-exponential G, but it also uses different seller
parameters and is a different exercise.

## 2. Why a ban can raise or lower welfare

The point estimates come from
[audit_ban_welfare_examples.py](audit_ban_welfare_examples.py), called unchanged
by the entry point. It solves both price fixed points twice, with higher
quadrature resolution on the second pass. It checks cutoff interiority,
positive action probabilities, seller responses, D1 endpoint inequalities,
and agreement between two welfare decompositions.

The two examples share all primitives except the common distribution of early
and late buyer values. Both value distributions have mean .5:

```text
F^S = .01 U[0,1] + .99 Beta(40,40)
F^T = .01 U[0,1] + .99 [(16/17) Beta(38,42) + (1/17) Beta(9,1)]
G   = .0001 U[0,1] + .9999 Beta(1,30)
```

Here (n_L,n_H)=(2,6), (v_L,v_H)=(.2,.4), pi=.5 and kappa=.02.
Both seller resolution benefits are zero. This is **not** the participation-only
example above: in the ban examples seller fallback values differ across states,
and G is fully specified.

| Output | Concentrated values F^S | Upper-tail mixture F^T |
|---|---:|---:|
| Probing price q_L | .510980593208 | .515613314494 |
| Knockout price q_H | .554378791664 | .640626332049 |
| Rejected attempt | .056313655095 | .066739617301 |
| Successful pre-emption | .154353208514 | .068388497142 |
| Avoided offer costs | .004213337272 | .002702562289 |
| Allocative gain from the ban | .003883522055 | .002757306596 |
| Forgone resolution gains | .011624510881 | .005156517170 |
| W^B−W^D | −.003527651553 | +.000303351715 |

These are point estimates. The script's dictionary field `timing_costs`
corresponds to forgone resolution gains in this table; its older variable names
do not change the economic accounting. It also reports the identity
W^B−W^D = excluded late-buyer surplus − buyer gain − seller gain.

The second distribution places more probability near the upper end while
holding the mean fixed. Both prices and the types selecting early offers
differ between the two equilibria. The comparison establishes two opposite
welfare rankings; it is not a general comparative-statics theorem for every
change in an upper tail.

## 3. Certifying the welfare signs

[certify_ban_welfare_examples.py](certify_ban_welfare_examples.py) is the
authoritative interval check for these two examples. `--certify` calls it
unchanged with its `--json` option. The calculation uses 60 decimal digits and
24,000 integration cells.

The certificate encloses an exact price fixed point in each reported box,
checks the strict equilibrium and refinement inequalities, and encloses both
welfare differences away from zero. It establishes local uniqueness inside
the reported boxes, not global uniqueness. Its analytical basis and numerical
bounds belong in the main paper's appendix because the main paper relies on
these examples.

The delegated solver can also be run directly:

```text
python code/certify_ban_welfare_examples.py --json
```

The entry point reports the certificate's bounds instead of relabeling the
floating-point digits as certified precision.

## 4. Calculations for the online appendix

The following map identifies the existing implementations. The default
`paper_calculations.py` invocation does not run these additional exercises.

| Question | Online-appendix topic | Existing calculation |
|---|---|---|
| Three-action equilibrium when all three seller components vary | Further examples | [certify_aligned_composite_full_menu.py](certify_aligned_composite_full_menu.py); independent floating-point comparison in [audit_aligned_composite_calibration.py](audit_aligned_composite_calibration.py) |
| Survival of waiting–knockout under seller-resolution information | Further regimes | [certify_urgency_only_knockout_gate.py](certify_urgency_only_knockout_gate.py); [audit_urgency_only_knockout_only_d1.py](audit_urgency_only_knockout_only_d1.py) |
| Seller-resolution benefits as the private state | Further regimes | [audit_seller_urgency_only_refined_pbe.py](audit_seller_urgency_only_refined_pbe.py) |
| Disclosure of participation information | Disclosure | [verify_continuous_demand_disclosure.py](verify_continuous_demand_disclosure.py); [audit_disclosure_welfare_examples.py](audit_disclosure_welfare_examples.py) |
| Insurance as a reason to reach early agreement | Risk aversion | [risk_aversion_strong_binary_cara_certificate.py](risk_aversion_strong_binary_cara_certificate.py) |
| Further bargaining before the auction | Alternative protocols | [audit_unit_urgency_renegotiation_independent.py](audit_unit_urgency_renegotiation_independent.py) |
| Seller counteroffers after bidding | Alternative protocols | [certify_full_linkage_counteroffer_equilibrium.py](certify_full_linkage_counteroffer_equilibrium.py) |
| Private offers during bidding | Conditional analysis, if retained | [check_mid_auction_local_incentives.py](check_mid_auction_local_incentives.py); this checks local incentives at a specified history, not a complete dynamic equilibrium |

Keep only exercises corresponding to results retained in the final appendix.
These links also make it possible to inspect an omitted research example
without treating it as necessary support for the main paper.

## 5. Figures and the full reproduction archive

The restored economic diagrams are reproducible TeX/TikZ sources. The
distribution plots are generated by
[generate_numerical_distribution_figures.py](generate_numerical_distribution_figures.py).
The full-menu outcome and price-geometry diagrams are generated by
[generate_theory_figure_data.py](generate_theory_figure_data.py).
The older probing-regime strip uses a composite seller calibration and should
not be mistaken for the new participation-only example.

[run_reproduction.py](run_reproduction.py) remains the complete archival runner:

```text
python code/run_reproduction.py --validate-manifest
python code/run_reproduction.py --mode publication --list
python code/run_reproduction.py --mode publication
```

Its figure round-trip tasks run in isolated copies. The runner records logs,
source hashes, environment metadata and claim-level outcomes under a fresh
result directory.

The current [claims.json](claims.json) still contains the long manuscript's
result labels and older section references. Its `core` includes several
online-appendix certificates; it does not mean “main paper only” or “quick”.
Its `publication` includes diagnostic research exercises as well as certificates.
The participation-only example is now registered in that manifest, bringing
the complete suite to 22 tasks. The workbook supplies the current section map
without rewriting or duplicating the existing economic solvers.

The new release packages the guide, all registered calculations, pinned
dependencies, figure data, recorded outputs and source hashes together.
Its notebook runs top to bottom and its HTML can be read without Python.
The older `ComputationalSupplement.zip` remains a historical release.

## Verification of this entry point

Checked on 19 September 2026:

- Default invocation: passed with Python 3.12.14 and numpy 2.3.5, taking about
  eight seconds on the test machine. Both resolutions agreed within
  1.94×10⁻⁹ and 1.03×10⁻⁹ in the respective ban examples.
- `--probing-only --json`: passed with the same Python, using standard-library
  arithmetic and explicitly marking the ban calculations `not_run`.
- `--certify`: passed in a Python 3.12.14 environment with numpy 2.3.5 and
  python-flint 0.9.0. The delegated certificate reported PASS for both welfare
  signs at its standard precision and cell count.

No numerical solver, manifest, manuscript or published artifact was changed
by these checks.
