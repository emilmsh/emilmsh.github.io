"""Audit: knockout-only PBE and criterion D1 under urgency-only seller states.

Setting (urgency-only microfoundation; see notes/176-urgency-only-parity.md).
The terminal auction environment is common across seller states: F = U[0,1]
buyer values, n = 2 deterministic late bidders, standing value v = 0.4.  The
seller's private state is its timing cost z_s: state L is the urgent seller
with cost z_U, state H the patient seller with cost z_P < z_U, so

    C_L(b) = R(b) - z_U  <  C_H(b) = R(b) - z_P,
    w_L(b) = w_H(b) = w(b)   (a global willingness plateau, Delta_w = 0).

Baseline primitives follow Example prop:sellerurgencystate in
manuscripts/Manuscript.tex: z_U = 0.02, z_P = 0, Pr(H) = pi = 1/2,
kappa = 0.01, buyer urgency truncated-exponential(rate 10) on [0, 1].

The script:
  A. reproduces the manuscript's full-menu urgency-only fixed point as a
     validation of the integration machinery;
  B. solves the boundary knockout-only fixed point
     q* = E[C_H(b) | w(b) + d >= q* + kappa] and its action masses;
  C. audits the strict-gain contingent-plan D1 completion of the
     knockout-only assessment: top permitted marginal value
     b_K^0 = min{1, w^{-1}(q* + kappa)}, the survival gates
       (i)  z_U <= Gamma(b_K^0) + kappa/(1-pi),
       (ii) q*  <= C_H(b_K^0),
     the two-branch deterrence table, and grid checks of the sup deviation
     gain under the branch responses;
  D. reports the survival boundary z_U* = Gamma(b_K^0) + kappa/(1-pi), the
     D1-surviving and raw-PBE knockout-only price bands, failure
     demonstrations for z_U > z_U*, and a z_P sensitivity row;
  E. solves a kappa = 0.05 variant in which the top-value type is itself
     marginal (D_K(1) >= 0) and C_L(1) > q*, so belief on (1, D_K(1)) makes
     both seller states reject every undercut (the note-114 Section 6
     fallback-only template transferred to urgency-only).

Deterministic (no randomness; no seed needed).  Standard library only.
Run:  python audit_urgency_only_knockout_only_d1.py
"""

from __future__ import annotations

from math import exp

# ------------------------------------------------------------------ setup
N_LATE = 2
STANDING_VALUE = 0.4
Z_URGENT = 0.02           # z_U: urgent seller timing cost (state L)
Z_PATIENT = 0.0           # z_P: patient seller timing cost (state H)
PATIENT_PROBABILITY = 0.5  # pi = Pr(s = H)
URGENT_PROBABILITY = 1.0 - PATIENT_PROBABILITY  # A = 1 - pi
ATTEMPT_COST = 0.01       # kappa
BUYER_URGENCY_CAP = 1.0   # dbar
BUYER_URGENCY_RATE = 10.0
PANELS = 131_072          # composite Simpson panels, endpoint inclusive
ROOT_TOL = 1e-15


def willingness(b: float) -> float:
    """Common patient-buyer terminal willingness w(b)."""
    v, n = STANDING_VALUE, N_LATE
    if b <= v:
        return b
    return b - (b ** (n + 1) - v ** (n + 1)) / (n + 1)


def revenue(b: float) -> float:
    """Common seller gross terminal payoff R(b)."""
    v, n = STANDING_VALUE, N_LATE
    if b <= v:
        return (n - 1) / (n + 1) + v ** n - (n - 1) * v ** (n + 1) / (n + 1)
    return ((n - 1) / (n + 1) + b ** n - n * b ** (n + 1) / (n + 1)
            + v ** (n + 1) / (n + 1))


def urgency_cdf(d: float) -> float:
    if d <= 0.0:
        return 0.0
    if d >= BUYER_URGENCY_CAP:
        return 1.0
    normalizer = 1.0 - exp(-BUYER_URGENCY_RATE * BUYER_URGENCY_CAP)
    return (1.0 - exp(-BUYER_URGENCY_RATE * d)) / normalizer


B_GRID = [i / PANELS for i in range(PANELS + 1)]
W_GRID = [willingness(b) for b in B_GRID]
R_GRID = [revenue(b) for b in B_GRID]


def simpson(values: list[float]) -> float:
    n = len(values) - 1
    return (values[0] + values[-1] + 4.0 * sum(values[1:-1:2])
            + 2.0 * sum(values[2:-1:2])) / (3.0 * n)


def bisect(func, lo: float, hi: float, tol: float = ROOT_TOL,
           iterations: int = 200) -> float:
    f_lo, f_hi = func(lo), func(hi)
    if f_lo * f_hi > 0.0:
        raise ValueError(f"no sign change on [{lo}, {hi}]: {f_lo}, {f_hi}")
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        f_mid = func(mid)
        if f_hi * f_mid <= 0.0:
            lo, f_lo = mid, f_mid
        else:
            hi, f_hi = mid, f_mid
        if hi - lo < tol:
            break
    return 0.5 * (lo + hi)


# ---------------------------------------------------- A. full-menu check
def full_menu_map(q_l: float, q_h: float):
    probe_wt, ko_wt, probe_cl, ko_ch = [], [], [], []
    for i in range(PANELS + 1):
        d_l = q_l - W_GRID[i] + ATTEMPT_COST / URGENT_PROBABILITY
        d_h = (q_h - URGENT_PROBABILITY * q_l) / PATIENT_PROBABILITY \
            - W_GRID[i]
        g_l, g_h = urgency_cdf(d_l), urgency_cdf(d_h)
        probe_wt.append(g_h - g_l)
        ko_wt.append(1.0 - g_h)
        probe_cl.append((R_GRID[i] - Z_URGENT) * (g_h - g_l))
        ko_ch.append((R_GRID[i] - Z_PATIENT) * (1.0 - g_h))
    mass_l, mass_h = simpson(probe_wt), simpson(ko_wt)
    return (simpson(probe_cl) / mass_l, simpson(ko_ch) / mass_h,
            mass_l, mass_h)


def part_a() -> None:
    q_l, q_h = 0.58, 0.65
    for _ in range(400):
        t_l, t_h, _, _ = full_menu_map(q_l, q_h)
        if abs(t_l - q_l) < 5e-15 and abs(t_h - q_h) < 5e-15:
            break
        q_l, q_h = t_l, t_h
    t_l, t_h, mass_l, mass_h = full_menu_map(q_l, q_h)
    mass_0 = 1.0 - mass_l - mass_h
    print("== A. validation: manuscript full-menu urgency-only Example ==")
    print(f"(q_L, q_H) = ({q_l:.9f}, {q_h:.9f})   "
          "[manuscript: (.586757, .643708)]")
    print(f"residuals ({t_l - q_l:.2e}, {t_h - q_h:.2e})")
    print(f"masses (M0, ML, MH) = ({mass_0:.9f}, {mass_l:.9f}, {mass_h:.9f})"
          "   [manuscript: (.550185181, .185288486, .264526333)]")
    print(f"outcome probabilities ({mass_0:.6f}, "
          f"{PATIENT_PROBABILITY * mass_l:.6f}, "
          f"{URGENT_PROBABILITY * mass_l + mass_h:.6f})"
          "   [manuscript: (.550185, .092644, .357171)]")


# ------------------------------------- B. knockout-only boundary pricing
def knockout_map(q: float, kappa: float, z_seller: float):
    """Posterior continuation of the seller with timing cost z_seller in
    the knockout pool {(b, d): w(b) + d >= q + kappa}, and pool mass."""
    weights, cont = [], []
    for i in range(PANELS + 1):
        cutoff = q + kappa - W_GRID[i]
        weight = 1.0 - urgency_cdf(cutoff)
        weights.append(weight)
        cont.append((R_GRID[i] - z_seller) * weight)
    mass = simpson(weights)
    return simpson(cont) / mass, mass


def waiting_mass(q: float, kappa: float) -> float:
    return simpson([urgency_cdf(q + kappa - W_GRID[i])
                    for i in range(PANELS + 1)])


def solve_knockout_only(kappa: float, z_patient: float) -> float:
    return bisect(
        lambda q: knockout_map(q, kappa, z_patient)[0] - q, 0.50, 0.687)


def top_marginal_value(q: float, kappa: float) -> float:
    """b_K^0 = min{1, w^{-1}(q + kappa)}: largest feasible wait--knockout
    marginal value, i.e. the top of the D1-tied curve w(b) + d = q + kappa."""
    if willingness(1.0) <= q + kappa:
        return 1.0
    return bisect(lambda b: willingness(b) - (q + kappa),
                  STANDING_VALUE, 1.0)


def sup_deviation_gain(p: float, q: float, kappa: float, rho: float,
                       nb: int = 1601, nd: int = 1601):
    """Grid sup over buyer types (b, d) of the deviation gain
    rho*(w(b)+d-p) - kappa - U*(w(b)+d) against the knockout-only
    equilibrium value U*(z) = max{0, z - q - kappa}."""
    best, arg = -1.0, None
    for i in range(nb):
        b = i / (nb - 1)
        w_b = willingness(b)
        for j in range(nd):
            d = j / (nd - 1) * BUYER_URGENCY_CAP
            z = w_b + d
            gain = rho * (z - p) - kappa - max(0.0, z - q - kappa)
            if gain > best:
                best, arg = gain, (b, d)
    return best, arg


def part_b_to_d() -> None:
    kappa = ATTEMPT_COST
    pi = PATIENT_PROBABILITY
    a = URGENT_PROBABILITY
    q_star = solve_knockout_only(kappa, Z_PATIENT)
    t_k, mass_k = knockout_map(q_star, kappa, Z_PATIENT)
    mass_0 = waiting_mass(q_star, kappa)
    cl_pool, _ = knockout_map(q_star, kappa, Z_URGENT)
    print("\n== B. knockout-only boundary fixed point, Example primitives ==")
    print(f"q* = {q_star:.12f}   residual {t_k - q_star:.2e}")
    print(f"masses: waiting {mass_0:.9f}, knockout {mass_k:.9f} "
          f"(sum {mass_0 + mass_k:.12f})")
    print(f"outcomes: (no offer, rejected, success) = "
          f"({mass_0:.6f}, 0, {mass_k:.6f})")
    print(f"on-path responses: patient indifferent at q* (boundary), "
          f"urgent strict margin q* - E[C_L|pool] = "
          f"{q_star - cl_pool:.9f} (= z_U - z_P)")

    d_k_top = q_star + kappa - willingness(1.0)
    b_k0 = top_marginal_value(q_star, kappa)
    gamma = revenue(b_k0) - willingness(b_k0)
    c_l_top = revenue(b_k0) - Z_URGENT
    c_h_top = revenue(b_k0) - Z_PATIENT
    z_u_star = gamma + kappa / a
    print("\n== C. strict-gain contingent-plan D1 audit at q* ==")
    print(f"D_K(1) = {d_k_top:.9f} < 0, so the top of the tied marginal "
          f"curve w(b)+d = q*+kappa is b_K^0 = {b_k0:.12f}")
    print(f"Gamma(b_K^0) = {gamma:.9f}   [(1-b)^3/3 = {(1-b_k0)**3/3:.9f}]")
    print(f"C_L(b_K^0) = {c_l_top:.9f},  C_H(b_K^0) = {c_h_top:.9f}")
    print(f"gate (i):  z_U = {Z_URGENT} <= Gamma + kappa/A = {z_u_star:.9f}"
          f"   margin {z_u_star - Z_URGENT:.9f}")
    print(f"gate (ii): q* <= C_H(b_K^0)   margin {c_h_top - q_star:.9f}")
    print(f"full-rejection variant C_L(b_K^0) - q* = {c_l_top - q_star:.9f}"
          " (< 0: completion uses the two-branch table below)")
    print("completion: belief delta_(b_K^0, 0) at every p < q*;")
    print(f"  p <  C_L(b_K^0) = {c_l_top:.9f}: both states reject; "
          "sup type gain = -kappa < 0")
    print(f"  p in [C_L(b_K^0), q*): urgent accepts, patient rejects; "
          f"sup type gain = A(q*+kappa-p)-kappa <= "
          f"{a * (q_star + kappa - c_l_top) - kappa:.9f}"
          f"  [= A(z_U - z_U*) = {a * (Z_URGENT - z_u_star):.9f}]")
    checks = [
        (c_l_top, a, "p = C_L(b_K^0), plan (1,0)"),
        (0.5 * (c_l_top + q_star), a, "p mid-branch, plan (1,0)"),
        (q_star - 1e-6, a, "p = q* - 1e-6, plan (1,0)"),
        (c_l_top - 1e-9, 0.0, "p just below C_L(b_K^0), plan (0,0)"),
        (0.30, 0.0, "p = 0.30, plan (0,0)"),
        (q_star + 0.02, 1.0, "overcut p = q* + .02, plan (1,1)"),
    ]
    for p, rho, label in checks:
        gain, arg = sup_deviation_gain(p, q_star, kappa, rho)
        print(f"  grid sup gain, {label}: {gain:.9f} at (b, d) = "
              f"({arg[0]:.5f}, {arg[1]:.5f})")

    print("\n== D. survival boundary and price bands ==")
    z_u_raw = willingness(1.0) - q_star + pi * kappa / a
    print(f"z_U* (D1 boundary)  = Gamma(b_K^0) + kappa/A = {z_u_star:.9f}")
    print(f"z_U^raw (PBE bound) = w(1) - q* + pi*kappa/A = {z_u_raw:.9f}")
    print(f"Example z_U = {Z_URGENT}: knockout-only SURVIVES D1 "
          f"(margin {z_u_star - Z_URGENT:.9f})")

    def psi(q: float, z_u: float) -> float:
        b_top = top_marginal_value(q, kappa)
        return q - pi * kappa / a - (revenue(b_top) - z_u)

    q_max = bisect(lambda q: psi(q, Z_URGENT), q_star, 0.6871)
    print(f"D1-surviving knockout-only price band at z_U = {Z_URGENT}: "
          f"[q*, q_max] = [{q_star:.9f}, {q_max:.9f}]")
    print(f"  (raw-PBE band upper endpoint w(1)-z_U+pi*kappa/A = "
          f"{willingness(1.0) - Z_URGENT + pi * kappa / a:.9f}; "
          "coincides at z_U = kappa/A)")
    q_max_22 = bisect(lambda q: psi(q, 0.022), q_star, 0.6871)
    print(f"  at z_U = 0.022 the band shrinks to [{q_star:.9f}, "
          f"{q_max_22:.9f}]")

    for z_u in (0.025, 0.03, 0.05):
        c_l = revenue(b_k0) - z_u
        hi = q_star - pi * kappa / a
        p_kill = 0.5 * (c_l + hi)
        marginal_gain = a * (q_star + kappa - p_kill) - kappa
        print(f"z_U = {z_u}: killer undercuts ({c_l:.6f}, {hi:.6f}); "
              f"every D1-permitted belief has E[C_L] <= C_L(b_K^0) = "
              f"{c_l:.6f} < p, urgent acceptance is forced, marginal-type "
              f"gain >= {marginal_gain:.6f} > 0  ->  FAILS D1")

    q_star_zp = solve_knockout_only(kappa, 0.005)
    b_k0_zp = top_marginal_value(q_star_zp, kappa)
    gamma_zp = revenue(b_k0_zp) - willingness(b_k0_zp)
    print(f"z_P sensitivity (z_P = 0.005): q* = {q_star_zp:.9f}, "
          f"b_K^0 = {b_k0_zp:.9f}, gap gate z_U - z_P <= "
          f"R(b_K^0) - E[R|pool] + pi*kappa/A = "
          f"{revenue(b_k0_zp) - (q_star_zp + 0.005) + pi * kappa / a:.9f}"
          f"  [here z_U - z_P = {Z_URGENT - 0.005:.4f}]")


# --------------------------------------- E. kappa = 0.05 clean variant
def part_e() -> None:
    kappa = 0.05
    pi, a = PATIENT_PROBABILITY, URGENT_PROBABILITY
    q_star = solve_knockout_only(kappa, Z_PATIENT)
    t_k, mass_k = knockout_map(q_star, kappa, Z_PATIENT)
    mass_0 = waiting_mass(q_star, kappa)
    cl_pool, _ = knockout_map(q_star, kappa, Z_URGENT)
    d_k_top = q_star + kappa - willingness(1.0)
    b_k0 = top_marginal_value(q_star, kappa)
    gamma = revenue(b_k0) - willingness(b_k0)
    print("\n== E. kappa = 0.05 variant: full-rejection counterexample ==")
    print(f"q* = {q_star:.12f}   residual {t_k - q_star:.2e}")
    print(f"masses: waiting {mass_0:.9f}, knockout {mass_k:.9f}")
    print(f"on-path urgent strict margin {q_star - cl_pool:.9f}")
    print(f"D_K(1) = {d_k_top:.9f} >= 0: the top-value type (1, D_K(1)) "
          f"is itself marginal, b_K^0 = {b_k0}")
    print(f"C_L(1) - q* = {revenue(1.0) - Z_URGENT - q_star:.9f} > 0: "
          "belief on (1, D_K(1)) makes BOTH seller states reject every "
          "undercut p < q*")
    print(f"gates: (i) margin {gamma + kappa / a - Z_URGENT:.9f}, "
          f"(ii) margin {revenue(1.0) - Z_PATIENT - q_star:.9f}")
    for p, rho, label in [
        (q_star - 1e-6, 0.0, "p = q* - 1e-6, plan (0,0)"),
        (0.55, 0.0, "p = 0.55, plan (0,0)"),
        (q_star + 0.02, 1.0, "overcut p = q* + .02, plan (1,1)"),
    ]:
        gain, arg = sup_deviation_gain(p, q_star, kappa, rho)
        print(f"  grid sup gain, {label}: {gain:.9f} at (b, d) = "
              f"({arg[0]:.5f}, {arg[1]:.5f})")


if __name__ == "__main__":
    part_a()
    part_b_to_d()
    part_e()
