"""Generate reproducible data for the maintained theory figures.

The script does not edit the manuscript.  It writes:

* ``figures/probing_only_regime_strip.csv``: the exact no-early-offer and
  sufficient probing-only regions in the aligned-composite calibration;
* ``figures/probing_only_outcomes.csv``: its three outcome probabilities;
* ``figures/renegotiation_thresholds.csv``: the canonical repeated-bargaining
  type boundaries ``a(b)``, ``x(b)``, and ``y(b)``; and
* ``figures/theory_figure_metadata.json``: exact constants, labels, and the
  proposed on-path bargaining tree; and
* ``figures/full_menu_outcomes_figure.tex``: the symbolic action-to-outcome
  diagram used in the manuscript; and
* ``figures/full_menu_price_geometry_figure.tex``: the symbolic price-space
  geometry for the three-action fixed-point argument.

All reported constants are re-derived and asserted against the established
notes before any output is written.
"""

from __future__ import annotations

import csv
import json
from fractions import Fraction
from pathlib import Path
from typing import Any

from generate_probing_only_regime_figure import probing_payload


Q = Fraction
ROOT = Path(__file__).resolve().parents[1]
FIGURE_DIR = ROOT / "figures"


def fraction_record(value: Q) -> dict[str, str | float]:
    return {
        "fraction": f"{value.numerator}/{value.denominator}",
        "decimal": float(value),
    }


def probing_data() -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict]:
    """Derive the aligned-composite regime strip and outcome example."""

    regions, outcomes, metadata, _ = probing_payload()
    return regions, outcomes, metadata


def renegotiation_data() -> tuple[list[dict[str, float]], dict]:
    """Derive the canonical q-r-p type partition and path."""
    a_prob = Q(7, 10)
    pi = Q(3, 10)
    kappa = Q(1, 2000)
    c_b = Q(1, 1000)
    c_s = Q(1, 500)
    beta = Q(9, 10)
    w_l_beta = Q(657, 1000)
    q_initial = Q(1, 2)
    p_revision = w_l_beta - (c_b + kappa) / a_prob
    r_counter = a_prob * w_l_beta - kappa + pi
    eta_star = Q(117204341, 120480341)

    if p_revision != Q(573, 875):
        raise AssertionError("The canonical revision price changed")
    if r_counter != Q(3797, 5000):
        raise AssertionError("The canonical counteroffer changed")
    if not q_initial < p_revision < r_counter:
        raise AssertionError("The canonical q-r-p price ordering changed")

    def w_l(b: Q) -> Q:
        return b - b**3 / 3

    def w_h(b: Q) -> Q:
        return b - b**6 / 6

    def x(b: Q) -> Q:
        return w_l_beta - w_l(b)

    def y(b: Q) -> Q:
        return 1 - w_h(b)

    def a_cutoff(b: Q) -> Q:
        return x(b) - kappa / a_prob

    endpoint_values = {
        "x_0": x(Q(0)),
        "x_beta": x(beta),
        "x_1": x(Q(1)),
        "y_0": y(Q(0)),
        "y_beta": y(beta),
        "y_1": y(Q(1)),
    }
    expected_endpoints = {
        "x_0": Q(657, 1000),
        "x_beta": Q(0),
        "x_1": -Q(29, 3000),
        "y_0": Q(1),
        "y_beta": Q(377147, 2000000),
        "y_1": Q(1, 6),
    }
    if endpoint_values != expected_endpoints:
        raise AssertionError("A canonical type boundary changed")
    if not (x(Q(4, 5)) < y(Q(4, 5)) and x(Q(1)) < 0 < y(Q(1))):
        raise AssertionError("The canonical type regions are not ordered")

    rows: list[dict[str, float]] = []
    for index in range(201):
        b = Q(index, 200)
        x_value = x(b)
        rows.append(
            {
                "b": float(b),
                "a": float(a_cutoff(b)),
                "x": float(x_value),
                "x_positive": float(max(Q(0), x_value)),
                "y": float(y(b)),
                "patient_initiates": float(b >= beta),
            }
        )

    metadata = {
        "calibration": {
            "value_distribution": "U[0,1]",
            "late_counts": {"n_L": 2, "n_H": 5},
            "standing_values": {"v_L": 0.0, "v_H": 0.0},
            "A": fraction_record(a_prob),
            "pi": fraction_record(pi),
            "kappa": fraction_record(kappa),
            "c_B": fraction_record(c_b),
            "c_S": fraction_record(c_s),
            "beta": fraction_record(beta),
            "eta_strict_upper": fraction_record(eta_star),
        },
        "prices": {
            "q": fraction_record(q_initial),
            "r": fraction_record(r_counter),
            "p": fraction_record(p_revision),
        },
        "threshold_endpoints": {
            name: fraction_record(value)
            for name, value in endpoint_values.items()
        },
        "type_regions": [
            {
                "region": "wait",
                "condition": "b < beta and 0 <= d < x(b)",
            },
            {
                "region": "initiate_then_revise",
                "condition": "d >= max{x(b),0} and d < y(b)",
            },
            {
                "region": "initiate_then_accept_counteroffer",
                "condition": "d >= y(b)",
            },
        ],
        "patient_types": (
            "On d=0, types b<beta wait and types b>beta initiate and revise; "
            "the b=beta tie is null and is prescribed to initiate."
        ),
        "on_path_tree": [
            {"from": "buyer", "action": "offer q", "to": "seller"},
            {"from": "seller", "action": "counter r", "to": "buyer"},
            {
                "from": "buyer",
                "action": "accept r if d >= y(b)",
                "to": "early agreement in both states",
            },
            {
                "from": "buyer",
                "action": "revise to p if d < y(b)",
                "to": "seller",
            },
            {
                "from": "seller L",
                "action": "accept p",
                "to": "early agreement",
            },
            {
                "from": "seller H",
                "action": "end bargaining after p",
                "to": "planned auction",
            },
        ],
        "caveat": (
            "The diagram represents the constructed PBE for "
            "0 <= eta < eta^dagger. It is not a general characterization of "
            "continuous-type bargaining or a dynamic-refinement result."
        ),
    }
    return rows, metadata


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"No rows supplied for {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def full_menu_figure_tex() -> str:
    """Return the canonical symbolic full-menu outcome diagram."""

    return r"""\begin{figure}[htbp]
\centering
\resizebox{0.98\textwidth}{!}{%
\begin{tikzpicture}[font=\small,
  action box/.style={draw=NHHblue,rounded corners=1.5pt,align=center,
    minimum height=1.0cm,text width=2.55cm,inner sep=4pt,fill=NHHblue!3},
  outcome box/.style={draw=black!50,rounded corners=1.5pt,align=center,
    minimum height=1.0cm,text width=3.85cm,inner sep=4pt,fill=black!2},
  flow/.style={->,>=stealth,semithick},
  branch label/.style={fill=white,inner sep=1.5pt,font=\scriptsize}]
  \node[action box] (buyer) at (0,0) {{\normalsize\bfseries Early buyer}};
  \node[action box] (wait) at (4,2.5)
    {{\normalsize\bfseries Wait}\\[-1pt]{\scriptsize probability \(M_W\)}};
  \node[action box] (probe) at (4,0)
    {{\normalsize\bfseries Probe at \(\bm{q_L}\)}\\[-1pt]{\scriptsize probability \(M_P\)}};
  \node[action box] (knockout) at (4,-2.5)
    {{\normalsize\bfseries Knockout at \(\bm{q_H}\)}\\[-1pt]{\scriptsize probability \(M_K\)}};

  \node[outcome box] (noattempt) at (10,2.5)
    {{\normalsize\bfseries No early offer}\\[-1pt]{\scriptsize probability \(M_W\)}};
  \node[outcome box] (rejected) at (10,0.55)
    {{\normalsize\bfseries Rejected attempt}\\[-1pt]{\scriptsize probability \(\pi M_P\)}};
  \node[outcome box] (success) at (10,-1.85)
    {{\normalsize\bfseries Successful pre-emption}\\[-1pt]{\scriptsize probability \((1-\pi)M_P+M_K\)}};

  \draw[flow] (buyer) -- (wait);
  \draw[flow] (buyer) -- (probe);
  \draw[flow] (buyer) -- (knockout);
  \draw[flow] (wait) -- (noattempt);
  \draw[flow] (probe) -- node[branch label,above,sloped,pos=.56] {state \(H\): \(\pi\)}
    (rejected);
  \draw[flow] (probe) -- node[branch label,above,sloped,pos=.58] {state \(L\): \(1-\pi\)}
    (success);
  \draw[flow] (knockout) -- node[branch label,below,sloped,pos=.56] {either state}
    (success);
\end{tikzpicture}%
}
\caption{Buyer actions and observable outcomes under support \(\{W,P,K\}\). The middle boxes report unconditional action probabilities. A probe is accepted in state \(L\) and rejected in state \(H\), while a knockout offer is accepted in both states. When no buyer chooses knockout (\(M_K=0\)), the diagram reduces to the waiting--probing support \(\{W,P\}\).}
\label{fig:fullmenuoutcomes}
\end{figure}
"""


def full_menu_price_geometry_tex() -> str:
    """Return the canonical price-space geometry for the full-menu proof."""

    return r"""\begin{figure}[htbp]
\centering
\begin{tikzpicture}[
  x=1.55cm,
  y=1.15cm,
  font=\small,
  axis/.style={->,>=stealth,semithick},
  price domain/.style={draw=black!65,semithick},
  bracket/.style={draw=NHHblue,very thick,fill=white,fill opacity=.90},
  face arrow/.style={->,>=stealth,very thick,NHHblue},
  boundary label/.style={font=\scriptsize,fill=white,inner sep=1.5pt}]
  % Schematic affine coordinates: only the ordering geometry is meaningful.
  \fill[NHHblue!7] (0,0.60) -- (5.00,3.60) -- (5.00,5.00) -- (0,5.00) -- cycle;
  \draw[axis] (0,0) -- (5.35,0) node[right] {probing price \(\bm{q_L}\)};
  \draw[axis] (0,0) -- (0,5.35) node[above] {knockout price \(\bm{q_H}\)};
  \draw[price domain] (0,0) rectangle (5,5);
  \node[anchor=south east] at (4.90,0.10) {\(\mathcal Q\)};
  \node[font=\scriptsize,anchor=north] at (2.50,-0.18)
    {\(q_L\in[C_L(\underline b),C_L(\bar b)]\)};
  \node[font=\scriptsize,rotate=90,anchor=south] at (-0.28,2.50)
    {\(q_H\in[C_H(\underline b),C_H(\bar b)]\)};

  \draw[dashed,darkred,very thick] (0,0.60) -- (5.00,3.60)
    node[pos=.84,below right,boundary label] {\(Z(\bar b;q)=0\)};
  \node[font=\scriptsize,NHHblue,align=center] at (3.76,4.54)
    {price ordering: \(Z(b;q)>0\) for all \(b\)};

  \draw[bracket] (0.65,2.65) rectangle (3.05,4.35);
  \node[anchor=north west,NHHblue] at (0.75,4.25) {\(\mathcal Q_0\)};
  \node[font=\scriptsize,anchor=north] at (0.65,2.58) {\(\ell_L\)};
  \node[font=\scriptsize,anchor=south west] at (3.12,2.65) {\(u_L\)};
  \node[font=\scriptsize,anchor=east] at (0.57,2.65) {\(\ell_H\)};
  \node[font=\scriptsize,anchor=east] at (0.57,4.35) {\(u_H\)};

  \draw[face arrow] (0.67,3.30) -- (1.25,3.30);
  \draw[face arrow] (3.03,3.70) -- (2.45,3.70);
  \draw[face arrow] (1.55,2.67) -- (1.55,3.18);
  \draw[face arrow] (2.15,4.33) -- (2.15,3.82);

  \fill[black] (2.25,3.30) circle (1.6pt);
  \node[anchor=west] at (2.30,3.00) {\(\bm q^{\ast}\)};
\end{tikzpicture}
\caption{Price-space geometry for the three-action fixed point. The outer rectangle \(\mathcal Q\) contains all boundary-price candidates. Since \(w_H(b)-w_L(b)\) is weakly increasing, \(Z(b;q)>0\) for every \(b\) is the region above \(Z(\bar b;q)=0\). The proof places \(\mathcal Q_0\) inside this region. The horizontal arrows show the residual \(T_P(q)-q_L\) on the two vertical faces, and the vertical arrows show \(T_K(q)-q_H\) on the two horizontal faces. Their inward directions imply a fixed point \(\bm q^{\ast}\). Other interiority conditions are omitted.}
\label{fig:fullmenupricegeometry}
\end{figure}
"""


def main() -> None:
    FIGURE_DIR.mkdir(exist_ok=True)
    regimes, outcomes, probing_metadata = probing_data()
    thresholds, renegotiation_metadata = renegotiation_data()

    write_csv(FIGURE_DIR / "probing_only_regime_strip.csv", regimes)
    write_csv(FIGURE_DIR / "probing_only_outcomes.csv", outcomes)
    write_csv(FIGURE_DIR / "renegotiation_thresholds.csv", thresholds)
    (FIGURE_DIR / "full_menu_outcomes_figure.tex").write_text(
        full_menu_figure_tex(), encoding="utf-8"
    )
    (FIGURE_DIR / "full_menu_price_geometry_figure.tex").write_text(
        full_menu_price_geometry_tex(), encoding="utf-8"
    )
    metadata = {
        "probing_only_figure": probing_metadata,
        "renegotiation_figure": renegotiation_metadata,
    }
    with (FIGURE_DIR / "theory_figure_metadata.json").open(
        "w", encoding="utf-8"
    ) as handle:
        json.dump(metadata, handle, indent=2)
        handle.write("\n")

    print("THEORY FIGURE DATA: PASS")
    print("  probing strip and three-outcome example reproduced")
    print("  renegotiation type thresholds and q-r-p path reproduced")
    print(f"  wrote six deterministic files under {FIGURE_DIR}")


if __name__ == "__main__":
    main()
