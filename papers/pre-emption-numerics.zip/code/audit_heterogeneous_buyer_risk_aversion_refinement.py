"""Bounded audit of a refined heterogeneous-buyer-CARA probing PBE.

The environment is the demand-only, committed-auction benchmark with two
deterministic late-buyer counts.  The early buyer privately observes both its
value b and its CARA coefficient alpha.  The script solves a continuous-alpha
probing-only candidate and audits the strict-gain interim-D1 test over the
complete rationalizable contingent-plan partition.

The calculation is a high-order quadrature and endpoint-inclusive grid audit,
not interval arithmetic.  Its scope is pure buyer offers, pure
on-path seller responses, independent uniform b and alpha, and the displayed
primitives.  It also evaluates normalized expected utility, population-
interim certainty equivalents, and material surplus for the same refined
assessment.  No random search is used.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.polynomial.legendre import leggauss


Array = np.ndarray

N_L = 2
N_H = 7
PI = 0.5
A = 1.0 - PI
KAPPA = 0.01
ALPHA_MAX = 5.0

PRIMARY_ORDER = 512
CHECK_ORDER = 256
ROOT_ITERATIONS = 64
WELFARE_PRIMARY_ORDERS = (512, 384)
WELFARE_CHECK_ORDERS = (256, 192)


def _moment_coefficients(n: int, terms: int = 64) -> Array:
    """Coefficients of n int_0^1 z^(n-1) exp[-x(1-z)] dz.

    The coefficient on x^j is (-1)^j n!/(n+j)!.  On the audited domain
    x=alpha*b is in [0,5], and 64 terms leave a negligible truncation tail.
    """

    coefficients = [1.0]
    for j in range(1, terms):
        coefficients.append(-coefficients[-1] / (n + j))
    return np.asarray(coefficients)


MOMENT_COEFFICIENTS = {
    N_L: _moment_coefficients(N_L),
    N_H: _moment_coefficients(N_H),
}


def buyer_moment(n: int, b: Array | float, alpha: Array | float) -> Array | float:
    """E exp[-alpha (b-Y_1)^+] for n iid U[0,1] late values."""

    values = np.asarray(b, dtype=float)
    curvature = np.asarray(alpha, dtype=float)
    active = np.polynomial.polynomial.polyval(
        curvature * values,
        MOMENT_COEFFICIENTS[n],
    )
    answer = 1.0 - values**n + values**n * active
    return float(answer) if answer.ndim == 0 else answer


def transformed_moment(
    n: int,
    b: Array | float,
    alpha: Array | float,
) -> Array | float:
    return np.exp(np.asarray(alpha) * np.asarray(b)) * buyer_moment(n, b, alpha)


def revenue(n: int, b: Array | float) -> Array | float:
    """Risk-neutral seller revenue in the terminal second-price auction."""

    return (n - 1) / (n + 1) + np.asarray(b) ** n - n * np.asarray(b) ** (
        n + 1
    ) / (n + 1)


def integrated_revenue(n: int, lower: Array | float) -> Array | float:
    """Integral of R_n(b) from lower to one."""

    lower = np.asarray(lower)
    return (
        (n - 1) * (1.0 - lower) / (n + 1)
        + (1.0 - lower ** (n + 1)) / (n + 1)
        - n * (1.0 - lower ** (n + 2)) / ((n + 1) * (n + 2))
    )


def wait_moment(b: Array | float, alpha: Array | float) -> Array | float:
    return A * buyer_moment(N_L, b, alpha) + PI * buyer_moment(N_H, b, alpha)


def probe_moment(
    b: Array | float,
    alpha: Array | float,
    price: float,
) -> Array | float:
    b = np.asarray(b)
    alpha = np.asarray(alpha)
    return np.exp(alpha * KAPPA) * (
        A * np.exp(-alpha * (b - price)) + PI * buyer_moment(N_H, b, alpha)
    )


def log_probe_wait_ratio(
    b: Array | float,
    alpha: Array | float,
    price: float,
) -> Array | float:
    return np.log(probe_moment(b, alpha, price) / wait_moment(b, alpha))


def bisect(function, lower: float, upper: float) -> float:
    f_lower = float(function(lower))
    f_upper = float(function(upper))
    if f_lower * f_upper > 0.0:
        raise ValueError(f"root is not bracketed: {f_lower=}, {f_upper=}")
    for _ in range(ROOT_ITERATIONS):
        midpoint = 0.5 * (lower + upper)
        f_midpoint = float(function(midpoint))
        if f_lower * f_midpoint <= 0.0:
            upper = midpoint
        else:
            lower = midpoint
            f_lower = f_midpoint
    return 0.5 * (lower + upper)


def boundary_values(alpha: Array, price: float) -> Array:
    """Unique wait--probe boundary beta(alpha), vectorized in alpha."""

    lower = np.zeros_like(alpha)
    upper = np.ones_like(alpha)
    for _ in range(ROOT_ITERATIONS):
        midpoint = 0.5 * (lower + upper)
        residual = log_probe_wait_ratio(midpoint, alpha, price)
        upper = np.where(residual <= 0.0, midpoint, upper)
        lower = np.where(residual > 0.0, midpoint, lower)
    return 0.5 * (lower + upper)


@dataclass(frozen=True)
class Candidate:
    price: float
    alpha_min: float
    probe_mass: float
    beta_at_alpha_max: float
    h_posterior_revenue: float


def solve_candidate(order: int) -> Candidate:
    """Solve q=T(q) jointly with beta(alpha_min)=1.

    Conditional seller means do not depend on the uniform alpha density's
    normalizing constant.  The probe mass does, and is normalized only after
    the joint endpoint has been found.
    """

    nodes, weights = leggauss(order)

    def price_map(price: float) -> tuple[float, float, float, float]:
        alpha_min = bisect(
            lambda alpha: log_probe_wait_ratio(1.0, alpha, price),
            0.001,
            1.0,
        )
        alpha = alpha_min + (ALPHA_MAX - alpha_min) * (nodes + 1.0) / 2.0
        alpha_weights = weights * (ALPHA_MAX - alpha_min) / 2.0
        beta = boundary_values(alpha, price)
        probe_area = float(np.dot(alpha_weights, 1.0 - beta))
        mapped_price = float(
            np.dot(alpha_weights, integrated_revenue(N_L, beta)) / probe_area
        )
        h_mean = float(
            np.dot(alpha_weights, integrated_revenue(N_H, beta)) / probe_area
        )
        return mapped_price, alpha_min, probe_area, h_mean

    # Below about .6467 even an alpha=0 top type probes, so the joint
    # endpoint equation has no positive-alpha root.  The fixed point lies in
    # the following feasible bracket.
    price = bisect(lambda q: price_map(q)[0] - q, 0.65, 0.665)
    mapped_price, alpha_min, probe_area, h_mean = price_map(price)
    if abs(mapped_price - price) > 5e-12:
        raise AssertionError("fixed-point residual is too large")
    beta_at_alpha_max = bisect(
        lambda b: log_probe_wait_ratio(b, ALPHA_MAX, price),
        0.5,
        0.95,
    )
    probe_mass = probe_area / (ALPHA_MAX - alpha_min)
    return Candidate(
        price,
        alpha_min,
        probe_mass,
        beta_at_alpha_max,
        h_mean,
    )


@dataclass(frozen=True)
class RawAudit:
    single_crossing_margin: float
    h_rejection_margin: float
    top_l_rejection_margin: float
    knockout_ce_loss: float
    knockout_min_alpha: float
    knockout_min_b: float


def raw_pbe_audit(candidate: Candidate) -> RawAudit:
    # The derivative of the transformed wait--probe difference has the sign
    # of A(1-b^2)-pi(exp(alpha*kappa)-1)(1-b^7).  The ratio
    # (1-b^2)/(1-b^7) is at least 2/7, so this is a global analytic margin.
    single_crossing_margin = (
        2.0 * A / N_H - PI * np.expm1(ALPHA_MAX * KAPPA)
    )

    top_l_rejection_margin = float(revenue(N_L, 1.0) - candidate.price)
    h_rejection_margin = candidate.h_posterior_revenue - candidate.price

    # Under the off-path belief b=1, the cheapest price accepted in both
    # states is R_H(1).  Check every (b,alpha) on an endpoint-inclusive mesh.
    knockout_price = float(revenue(N_H, 1.0))
    b_grid = np.linspace(0.0, 1.0, 2_001)
    best = (np.inf, np.nan, np.nan)
    for alpha in np.linspace(candidate.alpha_min, ALPHA_MAX, 1_001):
        waiting = wait_moment(b_grid, alpha)
        probing = probe_moment(b_grid, alpha, candidate.price)
        equilibrium = np.minimum(waiting, probing)
        knockout = np.exp(alpha * KAPPA - alpha * (b_grid - knockout_price))
        ce_loss = np.log(knockout / equilibrium) / alpha
        index = int(np.argmin(ce_loss))
        if ce_loss[index] < best[0]:
            best = (float(ce_loss[index]), alpha, float(b_grid[index]))

    return RawAudit(
        single_crossing_margin,
        h_rejection_margin,
        top_l_rejection_margin,
        best[0],
        best[1],
        best[2],
    )


@dataclass(frozen=True)
class D1Audit:
    undercut_gamma_slope_max: float
    undercut_endpoint_excess_max: float
    undercut_min_b: float
    undercut_max_b: float
    high_price_cutoff: float
    high_threshold_slope_max: float
    high_endpoint_excess_max: float
    high_min_b: float
    high_max_b: float
    high_threshold_at_cutoff: float


def d1_audit(candidate: Candidate) -> D1Audit:
    q = candidate.price
    alpha0 = candidate.alpha_min

    # Exact marginal curve and its cross-alpha gain index.  Dividing Gamma by
    # q-p removes the mechanically vanishing factor as p approaches q.
    frontier_alpha = np.linspace(alpha0, ALPHA_MAX, 5_001)
    frontier_beta = boundary_values(frontier_alpha, q)
    frontier_beta[0] = 1.0
    frontier_z_l = transformed_moment(N_L, frontier_beta, frontier_alpha)

    undercut_prices = np.linspace(float(revenue(N_L, 0.0)), q - 1e-7, 301)
    gamma_slope_max = -np.inf
    for price in undercut_prices:
        gamma = (
            (np.exp(frontier_alpha * q) - np.exp(frontier_alpha * price))
            / (frontier_z_l - np.exp(frontier_alpha * q))
            / (q - price)
        )
        slopes = np.diff(gamma) / np.diff(frontier_alpha)
        gamma_slope_max = max(gamma_slope_max, float(np.max(slopes)))

    # Full-type grid check: this includes waiters below every frontier, not
    # merely the marginal curve.  The endpoint (alpha0,1) is inserted exactly.
    alpha_grid = np.linspace(alpha0, ALPHA_MAX, 401)
    b_grid = np.linspace(0.0, 1.0, 801)
    alpha, b = np.meshgrid(alpha_grid, b_grid, indexing="ij")
    m_l = buyer_moment(N_L, b, alpha)
    m_h = buyer_moment(N_H, b, alpha)
    waiting = A * m_l + PI * m_h
    probing = np.exp(alpha * KAPPA) * (
        A * np.exp(-alpha * (b - q)) + PI * m_h
    )
    equilibrium = np.minimum(waiting, probing)
    rejected_attempt = np.exp(alpha * KAPPA) * waiting

    undercut_endpoint_excess_max = -np.inf
    undercut_min_b = np.inf
    undercut_max_b = -np.inf
    for price in undercut_prices:
        denominator = A * np.exp(alpha * KAPPA) * (
            m_l - np.exp(-alpha * (b - price))
        )
        threshold = np.full_like(denominator, np.inf)
        valid = denominator > 1e-14
        threshold[valid] = (
            rejected_attempt[valid] - equilibrium[valid]
        ) / denominator[valid]
        threshold[threshold >= 1.0] = np.inf
        index = np.unravel_index(int(np.argmin(threshold)), threshold.shape)

        endpoint_threshold = float(threshold[0, -1])
        grid_minimum = float(threshold[index])
        undercut_endpoint_excess_max = max(
            undercut_endpoint_excess_max,
            endpoint_threshold - grid_minimum,
        )
        undercut_min_b = min(undercut_min_b, float(b[index]))
        undercut_max_b = max(undercut_max_b, float(b[index]))

    # For p in [R_H(0),R_H(1)], L accepts for every posterior and only H's
    # acceptance probability x can vary.  Within an alpha slice the threshold
    # is minimized at b=1.  The exact top-line formula gives the cross-alpha
    # ordering and the last price at which any type can gain even when x=1.
    def top_h_threshold(alpha_value: Array | float, price: float) -> Array | float:
        alpha_value = np.asarray(alpha_value)
        z_h = transformed_moment(N_H, 1.0, alpha_value)
        return (A / PI) * (
            np.exp(alpha_value * price) - np.exp(alpha_value * q)
        ) / (z_h - np.exp(alpha_value * price))

    high_price_cutoff = bisect(
        lambda p: top_h_threshold(ALPHA_MAX, p) - 1.0,
        0.80,
        0.825,
    )
    high_prices = np.linspace(
        float(revenue(N_H, 0.0)),
        high_price_cutoff - 1e-7,
        201,
    )
    high_threshold_slope_max = -np.inf
    for price in high_prices:
        threshold = top_h_threshold(frontier_alpha, price)
        slopes = np.diff(threshold) / np.diff(frontier_alpha)
        high_threshold_slope_max = max(
            high_threshold_slope_max,
            float(np.max(slopes)),
        )

    high_endpoint_excess_max = -np.inf
    high_min_b = np.inf
    high_max_b = -np.inf
    for price in high_prices:
        certain = np.exp(-alpha * (b - price))
        base = np.exp(alpha * KAPPA) * (A * certain + PI * m_h)
        denominator = np.exp(alpha * KAPPA) * PI * (m_h - certain)
        threshold = np.full_like(denominator, np.inf)
        valid = denominator > 1e-14
        threshold[valid] = (base[valid] - equilibrium[valid]) / denominator[valid]
        threshold[threshold >= 1.0] = np.inf
        index = np.unravel_index(int(np.argmin(threshold)), threshold.shape)
        endpoint_threshold = float(threshold[-1, -1])
        grid_minimum = float(threshold[index])
        high_endpoint_excess_max = max(
            high_endpoint_excess_max,
            endpoint_threshold - grid_minimum,
        )
        high_min_b = min(high_min_b, float(b[index]))
        high_max_b = max(high_max_b, float(b[index]))

    high_threshold_at_cutoff = float(
        top_h_threshold(ALPHA_MAX, high_price_cutoff)
    )
    return D1Audit(
        gamma_slope_max,
        undercut_endpoint_excess_max,
        undercut_min_b,
        undercut_max_b,
        high_price_cutoff,
        high_threshold_slope_max,
        high_endpoint_excess_max,
        high_min_b,
        high_max_b,
        high_threshold_at_cutoff,
    )


@dataclass(frozen=True)
class WelfareAudit:
    probe_mass: float
    normalized_buyer_change: float
    seller_change: float
    late_buyer_change: float
    normalized_total_change: float
    interim_buyer_ce_change: float
    interim_summed_ce_change: float
    material_attempt_loss: float
    material_allocation_loss: float
    material_total_change: float
    alpha_conditional_exante_buyer_ce_change: float
    alpha_conditional_exante_summed_ce_change: float


def welfare_audit(
    candidate: Candidate,
    alpha_order: int,
    b_order: int,
) -> WelfareAudit:
    """Evaluate Note 130's welfare conventions for the refined assessment.

    Each CARA type is normalized by
    phi_alpha(x)=(1-exp(-alpha*x))/alpha, so phi_alpha(0)=0 and
    phi_alpha'(0)=1.  Seller and late-buyer utilities are linear with unit
    slopes, and all population types receive unit weight.  Material surplus
    treats all of kappa as a resource cost.

    The final two fields use an additional, explicitly conditional timing:
    take each alpha type's CE before b is drawn and then average over alpha.
    They are not a representative-agent CE before alpha is drawn.
    """

    alpha_nodes, alpha_weights = leggauss(alpha_order)
    alpha_values = candidate.alpha_min + (
        ALPHA_MAX - candidate.alpha_min
    ) * (alpha_nodes + 1.0) / 2.0
    # Mapping contributes the support width, while the uniform-alpha density
    # divides by the same width.
    alpha_weights = alpha_weights / 2.0
    beta = boundary_values(alpha_values, candidate.price)

    b_nodes, b_weights = leggauss(b_order)
    unit_nodes = (b_nodes + 1.0) / 2.0
    unit_weights = b_weights / 2.0
    b = beta[:, None] + (1.0 - beta[:, None]) * unit_nodes[None, :]
    alpha = alpha_values[:, None]
    weights = (
        alpha_weights[:, None]
        * (1.0 - beta[:, None])
        * unit_weights[None, :]
    )

    m_l = buyer_moment(N_L, b, alpha)
    m_h = buyer_moment(N_H, b, alpha)
    waiting = A * m_l + PI * m_h
    probing = np.exp(alpha * KAPPA) * (
        A * np.exp(-alpha * (b - candidate.price)) + PI * m_h
    )

    expected_phi_l = (1.0 - m_l) / alpha
    expected_phi_h = (1.0 - m_h) / alpha
    expected_phi_h_after_cost = (1.0 - np.exp(alpha * KAPPA) * m_h) / alpha
    accepted_phi = (
        1.0 - np.exp(alpha * KAPPA - alpha * (b - candidate.price))
    ) / alpha
    normalized_buyer = A * (accepted_phi - expected_phi_l) + PI * (
        expected_phi_h_after_cost - expected_phi_h
    )
    interim_buyer_ce = -np.log(probing / waiting) / alpha

    seller = A * (candidate.price - revenue(N_L, b))
    # Seller revenue plus aggregate late-buyer surplus equals Y_1.  Accepted
    # probing in L therefore removes late surplus 2/3-R_2(b).
    late_buyers = A * (revenue(N_L, b) - N_L / (N_L + 1))
    allocation_loss = A * (
        N_L / (N_L + 1) - b + b ** (N_L + 1) / (N_L + 1)
    )

    def integrate(values: Array) -> float:
        return float(np.sum(weights * values))

    probe_mass = integrate(np.ones_like(b))
    normalized_buyer_change = integrate(normalized_buyer)
    seller_change = integrate(seller)
    late_buyer_change = integrate(late_buyers)
    interim_buyer_ce_change = integrate(interim_buyer_ce)
    material_attempt_loss = -KAPPA * probe_mass
    material_allocation_loss = -integrate(allocation_loss)

    # Optional timing convention: first condition on alpha, then compare the
    # CE before b is drawn.  Integrate the waiting region separately.
    b_low = beta[:, None] * unit_nodes[None, :]
    wait_low = wait_moment(b_low, alpha)
    equilibrium_moment_by_alpha = beta * np.sum(
        unit_weights[None, :] * wait_low,
        axis=1,
    ) + (1.0 - beta) * np.sum(
        unit_weights[None, :] * probing,
        axis=1,
    )
    waiting_moment_by_alpha = beta * np.sum(
        unit_weights[None, :] * wait_low,
        axis=1,
    ) + (1.0 - beta) * np.sum(
        unit_weights[None, :] * waiting,
        axis=1,
    )
    alpha_conditional_exante_buyer_ce_change = float(
        np.dot(
            alpha_weights,
            -np.log(equilibrium_moment_by_alpha / waiting_moment_by_alpha)
            / alpha_values,
        )
    )

    return WelfareAudit(
        probe_mass=probe_mass,
        normalized_buyer_change=normalized_buyer_change,
        seller_change=seller_change,
        late_buyer_change=late_buyer_change,
        normalized_total_change=(
            normalized_buyer_change + seller_change + late_buyer_change
        ),
        interim_buyer_ce_change=interim_buyer_ce_change,
        interim_summed_ce_change=(
            interim_buyer_ce_change + seller_change + late_buyer_change
        ),
        material_attempt_loss=material_attempt_loss,
        material_allocation_loss=material_allocation_loss,
        material_total_change=material_attempt_loss + material_allocation_loss,
        alpha_conditional_exante_buyer_ce_change=(
            alpha_conditional_exante_buyer_ce_change
        ),
        alpha_conditional_exante_summed_ce_change=(
            alpha_conditional_exante_buyer_ce_change
            + seller_change
            + late_buyer_change
        ),
    )


def main() -> None:
    candidate = solve_candidate(PRIMARY_ORDER)
    check = solve_candidate(CHECK_ORDER)
    raw = raw_pbe_audit(candidate)
    d1 = d1_audit(candidate)
    welfare = welfare_audit(candidate, *WELFARE_PRIMARY_ORDERS)
    welfare_check = welfare_audit(candidate, *WELFARE_CHECK_ORDERS)

    convergence = {
        "price": abs(candidate.price - check.price),
        "alpha_min": abs(candidate.alpha_min - check.alpha_min),
        "probe_mass": abs(candidate.probe_mass - check.probe_mass),
        "h_mean": abs(candidate.h_posterior_revenue - check.h_posterior_revenue),
    }
    welfare_convergence = {
        name: abs(getattr(welfare, name) - getattr(welfare_check, name))
        for name in WelfareAudit.__dataclass_fields__
    }

    assert max(convergence.values()) < 2e-7
    assert raw.single_crossing_margin > 0.1
    assert raw.h_rejection_margin > 0.19
    assert raw.top_l_rejection_margin > 0.01
    assert raw.knockout_ce_loss > 0.06
    assert d1.undercut_gamma_slope_max < -1.0
    assert d1.undercut_endpoint_excess_max < 2e-9
    assert d1.undercut_min_b == d1.undercut_max_b == 1.0
    assert d1.high_threshold_slope_max < -0.05
    assert d1.high_endpoint_excess_max < 2e-9
    assert d1.high_min_b == d1.high_max_b == 1.0
    assert abs(d1.high_threshold_at_cutoff - 1.0) < 2e-12
    assert max(welfare_convergence.values()) < 5e-9
    assert abs(welfare.probe_mass - candidate.probe_mass) < 5e-10
    assert abs(welfare.seller_change) < 5e-11
    assert welfare.normalized_buyer_change > 0.0013
    assert welfare.late_buyer_change < -0.0009
    assert welfare.normalized_total_change > 0.0004
    assert welfare.interim_buyer_ce_change > 0.002
    assert welfare.interim_summed_ce_change > 0.0011
    assert welfare.material_allocation_loss < -0.0009
    assert welfare.material_total_change < -0.0026
    assert welfare.alpha_conditional_exante_summed_ce_change > 0.0005

    print("CONTINUOUS HETEROGENEOUS-CARA CANDIDATE")
    print(f"  (n_L,n_H,pi,kappa): ({N_L},{N_H},{PI:.1f},{KAPPA:.2f})")
    print(f"  alpha support: [{candidate.alpha_min:.12f},{ALPHA_MAX:.1f}]")
    print(f"  probing price q: {candidate.price:.12f}")
    print(f"  beta(alpha_min): 1.000000000000")
    print(f"  beta(alpha_max): {candidate.beta_at_alpha_max:.12f}")
    print(f"  probe mass: {candidate.probe_mass:.12f}")
    print(f"  no-offer mass: {1.0-candidate.probe_mass:.12f}")
    print(f"  accepted mass: {A*candidate.probe_mass:.12f}")
    print(f"  rejected mass: {PI*candidate.probe_mass:.12f}")
    print("QUADRATURE CONVERGENCE: |order 512 - order 256|")
    for key, value in convergence.items():
        print(f"  {key}: {value:.3e}")
    print("RAW PBE")
    print(f"  analytic single-crossing margin: {raw.single_crossing_margin:.12f}")
    print(f"  H on-path rejection margin: {raw.h_rejection_margin:.12f}")
    print(f"  top-belief L rejection gap: {raw.top_l_rejection_margin:.12f}")
    print(f"  minimum all-state CE loss at R_H(1): {raw.knockout_ce_loss:.12f}")
    print(
        "  all-state loss minimizer (alpha,b): "
        f"({raw.knockout_min_alpha:.12f},{raw.knockout_min_b:.12f})"
    )
    print("COMPLETE CONTINGENT-PLAN D1 AUDIT")
    print(
        "  undercut normalized Gamma slope max: "
        f"{d1.undercut_gamma_slope_max:.12f}"
    )
    print(
        "  undercut endpoint excess over grid minimum: "
        f"{d1.undercut_endpoint_excess_max:.3e}"
    )
    print(
        "  undercut grid-minimizer b range: "
        f"[{d1.undercut_min_b:.12f},{d1.undercut_max_b:.12f}]"
    )
    print(f"  minimum L rejection gap: {raw.top_l_rejection_margin:.12f}")
    print(f"  high-price gain cutoff: {d1.high_price_cutoff:.12f}")
    print(
        "  high-price threshold slope max: "
        f"{d1.high_threshold_slope_max:.12f}"
    )
    print(
        "  high-price endpoint excess over grid minimum: "
        f"{d1.high_endpoint_excess_max:.3e}"
    )
    print(
        "  high-price grid-minimizer b range: "
        f"[{d1.high_min_b:.12f},{d1.high_max_b:.12f}]"
    )
    print(f"  minimum H rejection gap on gain region: {float(revenue(N_H,1.0))-d1.high_price_cutoff:.12f}")
    print("PRICE PARTITION")
    print(f"  p < R_L(0)={float(revenue(N_L,0.0)):.12f}: both reject")
    print(f"  R_L(0) <= p < q={candidate.price:.12f}: only L can mix; D1 b=1 belief rejects")
    print(f"  q <= p <= R_L(1)={float(revenue(N_L,1.0)):.12f}: no buyer gain")
    print(f"  R_L(1) < p < R_H(0)={float(revenue(N_H,0.0)):.12f}: fixed (L accept,H reject), no gain")
    print(f"  R_H(0) <= p < {d1.high_price_cutoff:.12f}: only H can mix; D1 b=1 belief rejects")
    print(f"  {d1.high_price_cutoff:.12f} <= p < R_H(1)={float(revenue(N_H,1.0)):.12f}: no buyer gain")
    print(f"  p = R_H(1)={float(revenue(N_H,1.0)):.12f}: H may mix, no buyer gain")
    print(f"  p > R_H(1)={float(revenue(N_H,1.0)):.12f}: both accept, no buyer gain")
    print("WELFARE AUDIT")
    print("  convention: unit weights; phi_alpha(0)=0, phi_alpha'(0)=1")
    print(f"  normalized buyer change: {welfare.normalized_buyer_change:+.12f}")
    print(f"  seller change: {welfare.seller_change:+.12f}")
    print(f"  late-buyer change: {welfare.late_buyer_change:+.12f}")
    print(f"  normalized total change: {welfare.normalized_total_change:+.12f}")
    print(f"  interim buyer CE change: {welfare.interim_buyer_ce_change:+.12f}")
    print(f"  interim summed CE change: {welfare.interim_summed_ce_change:+.12f}")
    print(f"  material attempt loss: {welfare.material_attempt_loss:+.12f}")
    print(f"  material allocation loss: {welfare.material_allocation_loss:+.12f}")
    print(f"  material total change: {welfare.material_total_change:+.12f}")
    print(
        "  alpha-conditional pre-b buyer CE change: "
        f"{welfare.alpha_conditional_exante_buyer_ce_change:+.12f}"
    )
    print(
        "  alpha-conditional pre-b summed CE change: "
        f"{welfare.alpha_conditional_exante_summed_ce_change:+.12f}"
    )
    print(
        "WELFARE QUADRATURE CONVERGENCE: "
        f"orders {WELFARE_PRIMARY_ORDERS} vs {WELFARE_CHECK_ORDERS}"
    )
    for key, value in welfare_convergence.items():
        print(f"  {key}: {value:.3e}")


if __name__ == "__main__":
    main()
