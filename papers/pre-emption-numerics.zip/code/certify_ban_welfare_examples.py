"""Outward-rounded certificate for the paired ban-welfare examples.

Requires python-flint==0.9.0. The certificate stays inside the continuous
common-F full-menu model displayed in the manuscript. It avoids generic
complex adaptive integration: all distribution functions are polynomial,
while the terminal-auction integrands needed below are monotone or unimodal.
On a rational grid, Arb therefore encloses terminal integrals by upper and
lower cell sums. The outer expectation is a Lebesgue--Stieltjes sum: the
range of each integrand on a cell is multiplied by that cell's exact
value-probability mass.

The script certifies:

1. a locally unique posterior-price fixed point in a displayed box by the
   interval Krawczyk operator;
2. global cutoff interiority, positive action masses, seller-response
   inequalities, and the D1 endpoint inequalities; and
3. opposite signs of W^B-W^D in the symmetric and upper-tail rows.

The cell enclosures use the exact shape facts

    1-F^n and Pr(Y_2>x) are decreasing in x,
    n(1-F)F^(n-1) is unimodal in F,
    w_s and C_s are increasing in b.

Run from the repository root:

    python code/certify_ban_welfare_examples.py
    python code/certify_ban_welfare_examples.py --json
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from math import comb

import flint
from flint import arb, arb_mat, ctx


ctx.dps = 60

GRID_CELLS = 24000
PI = arb("1/2")
A = 1 - PI
V_L = arb("1/5")
V_H = arb("2/5")
KAPPA = arb("1/50")
KAPPA_RESOURCE = KAPPA
URGENCY_UNIFORM_WEIGHT = arb("1/10000")
URGENCY_BETA_WEIGHT = 1 - URGENCY_UNIFORM_WEIGHT


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def interval_record(value, digits=28):
    return {
        "arb": value.str(digits),
        "lower": value.lower().str(digits),
        "upper": value.upper().str(digits),
    }


def beta_cdf(x, alpha, beta):
    degree = alpha + beta - 1
    return sum(
        arb(comb(degree, success))
        * x**success
        * (1 - x) ** (degree - success)
        for success in range(alpha, degree + 1)
    )


@dataclass(frozen=True)
class ValueCase:
    label: str
    components: tuple[tuple[arb, int | None, int | None], ...]
    center: tuple[str, str]
    radius: str

    def cdf(self, x):
        total = arb(0)
        for weight, alpha, beta in self.components:
            total += weight * (
                x if alpha is None else beta_cdf(x, alpha, beta)
            )
        return total


CASES = (
    ValueCase(
        "symmetric",
        (
            (arb("1/100"), None, None),
            (arb("99/100"), 40, 40),
        ),
        ("0.510980593207608", "0.554378791664074"),
        "4e-4",
    ),
    ValueCase(
        "upper_tail",
        (
            (arb("1/100"), None, None),
            (arb("1584/1700"), 38, 42),
            (arb("99/1700"), 9, 1),
        ),
        ("0.515613314493683", "0.640626332049219"),
        "8e-4",
    ),
)


def urgency_cdf(d):
    return (
        URGENCY_UNIFORM_WEIGHT * d
        + URGENCY_BETA_WEIGHT * (1 - (1 - d) ** 30)
    )


def urgency_density(d):
    return (
        URGENCY_UNIFORM_WEIGHT
        + URGENCY_BETA_WEIGHT * 30 * (1 - d) ** 29
    )


def urgency_tail_first_moment(d):
    complement = 1 - d
    return (
        URGENCY_UNIFORM_WEIGHT * (1 - d**2) / 2
        + URGENCY_BETA_WEIGHT
        * (
            complement**30
            - arb(30) / 31 * complement**31
        )
    )


def urgency_excess(d):
    return urgency_tail_first_moment(d) - d * (1 - urgency_cdf(d))


def monotone_image(function, interval):
    """Tight enclosure from endpoint images of a monotone function."""

    return function(interval.lower()).union(function(interval.upper()))


def range_union(left, right):
    return left.union(right)


@dataclass
class StateGrid:
    w: list[arb]
    continuation: list[arb]
    excluded: list[arb]

    def cell_ranges(self, index):
        return (
            range_union(self.w[index], self.w[index + 1]),
            range_union(
                self.continuation[index],
                self.continuation[index + 1],
            ),
            range_union(self.excluded[index], self.excluded[index + 1]),
        )


@dataclass
class CaseGrid:
    case: ValueCase
    cdf: list[arb]
    probability: list[arb]
    low: StateGrid
    high: StateGrid


def probability_integrands(cdf, bidders):
    first_survival = []
    second_survival = []
    excluded = []
    for value in cdf:
        first_survival.append(1 - value**bidders)
        excluded_value = bidders * (1 - value) * value ** (bidders - 1)
        excluded.append(excluded_value)
        second_survival.append(1 - value**bidders - excluded_value)
    return first_survival, second_survival, excluded


def decreasing_cell_ranges(values):
    return [
        range_union(values[index + 1], values[index])
        for index in range(GRID_CELLS)
    ]


def excluded_cell_ranges(cdf, bidders):
    def excluded_probability(value):
        return bidders * (1 - value) * value ** (bidders - 1)

    ranges = []
    for index in range(GRID_CELLS):
        probability_range = range_union(cdf[index], cdf[index + 1])
        cell_range = range_union(
            excluded_probability(cdf[index]),
            excluded_probability(cdf[index + 1]),
        )
        peak = arb(bidders - 1) / bidders
        if probability_range.contains(peak):
            cell_range = cell_range.union(excluded_probability(peak))
        ranges.append(cell_range)
    return ranges


def suffix_integrals(cell_ranges, start):
    width = arb(1) / GRID_CELLS
    suffix = [arb(0) for _ in range(GRID_CELLS + 1)]
    for index in range(GRID_CELLS - 1, start - 1, -1):
        suffix[index] = suffix[index + 1] + width * cell_ranges[index]
    return suffix


def build_state(cdf, bidders, fallback):
    fallback_index = int(float(fallback) * GRID_CELLS)
    require(
        (arb(fallback_index) / GRID_CELLS - fallback).contains(0),
        ("fallback does not align with certificate grid", fallback),
    )
    first, second, _ = probability_integrands(cdf, bidders)
    first_cells = decreasing_cell_ranges(first)
    second_cells = decreasing_cell_ranges(second)
    excluded_cells = excluded_cell_ranges(cdf, bidders)

    width = arb(1) / GRID_CELLS
    first_prefix = [arb(0) for _ in range(GRID_CELLS + 1)]
    for index in range(fallback_index, GRID_CELLS):
        first_prefix[index + 1] = (
            first_prefix[index] + width * first_cells[index]
        )
    second_suffix = suffix_integrals(second_cells, fallback_index)
    excluded_suffix = suffix_integrals(excluded_cells, fallback_index)

    w, continuation, excluded = [], [], []
    for index in range(GRID_CELLS + 1):
        b = arb(index) / GRID_CELLS
        if index <= fallback_index:
            w_value = b
            gamma_value = fallback - b + second_suffix[fallback_index]
            excluded_value = excluded_suffix[fallback_index]
        else:
            w_value = fallback + first_prefix[index]
            gamma_value = second_suffix[index]
            excluded_value = excluded_suffix[index]
        w.append(w_value)
        continuation.append(w_value + gamma_value)
        excluded.append(excluded_value)

    # The range construction uses the analytical derivatives
    # w'=1-F^n >= 0, C'=n(1-F)F^(n-1) >= 0, and
    # excluded'=-n(1-F)F^(n-1) <= 0.  Endpoint balls need not themselves be
    # ordered because their independent quadrature radii overlap.
    return StateGrid(w, continuation, excluded)


def build_case_grid(case):
    cdf = [case.cdf(arb(index) / GRID_CELLS) for index in range(GRID_CELLS + 1)]
    require(cdf[0].contains(0), ("F(0) failed", case.label, cdf[0]))
    require(cdf[-1].contains(1), ("F(1) failed", case.label, cdf[-1]))
    probability = []
    for index in range(GRID_CELLS):
        mass = cdf[index + 1] - cdf[index]
        require(mass > 0, ("nonpositive value-cell mass", case.label, index, mass))
        probability.append(mass)
    return CaseGrid(
        case,
        cdf,
        probability,
        build_state(cdf, 2, V_L),
        build_state(cdf, 6, V_H),
    )


def cutoff_ranges(q_l, q_h, low_w, high_w):
    d_l = q_l - low_w + KAPPA / A
    d_h = (q_h - A * q_l) / PI - high_w
    return d_l, d_h


def certify_global_interiority(grid, q_l, q_h):
    minimum_gap = None
    minimum_state_ordering = None
    d_l_minimum = None
    d_h_maximum = None
    for index in range(GRID_CELLS):
        low_w, low_c, _ = grid.low.cell_ranges(index)
        high_w, high_c, _ = grid.high.cell_ranges(index)
        d_l, d_h = cutoff_ranges(q_l, q_h, low_w, high_w)
        gap = d_h - d_l
        state_ordering = high_c - low_c
        require(d_l > 0, ("d_L not globally positive", grid.case.label, index, d_l))
        require(1 - d_h > 0, ("d_H not globally below one", grid.case.label, index, d_h))
        require(gap > 0, ("cutoffs cross", grid.case.label, index, gap))
        require(
            state_ordering > 0,
            ("continuation states not ordered", grid.case.label, index, state_ordering),
        )
        if d_l_minimum is None or d_l.lower() < d_l_minimum:
            d_l_minimum = d_l.lower()
        if d_h_maximum is None or d_h.upper() > d_h_maximum:
            d_h_maximum = d_h.upper()
        if minimum_gap is None or gap.lower() < minimum_gap:
            minimum_gap = gap.lower()
        if (
            minimum_state_ordering is None
            or state_ordering.lower() < minimum_state_ordering
        ):
            minimum_state_ordering = state_ordering.lower()
    return (
        arb(d_l_minimum),
        arb(d_h_maximum),
        arb(minimum_gap),
        arb(minimum_state_ordering),
    )


def integrate_statistics(grid, q_l, q_h, include_jacobian=False):
    mass_wait = arb(0)
    mass_probe = arb(0)
    mass_knockout = arb(0)
    residual_l = arb(0)
    residual_h = arb(0)
    probe_c_h = arb(0)
    knockout_c_l = arb(0)
    attempt_resources = arb(0)
    allocation_gain = arb(0)
    timing_costs = arb(0)
    excluded_late = arb(0)
    buyer_rent = arb(0)
    seller_rent = arb(0)
    jacobian = [[arb(0), arb(0)], [arb(0), arb(0)]]

    for index, probability in enumerate(grid.probability):
        low_w, low_c, low_excluded = grid.low.cell_ranges(index)
        high_w, high_c, high_excluded = grid.high.cell_ranges(index)
        d_l, d_h = cutoff_ranges(q_l, q_h, low_w, high_w)
        g_l = monotone_image(urgency_cdf, d_l)
        g_h = monotone_image(urgency_cdf, d_h)
        wait = g_l
        probe = g_h - g_l
        knockout = 1 - g_h

        mass_wait += probability * wait
        mass_probe += probability * probe
        mass_knockout += probability * knockout
        residual_l += probability * probe * (low_c - q_l)
        residual_h += probability * knockout * (high_c - q_h)
        probe_c_h += probability * probe * high_c
        knockout_c_l += probability * knockout * low_c

        attempts = probe + knockout
        gamma_l = low_c - low_w
        gamma_h = high_c - high_w
        attempt_resources += probability * KAPPA_RESOURCE * attempts
        allocation_gain += probability * (
            A * attempts * (gamma_l + low_excluded)
            + PI * knockout * (gamma_h + high_excluded)
        )
        timing_costs += probability * (
            A * monotone_image(urgency_tail_first_moment, d_l)
            + PI * monotone_image(urgency_tail_first_moment, d_h)
        )
        excluded_late += probability * (
            A * attempts * low_excluded
            + PI * knockout * high_excluded
        )
        buyer_rent += probability * (
            A * monotone_image(urgency_excess, d_l)
            + PI * monotone_image(urgency_excess, d_h)
        )
        seller_rent += probability * (
            A * knockout * (high_c - low_c)
        )

        if include_jacobian:
            density_l = monotone_image(urgency_density, d_l)
            density_h = monotone_image(urgency_density, d_h)
            # d_L/d(q_L,q_H)=(1,0);
            # d_H/d(q_L,q_H)=(-1,2).
            probe_q_l = -density_h - density_l
            probe_q_h = 2 * density_h
            knockout_q_l = density_h
            knockout_q_h = -2 * density_h
            jacobian[0][0] += probability * (
                probe_q_l * (low_c - q_l) - probe
            )
            jacobian[0][1] += probability * probe_q_h * (low_c - q_l)
            jacobian[1][0] += probability * knockout_q_l * (high_c - q_h)
            jacobian[1][1] += probability * (
                knockout_q_h * (high_c - q_h) - knockout
            )

    return {
        "masses": (mass_wait, mass_probe, mass_knockout),
        "residual": (residual_l, residual_h),
        "probe_c_h": probe_c_h,
        "knockout_c_l": knockout_c_l,
        "attempt_resources": attempt_resources,
        "allocation_gain": allocation_gain,
        "timing_costs": timing_costs,
        "excluded_late": excluded_late,
        "buyer_rent": buyer_rent,
        "seller_rent": seller_rent,
        "jacobian": jacobian,
    }


def krawczyk_root(grid):
    center = [arb(value).mid() for value in grid.case.center]
    radius = arb(grid.case.radius)
    box = [arb(center[index], radius) for index in range(2)]
    certify_global_interiority(grid, box[0], box[1])

    center_statistics = integrate_statistics(
        grid, center[0], center[1], include_jacobian=True
    )
    box_statistics = integrate_statistics(
        grid, box[0], box[1], include_jacobian=True
    )
    center_jacobian = arb_mat(
        2,
        2,
        [
            center_statistics["jacobian"][row][column].mid()
            for row in range(2)
            for column in range(2)
        ],
    )
    inverse_ball = center_jacobian.inv()
    preconditioner = arb_mat(
        2,
        2,
        [
            inverse_ball[row, column].mid()
            for row in range(2)
            for column in range(2)
        ],
    )
    preconditioner.inv()
    box_jacobian = arb_mat(
        2,
        2,
        [
            box_statistics["jacobian"][row][column]
            for row in range(2)
            for column in range(2)
        ],
    )
    residual = arb_mat(2, 1, center_statistics["residual"])
    displacement = arb_mat(
        2,
        1,
        [box[index] - center[index] for index in range(2)],
    )
    identity = arb_mat(2, 2, [1, 0, 0, 1])
    image = (
        arb_mat(2, 1, center)
        - preconditioner * residual
        + (identity - preconditioner * box_jacobian) * displacement
    )
    image_box = [image[index, 0] for index in range(2)]
    require(
        all(box[index].contains_interior(image_box[index]) for index in range(2)),
        ("Krawczyk inclusion failed", grid.case.label, box, image_box),
    )
    determinant = (
        box_jacobian[0, 0] * box_jacobian[1, 1]
        - box_jacobian[0, 1] * box_jacobian[1, 0]
    )
    require(
        not determinant.contains(0),
        ("singular Jacobian box", grid.case.label, determinant),
    )
    return center, box, image_box, determinant, center_statistics


def certify_case(grid):
    center, root_box, image_box, determinant, center_statistics = krawczyk_root(grid)
    # The Krawczyk image contains the unique root and is typically much tighter
    # than the initial box. Re-evaluate every equilibrium and welfare object
    # on that certified root enclosure.
    interiority = certify_global_interiority(
        grid, image_box[0], image_box[1]
    )
    statistics = integrate_statistics(
        grid, image_box[0], image_box[1], include_jacobian=False
    )
    wait, probe, knockout = statistics["masses"]
    require(wait > 0 and probe > 0 and knockout > 0, ("action mass failed", grid.case.label))
    mass_sum = wait + probe + knockout
    require(mass_sum.contains(1), ("action masses do not sum to one", grid.case.label, mass_sum))

    seller_slacks = (
        statistics["probe_c_h"] / probe - image_box[0],
        image_box[1] - statistics["knockout_c_l"] / knockout,
    )
    require(
        all(slack > 0 for slack in seller_slacks),
        ("seller response failed", grid.case.label, seller_slacks),
    )
    d1_slacks = (
        grid.low.continuation[-1] - image_box[0],
        grid.high.continuation[-1] - image_box[1],
    )
    require(
        all(slack > 0 for slack in d1_slacks),
        ("D1 endpoint failed", grid.case.label, d1_slacks),
    )

    welfare = (
        statistics["attempt_resources"]
        + statistics["allocation_gain"]
        - statistics["timing_costs"]
    )
    rent_identity = (
        statistics["excluded_late"]
        - statistics["buyer_rent"]
        - statistics["seller_rent"]
    )
    require(
        welfare.overlaps(rent_identity),
        ("welfare identities do not overlap", grid.case.label, welfare, rent_identity),
    )
    outcomes = (wait, PI * probe, A * probe + knockout)
    return {
        "center": center,
        "initial_root_box": root_box,
        "root_box": image_box,
        "jacobian_determinant": determinant,
        "center_residual": center_statistics["residual"],
        "interiority": interiority,
        "masses": (wait, probe, knockout),
        "outcomes": outcomes,
        "seller_slacks": seller_slacks,
        "d1_slacks": d1_slacks,
        "welfare": welfare,
        "rent_identity": rent_identity,
        "attempt_resources": statistics["attempt_resources"],
        "allocation_gain": statistics["allocation_gain"],
        "timing_costs": statistics["timing_costs"],
        "excluded_late": statistics["excluded_late"],
    }


def run_certificate():
    require(
        flint.__version__ == "0.9.0",
        ("certificate audited only under python-flint 0.9.0", flint.__version__),
    )
    results = {}
    for case in CASES:
        results[case.label] = certify_case(build_case_grid(case))
    require(
        results["symmetric"]["welfare"] < 0,
        ("symmetric welfare sign failed", results["symmetric"]["welfare"]),
    )
    require(
        results["upper_tail"]["welfare"] > 0,
        ("upper-tail welfare sign failed", results["upper_tail"]["welfare"]),
    )
    return results


def json_payload(results):
    cases = {}
    for label, result in results.items():
        cases[label] = {
            "initial_root_box": [
                interval_record(value) for value in result["initial_root_box"]
            ],
            "certified_root_box": [
                interval_record(value) for value in result["root_box"]
            ],
            "jacobian_determinant": interval_record(
                result["jacobian_determinant"]
            ),
            "global_cutoff_margins": {
                "minimum_d_L": interval_record(result["interiority"][0]),
                "maximum_d_H": interval_record(result["interiority"][1]),
                "minimum_d_H_minus_d_L": interval_record(
                    result["interiority"][2]
                ),
                "minimum_C_H_minus_C_L": interval_record(
                    result["interiority"][3]
                ),
            },
            "action_masses": [
                interval_record(value) for value in result["masses"]
            ],
            "outcomes": [
                interval_record(value) for value in result["outcomes"]
            ],
            "seller_slacks": [
                interval_record(value) for value in result["seller_slacks"]
            ],
            "d1_slacks": [
                interval_record(value) for value in result["d1_slacks"]
            ],
            "welfare": {
                "W_B_minus_W_D": interval_record(result["welfare"]),
                "rent_identity": interval_record(result["rent_identity"]),
                "attempt_resources": interval_record(
                    result["attempt_resources"]
                ),
                "allocation_gain": interval_record(result["allocation_gain"]),
                "timing_costs": interval_record(result["timing_costs"]),
                "excluded_late_surplus": interval_record(
                    result["excluded_late"]
                ),
            },
        }
    return {
        "certificate": "continuous common-F ban-welfare examples",
        "status": "PASS",
        "dependency": {
            "python_flint": flint.__version__,
            "precision_decimal_digits": ctx.dps,
        },
        "grid_cells": GRID_CELLS,
        "method": (
            "Arb cell ranges, monotonicity-based terminal integral enclosures, "
            "Lebesgue-Stieltjes outer sums, and interval Krawczyk roots"
        ),
        "cases": cases,
    }


def display(results):
    def bounds(value, digits=14):
        return (
            f"[{value.lower().str(digits)}, "
            f"{value.upper().str(digits)}]"
        )

    print("PASS: outward-rounded common-F ban-welfare certificate")
    print(f"grid cells: {GRID_CELLS}")
    for label, result in results.items():
        print(f"\n{label.upper()}")
        print("root q_L:", bounds(result["root_box"][0]))
        print("root q_H:", bounds(result["root_box"][1]))
        print("welfare:", bounds(result["welfare"]))
        print("rent identity:", bounds(result["rent_identity"]))
        print("seller slacks:", *(bounds(value) for value in result["seller_slacks"]))
        print("D1 slacks:", *(bounds(value) for value in result["d1_slacks"]))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    arguments = parser.parse_args()
    results = run_certificate()
    if arguments.json:
        print(json.dumps(json_payload(results), indent=2, sort_keys=True))
    else:
        display(results)


if __name__ == "__main__":
    main()
