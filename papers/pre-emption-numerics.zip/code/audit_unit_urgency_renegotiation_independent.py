"""Independent exact audit of the unit-urgency renegotiation candidate.

This script intentionally does not import any earlier model audit.  It
re-derives the auction polynomials, thresholds, posterior integrals, global
deviation margins, and the posterior-consistent recursive tail repair from
the stated primitives using exact rational arithmetic.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Dict, List


Q = Fraction
Poly = List[Q]

A = Q(7, 10)
PI = Q(3, 10)
KAPPA = Q(1, 2000)
C_B = Q(1, 1000)
C_S = Q(1, 500)
BETA = Q(9, 10)
D_BAR = Q(1)
Q_INITIAL = Q(1, 2)
EPSILON = (C_S - C_B) / 2


def trim(poly: Poly) -> Poly:
    result = list(poly)
    while len(result) > 1 and result[-1] == 0:
        result.pop()
    return result


def add(left: Poly, right: Poly) -> Poly:
    size = max(len(left), len(right))
    return trim(
        [
            (left[i] if i < len(left) else Q(0))
            + (right[i] if i < len(right) else Q(0))
            for i in range(size)
        ]
    )


def scale(poly: Poly, scalar: Q) -> Poly:
    return trim([scalar * coefficient for coefficient in poly])


def multiply(left: Poly, right: Poly) -> Poly:
    result = [Q(0)] * (len(left) + len(right) - 1)
    for i, left_coefficient in enumerate(left):
        for j, right_coefficient in enumerate(right):
            result[i + j] += left_coefficient * right_coefficient
    return trim(result)


def evaluate(poly: Poly, point: Q) -> Q:
    return sum(
        coefficient * point**power
        for power, coefficient in enumerate(poly)
    )


def integrate(poly: Poly, lower: Q, upper: Q) -> Q:
    return sum(
        coefficient
        * (upper ** (power + 1) - lower ** (power + 1))
        / Q(power + 1)
        for power, coefficient in enumerate(poly)
    )


ONE: Poly = [Q(1)]
ZERO: Poly = [Q(0)]

# Direct derivation for n late U[0,1] draws:
# w_n(b)=b-b^(n+1)/(n+1),
# C_n(b)=(n-1)/(n+1)+b^n-n*b^(n+1)/(n+1).
W_L: Poly = [Q(0), Q(1), Q(0), -Q(1, 3)]
W_H: Poly = [Q(0), Q(1), Q(0), Q(0), Q(0), Q(0), -Q(1, 6)]
C_L: Poly = [Q(1, 3), Q(0), Q(1), -Q(2, 3)]
C_H: Poly = [Q(2, 3), Q(0), Q(0), Q(0), Q(0), Q(1), -Q(5, 6)]

W_L_BETA = evaluate(W_L, BETA)
P_REVISION = W_L_BETA - (C_B + KAPPA) / A
R_COUNTER = A * W_L_BETA - KAPPA + PI * D_BAR

X = add([W_L_BETA], scale(W_L, -1))
Y = add(ONE, scale(W_H, -1))

# G=U[0,1].  X is positive below beta and negative above it.
WAIT_LOWER = X
WAIT_UPPER = ZERO
REVISE_LOWER = add(Y, scale(X, -1))
REVISE_UPPER = Y
ACCEPT = W_H
ATTEMPT_LOWER = add(ONE, scale(X, -1))
ATTEMPT_UPPER = ONE


def expectation(lower: Poly, upper: Poly) -> Q:
    return integrate(lower, Q(0), BETA) + integrate(
        upper, BETA, Q(1)
    )


def weighted(lower: Poly, upper: Poly, value: Poly) -> Q:
    return expectation(multiply(lower, value), multiply(upper, value))


def run_audit() -> Dict[str, object]:
    if W_L_BETA != Q(657, 1000):
        raise AssertionError("Independent w_L(beta) derivation failed")
    if P_REVISION != Q(573, 875):
        raise AssertionError("Independent p derivation failed")
    if R_COUNTER != Q(3797, 5000):
        raise AssertionError("Independent r derivation failed")
    if not Q_INITIAL < P_REVISION < R_COUNTER:
        raise AssertionError("The path prices are not ordered")

    # Re-derive the post-r thresholds from payoff equalities.
    a = add([P_REVISION + C_B / A], scale(W_L, -1))
    x_from_payoffs = add(a, [KAPPA / A])
    y_from_payoffs = add(
        [(R_COUNTER - A * P_REVISION - C_B) / PI],
        scale(W_H, -1),
    )
    if x_from_payoffs != X or y_from_payoffs != Y:
        raise AssertionError("The candidate thresholds do not solve payoffs")

    threshold_values = {
        "x_0": evaluate(X, Q(0)),
        "x_beta": evaluate(X, BETA),
        "x_1": evaluate(X, Q(1)),
        "y_0": evaluate(Y, Q(0)),
        "y_beta": evaluate(Y, BETA),
        "y_1": evaluate(Y, Q(1)),
    }
    if threshold_values != {
        "x_0": Q(657, 1000),
        "x_beta": Q(0),
        "x_1": -Q(29, 3000),
        "y_0": Q(1),
        "y_beta": Q(377147, 2000000),
        "y_1": Q(1, 6),
    }:
        raise AssertionError("A threshold endpoint failed")

    # y-x has derivative b^5-b^2<0 on (0,1), and remains positive at beta.
    gap_beta = evaluate(add(Y, scale(X, -1)), BETA)
    if gap_beta <= 0:
        raise AssertionError("The revision interval closes at beta")

    z_wait = expectation(WAIT_LOWER, WAIT_UPPER)
    z_p = expectation(REVISE_LOWER, REVISE_UPPER)
    z_accept = expectation(ACCEPT, ACCEPT)
    z_q = expectation(ATTEMPT_LOWER, ATTEMPT_UPPER)
    masses = {
        "wait": z_wait,
        "revise": z_p,
        "accept": z_accept,
        "attempt": z_q,
    }
    expected_masses = {
        "wait": Q(9639, 40000),
        "revise": Q(237581, 840000),
        "accept": Q(10, 21),
        "attempt": Q(30361, 40000),
    }
    if masses != expected_masses:
        raise AssertionError("Independent mass integration disagrees")
    if z_wait + z_p + z_accept != 1:
        raise AssertionError("Action masses do not sum to one")

    c_q = {
        "L": weighted(ATTEMPT_LOWER, ATTEMPT_UPPER, C_L) / z_q,
        "H": weighted(ATTEMPT_LOWER, ATTEMPT_UPPER, C_H) / z_q,
    }
    c_p = {
        "L": weighted(REVISE_LOWER, REVISE_UPPER, C_L) / z_p,
        "H": weighted(REVISE_LOWER, REVISE_UPPER, C_H) / z_p,
    }
    k_r = {
        "L": (P_REVISION * z_p + R_COUNTER * z_accept) / z_q - C_S,
        "H": (
            weighted(REVISE_LOWER, REVISE_UPPER, C_H)
            + R_COUNTER * z_accept
        )
        / z_q
        - C_S,
    }

    c_l_one = evaluate(C_L, Q(1))
    c_h_one = evaluate(C_H, Q(1))
    global_buyer_margins = {
        "initial versus L-only": (
            A * (c_l_one - P_REVISION) - C_B
        ),
        "initial versus both": c_h_one - R_COUNTER,
        "revised versus L-only": A * (c_l_one - P_REVISION),
        "accept versus both": c_h_one + C_B - R_COUNTER,
    }
    if min(global_buyer_margins.values()) <= 0:
        raise AssertionError("A global buyer price deviation is profitable")

    # Raw-PBE completion with the old low-type tail.
    old_tail = evaluate(C_L, Q(0))
    old_threshold = old_tail + C_B
    old_counter = {
        "L": old_threshold - C_S,
        "H": evaluate(C_H, Q(0)) - C_S,
    }
    raw_seller_margins = {
        "L chooses r": k_r["L"]
        - max(Q_INITIAL, c_q["L"], old_counter["L"]),
        "H chooses r": k_r["H"]
        - max(Q_INITIAL, c_q["H"], old_counter["H"]),
        "L accepts p": P_REVISION
        - max(c_p["L"], old_counter["L"]),
        "H auctions p": c_p["H"]
        - max(P_REVISION, old_counter["H"]),
    }
    if min(raw_seller_margins.values()) <= 0:
        raise AssertionError("The raw PBE seller inequalities fail")
    if not W_L_BETA > old_threshold:
        raise AssertionError("An active type cannot use the old tail")

    # Posterior-consistent tail repair tau_h=C_L(mu_h)+epsilon.
    repaired: Dict[str, Dict[str, Q]] = {}
    for history, c_values in (("q", c_q), ("p", c_p)):
        tail = c_values["L"] + EPSILON
        threshold = tail + C_B
        repaired[history] = {
            "tail": tail,
            "threshold": threshold,
            "active_gap": W_L_BETA - threshold,
            "H_rejection_gap": c_values["H"] - tail,
            "tail_below_other_L_offer": c_l_one - tail,
            "L_tail_acceptance": EPSILON,
            "L_counter_below_auction": C_S - C_B - EPSILON,
            "H_counter_below_auction": C_S,
        }
        if min(
            value
            for name, value in repaired[history].items()
            if name not in {"tail", "threshold"}
        ) <= 0:
            raise AssertionError(
                f"The repaired recursive completion fails after {history}"
            )

    # Once repaired counters are bounded by the posterior auction value, only
    # the direct on-path seller comparisons remain.
    repaired_on_path = {
        "L chooses r": k_r["L"] - max(Q_INITIAL, c_q["L"]),
        "H chooses r": k_r["H"] - max(Q_INITIAL, c_q["H"]),
        "L accepts p": P_REVISION - c_p["L"],
        "H auctions p": c_p["H"] - P_REVISION,
    }
    if min(repaired_on_path.values()) <= 0:
        raise AssertionError("The repaired on-path seller incentives fail")

    # The original low tail is rejected by both states under either pooling
    # posterior in the atom-preserving diagnostic.
    old_tail_diagnostic = {
        "q_L": c_q["L"] - old_tail,
        "q_H": c_q["H"] - old_tail,
        "p_L": c_p["L"] - old_tail,
        "p_H": c_p["H"] - old_tail,
    }
    if min(old_tail_diagnostic.values()) <= 0:
        raise AssertionError("The atom-preserving tail diagnostic changed")

    outcomes = {
        "no_attempt": z_wait,
        "attempt_then_auction": PI * z_p,
        "early_agreement": A * z_p + z_accept,
    }
    if outcomes != {
        "no_attempt": Q(9639, 40000),
        "attempt_then_auction": Q(237581, 2800000),
        "early_agreement": Q(1887689, 2800000),
    }:
        raise AssertionError("The exact outcome probabilities changed")

    return {
        "prices": {"q": Q_INITIAL, "p": P_REVISION, "r": R_COUNTER},
        "thresholds": threshold_values,
        "masses": masses,
        "seller_values": {"C_q": c_q, "C_p": c_p, "K_r": k_r},
        "global_buyer_margins": global_buyer_margins,
        "raw_seller_margins": raw_seller_margins,
        "repaired": repaired,
        "repaired_on_path": repaired_on_path,
        "old_tail_diagnostic": old_tail_diagnostic,
        "outcomes": outcomes,
    }


def decimal(value: Q) -> str:
    return f"{float(value):.12f}"


def print_report(result: Dict[str, object]) -> None:
    print("INDEPENDENT UNIT-URGENCY AUDIT: PASS")
    print("  raw PBE: PASS")
    print("  posterior-consistent recursive completion: PASS")
    print("  prices")
    for name, value in result["prices"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  seller values")
    for state in ("L", "H"):
        print(
            f"    {state}: "
            f"C(q)={decimal(result['seller_values']['C_q'][state])}, "
            f"K(r)={decimal(result['seller_values']['K_r'][state])}, "
            f"C(p)={decimal(result['seller_values']['C_p'][state])}"
        )
    print("  repaired tails")
    for history, values in result["repaired"].items():
        print(
            f"    {history}: tau={decimal(values['tail'])}, "
            f"active gap={decimal(values['active_gap'])}, "
            f"H gap={decimal(values['H_rejection_gap'])}"
        )
    print("  outcomes")
    for name, value in result["outcomes"].items():
        print(f"    {name}: {value} ({decimal(value)})")
    print("  dynamic D1 / forward induction: not established")


if __name__ == "__main__":
    print_report(run_audit())
