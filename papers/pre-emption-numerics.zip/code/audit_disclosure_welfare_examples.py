"""Audit paired welfare examples for participation-state disclosure.

Each row has a private-state full-menu fixed point, a state-specific disclosed
pooling fixed point in both states, strict global interiority of the private
action regions, and D1-compatible disclosed pools.  The paired rows certify
that the welfare sign of automatic disclosure can go either way.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

import explore_continuous_regime_map as regime_module
import verify_continuous_demand_disclosure as disclosure_module
from explore_continuous_regime_map import Primitives
from verify_continuous_demand_disclosure import (
    DisclosureReserveModel,
    allocation_gain,
    d1_data,
    disclosed_roots,
    tail_first_moment,
)


@dataclass(frozen=True)
class DisclosureComparison:
    primitives: Primitives
    ell: float
    pi: float
    n_l: int
    n_h: int
    d_seller: float
    q_private_l: float
    q_private_h: float
    q_disclosed_l: float
    q_disclosed_h: float
    private_attempt: float
    private_completed: float
    private_rejected: float
    private_probe: float
    private_knockout: float
    disclosed_completed: float
    disclosed_l: float
    disclosed_h: float
    private_welfare: float
    disclosed_welfare: float
    rejection_cost_saving: float
    changed_sales_value: float
    changed_sales_l: float
    changed_sales_h: float
    interior_margin: float

    @property
    def welfare_change(self) -> float:
        return self.disclosed_welfare - self.private_welfare


def evaluate(
    primitives: Primitives,
    ell: float = 0.4,
    pi: float = 0.5,
    n_l: int = 2,
    n_h: int = 7,
    d_seller: float = 0.01,
) -> DisclosureComparison | None:
    """Evaluate the canonical opaque and disclosed boundary equilibria."""
    regime_module.PI = pi
    disclosure_module.PI = pi
    regime_module.N_L = n_l
    regime_module.N_H = n_h
    disclosure_module.N_L = n_l
    disclosure_module.N_H = n_h
    regime_module.D_SELLER = d_seller
    disclosure_module.D_SELLER = d_seller
    disclosure_module._DISCLOSED_ROOT_CACHE.clear()
    model = DisclosureReserveModel(primitives, ell=ell)
    private_roots = model.solve_two_price()
    roots_l = disclosed_roots(model, "L")
    roots_h = disclosed_roots(model, "H")
    if len(private_roots) != 1 or len(roots_l) != 1 or len(roots_h) != 1:
        return None

    q_private_l, q_private_h = private_roots[0]
    q_disclosed_l, q_disclosed_h = roots_l[0], roots_h[0]
    mapped_private = model.two_price_map(
        np.array([q_private_l, q_private_h])
    )
    if mapped_private is None or np.max(
        np.abs(mapped_private - np.array([q_private_l, q_private_h]))
    ) > 5e-9:
        return None
    if np.min(model.c_h - model.c_l) <= 0.0:
        return None
    for state, price in (("L", q_disclosed_l), ("H", q_disclosed_h)):
        mapped_disclosed = model.state_mapping(state, price)
        if mapped_disclosed is None or abs(mapped_disclosed - price) > 5e-9:
            return None
    if not d1_data("L", q_disclosed_l, primitives, ell=ell)[2]:
        return None
    if not d1_data("H", q_disclosed_h, primitives, ell=ell)[2]:
        return None

    masses, breakpoints, switches = model.private_masses(
        q_private_l,
        q_private_h,
    )
    mass_no_offer = model.integrate_function(
        lambda value: masses(value)[0],
        cutoff_functions=breakpoints,
        zero_functions=switches,
    )
    mass_probe = model.integrate_function(
        lambda value: masses(value)[1],
        cutoff_functions=breakpoints,
        zero_functions=switches,
    )
    mass_knockout = model.integrate_function(
        lambda value: masses(value)[2],
        cutoff_functions=breakpoints,
        zero_functions=switches,
    )
    if min(mass_no_offer, mass_probe, mass_knockout) <= 1e-8:
        return None

    d_l, _, d_h, z = model.private_cutoffs(q_private_l, q_private_h)
    grid = np.linspace(0.0, 1.0, 2001)
    interior_margin = float(
        min(
            np.min(d_l(grid)),
            np.min(d_h(grid) - d_l(grid)),
            np.min(primitives.d_bar - d_h(grid)),
            np.min(z(grid)),
        )
    )
    if interior_margin <= 1e-6:
        return None

    private_attempt = mass_probe + mass_knockout
    private_rejected = pi * mass_probe
    private_completed = (1.0 - pi) * private_attempt + pi * mass_knockout

    disclosed_cutoffs = {}
    disclosed_masses = {}
    for state, price, n_late in (
        ("L", q_disclosed_l, n_l),
        ("H", q_disclosed_h, n_h),
    ):
        def cutoff(value, price=price, n_late=n_late):
            return price - model.w_state(n_late, value) + primitives.kappa

        disclosed_cutoffs[state] = cutoff
        disclosed_masses[state] = model.state_mass(state, price)
        if disclosed_masses[state] <= 1e-8:
            return None

    disclosed_completed = (
        (1.0 - pi) * disclosed_masses["L"]
        + pi * disclosed_masses["H"]
    )

    def private_welfare_integrand(value):
        cutoff_l = d_l(value)
        cutoff_h = d_h(value)
        _, probe, _ = masses(value)
        return (
            (1.0 - pi)
            * (
                tail_first_moment(cutoff_l, primitives)
                + (
                    d_seller
                    - allocation_gain(n_l, value, ell=ell)
                    - primitives.kappa
                )
                * (1.0 - model.urgency_cdf(cutoff_l))
            )
            + pi
            * (
                -primitives.kappa * probe
                + tail_first_moment(cutoff_h, primitives)
                + (
                    d_seller
                    - allocation_gain(n_h, value, ell=ell)
                    - primitives.kappa
                )
                * (1.0 - model.urgency_cdf(cutoff_h))
            )
        )

    private_welfare = model.integrate_function(
        private_welfare_integrand,
        cutoff_functions=breakpoints,
        zero_functions=switches,
    )

    disclosed_welfare = 0.0
    changed_sales_value = 0.0
    changed_sales_by_state = {}
    for state, probability, n_late, private_cutoff in (
        ("L", 1.0 - pi, n_l, d_l),
        ("H", pi, n_h, d_h),
    ):
        disclosed_cutoff = disclosed_cutoffs[state]

        def tail_value(value, cutoff):
            threshold = cutoff(value)
            return (
                tail_first_moment(threshold, primitives)
                + (
                    d_seller
                    - allocation_gain(n_late, value, ell=ell)
                    - primitives.kappa
                )
                * (1.0 - model.urgency_cdf(threshold))
            )

        disclosed_component = model.integrate_function(
            lambda value, cutoff=disclosed_cutoff: tail_value(value, cutoff),
            cutoff_functions=(disclosed_cutoff,),
        )
        private_component = model.integrate_function(
            lambda value, cutoff=private_cutoff: tail_value(value, cutoff),
            cutoff_functions=(private_cutoff,),
        )
        disclosed_welfare += probability * disclosed_component
        state_changed_sales = probability * (
            disclosed_component - private_component
        )
        changed_sales_by_state[state] = state_changed_sales
        changed_sales_value += state_changed_sales

    rejection_cost_saving = primitives.kappa * private_rejected
    if abs(
        disclosed_welfare
        - private_welfare
        - rejection_cost_saving
        - changed_sales_value
    ) > 2e-8:
        raise AssertionError("Disclosure welfare decomposition failed")

    return DisclosureComparison(
        primitives=primitives,
        ell=ell,
        pi=pi,
        n_l=n_l,
        n_h=n_h,
        d_seller=d_seller,
        q_private_l=q_private_l,
        q_private_h=q_private_h,
        q_disclosed_l=q_disclosed_l,
        q_disclosed_h=q_disclosed_h,
        private_attempt=private_attempt,
        private_completed=private_completed,
        private_rejected=private_rejected,
        private_probe=mass_probe,
        private_knockout=mass_knockout,
        disclosed_completed=disclosed_completed,
        disclosed_l=disclosed_masses["L"],
        disclosed_h=disclosed_masses["H"],
        private_welfare=private_welfare,
        disclosed_welfare=disclosed_welfare,
        rejection_cost_saving=rejection_cost_saving,
        changed_sales_value=changed_sales_value,
        changed_sales_l=changed_sales_by_state["L"],
        changed_sales_h=changed_sales_by_state["H"],
        interior_margin=interior_margin,
    )


def print_result(result: DisclosureComparison) -> None:
    pr = result.primitives
    print(
        f"kappa={pr.kappa:.4f}, d_bar={pr.d_bar:.4f}, "
        f"lambda={pr.urgency_rate:.4f}, ell={result.ell:.4f}, "
        f"pi={result.pi:.4f}, n=({result.n_l},{result.n_h}), "
        f"dS={result.d_seller:.4f}: "
        f"change={result.welfare_change:+.12f}, "
        f"rejection saving={result.rejection_cost_saving:+.12f}, "
        f"changed sales={result.changed_sales_value:+.12f}, "
        f"completed {result.private_completed:.12f} -> "
        f"{result.disclosed_completed:.12f}, rejected="
        f"{result.private_rejected:.12f}, "
        f"margin={result.interior_margin:.6g}"
    )
    print(
        f"  prices private=({result.q_private_l:.9f}, "
        f"{result.q_private_h:.9f}), disclosed=({result.q_disclosed_l:.9f}, "
        f"{result.q_disclosed_h:.9f}); private masses wait/probe/knockout="
        f"({1.0-result.private_attempt:.9f}, {result.private_probe:.9f}, "
        f"{result.private_knockout:.9f}); disclosed L/H masses="
        f"({result.disclosed_l:.9f}, {result.disclosed_h:.9f}); "
        f"state changed-sales values=({result.changed_sales_l:+.9f}, "
        f"{result.changed_sales_h:+.9f}); welfare private/disclosed="
        f"({result.private_welfare:+.9f}, {result.disclosed_welfare:+.9f})"
    )


def main() -> None:
    results = []
    configurations = (
        (Primitives(kappa=0.02, d_bar=1.2, urgency_rate=10.0), 0.65, 1, 3, 0.0),
        (Primitives(kappa=0.02, d_bar=1.2, urgency_rate=10.0), 0.775, 1, 3, 0.0),
    )
    for primitives, pi, n_l, n_h, d_seller in configurations:
        result = evaluate(
            primitives,
            ell=0.4,
            pi=pi,
            n_l=n_l,
            n_h=n_h,
            d_seller=d_seller,
        )
        if result is not None:
            results.append(result)
            print_result(result)
    if len(results) != len(configurations):
        raise AssertionError("A disclosure comparison failed its audit")
    if not results[0].welfare_change > 0.0:
        raise AssertionError("The first disclosure example must raise welfare")
    if not results[1].welfare_change < 0.0:
        raise AssertionError("The second disclosure example must lower welfare")

    targets = (
        {
            "private_completed": 0.225328975275,
            "disclosed_completed": 0.361031095365,
            "private_rejected": 0.153215475178,
            "rejection_cost_saving": 0.003064309504,
            "changed_sales_value": -0.001446038335,
            "welfare_change": 0.001618271168,
        },
        {
            "private_completed": 0.242586146554,
            "disclosed_completed": 0.341579446974,
            "private_rejected": 0.097359692054,
            "rejection_cost_saving": 0.001947193841,
            "changed_sales_value": -0.002282811085,
            "welfare_change": -0.000335617244,
        },
    )
    for result, expected in zip(results, targets):
        for name, target in expected.items():
            value = (
                result.welfare_change
                if name == "welfare_change"
                else getattr(result, name)
            )
            if abs(value - target) > 3e-8:
                raise AssertionError((name, value, target))


if __name__ == "__main__":
    main()
