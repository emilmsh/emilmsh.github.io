"""Local seller-RA and standing-value robustness of the refined buyer-RA PBE.

This is a bounded continuation of the continuous heterogeneous-buyer-CARA
construction in audit_heterogeneous_buyer_risk_aversion_refinement.py.  It
adds a public seller CARA coefficient and a common public standing value v.
The script checks the two-equation IFT system, solves one nearby numerical
candidate, and repeats the raw-PBE and complete rationalizable-branch D1
checks on endpoint-inclusive grids.  It is not a new global search.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import log

import numpy as np
from numpy.polynomial.legendre import leggauss

import audit_heterogeneous_buyer_risk_aversion_refinement as base


ALPHA_MAX = base.ALPHA_MAX
A = base.A
PI = base.PI
KAPPA = base.KAPPA
N_L = base.N_L
N_H = base.N_H


def buyer_moment(
    n: int,
    b: np.ndarray | float,
    alpha: np.ndarray | float,
    standing: float,
) -> np.ndarray | float:
    """E exp[-alpha (b-max(v,Y_1))^+] for uniform late values."""

    b_array = np.asarray(b, dtype=float)
    alpha_array = np.asarray(alpha, dtype=float)
    zero = np.asarray(base.buyer_moment(n, b_array, alpha_array))
    if standing == 0.0:
        return float(zero) if zero.ndim == 0 else zero
    kernel_b = (zero - 1.0 + b_array**n) / n
    zero_v = np.asarray(base.buyer_moment(n, standing, alpha_array))
    kernel_v = (zero_v - 1.0 + standing**n) / n
    discount = np.exp(-alpha_array * (b_array - standing))
    active = (
        1.0
        - b_array**n
        + n * (kernel_b - discount * kernel_v)
        + standing**n * discount
    )
    answer = np.where(b_array <= standing, 1.0, active)
    return float(answer) if answer.ndim == 0 else answer


def wait_moment(
    b: np.ndarray | float, alpha: np.ndarray | float, standing: float
) -> np.ndarray | float:
    return A * buyer_moment(N_L, b, alpha, standing) + PI * buyer_moment(
        N_H, b, alpha, standing
    )


def probe_moment(
    b: np.ndarray | float,
    alpha: np.ndarray | float,
    price: float,
    standing: float,
) -> np.ndarray | float:
    b_array = np.asarray(b)
    alpha_array = np.asarray(alpha)
    return np.exp(alpha_array * KAPPA) * (
        A * np.exp(-alpha_array * (b_array - price))
        + PI * buyer_moment(N_H, b_array, alpha_array, standing)
    )


def log_ratio(b, alpha, price: float, standing: float):
    return np.log(
        probe_moment(b, alpha, price, standing)
        / wait_moment(b, alpha, standing)
    )


def boundaries(alpha: np.ndarray, price: float, standing: float) -> np.ndarray:
    lower = np.zeros_like(alpha)
    upper = np.ones_like(alpha)
    for _ in range(68):
        midpoint = 0.5 * (lower + upper)
        residual = log_ratio(midpoint, alpha, price, standing)
        upper = np.where(residual <= 0.0, midpoint, upper)
        lower = np.where(residual > 0.0, midpoint, lower)
    return 0.5 * (lower + upper)


def lower_exp_moment(power: int, x, gamma: float):
    x_array = np.asarray(x, dtype=float)
    value = -np.expm1(-gamma * x_array) / gamma
    for current in range(1, power + 1):
        value = (
            -np.exp(-gamma * x_array) * x_array**current / gamma
            + current * value / gamma
        )
    return value


def seller_expectation(n: int, b, standing: float):
    """E max{v,Y_2,min(b,Y_1)} for uniform late values."""

    b_array = np.asarray(b, dtype=float)
    f_second = standing**n + n * (1.0 - standing) * standing ** (n - 1)
    below = standing * f_second + n * (n - 1) * (
        (1.0 - standing**n) / n
        - (1.0 - standing ** (n + 1)) / (n + 1)
    )
    above = (
        standing ** (n + 1)
        + n * (b_array ** (n + 1) - standing ** (n + 1)) / (n + 1)
        + n * (1.0 - b_array) * b_array**n
        + n
        * (n - 1)
        * (
            (1.0 - b_array**n) / n
            - (1.0 - b_array ** (n + 1)) / (n + 1)
        )
    )
    answer = np.where(b_array <= standing, below, above)
    return float(answer) if answer.ndim == 0 else answer


def seller_exp_moment(n: int, b, gamma: float, standing: float):
    """E exp[-gamma max{v,Y_2,min(b,Y_1)}]."""

    b_array = np.asarray(b, dtype=float)
    f_second = standing**n + n * (1.0 - standing) * standing ** (n - 1)
    below = np.exp(-gamma * standing) * f_second + n * (n - 1) * (
        lower_exp_moment(n - 2, 1.0, gamma)
        - lower_exp_moment(n - 2, standing, gamma)
        - lower_exp_moment(n - 1, 1.0, gamma)
        + lower_exp_moment(n - 1, standing, gamma)
    )
    above = (
        np.exp(-gamma * standing) * standing**n
        + n
        * (
            lower_exp_moment(n - 1, b_array, gamma)
            - lower_exp_moment(n - 1, standing, gamma)
        )
        + np.exp(-gamma * b_array)
        * n
        * (1.0 - b_array)
        * b_array ** (n - 1)
        + n
        * (n - 1)
        * (
            lower_exp_moment(n - 2, 1.0, gamma)
            - lower_exp_moment(n - 2, b_array, gamma)
            - lower_exp_moment(n - 1, 1.0, gamma)
            + lower_exp_moment(n - 1, b_array, gamma)
        )
    )
    answer = np.where(b_array <= standing, below, above)
    return float(answer) if answer.ndim == 0 else answer


def seller_point_ce(n: int, b, gamma: float, standing: float):
    if gamma == 0.0:
        return seller_expectation(n, b, standing)
    moment = seller_exp_moment(n, b, gamma, standing)
    return -np.log(moment) / gamma


@dataclass(frozen=True)
class Candidate:
    alpha_min: float
    price: float
    probe_mass: float
    beta_at_alpha_min: float
    beta_at_alpha_max: float
    h_pool_ce: float


ALPHA_NODES, ALPHA_WEIGHTS = leggauss(180)
B_NODES, B_WEIGHTS = leggauss(180)


def pool_objects(
    alpha_min: float,
    price: float,
    seller_gamma: float,
    standing: float,
) -> tuple[float, float, float, np.ndarray, np.ndarray]:
    alpha = alpha_min + (ALPHA_MAX - alpha_min) * (ALPHA_NODES + 1.0) / 2.0
    alpha_weights = ALPHA_WEIGHTS * (ALPHA_MAX - alpha_min) / 2.0
    beta = boundaries(alpha, price, standing)
    probe_area = float(np.dot(alpha_weights, 1.0 - beta))
    if probe_area <= 0.0:
        raise AssertionError("empty probing pool")

    def compound_ce(n: int) -> float:
        b = beta[:, None] + (1.0 - beta[:, None]) * (B_NODES[None, :] + 1.0) / 2.0
        weights = (
            alpha_weights[:, None]
            * (1.0 - beta[:, None])
            * B_WEIGHTS[None, :]
            / 2.0
        )
        if seller_gamma == 0.0:
            total = float(np.sum(weights * seller_expectation(n, b, standing)))
            return total / probe_area
        total_moment = float(
            np.sum(weights * seller_exp_moment(n, b, seller_gamma, standing))
        )
        return -log(total_moment / probe_area) / seller_gamma

    return compound_ce(N_L), compound_ce(N_H), probe_area, alpha, beta


def equations(values, seller_gamma: float, standing: float):
    alpha_min, price = map(float, values)
    endpoint = float(log_ratio(1.0, alpha_min, price, standing))
    l_ce, _, _, _, _ = pool_objects(alpha_min, price, seller_gamma, standing)
    return np.array([endpoint, l_ce - price])


def solve_candidate(
    seller_gamma: float,
    standing: float,
    start=(0.3697540263, 0.65595439145),
) -> Candidate:
    values = np.asarray(start, dtype=float)
    for _ in range(40):
        residual = equations(values, seller_gamma, standing)
        if np.max(np.abs(residual)) < 2e-12:
            break
        step = np.array([2e-5, 2e-6])
        jacobian = np.column_stack(
            [
                (equations(values + step[i] * np.eye(2)[i], seller_gamma, standing) - residual)
                / step[i]
                for i in range(2)
            ]
        )
        direction = np.linalg.solve(jacobian, -residual)
        accepted = False
        for damping in (1.0, 0.5, 0.25, 0.125, 0.0625):
            trial = values + damping * direction
            if not 0.01 < trial[0] < ALPHA_MAX or not 0.5 < trial[1] < 0.8:
                continue
            if np.linalg.norm(equations(trial, seller_gamma, standing)) < np.linalg.norm(residual):
                values = trial
                accepted = True
                break
        if not accepted:
            raise AssertionError("local Newton step failed")
    residual = equations(values, seller_gamma, standing)
    if np.max(np.abs(residual)) > 2e-9:
        raise AssertionError(f"candidate residual too large: {residual}")
    alpha_min, price = map(float, values)
    l_ce, h_ce, probe_area, _, _ = pool_objects(
        alpha_min, price, seller_gamma, standing
    )
    if abs(l_ce - price) > 2e-9:
        raise AssertionError("seller fixed point failed")
    beta_top = float(boundaries(np.array([ALPHA_MAX]), price, standing)[0])
    beta_bottom = float(boundaries(np.array([alpha_min]), price, standing)[0])
    return Candidate(
        alpha_min,
        price,
        probe_area / (ALPHA_MAX - alpha_min),
        beta_bottom,
        beta_top,
        h_ce,
    )


def solve_fixed_support(
    alpha_min: float,
    seller_gamma: float,
    standing: float,
    start_price: float,
) -> Candidate:
    """Continue the equilibrium while holding the alpha support fixed."""

    price = float(start_price)
    for _ in range(50):
        l_ce, _, _, _, _ = pool_objects(
            alpha_min, price, seller_gamma, standing
        )
        residual = l_ce - price
        if abs(residual) < 2e-12:
            break
        step = 2e-6
        l_ce_up, _, _, _, _ = pool_objects(
            alpha_min, price + step, seller_gamma, standing
        )
        derivative = (l_ce_up - (price + step) - residual) / step
        direction = -residual / derivative
        accepted = False
        for damping in (1.0, 0.5, 0.25, 0.125):
            trial = price + damping * direction
            if not 0.5 < trial < 0.8:
                continue
            trial_ce, _, _, _, _ = pool_objects(
                alpha_min, trial, seller_gamma, standing
            )
            if abs(trial_ce - trial) < abs(residual):
                price = trial
                accepted = True
                break
        if not accepted:
            raise AssertionError("fixed-support price iteration failed")
    l_ce, h_ce, probe_area, _, _ = pool_objects(
        alpha_min, price, seller_gamma, standing
    )
    if abs(l_ce - price) > 2e-9:
        raise AssertionError("fixed-support seller equation failed")
    beta = boundaries(
        np.array([alpha_min, ALPHA_MAX]), price, standing
    )
    return Candidate(
        alpha_min,
        price,
        probe_area / (ALPHA_MAX - alpha_min),
        float(beta[0]),
        float(beta[1]),
        h_ce,
    )


def fixed_support_ift_derivative(candidate: Candidate) -> float:
    """Derivative in q of CE_L(pool(q))-q at the baseline."""

    step = 2e-6
    base_ce, _, _, _, _ = pool_objects(
        candidate.alpha_min, candidate.price, 0.0, 0.0
    )
    up_ce, _, _, _, _ = pool_objects(
        candidate.alpha_min, candidate.price + step, 0.0, 0.0
    )
    return float((up_ce - (candidate.price + step) - (base_ce - candidate.price)) / step)


def raw_audit(candidate: Candidate, seller_gamma: float, standing: float):
    alpha_grid = np.linspace(candidate.alpha_min, ALPHA_MAX, 121)
    b_grid = np.linspace(0.0, 1.0, 2001)
    alpha, b = np.meshgrid(alpha_grid, b_grid, indexing="ij")
    log_difference = log_ratio(b, alpha, candidate.price, standing)
    beta = boundaries(alpha_grid, candidate.price, standing)
    predicted_probe = b >= beta[:, None]
    violation = np.maximum(
        np.where(predicted_probe, log_difference, -log_difference), 0.0
    )
    sorting_violation = float(np.max(violation))

    h_rejection = candidate.h_pool_ce - candidate.price
    top_l_gap = float(
        seller_point_ce(N_L, 1.0, seller_gamma, standing) - candidate.price
    )
    state_separation = float(
        seller_point_ce(N_H, 0.0, seller_gamma, standing)
        - seller_point_ce(N_L, 1.0, seller_gamma, standing)
    )
    knockout_price = float(
        seller_point_ce(N_H, 1.0, seller_gamma, standing)
    )
    waiting = wait_moment(b, alpha, standing)
    probing = probe_moment(b, alpha, candidate.price, standing)
    equilibrium = np.minimum(waiting, probing)
    knockout = np.exp(alpha * KAPPA - alpha * (b - knockout_price))
    ce_loss = np.log(knockout / equilibrium) / alpha
    return {
        "sorting_violation": sorting_violation,
        "h_rejection_margin": h_rejection,
        "top_l_rejection_gap": top_l_gap,
        "state_separation_margin": state_separation,
        "knockout_ce_loss": float(np.min(ce_loss)),
        "knockout_price": knockout_price,
    }


def d1_audit(candidate: Candidate, seller_gamma: float, standing: float):
    alpha_grid = np.linspace(candidate.alpha_min, ALPHA_MAX, 181)
    b_grid = np.linspace(0.0, 1.0, 901)
    alpha, b = np.meshgrid(alpha_grid, b_grid, indexing="ij")
    m_l = buyer_moment(N_L, b, alpha, standing)
    m_h = buyer_moment(N_H, b, alpha, standing)
    waiting = A * m_l + PI * m_h
    probing = np.exp(alpha * KAPPA) * (
        A * np.exp(-alpha * (b - candidate.price)) + PI * m_h
    )
    equilibrium = np.minimum(waiting, probing)
    rejected_attempt = np.exp(alpha * KAPPA) * waiting

    l_min = float(seller_point_ce(N_L, 0.0, seller_gamma, standing))
    l_prices = np.unique(
        np.r_[
            np.linspace(l_min, candidate.price, 121, endpoint=False),
            candidate.price - np.geomspace(1e-8, 1e-3, 20),
        ]
    )
    l_prices = l_prices[(l_prices >= l_min) & (l_prices < candidate.price)]
    l_endpoint_excess = -np.inf
    l_min_b = np.inf
    l_max_b = -np.inf
    l_min_alpha = np.inf
    l_max_alpha = -np.inf
    l_rejection_margin = np.inf
    for price in l_prices:
        denominator = A * np.exp(alpha * KAPPA) * (
            m_l - np.exp(-alpha * (b - price))
        )
        threshold = np.full_like(denominator, np.inf)
        valid = denominator > 1e-14
        threshold[valid] = (
            rejected_attempt[valid] - equilibrium[valid]
        ) / denominator[valid]
        threshold[threshold >= 1.0] = np.inf
        index = np.unravel_index(int(np.argmin(threshold)), threshold.shape)
        endpoint = float(threshold[0, -1])
        minimum = float(threshold[index])
        l_endpoint_excess = max(l_endpoint_excess, endpoint - minimum)
        l_min_b = min(l_min_b, float(b[index]))
        l_max_b = max(l_max_b, float(b[index]))
        l_min_alpha = min(l_min_alpha, float(alpha[index]))
        l_max_alpha = max(l_max_alpha, float(alpha[index]))
        survivors = threshold <= minimum + 3e-7
        best_rejection = float(
            np.max(
                seller_point_ce(
                    N_L, b[survivors], seller_gamma, standing
                )
                - price
            )
        )
        l_rejection_margin = min(l_rejection_margin, best_rejection)

    def h_threshold(alpha_value, b_value, price):
        m_h_value = buyer_moment(N_H, b_value, alpha_value, standing)
        certain = np.exp(-alpha_value * (b_value - price))
        waiting_value = wait_moment(b_value, alpha_value, standing)
        probing_value = probe_moment(
            b_value, alpha_value, candidate.price, standing
        )
        equilibrium_value = np.minimum(waiting_value, probing_value)
        numerator = np.exp(alpha_value * KAPPA) * (
            A * certain + PI * m_h_value
        ) - equilibrium_value
        denominator = np.exp(alpha_value * KAPPA) * PI * (
            m_h_value - certain
        )
        return numerator / denominator

    h_min = float(seller_point_ce(N_H, 0.0, seller_gamma, standing))
    h_max = float(seller_point_ce(N_H, 1.0, seller_gamma, standing))
    lo, hi = h_min, h_max
    for _ in range(70):
        middle = 0.5 * (lo + hi)
        if float(h_threshold(ALPHA_MAX, 1.0, middle)) < 1.0:
            lo = middle
        else:
            hi = middle
    h_cutoff = 0.5 * (lo + hi)
    h_prices = np.linspace(h_min, h_cutoff - 1e-8, 101)
    h_endpoint_excess = -np.inf
    h_min_b = np.inf
    h_max_b = -np.inf
    h_min_alpha = np.inf
    h_max_alpha = -np.inf
    h_rejection_margin = np.inf
    for price in h_prices:
        certain = np.exp(-alpha * (b - price))
        numerator = np.exp(alpha * KAPPA) * (A * certain + PI * m_h) - equilibrium
        denominator = np.exp(alpha * KAPPA) * PI * (m_h - certain)
        threshold = np.full_like(denominator, np.inf)
        valid = denominator > 1e-14
        threshold[valid] = numerator[valid] / denominator[valid]
        threshold[threshold >= 1.0] = np.inf
        index = np.unravel_index(int(np.argmin(threshold)), threshold.shape)
        endpoint = float(threshold[-1, -1])
        minimum = float(threshold[index])
        h_endpoint_excess = max(h_endpoint_excess, endpoint - minimum)
        h_min_b = min(h_min_b, float(b[index]))
        h_max_b = max(h_max_b, float(b[index]))
        h_min_alpha = min(h_min_alpha, float(alpha[index]))
        h_max_alpha = max(h_max_alpha, float(alpha[index]))
        survivors = threshold <= minimum + 3e-7
        best_rejection = float(
            np.max(
                seller_point_ce(
                    N_H, b[survivors], seller_gamma, standing
                )
                - price
            )
        )
        h_rejection_margin = min(h_rejection_margin, best_rejection)
    return {
        "l_endpoint_excess": l_endpoint_excess,
        "l_minimizer_b_min": l_min_b,
        "l_minimizer_b_max": l_max_b,
        "l_minimizer_alpha_min": l_min_alpha,
        "l_minimizer_alpha_max": l_max_alpha,
        "l_rejection_margin": l_rejection_margin,
        "h_gain_cutoff": h_cutoff,
        "h_endpoint_excess": h_endpoint_excess,
        "h_minimizer_b_min": h_min_b,
        "h_minimizer_b_max": h_max_b,
        "h_minimizer_alpha_min": h_min_alpha,
        "h_minimizer_alpha_max": h_max_alpha,
        "h_rejection_margin": h_rejection_margin,
    }


def main():
    baseline = solve_candidate(0.0, 0.0)
    ift_derivative = fixed_support_ift_derivative(baseline)

    seller_gamma = 0.10
    standing = 0.05
    seller_ra_only = solve_fixed_support(
        baseline.alpha_min,
        seller_gamma,
        0.0,
        baseline.price,
    )
    standing_only = solve_fixed_support(
        baseline.alpha_min,
        0.0,
        standing,
        baseline.price,
    )
    perturbed = solve_fixed_support(
        baseline.alpha_min,
        seller_gamma,
        standing,
        baseline.price,
    )
    raw = raw_audit(perturbed, seller_gamma, standing)
    d1 = d1_audit(perturbed, seller_gamma, standing)

    assert abs(baseline.alpha_min - 0.3697540263) < 3e-6
    assert abs(baseline.price - 0.65595439145) < 3e-6
    assert abs(ift_derivative) > 0.1
    assert raw["sorting_violation"] < 2e-10
    assert min(
        raw["h_rejection_margin"],
        raw["top_l_rejection_gap"],
        raw["state_separation_margin"],
        raw["knockout_ce_loss"],
    ) > 0.0
    assert d1["l_rejection_margin"] > 0.0
    assert d1["h_rejection_margin"] > 0.0

    print("BASELINE REPLICATION")
    print(f"  alpha_min={baseline.alpha_min:.12f}")
    print(f"  price={baseline.price:.12f}")
    print(f"  probe_mass={baseline.probe_mass:.12f}")
    print("FIXED-SUPPORT IFT")
    print(f"  d[CE_L(pool(q))-q]/dq={ift_derivative:.12f}")
    print("ONE-DIMENSIONAL LOCAL CONTINUATIONS")
    print(
        "  seller RA only (alpha_min,q,probe_mass)="
        f"({seller_ra_only.alpha_min:.12f},{seller_ra_only.price:.12f},"
        f"{seller_ra_only.probe_mass:.12f})"
    )
    print(
        "  standing value only (alpha_min,q,probe_mass)="
        f"({standing_only.alpha_min:.12f},{standing_only.price:.12f},"
        f"{standing_only.probe_mass:.12f})"
    )
    print("LOCAL SELLER-RA / STANDING-VALUE AUDIT")
    print(f"  seller_gamma={seller_gamma:.4f}")
    print(f"  standing_value={standing:.4f}")
    print(f"  alpha_min={perturbed.alpha_min:.12f}")
    print(f"  price={perturbed.price:.12f}")
    print(f"  beta(alpha_min)={perturbed.beta_at_alpha_min:.12f}")
    print(f"  beta(alpha_max)={perturbed.beta_at_alpha_max:.12f}")
    print(f"  probe_mass={perturbed.probe_mass:.12f}")
    print(f"  no_sale_probability_L={standing ** (N_L + 1):.12f}")
    print(f"  no_sale_probability_H={standing ** (N_H + 1):.12f}")
    print("RAW MARGINS")
    for key, value in raw.items():
        print(f"  {key}={value:.12f}")
    print("D1 MARGINS")
    for key, value in d1.items():
        print(f"  {key}={value:.12f}")


if __name__ == "__main__":
    main()
