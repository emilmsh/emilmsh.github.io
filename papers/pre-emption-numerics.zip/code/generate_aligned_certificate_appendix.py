"""Generate the manuscript certificate tables from the maintained Arb calculation.

Run from the repository root:
    python code/generate_aligned_certificate_appendix.py

The JSON retains full interval records. Displayed decimal bounds are rounded
outwards from those records, including uncertainty in endpoint conversion.
"""
from __future__ import annotations

import argparse
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
import json
from pathlib import Path

from certify_aligned_composite_full_menu import json_payload, run_certificate


ROOT = Path(__file__).resolve().parents[1]


def ball_bounds(text):
    text = text.strip("[] ")
    if "+/-" in text:
        midpoint, radius = text.split("+/-")
        midpoint = Decimal(midpoint.strip() or "0")
        radius = Decimal(radius.strip())
        return midpoint - radius, midpoint + radius
    value = Decimal(text)
    return value, value


def bounds(record, places=12):
    # The endpoint fields are themselves outward-rounded balls.
    lower = ball_bounds(record["lower"])[0]
    upper = ball_bounds(record["upper"])[1]
    quantum = Decimal(1).scaleb(-places)
    return (lower.quantize(quantum, rounding=ROUND_FLOOR),
            upper.quantize(quantum, rounding=ROUND_CEILING))


def interval(record, places=12):
    lower, upper = bounds(record, places)
    return rf"\([{lower:f},\,{upper:f}]\)"


def lower_bound(record):
    return rf"\({bounds(record, 9)[0]:f}\)"


def table(caption, label, heading, rows, note, label_width):
    lines = [
        r"\begin{table}[H]", r"\centering\small",
        rf"\caption{{{caption}}}", rf"\label{{{label}}}",
        rf"\begin{{tabular}}{{@{{}}p{{{label_width}\textwidth}}r@{{}}}}",
        r"\toprule", heading + r" \\", r"\midrule",
    ]
    lines.extend(name + " & " + value + r" \\" for name, value in rows)
    lines.extend([
        r"\bottomrule", r"\end{tabular}", r"\par\smallskip",
        r"\begin{minipage}{\textwidth}\footnotesize",
        r"\textit{Notes:} " + note,
        r"\end{minipage}", r"\end{table}", "",
    ])
    return "\n".join(lines)


def render(data):
    rows = []
    for i, state in enumerate(("L", "H")):
        rows.append((rf"Root-box coordinate \(q_{state}\)", interval(data["root_box"][i], 15)))
    for i, state in enumerate(("L", "H")):
        rows.append((rf"Krawczyk image, coordinate \({state}\)", interval(data["krawczyk_image"][i], 21)))
    for i in range(2):
        for j in range(2):
            rows.append((rf"Jacobian entry \(J_{{{i+1}{j+1}}}\)", interval(data["interval_jacobian"][i][j])))
    rows.append((r"\(\det J\)", interval(data["jacobian_determinant"])))
    first = table(
        "Root Enclosure and Local Uniqueness Certificate",
        "tab:alignedrootcertificate", "Quantity & Outward enclosure", rows,
        r"The calculation uses Arb through \texttt{python-flint 0.9.0}, at 60 decimal digits. "
        r"These intervals are outward-rounded displays of the computed balls. "
        r"Strict Krawczyk inclusion is checked before display rounding. "
        r"The Jacobian is for the unnormalised zero-rent equations defined in the text, "
        r"not for the price map \(T\) itself.", ".34")
    faces = [
        r"\(T_P(\ell_L,\ell_H)-\ell_L\)",
        r"\(u_L-T_P(u_L,u_H)\)",
        r"\(T_K(u_L,\ell_H)-\ell_H\)",
        r"\(u_H-T_K(\ell_L,u_H)\)",
    ]
    interior = [
        r"\(\min_{b\in[0,1],\,q\in\mathcal Q_0}D_L(b;q)\)",
        r"\(\min_{b\in[0,1],\,q\in\mathcal Q_0}[\bar d-D_H(b;q)]\)",
        r"\(\min_{b\in[0,1],\,q\in\mathcal Q_0}Z(b;q)\)",
    ]
    domain = [r"\(\ell_L-C_L(0)\)", r"\(C_L(1)-u_L\)",
              r"\(\ell_H-C_H(0)\)", r"\(C_H(1)-u_H\)"]
    rows = []
    for labels, key in [
        (faces, "price_box_face_margins"),
        (interior, "price_box_interior_margins"),
        (domain, "price_box_domain_margins"),
    ]:
        rows += [(label, lower_bound(value)) for label, value in zip(labels, data[key])]
    rows += [(r"\(\min_b[C_H(b)-C_L(b)]\)",
              lower_bound(data["minimum_C_H_minus_C_L_cell_bound"]))]
    rows += [(label, lower_bound(value)) for label, value in zip(
        [r"\(\E[C_H(b)\mid P]-q_L\)", r"\(q_H-\E[C_L(b)\mid K]\)"],
        data["seller_response_slacks"])]
    rows += [(label, lower_bound(value)) for label, value in zip(
        [r"\(C_L(1)-q_L\)", r"\(C_H(1)-q_H\)"], data["D1_endpoint_slacks"])]
    for name, label in [("D_L", "D_L"), ("D_aux", r"\widetilde D_H"), ("D_H", "D_H")]:
        low, high = data["cutoff_ranges"][name]
        rows.append((rf"Root-box range of \({label}\)",
                     rf"\([{bounds(low, 9)[0]:f},\,{bounds(high, 9)[1]:f}]\)"))
    second = table(
        "Uniform Price-Box and Equilibrium Margins",
        "tab:alignedmargincertificate", "Quantity & Certified lower bound or range", rows,
        r"The first eleven bounds hold on the entire price rectangle \(\mathcal Q_0\). "
        r"The state-ordering bound holds for all buyer values. Seller-response, D1 "
        r"and cutoff bounds hold on the certified root box. The finite corner argument "
        r"in Appendix~\ref{app:equilibrium} extends the four face checks to whole faces; "
        r"the cutoff identities reduce interiority to endpoint checks. All displayed "
        r"lower bounds are rounded down.", ".52")
    return "% Generated by code/generate_aligned_certificate_appendix.py.\n" + first + second


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-json", type=Path)
    parser.add_argument("--tex", type=Path,
                        default=ROOT / "figures/aligned_certificate_tables.tex")
    parser.add_argument("--json", type=Path,
                        default=ROOT / "code/certificate_outputs/aligned_composite_certificate.json")
    args = parser.parse_args()
    data = (json.loads(args.input_json.read_text(encoding="utf-8-sig"))
            if args.input_json else json_payload(run_certificate()))
    if data["status"] != "PASS" or "interval_jacobian" not in data:
        raise ValueError("A passing certificate with interval Jacobian is required.")
    with localcontext() as context:
        context.prec = 100
        output = render(data)
    args.tex.parent.mkdir(parents=True, exist_ok=True)
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.tex.write_text(output, encoding="utf-8", newline="\n")
    args.json.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8", newline="\n")
    print(f"Generated {args.tex.name} and {args.json.name} from PASS certificate.")


if __name__ == "__main__":
    main()
