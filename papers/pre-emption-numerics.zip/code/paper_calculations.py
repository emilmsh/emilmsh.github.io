"""Reader-facing calculations for the shortened pre-emption paper.

Run without arguments for the analytic participation example and the existing
floating-point ban audit. Add --certify for the existing interval certificate.
The economic solvers remain in their original scripts; this file supplies a
short reading order and the exact arithmetic for the new participation example.
It writes no results or manuscript files.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time


CODE = Path(__file__).resolve().parent
ROOT = CODE.parent


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def fraction_record(value: Fraction) -> dict[str, str | float]:
    return {"exact": str(value), "decimal": float(value)}


def participation_example() -> dict:
    """Check the paper's sufficient probing conditions in exact arithmetic.

    With F=U[0,1], at b=1 the competition wedge is zero and
    C_s(1)=R_s(1)=w_s(1)=1-(1-v**(n_s+1))/(n_s+1).
    The seller has no resolution benefit in this particular example.
    No distribution G beyond its stated support/regularity is chosen here.
    """
    n_l, n_h = 2, 6
    v = Fraction(2, 5)
    pi = Fraction(1, 2)
    kappa = Fraction(1, 50)
    d_bar = Fraction(1, 10)
    a = 1 - pi
    w_l = 1 - (1 - v ** (n_l + 1)) / (n_l + 1)
    w_h = 1 - (1 - v ** (n_h + 1)) / (n_h + 1)
    c_l_top, c_h_top = w_l, w_h
    c_l_bottom = (
        Fraction(n_l - 1, n_l + 1)
        + v**n_l
        - Fraction(n_l - 1, n_l + 1) * v ** (n_l + 1)
    )
    d_l = c_l_top - w_l + kappa / a
    d_h = c_h_top - (a * w_l + pi * w_h) + kappa
    delta = d_h - d_l
    upper = d_l + delta / pi
    lower_type_condition = c_l_bottom + kappa / a  # w_L(0)=0.

    checks = {
        "ordered_participation_counts": 2 <= n_l < n_h,
        "positive_lower_seller_continuation": c_l_bottom > 0,
        "positive_threshold_gap": delta > 0,
        "positive_mass_probing_window": d_l < d_bar <= upper,
        "positive_lower_type_cutoff_at_lower_price": lower_type_condition > 0,
        "sufficient_D1_condition": d_l >= 0,
        "waiting_only_condition_fails": d_bar > min(d_l, d_h),
    }
    require(all(checks.values()), f"Participation example failed: {checks}")
    require(d_l == Fraction(1, 25), "Unexpected low-state entry threshold.")
    return {
        "classification": "exact_arithmetic_check_of_sufficient_conditions",
        "status": "pass",
        "parameters": {
            "value_distribution": "U[0,1]",
            "late_counts": [n_l, n_h],
            "seller_fallback_both_states": fraction_record(v),
            "seller_resolution_benefit_both_states": 0,
            "probability_high_state": fraction_record(pi),
            "offer_cost": fraction_record(kappa),
            "buyer_resolution_benefit_support_upper": fraction_record(d_bar),
            "resolution_benefit_distribution": (
                "Any G satisfying the paper's regularity assumptions on [0, 1/10]."
            ),
        },
        "quantities": {
            "w_L(1)=C_L(1)": fraction_record(w_l),
            "w_H(1)=C_H(1)": fraction_record(w_h),
            "C_L(0)": fraction_record(c_l_bottom),
            "bar_D_L": fraction_record(d_l),
            "bar_D_H": fraction_record(d_h),
            "Delta_D": fraction_record(delta),
            "probing_window_upper": fraction_record(upper),
            "lower_type_condition": fraction_record(lower_type_condition),
        },
        "checks": checks,
        "scope": (
            "These exact inequalities verify the numerical premises of the "
            "paper's probing proposition. Existence and D1 compatibility use "
            "that proposition's analytical proof. No fixed-point price or "
            "action probability is computed: those require a specified G."
        ),
    }


def package_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def require_package(name: str, version: str) -> None:
    actual = package_version(name)
    require(
        actual == version,
        f"{name}=={version} is required for this calculation; found {actual!r}. "
        "Install code/requirements-publication.txt in your Python environment. "
        "The --probing-only calculation uses the standard library alone.",
    )


def run_existing(script: str, *, certificate: bool = False) -> dict:
    """Delegate unchanged solvers and retain their complete output."""
    path = CODE / script
    require(path.is_file(), f"Missing calculation script: {path}")
    command = [sys.executable, str(path)]
    if certificate:
        command.append("--json")
    started = time.perf_counter()
    environment = os.environ.copy()
    # Existing audits use assertions: do not inherit an optimization setting
    # that could silently turn those checks off.
    environment.pop("PYTHONOPTIMIZE", None)
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env=environment,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=900 if certificate else 300,
        check=False,
    )
    require(
        completed.returncode == 0,
        f"{script} failed (exit {completed.returncode}).\n"
        f"{completed.stdout}\n{completed.stderr}",
    )
    record = {
        "script": script,
        "classification": "interval_certificate" if certificate else "floating_point_audit",
        "status": "pass",
        "elapsed_seconds": round(time.perf_counter() - started, 3),
        "stderr": completed.stderr,
    }
    if certificate:
        record["results"] = json.loads(completed.stdout)
        require(record["results"].get("status") == "PASS", "Certificate did not report PASS.")
    else:
        record["stdout"] = completed.stdout
        require("PASS:" in completed.stdout, "Floating-point audit did not report PASS.")
    return record


def print_participation(result: dict) -> None:
    print("1. Participation example: exact sufficient conditions", flush=True)
    print("   F=U[0,1]; (n_L,n_H)=(2,6); v_L=v_H=.4; pi=.5; kappa=.02; d_bar=.1.")
    print("   Both seller resolution benefits are zero.")
    for name, value in result["quantities"].items():
        print(f"   {name}: {value['exact']} = {value['decimal']:.12g}")
    print("   PASS: .04 < .1 <= probing_window_upper; Delta_D > 0; D1 condition holds.")
    print("   G is left unspecified, so no numerical price or incidence is claimed.")
    print("   These are premises for the analytical existence result.\n", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--probing-only", action="store_true",
        help="only exact participation thresholds (standard library; no ban audit)",
    )
    parser.add_argument(
        "--certify", action="store_true",
        help="also run the existing outward-rounded ban-welfare certificate",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="print one machine-readable report, including delegated solver output",
    )
    args = parser.parse_args()
    if args.probing_only and args.certify:
        parser.error("--probing-only and --certify cannot be combined")
    report = {
        "python": platform.python_version(),
        "dependencies": {
            "numpy": package_version("numpy"),
            "python-flint": package_version("python-flint"),
        },
        "participation": participation_example(),
        "ban_audit": {"status": "not_run"},
        "ban_certificate": {"status": "not_run"},
    }
    try:
        if not args.json:
            print_participation(report["participation"])
        if not args.probing_only:
            require_package("numpy", "2.3.5")
            if args.certify:
                require_package("python-flint", "0.9.0")
            if not args.json:
                print("2. Ban examples: existing two-resolution floating-point audit", flush=True)
            report["ban_audit"] = run_existing("audit_ban_welfare_examples.py")
            if not args.json:
                print(report["ban_audit"]["stdout"], end="", flush=True)
            if args.certify:
                if not args.json:
                    print("\n3. Ban examples: existing interval certificate", flush=True)
                report["ban_certificate"] = run_existing(
                    "certify_ban_welfare_examples.py", certificate=True
                )
                if not args.json:
                    result = report["ban_certificate"]["results"]
                    print(f"   {result['status']}: {result['certificate']}")
                    print(f"   Precision: {result['dependency']['precision_decimal_digits']} digits; "
                          f"cells: {result['grid_cells']}")
                    for label, case in result["cases"].items():
                        print(f"   {label}: W_B-W_D = {case['welfare']['W_B_minus_W_D']['arb']}")
        report["status"] = "pass"
        if args.json:
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            print("\nPASS: all requested calculations completed. No manuscript files were written.")
        return 0
    except (ValueError, OSError, subprocess.TimeoutExpired) as error:
        if args.json:
            report["status"] = "fail"
            report["error"] = str(error)
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

