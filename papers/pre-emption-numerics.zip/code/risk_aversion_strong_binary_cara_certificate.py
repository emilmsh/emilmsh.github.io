"""Arb certificate for a refined zero-urgency binary-CARA probing PBE.

The buyer privately observes value b ~ U[0,1] and one of two CARA
coefficients.  Both coefficients have positive probability.  The seller is
risk neutral, urgency is zero on both sides, and the demand state determines
whether two or seven iid U[0,1] late buyers arrive.

The construction fixes alpha_L=0.37.  The probing price makes the top
alpha_L buyer indifferent between waiting and probing.  Seller indifference
then determines the lower boundary beta of the alpha_H probing interval, and
the alpha_H boundary equation determines alpha_H.  Outward-rounded Arb
arithmetic certifies the roots and every numerical inequality used by the
analytical PBE and strict-gain interim-D1 proof.

Requires python-flint==0.9.0.  This is a certificate for the displayed
assessment and a regularity certificate for its IFT continuation.  It is not
a global equilibrium-uniqueness result.
"""

from __future__ import annotations

from dataclasses import dataclass

from flint import arb, ctx


ctx.dps = 80

N_L = 2
N_H = 7
A = arb(1) / 2
PI = arb(1) / 2
KAPPA = arb(1) / 100
ALPHA_L = arb(37) / 100
MIX_HIGH = arb(1) / 2

BETA_CENTER = "0.811699930342779"
BETA_RADIUS = "2e-15"
ALPHA_H_CENTER = "2.78802798033663"
ALPHA_H_RADIUS = "1e-10"

BETA_COVER = arb(203) / 250  # 0.812, strictly above the root box.
LOW_PRICE_COVER = arb(323) / 1000  # Covers q-1/3.
SUBDIVISIONS = 512


def require(condition: bool, label: str, value=None) -> None:
    if not condition:
        raise AssertionError((label, value))


def interval(center: str, radius: str) -> arb:
    return arb(center, arb(radius))


def z_moment(n: int, b, alpha):
    """Z_n(b,alpha)=E exp(alpha min{b,Y_(n)}) for uniform late values.

    The finite integration-by-parts recurrence is exact before ball
    rounding.  Alpha is bounded away from zero throughout the certificate.
    """

    b = b if isinstance(b, (arb, Dual)) else arb(b)
    alpha = alpha if isinstance(alpha, (arb, Dual)) else arb(alpha)
    exponential = (alpha * b).exp()
    integral = (exponential - 1) / alpha
    for power in range(1, n):
        integral = b**power * exponential / alpha - power * integral / alpha
    return n * integral + exponential * (1 - b**n)


def revenue(n: int, b):
    """Risk-neutral expected terminal second-price revenue."""

    b = b if isinstance(b, arb) else arb(b)
    return (
        arb(n - 1) / (n + 1)
        + b**n
        - arb(n) * b ** (n + 1) / (n + 1)
    )


def integrated_revenue(n: int, lower):
    """Integral of R_n(b) from lower to one."""

    lower = lower if isinstance(lower, arb) else arb(lower)
    return (
        arb(n - 1) * (1 - lower) / (n + 1)
        + (1 - lower ** (n + 1)) / (n + 1)
        - arb(n)
        * (1 - lower ** (n + 2))
        / ((n + 1) * (n + 2))
    )


def mean_revenue(n: int, lower):
    return integrated_revenue(n, lower) / (1 - lower)


def frontier_residual(b, alpha, price):
    """Twice the transformed wait-minus-probe moment."""

    t = (alpha * KAPPA).exp() - 1
    return (
        z_moment(N_L, b, alpha)
        - (alpha * (price + KAPPA)).exp()
        - t * z_moment(N_H, b, alpha)
    )


class Dual:
    """One-variable first-order automatic differentiation over Arb balls."""

    __slots__ = ("v", "d")

    def __init__(self, value, derivative=0):
        self.v = value if isinstance(value, arb) else arb(value)
        self.d = derivative if isinstance(derivative, arb) else arb(derivative)

    def __add__(self, other):
        other = as_dual(other)
        return Dual(self.v + other.v, self.d + other.d)

    __radd__ = __add__

    def __neg__(self):
        return Dual(-self.v, -self.d)

    def __sub__(self, other):
        return self + (-as_dual(other))

    def __rsub__(self, other):
        return as_dual(other) - self

    def __mul__(self, other):
        other = as_dual(other)
        return Dual(
            self.v * other.v,
            self.d * other.v + self.v * other.d,
        )

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_dual(other)
        return Dual(
            self.v / other.v,
            (self.d * other.v - self.v * other.d) / other.v**2,
        )

    def __rtruediv__(self, other):
        return as_dual(other) / self

    def __pow__(self, power: int):
        if power == 0:
            return Dual(1)
        return Dual(
            self.v**power,
            power * self.v ** (power - 1) * self.d,
        )

    def exp(self):
        value = self.v.exp()
        return Dual(value, value * self.d)


def as_dual(value):
    return value if isinstance(value, Dual) else Dual(value)


def frontier_alpha_derivative(b, alpha, price) -> arb:
    alpha_dual = Dual(alpha, 1)
    return frontier_residual(b, alpha_dual, price).d


def phi_point(x: arb) -> arb:
    """phi(x)=(1-exp(-x))/x at a nonnegative point ball."""

    if x == 0:
        return arb(1)
    return -(-x).expm1() / x


@dataclass(frozen=True)
class Candidate:
    price: arb
    beta: arb
    alpha_h: arb


@dataclass(frozen=True)
class Certificate:
    low_endpoint_residual: arb
    beta_lower_residual: arb
    beta_upper_residual: arb
    high_alpha_lower_residual: arb
    high_alpha_upper_residual: arb
    high_alpha_derivative: arb
    single_crossing_margin: arb
    low_waiter_analytic_margin: arb
    high_waiter_derivative_numerator_upper: arb
    cross_curvature_gamma_margin: arb
    low_endpoint_alpha_derivative: arb
    pool_averaging_margin: arb
    thickening_center_derivative: arb
    low_state_top_rejection_margin: arb
    high_state_onpath_rejection_margin: arb
    high_price_cutoff: arb
    high_price_rejection_margin: arb
    low_alpha_knockout_moment_gap: arb
    high_alpha_knockout_moment_gap: arb
    jacobian_q_entry: arb
    jacobian_beta_entry: arb
    probe_mass: arb
    accepted_mass: arb
    rejected_mass: arb


def construct_candidate() -> tuple[Candidate, dict[str, arb]]:
    """Enclose beta and alpha_H by sign brackets and strict derivatives."""

    z_l_top = z_moment(N_L, 1, ALPHA_L)
    z_h_top = z_moment(N_H, 1, ALPHA_L)
    t_l = (ALPHA_L * KAPPA).exp() - 1
    price = (z_l_top - t_l * z_h_top).log() / ALPHA_L - KAPPA

    beta = interval(BETA_CENTER, BETA_RADIUS)
    beta_lower = beta.lower()
    beta_upper = beta.upper()
    beta_lower_residual = mean_revenue(N_L, beta_lower) - price
    beta_upper_residual = mean_revenue(N_L, beta_upper) - price
    require(beta_lower_residual < 0, "beta lower sign", beta_lower_residual)
    require(beta_upper_residual > 0, "beta upper sign", beta_upper_residual)

    # R_2 is increasing in the posterior cutoff:
    # d mean_R_2/dbeta=(1+2 beta-3 beta^2)/6>0 on (0,1).
    beta_derivative = (1 + 2 * beta - 3 * beta**2) / 6
    require(beta_derivative > 0, "beta uniqueness derivative", beta_derivative)

    alpha_h = interval(ALPHA_H_CENTER, ALPHA_H_RADIUS)
    alpha_lower = alpha_h.lower()
    alpha_upper = alpha_h.upper()
    alpha_lower_residual = frontier_residual(beta, alpha_lower, price)
    alpha_upper_residual = frontier_residual(beta, alpha_upper, price)
    require(
        alpha_lower_residual < 0,
        "alpha_H lower sign",
        alpha_lower_residual,
    )
    require(
        alpha_upper_residual > 0,
        "alpha_H upper sign",
        alpha_upper_residual,
    )
    alpha_derivative = frontier_alpha_derivative(beta, alpha_h, price)
    require(alpha_derivative > 0, "alpha_H local uniqueness", alpha_derivative)

    candidate = Candidate(price=price, beta=beta, alpha_h=alpha_h)
    diagnostics = {
        "beta_lower_residual": beta_lower_residual,
        "beta_upper_residual": beta_upper_residual,
        "alpha_lower_residual": alpha_lower_residual,
        "alpha_upper_residual": alpha_upper_residual,
        "alpha_derivative": alpha_derivative,
        "beta_derivative": beta_derivative,
    }
    return candidate, diagnostics


def certify_high_waiter_order(candidate: Candidate) -> arb:
    """Certify that alpha_H waiter thresholds fall toward beta.

    The sign of d log r_W/db is the sign of

      N=(S_2+S_7)(Z_2-exp(alpha p))-S_2(Z_2+Z_7).

    N decreases in p, so p=1/3 is the worst case.  The fixed cover
    [0,.812] contains the certified beta box.
    """

    require(BETA_COVER > candidate.beta, "beta cover", candidate.beta)
    maximum_upper = None
    for index in range(SUBDIVISIONS):
        midpoint = (
            arb(2 * index + 1)
            * BETA_COVER
            / (2 * SUBDIVISIONS)
        )
        radius = BETA_COVER / (2 * SUBDIVISIONS)
        b = arb(midpoint, radius)
        s_l = 1 - b**N_L
        s_h = 1 - b**N_H
        z_l = z_moment(N_L, b, candidate.alpha_h)
        z_h = z_moment(N_H, b, candidate.alpha_h)
        numerator = (
            (s_l + s_h)
            * (z_l - (candidate.alpha_h / 3).exp())
            - s_l * (z_l + z_h)
        )
        upper = numerator.upper()
        maximum_upper = upper if maximum_upper is None else max(maximum_upper, upper)
    require(
        maximum_upper < 0,
        "high-alpha waiter derivative numerator",
        maximum_upper,
    )
    return maximum_upper


def certify_cross_curvature_order(candidate: Candidate) -> arb:
    """Certify Gamma_L(delta)>Gamma_H(delta) for every probing undercut.

    Gamma_i(delta)/delta =
      C_i phi(alpha_i delta),
    C_i=alpha_i exp(alpha_i q)/(Z_2-exp(alpha_i q)).

    phi is decreasing on the nonnegative line.  Endpoint bounds on each
    delta subinterval therefore give a rigorous enclosure, including the
    removable delta=0 boundary.
    """

    require(
        LOW_PRICE_COVER > candidate.price - arb(1) / 3,
        "low-price delta cover",
        candidate.price,
    )

    x_l = (
        z_moment(N_L, 1, ALPHA_L)
        - (ALPHA_L * candidate.price).exp()
    )
    x_h = (
        z_moment(N_L, candidate.beta, candidate.alpha_h)
        - (candidate.alpha_h * candidate.price).exp()
    )
    c_l = (
        ALPHA_L
        * (ALPHA_L * candidate.price).exp()
        / x_l
    )
    c_h = (
        candidate.alpha_h
        * (candidate.alpha_h * candidate.price).exp()
        / x_h
    )
    require(x_l > 0, "low endpoint X", x_l)
    require(x_h > 0, "high boundary X", x_h)

    minimum_lower = None
    for index in range(SUBDIVISIONS):
        delta_lower = arb(index) * LOW_PRICE_COVER / SUBDIVISIONS
        delta_upper = arb(index + 1) * LOW_PRICE_COVER / SUBDIVISIONS

        # phi(alpha*delta) decreases in both positive arguments.
        low_term = c_l.lower() * phi_point(
            ALPHA_L * delta_upper
        )
        high_term = c_h.upper() * phi_point(
            candidate.alpha_h.lower() * delta_lower
        )
        margin = low_term - high_term
        lower = margin.lower()
        minimum_lower = lower if minimum_lower is None else min(minimum_lower, lower)

    require(
        minimum_lower > 0,
        "cross-curvature normalized Gamma margin",
        minimum_lower,
    )
    return minimum_lower


def certify_candidate() -> tuple[Candidate, Certificate]:
    candidate, root = construct_candidate()

    low_endpoint_residual = frontier_residual(
        1,
        ALPHA_L,
        candidate.price,
    )
    require(
        low_endpoint_residual.contains(0),
        "low endpoint identity",
        low_endpoint_residual,
    )

    # Global one-cutoff condition in each curvature slice.
    single_crossing_margin = (
        arb(N_L) / N_H
        - ((candidate.alpha_h * KAPPA).exp() - 1)
    )
    require(
        single_crossing_margin > 0,
        "single-crossing margin",
        single_crossing_margin,
    )

    # For alpha_L, the waiter-threshold derivative is negative because
    # (S_7-S_2)/(S_7+S_2) <= 5/9, Z_2 <= exp(alpha b), and p >= 1/3.
    low_waiter_margin = (
        1
        - arb(5) / 9 * (arb(2) * ALPHA_L / 3).exp()
    )
    require(
        low_waiter_margin > 0,
        "low-alpha analytic waiter margin",
        low_waiter_margin,
    )

    waiter_upper = certify_high_waiter_order(candidate)
    gamma_margin = certify_cross_curvature_order(candidate)

    low_top_gap = revenue(N_L, 1) - candidate.price
    high_onpath_gap = (
        mean_revenue(N_H, candidate.beta) - candidate.price
    )
    pool_averaging_margin = candidate.price - revenue(N_L, candidate.beta)
    require(low_top_gap > 0, "low-state top rejection", low_top_gap)
    require(high_onpath_gap > 0, "high-state on-path rejection", high_onpath_gap)
    require(
        pool_averaging_margin > 0,
        "low-state pool averaging",
        pool_averaging_margin,
    )

    high_price_cutoff = (
        (
            (
                (candidate.alpha_h * candidate.price).exp()
                + z_moment(N_H, 1, candidate.alpha_h)
            )
            / 2
        ).log()
        / candidate.alpha_h
    )
    high_price_gap = arb(7) / 8 - high_price_cutoff
    require(high_price_gap > 0, "high-price D1 rejection", high_price_gap)

    def knockout_gap(alpha):
        return (
            (alpha * arb(7) / 8).exp()
            - A * (alpha * candidate.price).exp()
            - PI * z_moment(N_H, 1, alpha)
        )

    low_knockout_gap = knockout_gap(ALPHA_L)
    high_knockout_gap = knockout_gap(candidate.alpha_h)
    require(low_knockout_gap > 0, "low-alpha knockout gap", low_knockout_gap)
    require(high_knockout_gap > 0, "high-alpha knockout gap", high_knockout_gap)

    # The equilibrium equalities are triangular in (q,beta,alpha_H).
    # These three diagonal entries certify the nonsingular IFT Jacobian.
    jacobian_q = (
        -ALPHA_L
        * (ALPHA_L * (candidate.price + KAPPA)).exp()
    )
    jacobian_beta = root["beta_derivative"]
    jacobian_alpha = root["alpha_derivative"]
    low_endpoint_alpha_derivative = frontier_alpha_derivative(
        1,
        ALPHA_L,
        candidate.price,
    )
    high_frontier_b_derivative = (
        candidate.alpha_h
        * (candidate.alpha_h * candidate.beta).exp()
        * (
            1
            - candidate.beta**N_L
            - ((candidate.alpha_h * KAPPA).exp() - 1)
            * (1 - candidate.beta**N_H)
        )
    )
    high_beta_prime = -jacobian_alpha / high_frontier_b_derivative
    thickening_center_derivative = -(
        revenue(N_L, candidate.beta) - candidate.price
    ) * high_beta_prime
    require(jacobian_q < 0, "IFT q derivative", jacobian_q)
    require(jacobian_beta > 0, "IFT beta derivative", jacobian_beta)
    require(jacobian_alpha > 0, "IFT alpha derivative", jacobian_alpha)
    require(
        low_endpoint_alpha_derivative > 0,
        "low-band endpoint ordering",
        low_endpoint_alpha_derivative,
    )
    require(
        high_frontier_b_derivative > 0,
        "high frontier b derivative",
        high_frontier_b_derivative,
    )
    require(
        thickening_center_derivative < 0,
        "continuous-thickening IFT derivative",
        thickening_center_derivative,
    )

    probe_mass = MIX_HIGH * (1 - candidate.beta)
    accepted_mass = A * probe_mass
    rejected_mass = PI * probe_mass
    require(probe_mass > 0, "positive probing mass", probe_mass)

    certificate = Certificate(
        low_endpoint_residual=low_endpoint_residual,
        beta_lower_residual=root["beta_lower_residual"],
        beta_upper_residual=root["beta_upper_residual"],
        high_alpha_lower_residual=root["alpha_lower_residual"],
        high_alpha_upper_residual=root["alpha_upper_residual"],
        high_alpha_derivative=jacobian_alpha,
        single_crossing_margin=single_crossing_margin,
        low_waiter_analytic_margin=low_waiter_margin,
        high_waiter_derivative_numerator_upper=waiter_upper,
        cross_curvature_gamma_margin=gamma_margin,
        low_endpoint_alpha_derivative=low_endpoint_alpha_derivative,
        pool_averaging_margin=pool_averaging_margin,
        thickening_center_derivative=thickening_center_derivative,
        low_state_top_rejection_margin=low_top_gap,
        high_state_onpath_rejection_margin=high_onpath_gap,
        high_price_cutoff=high_price_cutoff,
        high_price_rejection_margin=high_price_gap,
        low_alpha_knockout_moment_gap=low_knockout_gap,
        high_alpha_knockout_moment_gap=high_knockout_gap,
        jacobian_q_entry=jacobian_q,
        jacobian_beta_entry=jacobian_beta,
        probe_mass=probe_mass,
        accepted_mass=accepted_mass,
        rejected_mass=rejected_mass,
    )
    return candidate, certificate


def main() -> None:
    candidate, certificate = certify_candidate()
    print("BINARY PRIVATE-CARA REFINED PBE: ARB CERTIFICATE")
    print(f"  alpha_L (exact): {ALPHA_L}")
    print(f"  q: {candidate.price}")
    print(f"  beta: {candidate.beta}")
    print(f"  alpha_H: {candidate.alpha_h}")
    print("ROOT AND REGULARITY")
    print(f"  low endpoint residual: {certificate.low_endpoint_residual}")
    print(f"  beta lower residual: {certificate.beta_lower_residual}")
    print(f"  beta upper residual: {certificate.beta_upper_residual}")
    print(f"  alpha_H lower residual: {certificate.high_alpha_lower_residual}")
    print(f"  alpha_H upper residual: {certificate.high_alpha_upper_residual}")
    print(f"  dF_H/dalpha: {certificate.high_alpha_derivative}")
    print(f"  IFT q diagonal: {certificate.jacobian_q_entry}")
    print(f"  IFT beta diagonal: {certificate.jacobian_beta_entry}")
    print("BUYER SORTING AND LOW-PRICE D1")
    print(f"  single-crossing margin: {certificate.single_crossing_margin}")
    print(
        "  low-alpha analytic waiter margin: "
        f"{certificate.low_waiter_analytic_margin}"
    )
    print(
        "  high-alpha waiter derivative numerator upper bound: "
        f"{certificate.high_waiter_derivative_numerator_upper}"
    )
    print(
        "  min normalized Gamma_L-Gamma_H: "
        f"{certificate.cross_curvature_gamma_margin}"
    )
    print(
        "  dF_top/dalpha at alpha_L: "
        f"{certificate.low_endpoint_alpha_derivative}"
    )
    print(
        "  q-R_2(beta): "
        f"{certificate.pool_averaging_margin}"
    )
    print(
        "  thickening seller-map derivative: "
        f"{certificate.thickening_center_derivative}"
    )
    print("SELLER AND HIGH-PRICE MARGINS")
    print(
        "  R_2(1)-q: "
        f"{certificate.low_state_top_rejection_margin}"
    )
    print(
        "  E[R_7|probe]-q: "
        f"{certificate.high_state_onpath_rejection_margin}"
    )
    print(
        "  p_dagger: "
        f"{certificate.high_price_cutoff}"
    )
    print(
        "  7/8-p_dagger: "
        f"{certificate.high_price_rejection_margin}"
    )
    print(
        "  low-alpha all-state moment gap: "
        f"{certificate.low_alpha_knockout_moment_gap}"
    )
    print(
        "  high-alpha all-state moment gap: "
        f"{certificate.high_alpha_knockout_moment_gap}"
    )
    print("OUTCOME PROBABILITIES (equal curvature masses)")
    print(f"  no offer: {1-certificate.probe_mass}")
    print(f"  rejection: {certificate.rejected_mass}")
    print(f"  agreement: {certificate.accepted_mass}")


if __name__ == "__main__":
    main()
