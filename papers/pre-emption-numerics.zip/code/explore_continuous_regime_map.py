"""Numerical diagnostics for equilibrium regimes in the continuous-b model.

The script searches for boundary-price PBEs supported by the off-path belief
that a deviating buyer has b = b_bar. It is diagnostic rather than a proof:
one-dimensional fixed points are bracketed exhaustively on a fine grid, while
two-price fixed points are sought by damped Newton iteration from many starts.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import expm1

import numpy as np
from numpy.polynomial.legendre import leggauss


N_L = 2
N_H = 7
PI = 0.5
D_SELLER = 0.01
QUAD_N = 400
MASS_TOL = 1e-10
ROOT_TOL = 2e-10


def w_uniform(n: int, b: np.ndarray | float) -> np.ndarray | float:
    return b - b ** (n + 1) / (n + 1)


def revenue_uniform(n: int, b: np.ndarray | float) -> np.ndarray | float:
    return (n - 1) / (n + 1) + b**n - n * b ** (n + 1) / (n + 1)


@dataclass(frozen=True)
class Primitives:
    kappa: float
    d_bar: float
    urgency_rate: float


class RegimeModel:
    def __init__(self, primitives: Primitives) -> None:
        self.pr = primitives
        nodes, weights = leggauss(QUAD_N)
        self.b = (nodes + 1.0) / 2.0
        self.weights = weights / 2.0
        # Gauss--Legendre nodes are interior. Keep a separate grid for
        # supremum calculations so that b=0 and b=1 are checked explicitly.
        self.b_sup = np.concatenate(([0.0], self.b, [1.0]))
        self.w_l = w_uniform(N_L, self.b)
        self.w_h = w_uniform(N_H, self.b)
        self.bar_w = (1.0 - PI) * self.w_l + PI * self.w_h
        self.w_l_sup = w_uniform(N_L, self.b_sup)
        self.w_h_sup = w_uniform(N_H, self.b_sup)
        self.bar_w_sup = (
            (1.0 - PI) * self.w_l_sup + PI * self.w_h_sup
        )
        self.c_l = revenue_uniform(N_L, self.b) - D_SELLER
        self.c_h = revenue_uniform(N_H, self.b) - D_SELLER
        self.c_l_bounds = (
            float(revenue_uniform(N_L, 0.0) - D_SELLER),
            float(revenue_uniform(N_L, 1.0) - D_SELLER),
        )
        self.c_h_bounds = (
            float(revenue_uniform(N_H, 0.0) - D_SELLER),
            float(revenue_uniform(N_H, 1.0) - D_SELLER),
        )

    def integrate(self, values: np.ndarray) -> float:
        return float(np.dot(self.weights, values))

    def urgency_cdf(self, d: np.ndarray | float) -> np.ndarray:
        d_array = np.asarray(d)
        rate = self.pr.urgency_rate
        d_bar = self.pr.d_bar
        raw = np.expm1(-rate * np.clip(d_array, 0.0, d_bar))
        interior = raw / expm1(-rate * d_bar)
        return np.where(
            d_array <= 0.0,
            0.0,
            np.where(d_array >= d_bar, 1.0, interior),
        )

    def posterior_mean(self, values: np.ndarray, mass: np.ndarray) -> float | None:
        denominator = self.integrate(mass)
        if denominator <= MASS_TOL:
            return None
        return self.integrate(values * mass) / denominator

    def two_price_masses(
        self, q_l: float, q_h: float
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        a = 1.0 - PI
        kappa = self.pr.kappa
        d_l = q_l - self.w_l + kappa / a
        d_aux = q_h - self.bar_w + kappa
        d_h = (q_h - a * q_l) / PI - self.w_h
        z = d_aux - d_l

        screening = z > 0.0
        m_0_screen = self.urgency_cdf(d_l)
        m_l_screen = self.urgency_cdf(d_h) - self.urgency_cdf(d_l)
        m_h_screen = 1.0 - self.urgency_cdf(d_h)
        m_0_direct = self.urgency_cdf(d_aux)
        m_h_direct = 1.0 - self.urgency_cdf(d_aux)

        m_0 = np.where(screening, m_0_screen, m_0_direct)
        m_l = np.where(screening, m_l_screen, 0.0)
        m_h = np.where(screening, m_h_screen, m_h_direct)
        return m_0, m_l, m_h

    def two_price_map(self, q: np.ndarray) -> np.ndarray | None:
        q_l, q_h = map(float, q)
        _, m_l, m_h = self.two_price_masses(q_l, q_h)
        mapped_l = self.posterior_mean(self.c_l, m_l)
        mapped_h = self.posterior_mean(self.c_h, m_h)
        if mapped_l is None or mapped_h is None:
            return None
        return np.array([mapped_l, mapped_h])

    def probing_map(self, q_l: float) -> float | None:
        d_l = q_l - self.w_l + self.pr.kappa / (1.0 - PI)
        m_l = 1.0 - self.urgency_cdf(d_l)
        return self.posterior_mean(self.c_l, m_l)

    def knockout_map(self, q_h: float) -> float | None:
        d_h = q_h - self.bar_w + self.pr.kappa
        m_h = 1.0 - self.urgency_cdf(d_h)
        return self.posterior_mean(self.c_h, m_h)

    def solve_one_dimensional(
        self, mapping, bounds: tuple[float, float]
    ) -> list[float]:
        lo, hi = bounds
        grid = np.linspace(lo, hi, 1201)
        values: list[float | None] = []
        for q in grid:
            mapped = mapping(float(q))
            values.append(None if mapped is None else mapped - float(q))

        roots: list[float] = []
        for index in range(len(grid) - 1):
            f_lo, f_hi = values[index], values[index + 1]
            if f_lo is None or f_hi is None:
                continue
            if abs(f_lo) < ROOT_TOL:
                roots.append(float(grid[index]))
                continue
            if f_lo * f_hi > 0.0:
                continue
            left, right = float(grid[index]), float(grid[index + 1])
            for _ in range(80):
                middle = 0.5 * (left + right)
                mapped = mapping(middle)
                if mapped is None:
                    break
                f_middle = mapped - middle
                if abs(f_middle) < ROOT_TOL:
                    left = right = middle
                    break
                mapped_left = mapping(left)
                if mapped_left is None:
                    break
                if (mapped_left - left) * f_middle <= 0.0:
                    right = middle
                else:
                    left = middle
            roots.append(0.5 * (left + right))

        unique: list[float] = []
        for root in roots:
            if not any(abs(root - old) < 2e-7 for old in unique):
                unique.append(root)
        return unique

    def solve_two_price(self) -> list[tuple[float, float]]:
        l_lo, l_hi = self.c_l_bounds
        h_lo, h_hi = self.c_h_bounds
        starts_l = np.linspace(l_lo, l_hi, 9)
        starts_h = np.linspace(h_lo, h_hi, 9)
        roots: list[tuple[float, float]] = []

        for start_l in starts_l:
            for start_h in starts_h:
                q = np.array([start_l, start_h], dtype=float)
                for _ in range(250):
                    mapped = self.two_price_map(q)
                    if mapped is None:
                        break
                    residual = mapped - q
                    if np.max(np.abs(residual)) < ROOT_TOL:
                        candidate = (float(q[0]), float(q[1]))
                        if not any(
                            max(abs(candidate[0] - old[0]), abs(candidate[1] - old[1]))
                            < 2e-7
                            for old in roots
                        ):
                            roots.append(candidate)
                        break

                    step = 2e-6
                    jacobian = np.empty((2, 2))
                    valid = True
                    for column in range(2):
                        shifted = q.copy()
                        shifted[column] += step
                        mapped_shifted = self.two_price_map(shifted)
                        if mapped_shifted is None:
                            valid = False
                            break
                        residual_shifted = mapped_shifted - shifted
                        jacobian[:, column] = (residual_shifted - residual) / step
                    if not valid:
                        break
                    try:
                        delta = np.linalg.solve(jacobian, -residual)
                    except np.linalg.LinAlgError:
                        delta = 0.4 * residual

                    accepted = False
                    for damping in (1.0, 0.5, 0.25, 0.1, 0.05):
                        trial = q + damping * delta
                        trial[0] = np.clip(trial[0], l_lo, l_hi)
                        trial[1] = np.clip(trial[1], h_lo, h_hi)
                        mapped_trial = self.two_price_map(trial)
                        if mapped_trial is None:
                            continue
                        if np.max(np.abs(mapped_trial - trial)) < np.max(np.abs(residual)):
                            q = trial
                            accepted = True
                            break
                    if not accepted:
                        q = 0.6 * q + 0.4 * mapped
        return roots

    def probing_deviation_gain(self, q_h: float) -> float:
        """Best gain from adding an L-only offer to a knockout-only menu."""
        p = self.c_l_bounds[1]
        d_k = q_h - self.bar_w_sup + self.pr.kappa
        candidates = np.stack(
            [
                np.zeros_like(self.b_sup),
                np.full_like(self.b_sup, self.pr.d_bar),
                np.clip(d_k, 0.0, self.pr.d_bar),
            ]
        )
        v_l = (1.0 - PI) * (self.w_l_sup[None, :] + candidates - p) - self.pr.kappa
        v_h = self.bar_w_sup[None, :] + candidates - q_h - self.pr.kappa
        equilibrium = np.maximum(0.0, v_h)
        return float(np.max(v_l - equilibrium))

    def knockout_deviation_gain(self, q_l: float) -> float:
        """Best gain from adding an all-state offer to a probing-only menu."""
        p = self.c_h_bounds[1]
        d_l = q_l - self.w_l_sup + self.pr.kappa / (1.0 - PI)
        candidates = np.stack(
            [
                np.zeros_like(self.b_sup),
                np.full_like(self.b_sup, self.pr.d_bar),
                np.clip(d_l, 0.0, self.pr.d_bar),
            ]
        )
        v_l = (1.0 - PI) * (
            self.w_l_sup[None, :] + candidates - q_l
        ) - self.pr.kappa
        v_h = self.bar_w_sup[None, :] + candidates - p - self.pr.kappa
        equilibrium = np.maximum(0.0, v_l)
        return float(np.max(v_h - equilibrium))

    def auction_only(self) -> bool:
        p_l = self.c_l_bounds[1]
        p_h = self.c_h_bounds[1]
        max_probe = np.max(
            (1.0 - PI) * (self.w_l_sup + self.pr.d_bar - p_l) - self.pr.kappa
        )
        max_knockout = np.max(
            self.bar_w_sup + self.pr.d_bar - p_h - self.pr.kappa
        )
        return bool(max(max_probe, max_knockout) <= 2e-10)

    def candidate_regimes(self) -> list[str]:
        regimes: list[str] = []
        if self.auction_only():
            regimes.append("A")

        for q_l in self.solve_one_dimensional(self.probing_map, self.c_l_bounds):
            d_l = q_l - self.w_l + self.pr.kappa / (1.0 - PI)
            mass_l = self.integrate(1.0 - self.urgency_cdf(d_l))
            if mass_l > MASS_TOL and self.knockout_deviation_gain(q_l) <= 2e-8:
                regimes.append(f"P({q_l:.4f})")

        for q_h in self.solve_one_dimensional(self.knockout_map, self.c_h_bounds):
            d_h = q_h - self.bar_w + self.pr.kappa
            mass_h = self.integrate(1.0 - self.urgency_cdf(d_h))
            if mass_h > MASS_TOL and self.probing_deviation_gain(q_h) <= 2e-8:
                regimes.append(f"K({q_h:.4f})")

        for q_l, q_h in self.solve_two_price():
            m_0, m_l, m_h = self.two_price_masses(q_l, q_h)
            masses = tuple(self.integrate(mass) for mass in (m_0, m_l, m_h))
            if masses[1] > MASS_TOL and masses[2] > MASS_TOL:
                regimes.append(
                    f"F({q_l:.4f},{q_h:.4f};"
                    f"{masses[0]:.3f},{masses[1]:.3f},{masses[2]:.3f})"
                )
        return regimes


def main() -> None:
    print("Regime codes: A=auction only, P=probing only, K=knockout only, F=two-price")
    for d_bar in (0.25, 0.5, 0.8, 1.2):
        print(f"\nd_bar={d_bar:.2f}")
        for kappa in np.linspace(0.0, 0.6, 13):
            model = RegimeModel(
                Primitives(
                    kappa=float(kappa),
                    d_bar=d_bar,
                    urgency_rate=10.0,
                )
            )
            regimes = model.candidate_regimes()
            print(f"kappa={kappa:.2f}: {', '.join(regimes) if regimes else 'none found'}")


if __name__ == "__main__":
    main()
