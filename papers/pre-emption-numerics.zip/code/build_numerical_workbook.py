"""Execute the Markdown workbook as a notebook and package a checked release.

Python 3.12 with code/requirements-workbook.txt. Run from the repository root:
    python code/build_numerical_workbook.py
Outputs are in manuscripts/release/numerics/. Economic solvers are unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
STEM = 'pre-emption-numerics'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def build_notebook():
    import nbformat
    source = (ROOT / 'code/NUMERICAL_WORKBOOK.md').read_text(encoding='utf-8')
    parts = re.split(r'^```python\n(.*?)^```\s*$', source, flags=re.M | re.S)
    cells = []
    for i, part in enumerate(parts):
        if not part.strip():
            continue
        cell = (nbformat.v4.new_code_cell(part.strip()) if i % 2
                else nbformat.v4.new_markdown_cell(part.strip()))
        cell['id'] = f'workbook-{i:02d}'
        cells.append(cell)
    return nbformat.v4.new_notebook(cells=cells, metadata={
        'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
        'language_info': {'name': 'python', 'version': '3.12'},
    })


def render_html(notebook):
    import mistune
    markdown = mistune.create_markdown(escape=False, plugins=['table'])
    contents, navigation = [], []
    for cell in notebook.cells:
        if cell.cell_type == 'markdown':
            body = markdown(cell.source)
            def heading(match):
                title = match.group(1)
                anchor = re.sub(r'[^a-z0-9]+', '-', re.sub('<[^>]+>', '', title).lower()).strip('-')
                navigation.append(f'<a href="#{anchor}">{title}</a>')
                return f'<h2 id="{anchor}">{title}</h2>'
            contents.append(re.sub(r'<h2>(.*?)</h2>', heading, body))
        else:
            contents.append('<details class="code"><summary>Show Python code</summary><pre><code>'
                            + html.escape(cell.source) + '</code></pre></details>')
            for output in cell.get('outputs', []):
                if output.output_type == 'error':
                    raise ValueError('Notebook contains an execution error.')
                if output.output_type == 'stream':
                    contents.append('<pre class="result">' + html.escape(output.text) + '</pre>')
                elif output.output_type in ('display_data', 'execute_result'):
                    data = output.data
                    contents.append(data.get('text/html', '<pre>' + html.escape(data.get('text/plain', '')) + '</pre>'))
    style = '''
    :root{color-scheme:light;--ink:#23313c;--blue:#245878;--line:#d7e1e7}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);background:#fafbf9;font:17px/1.65 Georgia,serif}
    header{border-bottom:1px solid var(--line);padding:20px max(24px,calc((100% - 1100px)/2));font:14px/1.6 system-ui,sans-serif;background:#fff}
    a{color:var(--blue);text-underline-offset:3px}header a{text-decoration:none}header span{float:right}
    .layout{max-width:1160px;margin:0 auto;display:grid;grid-template-columns:225px minmax(0,1fr);gap:45px;padding:42px 30px 80px}
    nav{position:sticky;top:24px;align-self:start;font:14px/1.5 system-ui,sans-serif}nav strong{display:block;color:#647481;text-transform:uppercase;letter-spacing:.08em;font-size:11px;margin-bottom:16px}nav a{display:block;padding:8px 0;text-decoration:none}
    main{min-width:0}h1,h2,h3{font-family:system-ui,sans-serif;color:#163f59;line-height:1.22}h1{font-size:36px;font-weight:650;letter-spacing:-.025em;margin:0 0 24px}h2{font-size:25px;margin:56px 0 20px;border-top:1px solid var(--line);padding-top:25px;scroll-margin-top:20px}h3{font-size:20px;margin-top:30px}p{margin:16px 0}code{font-size:.85em;font-family:Consolas,monospace;overflow-wrap:anywhere}
    pre{font:12px/1.6 Consolas,monospace;white-space:pre-wrap;overflow-wrap:anywhere;margin:12px 0;padding:16px;background:#f1f4f5;border-radius:4px;max-height:600px;overflow:auto}
    details{margin:12px 0;border:1px solid var(--line);border-radius:5px;padding:10px 14px;background:#fff}summary{cursor:pointer;font:13px/1.6 system-ui,sans-serif;color:var(--blue)}details p{font:13px/1.5 system-ui,sans-serif}.code{background:transparent;border-style:dashed}.result{border-left:3px solid #78988b}
    .table-wrap{overflow-x:auto;margin:24px 0}table{border-collapse:collapse;min-width:100%;font:13px/1.6 system-ui,sans-serif;background:white}th{text-align:left;background:#edf3f5;color:#244c62;font-weight:600}th,td{padding:10px 13px;border-bottom:1px solid var(--line);vertical-align:top}td:not(:first-child){font-variant-numeric:tabular-nums}tbody tr:last-child td{border-bottom:2px solid var(--line)}.explorer{margin:22px 0 28px;padding:22px;background:#edf3f5;border:1px solid var(--line);border-radius:7px;font-family:system-ui,sans-serif}.explorer-controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px 24px}.explorer label{font-size:13px;color:#244c62;display:grid;grid-template-columns:1fr auto;gap:5px}.explorer input{grid-column:1/-1;width:100%;accent-color:var(--blue)}.explorer output{font-variant-numeric:tabular-nums;font-weight:650}.formula{font-family:Georgia,serif;font-style:italic}.explorer-result{display:flex;gap:12px;align-items:baseline;margin-top:22px;padding-top:16px;border-top:1px solid #c8d7de;font-size:14px}.explorer-result strong{font-size:18px;color:#163f59}.explorer-note{font:12px/1.55 system-ui,sans-serif;color:#52636e;margin-bottom:0}footer{font:12px/1.5 system-ui,sans-serif;color:#647481;border-top:1px solid var(--line);padding:25px 0;margin-top:40px}
    @media(max-width:820px){.layout{display:block;padding:26px 20px}nav{position:static;border-bottom:1px solid var(--line);padding-bottom:20px;margin-bottom:30px}nav a{display:inline-block;margin-right:14px;padding:5px 0}h1{font-size:29px}header span{float:none;display:block}h2{font-size:23px}body{font-size:16px}.explorer-controls{grid-template-columns:1fr}.explorer-result{display:block}.explorer-result span{display:block;margin-top:6px}}@media print{nav,.code,.explorer{display:none}.layout{display:block;padding:0}details:not([open]){display:none}body{background:#fff}}
    '''
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<meta name="description" content="Reproduce the numerical examples, interval certificates and figures for Pre-empting Competitive Sales.">'
            '<title>Numerical workbook | Pre-empting Competitive Sales</title><style>' + style + '</style></head><body>'
            '<header><a href="../">Emil M. S. Halseth</a><span>Research materials · Numerical workbook</span></header>'
            '<div class="layout"><nav aria-label="Workbook contents"><strong>Contents</strong>'
            + ''.join(navigation) + '</nav><main>' + ''.join(contents)
            + '''<footer>Saved execution with reproducible source and full calculation records. See the companion papers for assumptions and analytical proofs.</footer>
<script>(function(){const ids=['buyer-benefit','seller-benefit','wedge','cost'];const val=id=>Number(document.getElementById(id).value);const render=()=>{for(const id of ids)document.getElementById(id+'-value')?.replaceChildren(document.createTextNode(val(id).toFixed(2)));const gain=val('buyer-benefit')+val('seller-benefit')-val('wedge')-val('cost');document.getElementById('private-result').textContent='Private joint gain: '+gain.toFixed(2);document.getElementById('private-explanation').textContent=gain>0?'A mutually beneficial early agreement can be feasible.':'The chosen resolution benefits do not cover the wedge and offer cost.'};ids.forEach(id=>document.getElementById(id)?.addEventListener('input',render));render();})();</script>'''
            '</main></div></body></html>')


def build(output):
    import nbformat
    from nbclient import NotebookClient
    from jupyter_client import KernelManager
    from pypdf import PdfReader

    pdf_checks = {}
    for stem in ('Manuscript-short', 'Manuscript-online-appendix'):
        path = ROOT / 'manuscripts/release' / (stem + '.pdf')
        reader = PdfReader(path)
        annotations = [a for page in reader.pages for a in page.get('/Annots', [])
                       if a.get_object().get('/Subtype') != '/Link']
        if annotations:
            raise ValueError('Review annotations in release PDF; preserve them before rebuilding: ' + str(path))
        pdf_checks[stem + '.pdf'] = {'sha256': sha(path.read_bytes()),
                                    'pages': len(reader.pages), 'review_annotations': 0}

    # Keep execution infrastructure in this project, including the native kernel.
    scratch = ROOT / 'tmp/workbook-runtime'
    for variable in ('JUPYTER_CONFIG_DIR', 'JUPYTER_DATA_DIR', 'JUPYTER_RUNTIME_DIR', 'IPYTHONDIR'):
        directory = scratch / variable.lower()
        directory.mkdir(parents=True, exist_ok=True)
        os.environ[variable] = str(directory)
    tracked = ['code/NUMERICAL_WORKBOOK.md', 'code/build_numerical_workbook.py',
               'code/requirements-workbook.txt', 'code/PAPER_CALCULATIONS.md',
               'code/generate_aligned_certificate_appendix.py', 'figures/aligned_certificate_tables.tex',
               'manuscripts/Manuscript-short.tex', 'manuscripts/Manuscript-online-appendix.tex',
               'manuscripts/preamble.tex', 'manuscripts/References.bib',
               'manuscripts/release/Manuscript-short.pdf',
               'manuscripts/release/Manuscript-online-appendix.pdf']
    hashes = {path: sha((ROOT / path).read_bytes()) for path in tracked}
    notebook = build_notebook()
    km = KernelManager(kernel_name='python3')
    km.kernel_spec.argv = [sys.executable, '-m', 'ipykernel_launcher', '-f', '{connection_file}']
    print('Executing workbook from a fresh Python kernel; all calculations will be rerun.', flush=True)
    try:
        NotebookClient(notebook, timeout=3900, km=km,
                       resources={'metadata': {'path': str(ROOT)}}).execute()
    finally:
        if km.has_kernel:
            km.shutdown_kernel(now=True)
    # Preserve a completed notebook even if a subsequent packaging check fails.
    checkpoint = ROOT / 'tmp/workbook-runtime/executed.ipynb'
    nbformat.write(notebook, checkpoint)
    stdout = '\n'.join(o.get('text', '') for c in notebook.cells for o in c.get('outputs', []))
    matches = re.findall(r'^Fresh results: (.+)$', stdout, flags=re.M)
    if len(matches) != 1:
        raise ValueError('No unique completed run recorded by the notebook.')
    run = ROOT / matches[0]
    summary = json.loads((run / 'summary.json').read_text())
    if summary['status'] != 'pass':
        raise ValueError('Only successful calculations may be published.')
    for record in json.loads((run / 'source_hashes.json').read_text()):
        hashes[record['path']] = record['sha256']
    for path, expected in hashes.items():
        if sha((ROOT / path).read_bytes()) != expected:
            raise ValueError('Source changed during computation: ' + path)
    notebook_bytes = nbformat.writes(notebook).encode('utf-8')
    html_bytes = render_html(notebook).encode('utf-8')
    # The downloadable package is intentionally code-only. The public HTML
    # provides the recorded evidence; reproduction needs source closure,
    # expected figure sources, requirements, manifest and notebook, not PDFs,
    # logs or historical proof notes.
    paths = {p for p in hashes if not p.startswith('manuscripts/') and
             (p.startswith('code/') or p.startswith('figures/'))}
    members = {p: (ROOT / p).read_bytes() for p in sorted(paths)}
    # The runner keeps proof-note paths to audit the full research repository.
    # They are not inputs to any calculation, so remove only those references
    # from the package-local manifest.
    code_only_manifest = json.loads(members['code/claims.json'])
    for claim in code_only_manifest['claims']:
        claim['proof_notes'] = []
    members['code/claims.json'] = json_bytes(code_only_manifest)
    members[f'{STEM}.ipynb'] = notebook_bytes
    members['README.txt'] = ('''Numerical workbook for Pre-empting Competitive Sales

Start with pre-emption-numerics.ipynb to read and rerun the calculations.
To rerun: install Python 3.12, then from this extracted directory:
  python -m pip install -r code/requirements-workbook.txt
Open pre-emption-numerics.ipynb in Jupyter or VS Code and run all cells.
The notebook calls the existing scripts and creates a fresh results directory.

Without Jupyter (only numpy and python-flint required):
  python -m pip install -r code/requirements-publication.txt
  python code/run_reproduction.py --mode publication

This is the minimal code package: it contains runnable source, configuration,
requirements, expected generated figure sources and the executed notebook. It
does not include PDFs, recorded execution logs or historical proof notes.
PACKAGE_MANIFEST.json gives SHA-256 hashes for every other member. The public
HTML workbook links to the papers and shows the recorded execution. The
package-local claims manifest omits proof-note links because they are not
calculation inputs; the public repository retains the complete research audit.

This is a website release; no archive DOI has been assigned.
''').encode('utf-8')
    inventory = [{'path': p, 'sha256': sha(data), 'bytes': len(data)} for p, data in sorted(members.items())]
    members['PACKAGE_MANIFEST.json'] = json_bytes({'format': 1, 'members': inventory})
    output.mkdir(parents=True, exist_ok=True)
    (output / f'{STEM}.ipynb').write_bytes(notebook_bytes)
    (output / f'{STEM}.html').write_bytes(html_bytes)
    archive_path = output / f'{STEM}.zip'
    with ZipFile(archive_path, 'w', compression=ZIP_DEFLATED) as archive:
        for path, data in sorted(members.items()):
            archive.writestr(path, data)
    with ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP integrity check failed.')
        for record in inventory:
            if sha(archive.read(record['path'])) != record['sha256']:
                raise ValueError('ZIP hash mismatch: ' + record['path'])
    release = {'schema_version': 1, 'status': 'pass', 'run_directory': run.relative_to(ROOT).as_posix(),
               'completed_at_utc': summary['finished_at_utc'], 'task_count': len(summary['tasks']),
               'pdf_checks': pdf_checks, 'sources': hashes, 'artifacts': {f'{STEM}.{ext}': sha((output / f'{STEM}.{ext}').read_bytes())
                                             for ext in ('html', 'ipynb', 'zip')}}
    (output / 'release.json').write_bytes(json_bytes(release))
    print(f'Workbook verified: {len(summary["tasks"])} tasks, {len(members)} ZIP members. {output}', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'manuscripts/release/numerics')
    args = parser.parse_args()
    build(args.output.resolve())
