"""Certify a refined full-menu PBE with private urgency as the sole seller state.

There is one common terminal auction environment.  The seller is privately
urgent with probability A and patient with probability PI.  Urgency lowers
the seller's continuation value by DELTA but does not change the buyer's
terminal willingness.  Buyer match value is uniform and buyer urgency has a
truncated-exponential distribution.  The script solves the two boundary-price
fixed points, audits the PBE (including endpoints), and reports the two exact
inequalities used by the contingent-plan D1 completion.

Only the Python standard library is used.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, inf


N_LATE = 2
STANDING_VALUE = 0.4
SELLER_URGENCY_GAP = 0.02
PATIENT_PROBABILITY = 0.5
URGENT_PROBABILITY = 1.0 - PATIENT_PROBABILITY
ATTEMPT_COST = 0.01
BUYER_URGENCY_CAP = 1.0
BUYER_URGENCY_RATE = 10.0
SEARCH_PANELS = 8_192
VALIDATION_PANELS = 65_536
ROOT_TOL = 2e-14


def willingness(b: float) -> float:
    """Expected maximum early payment in the committed terminal auction."""
    v = STANDING_VALUE
    n = N_LATE
    if b <= v:
        return b
    return b - (b ** (n + 1) - v ** (n + 1)) / (n + 1)


def revenue(b: float) -> float:
    """Seller's expected terminal payoff, including the standing value."""
    v = STANDING_VALUE
    n = N_LATE
    if b <= v:
        return (
            (n - 1) / (n + 1)
            + v**n
            - (n - 1) * v ** (n + 1) / (n + 1)
        )
    return (
        (n - 1) / (n + 1)
        + b**n
        - n * b ** (n + 1) / (n + 1)
        + v ** (n + 1) / (n + 1)
    )


def urgency_cdf(d: float) -> float:
    if d <= 0.0:
        return 0.0
    if d >= BUYER_URGENCY_CAP:
        return 1.0
    normalizer = 1.0 - exp(-BUYER_URGENCY_RATE * BUYER_URGENCY_CAP)
    return (1.0 - exp(-BUYER_URGENCY_RATE * d)) / normalizer


def simpson(values: list[float], panels: int) -> float:
    return (
        values[0]
        + values[-1]
        + 4.0 * sum(values[1:-1:2])
        + 2.0 * sum(values[2:-1:2])
    ) / (3.0 * panels)


@dataclass(frozen=True)
class Grid:
    panels: int
    b: list[float]
    w: list[float]
    c_urgent: list[float]
    c_patient: list[float]

    @classmethod
    def build(cls, panels: int) -> "Grid":
        if panels % 2:
            raise ValueError("Composite Simpson integration needs even panels.")
        b = [index / panels for index in range(panels + 1)]
        w = [willingness(value) for value in b]
        c_patient = [revenue(value) for value in b]
        c_urgent = [value - SELLER_URGENCY_GAP for value in c_patient]
        return cls(panels, b, w, c_urgent, c_patient)


@dataclass(frozen=True)
class Stats:
    prices: tuple[float, float]
    masses: tuple[float, float, float]
    mapped_prices: tuple[float, float]
    posterior_continuations: tuple[tuple[float, float], tuple[float, float]]
    cutoff_ranges: tuple[tuple[float, float], tuple[float, float]]
    minimum_cutoff_gap: float


def cutoffs(w: float, q_l: float, q_h: float) -> tuple[float, float]:
    d_l = q_l - w + ATTEMPT_COST / URGENT_PROBABILITY
    d_h = (
        (q_h - URGENT_PROBABILITY * q_l) / PATIENT_PROBABILITY
        - w
    )
    return d_l, d_h


def action_probabilities(d_l: float, d_h: float) -> tuple[float, float, float]:
    g_l = urgency_cdf(d_l)
    g_h = urgency_cdf(d_h)
    return g_l, g_h - g_l, 1.0 - g_h


def statistics(grid: Grid, prices: tuple[float, float]) -> Stats:
    q_l, q_h = prices
    weights = ([], [], [])
    ranges = [[inf, -inf], [inf, -inf]]
    minimum_gap = inf

    for index, w in enumerate(grid.w):
        d_l, d_h = cutoffs(w, q_l, q_h)
        for row, value in zip(ranges, (d_l, d_h)):
            row[0] = min(row[0], value)
            row[1] = max(row[1], value)
        minimum_gap = min(minimum_gap, d_h - d_l)
        probabilities = action_probabilities(d_l, d_h)
        if min(probabilities) < -1e-12:
            raise AssertionError(
                f"Unordered cutoffs at b={grid.b[index]}: {(d_l, d_h)}"
            )
        for action, probability in enumerate(probabilities):
            weights[action].append(max(0.0, probability))

    masses = tuple(simpson(row, grid.panels) for row in weights)
    if min(masses[1:]) <= 0.0:
        raise AssertionError(f"An on-path offer has zero mass: {masses}")

    posterior_rows = []
    for action in (1, 2):
        row = []
        for continuation in (grid.c_urgent, grid.c_patient):
            numerator = simpson(
                [
                    weights[action][index] * continuation[index]
                    for index in range(grid.panels + 1)
                ],
                grid.panels,
            )
            row.append(numerator / masses[action])
        posterior_rows.append(tuple(row))

    mapped = posterior_rows[0][0], posterior_rows[1][1]
    return Stats(
        prices,
        masses,
        mapped,
        tuple(posterior_rows),
        tuple((row[0], row[1]) for row in ranges),
        minimum_gap,
    )


def solve(
    grid: Grid, start: tuple[float, float] | None = None
) -> tuple[float, float]:
    prices = list(start if start is not None else (0.586, 0.644))
    for _ in range(2_000):
        stats = statistics(grid, tuple(prices))
        residuals = [
            stats.mapped_prices[index] - prices[index] for index in range(2)
        ]
        if max(abs(value) for value in residuals) < ROOT_TOL:
            return tuple(prices)
        prices = [prices[index] + 0.4 * residuals[index] for index in range(2)]
    raise AssertionError(f"Fixed-point iteration did not converge: {prices}")


def bisection_for_w(target: float) -> float:
    if target <= willingness(0.0):
        return 0.0
    if target >= willingness(1.0):
        return 1.0
    lower, upper = 0.0, 1.0
    for _ in range(120):
        midpoint = 0.5 * (lower + upper)
        if willingness(midpoint) < target:
            lower = midpoint
        else:
            upper = midpoint
    return 0.5 * (lower + upper)


def direct_best_response_audit(prices: tuple[float, float]) -> float:
    q_l, q_h = prices
    largest_loss = 0.0
    for b_index in range(2_001):
        b = b_index / 2_000
        w = willingness(b)
        d_l, d_h = cutoffs(w, q_l, q_h)
        for d_index in range(2_001):
            d = d_index * BUYER_URGENCY_CAP / 2_000
            payoffs = (
                0.0,
                URGENT_PROBABILITY * (w + d - q_l) - ATTEMPT_COST,
                w + d - q_h - ATTEMPT_COST,
            )
            predicted = 0 if d < d_l else (1 if d < d_h else 2)
            largest_loss = max(largest_loss, max(payoffs) - payoffs[predicted])
    return largest_loss


def main() -> None:
    search = Grid.build(SEARCH_PANELS)
    search_prices = solve(search)
    validation = Grid.build(VALIDATION_PANELS)
    prices = solve(validation, search_prices)
    stats = statistics(validation, prices)
    residual = max(
        abs(stats.mapped_prices[index] - prices[index]) for index in range(2)
    )

    q_l, q_h = prices
    z_l = q_l + ATTEMPT_COST / URGENT_PROBABILITY
    z_h = (q_h - URGENT_PROBABILITY * q_l) / PATIENT_PROBABILITY
    b_l_zero = bisection_for_w(z_l)
    b_h_zero = bisection_for_w(z_h)
    d_h_at_top = z_h - willingness(b_h_zero)
    if b_h_zero == 1.0:
        d_h_at_top = z_h - willingness(1.0)

    d1_probe_slack = revenue(b_l_zero) - SELLER_URGENCY_GAP - q_l
    d1_knockout_slack = revenue(b_h_zero) - q_h
    top_belief_thresholds = (
        revenue(1.0) - SELLER_URGENCY_GAP,
        revenue(1.0),
    )
    pointwise_loss = direct_best_response_audit(prices)

    wait_mass, probe_mass, knockout_mass = stats.masses
    rejected = PATIENT_PROBABILITY * probe_mass
    successful = URGENT_PROBABILITY * probe_mass + knockout_mass

    print("private seller urgency as sole seller state: full-menu audit")
    print(f"q_L={q_l:.12f}")
    print(f"q_H={q_h:.12f}")
    print(
        "masses(wait,probe,knockout)="
        f"({wait_mass:.12f},{probe_mass:.12f},{knockout_mass:.12f})"
    )
    print(
        "outcomes(no early offer,rejected,successful)="
        f"({wait_mass:.12f},{rejected:.12f},{successful:.12f})"
    )
    print(f"fixed_point_residual={residual:.3e}")
    print(f"minimum_cutoff_gap={stats.minimum_cutoff_gap:.12f}")
    print(f"cutoff_ranges={stats.cutoff_ranges}")
    print(f"posterior_continuations={stats.posterior_continuations}")
    print(f"top_belief_thresholds={top_belief_thresholds}")
    print(f"largest_pointwise_best_response_loss={pointwise_loss:.3e}")
    print(f"D1_probe_bmax={b_l_zero:.12f}")
    print(f"D1_probe_slack={d1_probe_slack:.12f}")
    print(f"D1_knockout_bmax={b_h_zero:.12f}")
    print(f"D1_knockout_d_at_bmax={d_h_at_top:.12f}")
    print(f"D1_knockout_slack={d1_knockout_slack:.12f}")

    checks = {
        "positive action masses": min(stats.masses) > 0.0,
        "ordered cutoffs": stats.minimum_cutoff_gap > 0.0,
        "fixed point": residual < 2e-10,
        "buyer best responses": pointwise_loss < 2e-12,
        "probing D1 deterrence": d1_probe_slack > 0.0,
        "knockout D1 deterrence": d1_knockout_slack > 0.0,
        "top belief makes deviations weakly dearer": (
            top_belief_thresholds[0] > q_l
            and top_belief_thresholds[1] > q_h
        ),
    }
    for label, passed in checks.items():
        print(f"{label}: {'PASS' if passed else 'FAIL'}")
    if not all(checks.values()):
        raise AssertionError(checks)


if __name__ == "__main__":
    main()
