"""Audit aligned binary composite-state one-offer calibrations.

The seller state is ``(n_s, v_s, d_{S,s})``: ``n_s`` is the number of late
buyers, ``v_s`` is a hidden but committed terminal standing value, and
``d_{S,s}`` is the seller's cost of waiting for the bidding round.  Buyer
values are common U[0,1] draws and buyer urgency has the manuscript's
truncated-exponential distribution.  This script is intentionally standalone
and does not modify or import the certified public-threshold audit.

The script reports numerical certificates, not interval-arithmetic proofs.
All integrals are split at both state-specific standing-value kinks and at
endogenous cutoff crossings, and every fixed point is re-evaluated with an
independent higher-order quadrature rule.  Endpoint inequalities and the
closed-form two-kink D1 rankings are checked explicitly.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import expm1

import numpy as np
from numpy.polynomial.legendre import leggauss


PI = 0.5
A = 1.0 - PI
D_SELLER = 0.01
QUAD_N = 140
VALIDATION_QUAD_N = 260
ROOT_TOL = 3e-13


@dataclass(frozen=True)
class StatePrimitives:
    n_l: int
    n_h: int
    v_l: float
    v_h: float
    d_s_l: float = D_SELLER
    d_s_h: float = D_SELLER


@dataclass(frozen=True)
class OfferPrimitives:
    kappa: float
    d_bar: float
    urgency_rate: float = 10.0


@dataclass(frozen=True)
class ProbeCertificate:
    state: StatePrimitives
    offer: OfferPrimitives
    q_l: float
    price_bounds: tuple[float, float]
    root_bracket_signs: tuple[float, float]
    cutoff_endpoints: tuple[float, float]
    active_b_start: float
    masses: tuple[float, float]
    outcomes: tuple[float, float, float]
    no_sale: tuple[float, float]
    equilibrium_no_sale: tuple[float, float, float]
    residual: float
    seller_l_rent: float
    seller_h_rejection_slack: float
    knockout_deviation_gain: float
    d1_marginal_b: float
    d1_slack: float
    theorem_thresholds: tuple[float, float, float, float]
    two_kink_identity_error: float
    delta_monotonicity_margin: float


@dataclass(frozen=True)
class FullMenuCertificate:
    state: StatePrimitives
    offer: OfferPrimitives
    q_l: float
    q_h: float
    price_bounds: tuple[tuple[float, float], tuple[float, float]]
    cutoff_ranges: tuple[tuple[float, float], ...]
    z_min: float
    masses: tuple[float, float, float]
    outcomes: tuple[float, float, float]
    conditional_mean_prices: tuple[float, float]
    no_sale: tuple[float, float]
    equilibrium_no_sale: tuple[float, float, float]
    residual: float
    fixed_point_residuals: tuple[float, float]
    seller_slacks: tuple[float, float]
    offpath_price_slacks: tuple[float, float]
    d1_slacks: tuple[float, float]
    private_seller_urgency_margin: float
    box_widths: tuple[float, float]
    box_interior_margins: tuple[float, float, float]
    box_face_margins: tuple[float, float, float, float]
    two_kink_identity_error: float
    delta_monotonicity_margin: float


def w_uniform(
    n: int, b: np.ndarray | float, v: float
) -> np.ndarray | float:
    """Patient willingness under a committed terminal standing value."""

    value = np.asarray(b)
    result = np.where(
        value <= v,
        value,
        value - (value ** (n + 1) - v ** (n + 1)) / (n + 1),
    )
    return float(result) if np.ndim(value) == 0 else result


def revenue_uniform(
    n: int, b: np.ndarray | float, v: float
) -> np.ndarray | float:
    """Seller terminal payoff, including retention at value ``v``."""

    value = np.asarray(b)
    below = (
        (n - 1) / (n + 1)
        + v**n
        - (n - 1) * v ** (n + 1) / (n + 1)
    )
    above = (
        (n - 1) / (n + 1)
        + value**n
        - n * value ** (n + 1) / (n + 1)
        + v ** (n + 1) / (n + 1)
    )
    result = np.where(value <= v, below, above)
    return float(result) if np.ndim(value) == 0 else result


def delta_w_two_kink(
    state: StatePrimitives, b: np.ndarray | float
) -> np.ndarray | float:
    """Closed-form w_H-w_L for v_L<v_H under common uniform values."""

    value = np.asarray(b)
    first = (
        np.maximum(np.minimum(value, state.v_h), state.v_l)
        ** (state.n_l + 1)
        - state.v_l ** (state.n_l + 1)
    ) / (state.n_l + 1)
    above_h = np.maximum(value, state.v_h)
    second = np.where(
        value <= state.v_h,
        0.0,
        (above_h ** (state.n_l + 1) - state.v_h ** (state.n_l + 1))
        / (state.n_l + 1)
        - (above_h ** (state.n_h + 1) - state.v_h ** (state.n_h + 1))
        / (state.n_h + 1),
    )
    result = np.where(value <= state.v_l, 0.0, first + second)
    return float(result) if np.ndim(value) == 0 else result


def _crossing_point(function, target: float) -> float | None:
    left, right = 0.0, 1.0
    f_left = float(function(left) - target)
    f_right = float(function(right) - target)
    if abs(f_left) <= 1e-14:
        return left
    if abs(f_right) <= 1e-14:
        return right
    if f_left * f_right > 0.0:
        return None
    for _ in range(110):
        middle = 0.5 * (left + right)
        f_middle = float(function(middle) - target)
        if f_left * f_middle <= 0.0:
            right = middle
        else:
            left = middle
            f_left = f_middle
    return 0.5 * (left + right)


class CompositeModel:
    def __init__(
        self,
        state: StatePrimitives,
        offer: OfferPrimitives,
        quad_n: int,
    ) -> None:
        if not (0.0 < state.v_l < state.v_h < 1.0):
            raise ValueError("Require 0 < v_L < v_H < 1.")
        if not (2 <= state.n_l < state.n_h):
            raise ValueError("Require 2 <= n_L < n_H.")
        self.state = state
        self.offer = offer
        self.nodes, self.weights = leggauss(quad_n)

    def w_l(self, b):
        return w_uniform(self.state.n_l, b, self.state.v_l)

    def w_h(self, b):
        return w_uniform(self.state.n_h, b, self.state.v_h)

    def c_l(self, b):
        return revenue_uniform(self.state.n_l, b, self.state.v_l) - self.state.d_s_l

    def c_h(self, b):
        return revenue_uniform(self.state.n_h, b, self.state.v_h) - self.state.d_s_h

    def urgency_cdf(self, cutoff):
        value = np.asarray(cutoff)
        clipped = np.clip(value, 0.0, self.offer.d_bar)
        raw = np.expm1(-self.offer.urgency_rate * clipped)
        interior = raw / expm1(-self.offer.urgency_rate * self.offer.d_bar)
        result = np.where(
            value <= 0.0,
            0.0,
            np.where(value >= self.offer.d_bar, 1.0, interior),
        )
        return float(result) if np.ndim(value) == 0 else result

    def rule(self, breakpoints: list[float | None]):
        clean = sorted(
            value
            for value in {
                round(float(point), 15)
                for point in breakpoints
                if point is not None and 0.0 <= point <= 1.0
            }
        )
        if not clean or clean[0] != 0.0:
            clean.insert(0, 0.0)
        if clean[-1] != 1.0:
            clean.append(1.0)
        values, weights = [], []
        for left, right in zip(clean[:-1], clean[1:]):
            if right - left <= 1e-14:
                continue
            values.append(left + 0.5 * (self.nodes + 1.0) * (right - left))
            weights.append(0.5 * (right - left) * self.weights)
        return np.concatenate(values), np.concatenate(weights)

    def probing_statistics(self, q_l: float):
        cutoff = lambda b: (
            q_l - self.w_l(b) + self.offer.kappa / A
        )
        breaks: list[float | None] = [
            0.0,
            self.state.v_l,
            self.state.v_h,
            1.0,
        ]
        for target in (0.0, self.offer.d_bar):
            breaks.append(_crossing_point(cutoff, target))
        b, weights = self.rule(breaks)
        mass_b = 1.0 - self.urgency_cdf(cutoff(b))
        mass = float(np.dot(weights, mass_b))
        if mass <= 1e-14:
            raise AssertionError("Zero probing mass.")
        mapped = float(np.dot(weights, self.c_l(b) * mass_b) / mass)
        post_h = float(np.dot(weights, self.c_h(b) * mass_b) / mass)
        wait_b = 1.0 - mass_b
        ns_l = self.state.v_l**self.state.n_l * float(
            np.dot(weights, wait_b * (b < self.state.v_l))
        )
        # Every H-state probe is rejected, so every H-state history reaches
        # the terminal mechanism.
        ns_h = self.state.v_h ** (self.state.n_h + 1)
        active = _crossing_point(cutoff, self.offer.d_bar)
        return {
            "mapped": mapped,
            "post_h": post_h,
            "mass": mass,
            "active_start": 0.0 if active is None else active,
            "equilibrium_no_sale": (ns_l, ns_h, A * ns_l + PI * ns_h),
        }

    def two_price_statistics(self, q_l: float, q_h: float):
        d_l = lambda b: q_l - self.w_l(b) + self.offer.kappa / A
        d_aux = lambda b: (
            q_h - A * self.w_l(b) - PI * self.w_h(b) + self.offer.kappa
        )
        d_h = lambda b: (q_h - A * q_l) / PI - self.w_h(b)
        z_gap = lambda b: (
            q_h
            - q_l
            - PI * (self.w_h(b) - self.w_l(b))
            - PI * self.offer.kappa / A
        )
        breaks: list[float | None] = [
            0.0,
            self.state.v_l,
            self.state.v_h,
            1.0,
        ]
        for cutoff in (d_l, d_aux, d_h):
            for target in (0.0, self.offer.d_bar):
                breaks.append(_crossing_point(cutoff, target))
        breaks.append(_crossing_point(z_gap, 0.0))
        b, weights = self.rule(breaks)
        dl, da, dh = d_l(b), d_aux(b), d_h(b)
        screening = z_gap(b) > 0.0
        m0 = np.where(screening, self.urgency_cdf(dl), self.urgency_cdf(da))
        ml = np.where(
            screening,
            self.urgency_cdf(dh) - self.urgency_cdf(dl),
            0.0,
        )
        mh = np.where(
            screening,
            1.0 - self.urgency_cdf(dh),
            1.0 - self.urgency_cdf(da),
        )
        masses = tuple(float(np.dot(weights, item)) for item in (m0, ml, mh))
        if min(masses[1:]) <= 1e-14:
            raise AssertionError("A full-menu action has zero mass.")
        mapped_l = float(np.dot(weights, self.c_l(b) * ml) / masses[1])
        mapped_h = float(np.dot(weights, self.c_h(b) * mh) / masses[2])
        post_h_probe = float(np.dot(weights, self.c_h(b) * ml) / masses[1])
        post_l_knockout = float(np.dot(weights, self.c_l(b) * mh) / masses[2])
        ns_l = self.state.v_l**self.state.n_l * float(
            np.dot(weights, m0 * (b < self.state.v_l))
        )
        ns_h = self.state.v_h**self.state.n_h * float(
            np.dot(weights, (m0 + ml) * (b < self.state.v_h))
        )
        early_sale_mass = A * masses[1] + masses[2]
        mean_early_price = (
            A * q_l * masses[1] + q_h * masses[2]
        ) / early_sale_mass
        no_sale_given_b_l = np.where(
            b < self.state.v_l,
            self.state.v_l**self.state.n_l,
            0.0,
        )
        no_sale_given_b_h = np.where(
            b < self.state.v_h,
            self.state.v_h**self.state.n_h,
            0.0,
        )
        auction_history_l = m0
        auction_history_h = m0 + ml
        auction_sale_mass = A * float(
            np.dot(weights, auction_history_l * (1.0 - no_sale_given_b_l))
        ) + PI * float(
            np.dot(weights, auction_history_h * (1.0 - no_sale_given_b_h))
        )
        auction_price_numerator = A * float(
            np.dot(
                weights,
                auction_history_l
                * (
                    revenue_uniform(
                        self.state.n_l, b, self.state.v_l
                    )
                    - self.state.v_l * no_sale_given_b_l
                ),
            )
        ) + PI * float(
            np.dot(
                weights,
                auction_history_h
                * (
                    revenue_uniform(
                        self.state.n_h, b, self.state.v_h
                    )
                    - self.state.v_h * no_sale_given_b_h
                ),
            )
        )
        mean_auction_sale_price = auction_price_numerator / auction_sale_mass
        return {
            "mapped": np.array([mapped_l, mapped_h]),
            "masses": masses,
            "post_h_probe": post_h_probe,
            "post_l_knockout": post_l_knockout,
            "equilibrium_no_sale": (ns_l, ns_h, A * ns_l + PI * ns_h),
            "conditional_mean_prices": (
                float(mean_early_price),
                float(mean_auction_sale_price),
            ),
        }


def _solve_scalar(model: CompositeModel) -> float:
    left, right = float(model.c_l(0.0)), float(model.c_l(1.0))
    f_left = float(model.probing_statistics(left)["mapped"]) - left
    f_right = float(model.probing_statistics(right)["mapped"]) - right
    if not (f_left > 0.0 and f_right < 0.0):
        raise AssertionError(f"Probe root not bracketed: {f_left=}, {f_right=}")
    for _ in range(110):
        middle = 0.5 * (left + right)
        residual = float(model.probing_statistics(middle)["mapped"]) - middle
        if residual > 0.0:
            left = middle
        else:
            right = middle
    return 0.5 * (left + right)


def _solve_vector(model: CompositeModel, start: tuple[float, float]) -> np.ndarray:
    q = np.array(start, dtype=float)
    for _ in range(120):
        mapped = model.two_price_statistics(*q)["mapped"]
        residual = np.asarray(mapped) - q
        if float(np.max(np.abs(residual))) < ROOT_TOL:
            return q
        step = 1e-7
        jacobian = np.empty((2, 2))
        for column in range(2):
            shifted = q.copy()
            shifted[column] += step
            shifted_residual = (
                np.asarray(model.two_price_statistics(*shifted)["mapped"])
                - shifted
            )
            jacobian[:, column] = (shifted_residual - residual) / step
        delta = np.linalg.solve(jacobian, -residual)
        old_norm = float(np.max(np.abs(residual)))
        for damping in (1.0, 0.5, 0.25, 0.1, 0.05, 0.01):
            trial = q + damping * delta
            try:
                trial_residual = (
                    np.asarray(model.two_price_statistics(*trial)["mapped"])
                    - trial
                )
            except AssertionError:
                continue
            if float(np.max(np.abs(trial_residual))) < old_norm:
                q = trial
                break
        else:
            q = 0.8 * q + 0.2 * np.asarray(mapped)
    raise AssertionError("Full-menu Newton iteration did not converge.")


def _two_kink_checks(state: StatePrimitives) -> tuple[float, float]:
    grid = np.unique(
        np.concatenate(
            (
                np.linspace(0.0, 1.0, 20001),
                np.array([state.v_l, state.v_h]),
            )
        )
    )
    direct = w_uniform(state.n_h, grid, state.v_h) - w_uniform(
        state.n_l, grid, state.v_l
    )
    closed = delta_w_two_kink(state, grid)
    error = float(np.max(np.abs(direct - closed)))
    margin = float(np.min(np.diff(closed)))
    if error > 5e-14 or margin < -5e-14:
        raise AssertionError(f"Two-kink audit failed: {error=}, {margin=}")
    return error, margin


def _theorem_thresholds(model: CompositeModel):
    wl, wh = float(model.w_l(1.0)), float(model.w_h(1.0))
    cl, ch = float(model.c_l(1.0)), float(model.c_h(1.0))
    dl = cl - wl + model.offer.kappa / A
    dh = ch - A * wl - PI * wh + model.offer.kappa
    delta = dh - dl
    return dl, dh, delta, dl + delta / PI


def solve_probe(
    state: StatePrimitives,
    offer: OfferPrimitives,
) -> ProbeCertificate:
    model = CompositeModel(state, offer, QUAD_N)
    validation = CompositeModel(state, offer, VALIDATION_QUAD_N)
    q_l = _solve_scalar(model)
    stats = validation.probing_statistics(q_l)
    residual = abs(float(stats["mapped"]) - q_l)
    cl0, cl1 = float(model.c_l(0.0)), float(model.c_l(1.0))
    root_bracket_signs = (
        float(validation.probing_statistics(cl0)["mapped"]) - cl0,
        float(validation.probing_statistics(cl1)["mapped"]) - cl1,
    )
    dl0 = q_l - float(model.w_l(0.0)) + offer.kappa / A
    dl1 = q_l - float(model.w_l(1.0)) + offer.kappa / A

    cutoff = lambda b: q_l - model.w_l(b) + offer.kappa / A
    if dl1 >= 0.0:
        b0 = 1.0
    else:
        root = _crossing_point(cutoff, 0.0)
        if root is None:
            raise AssertionError("No feasible wait--probe marginal value.")
        b0 = root
    d1_slack = float(model.c_l(b0)) - q_l

    wl1, wh1 = float(model.w_l(1.0)), float(model.w_h(1.0))
    ch1 = float(model.c_h(1.0))
    probe_top = A * (wl1 + offer.d_bar - q_l) - offer.kappa
    knockout_top = (
        A * wl1 + PI * wh1 + offer.d_bar - ch1 - offer.kappa
    )
    knockout_gain = knockout_top - max(0.0, probe_top)

    # Endpoint maximization is exact: in the waiting region the knockout
    # payoff rises in b and d; in the probing region its gain relative to the
    # probe rises with w_H(b) and d.  The dense grid is an independent check.
    b_grid = np.unique(
        np.concatenate(
            (
                np.linspace(0.0, 1.0, 20001),
                np.array([state.v_l, state.v_h]),
            )
        )
    )
    dl_grid = q_l - model.w_l(b_grid) + offer.kappa / A
    d_candidates = np.stack(
        (
            np.zeros_like(b_grid),
            np.full_like(b_grid, offer.d_bar),
            np.clip(dl_grid, 0.0, offer.d_bar),
        )
    )
    probe_payoff = A * (
        model.w_l(b_grid)[None, :] + d_candidates - q_l
    ) - offer.kappa
    knockout_payoff = (
        A * model.w_l(b_grid)[None, :]
        + PI * model.w_h(b_grid)[None, :]
        + d_candidates
        - ch1
        - offer.kappa
    )
    grid_gain = float(np.max(knockout_payoff - np.maximum(0.0, probe_payoff)))
    if abs(grid_gain - knockout_gain) > 2e-10:
        raise AssertionError("Knockout endpoint and grid maxima disagree.")

    two_kink_error, delta_margin = _two_kink_checks(state)
    thresholds = _theorem_thresholds(model)
    wait_mass, probe_mass = 1.0 - float(stats["mass"]), float(stats["mass"])
    outcomes = (wait_mass, PI * probe_mass, A * probe_mass)
    no_sale = (
        state.v_l ** (state.n_l + 1),
        state.v_h ** (state.n_h + 1),
    )
    certificate = ProbeCertificate(
        state=state,
        offer=offer,
        q_l=q_l,
        price_bounds=(cl0, cl1),
        root_bracket_signs=root_bracket_signs,
        cutoff_endpoints=(dl1, dl0),
        active_b_start=float(stats["active_start"]),
        masses=(wait_mass, probe_mass),
        outcomes=outcomes,
        no_sale=no_sale,
        equilibrium_no_sale=tuple(float(x) for x in stats["equilibrium_no_sale"]),
        residual=residual,
        seller_l_rent=q_l - float(stats["mapped"]),
        seller_h_rejection_slack=float(stats["post_h"]) - q_l,
        knockout_deviation_gain=knockout_gain,
        d1_marginal_b=b0,
        d1_slack=d1_slack,
        theorem_thresholds=thresholds,
        two_kink_identity_error=two_kink_error,
        delta_monotonicity_margin=delta_margin,
    )
    dl_bar, _, delta_d, upper = thresholds
    if not (
        residual < 3e-12
        and certificate.seller_h_rejection_slack > 0.0
        and root_bracket_signs[0] > 0.0
        and root_bracket_signs[1] < 0.0
        and knockout_gain < 0.0
        and d1_slack > 0.0
        and wait_mass > 0.0
        and probe_mass > 0.0
        and delta_d > 0.0
        and dl_bar < offer.d_bar <= upper
    ):
        raise AssertionError(f"Probe certificate failed: {certificate}")
    return certificate


def _audit_price_box(
    model: CompositeModel,
    root: np.ndarray,
    widths: tuple[float, float],
):
    wl1, wh1 = float(model.w_l(1.0)), float(model.w_h(1.0))
    wl0, wh0 = float(model.w_l(0.0)), float(model.w_h(0.0))
    low_l, high_l = root[0] - widths[0], root[0] + widths[0]
    low_h, high_h = root[1] - widths[1], root[1] + widths[1]
    interior = (
        low_l - wl1 + model.offer.kappa / A,
        model.offer.d_bar - (high_h - A * low_l) / PI + wh0,
        low_h
        - high_l
        - PI * (wh1 - wl1)
        - PI * model.offer.kappa / A,
    )
    h_grid = np.linspace(low_h, high_h, 301)
    l_grid = np.linspace(low_l, high_l, 301)
    # Under global interiority and truncated-exponential G, monotone likelihood
    # ratios reduce each continuum face sign to one corner.  T_L rises with
    # q_H because the added probe weight tilts toward high b when Delta w rises;
    # T_H falls with q_L because the added knockout weight tilts toward low b.
    corners = (
        float(model.two_price_statistics(low_l, low_h)["mapped"][0] - low_l),
        float(high_l - model.two_price_statistics(high_l, high_h)["mapped"][0]),
        float(model.two_price_statistics(high_l, low_h)["mapped"][1] - low_h),
        float(high_h - model.two_price_statistics(low_l, high_h)["mapped"][1]),
    )
    grid_faces = (
        min(
            float(model.two_price_statistics(low_l, h)["mapped"][0] - low_l)
            for h in h_grid
        ),
        min(
            float(high_l - model.two_price_statistics(high_l, h)["mapped"][0])
            for h in h_grid
        ),
        min(
            float(model.two_price_statistics(l, low_h)["mapped"][1] - low_h)
            for l in l_grid
        ),
        min(
            float(high_h - model.two_price_statistics(l, high_h)["mapped"][1])
            for l in l_grid
        ),
    )
    if max(abs(x - y) for x, y in zip(corners, grid_faces)) > 2e-11:
        raise AssertionError(
            f"Price-box corner reduction failed: {corners=}, {grid_faces=}"
        )
    if min(interior) <= 0.0 or min(corners) <= 0.0:
        raise AssertionError(f"Price box failed: {interior=}, {corners=}")
    return tuple(float(x) for x in interior), tuple(float(x) for x in corners)


def solve_full_menu(
    state: StatePrimitives,
    offer: OfferPrimitives,
    start: tuple[float, float],
    widths: tuple[float, float] = (5e-4, 5e-5),
) -> FullMenuCertificate:
    model = CompositeModel(state, offer, QUAD_N)
    validation = CompositeModel(state, offer, VALIDATION_QUAD_N)
    root = _solve_vector(model, start)
    stats = validation.two_price_statistics(*root)
    residual = float(np.max(np.abs(np.asarray(stats["mapped"]) - root)))
    fixed_point_residuals = tuple(
        float(x) for x in np.asarray(stats["mapped"]) - root
    )

    dl = lambda b: root[0] - model.w_l(b) + offer.kappa / A
    da = lambda b: (
        root[1] - A * model.w_l(b) - PI * model.w_h(b) + offer.kappa
    )
    dh = lambda b: (root[1] - A * root[0]) / PI - model.w_h(b)
    ranges = tuple((float(fn(1.0)), float(fn(0.0))) for fn in (dl, da, dh))
    z_min = (
        root[1]
        - root[0]
        - PI * (float(model.w_h(1.0)) - float(model.w_l(1.0)))
        - PI * offer.kappa / A
    )
    cl_bounds = (float(model.c_l(0.0)), float(model.c_l(1.0)))
    ch_bounds = (float(model.c_h(0.0)), float(model.c_h(1.0)))
    seller_slacks = (
        float(stats["post_h_probe"]) - float(root[0]),
        float(root[1]) - float(stats["post_l_knockout"]),
    )
    offpath = (cl_bounds[1] - float(root[0]), ch_bounds[1] - float(root[1]))
    d1 = offpath
    private_urgency_margin = min(
        offpath[0],
        offpath[1],
        seller_slacks[0],
        ch_bounds[1] - cl_bounds[1],
    )
    interior, faces = _audit_price_box(validation, root, widths)
    two_kink_error, delta_margin = _two_kink_checks(state)
    masses = tuple(float(x) for x in stats["masses"])
    outcomes = (masses[0], PI * masses[1], A * masses[1] + masses[2])
    no_sale = (
        state.v_l ** (state.n_l + 1),
        state.v_h ** (state.n_h + 1),
    )
    certificate = FullMenuCertificate(
        state=state,
        offer=offer,
        q_l=float(root[0]),
        q_h=float(root[1]),
        price_bounds=(cl_bounds, ch_bounds),
        cutoff_ranges=ranges,
        z_min=float(z_min),
        masses=masses,
        outcomes=outcomes,
        conditional_mean_prices=tuple(
            float(x) for x in stats["conditional_mean_prices"]
        ),
        no_sale=no_sale,
        equilibrium_no_sale=tuple(float(x) for x in stats["equilibrium_no_sale"]),
        residual=residual,
        fixed_point_residuals=fixed_point_residuals,
        seller_slacks=seller_slacks,
        offpath_price_slacks=offpath,
        d1_slacks=d1,
        private_seller_urgency_margin=float(private_urgency_margin),
        box_widths=widths,
        box_interior_margins=interior,
        box_face_margins=faces,
        two_kink_identity_error=two_kink_error,
        delta_monotonicity_margin=delta_margin,
    )
    if not (
        residual < 3e-12
        and min(ranges[0]) > 0.0
        and max(ranges[2]) < offer.d_bar
        and z_min > 0.0
        and min(masses) > 0.0
        and min(seller_slacks) > 0.0
        and min(offpath) > 0.0
        and min(d1) > 0.0
        and private_urgency_margin > 0.0
    ):
        raise AssertionError(f"Full-menu certificate failed: {certificate}")
    return certificate


def bounded_nearby_full_search():
    """Short local search around the preferred n=(2,3), v=(.38,.42) row.

    This search deliberately omits the expensive price-box face audit.  It
    ranks only strict roots; the selected row must then pass ``solve_full_menu``
    with an explicitly reported rectangle.
    """

    state = StatePrimitives(2, 3, 0.38, 0.42, 0.02, 0.0)
    starts = ((0.588, 0.705), (0.58, 0.68), (0.60, 0.74))
    candidates = []
    for kappa in (0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 0.12):
        for d_bar in (0.6, 0.8, 1.0, 1.2, 1.5):
            offer = OfferPrimitives(kappa, d_bar)
            model = CompositeModel(state, offer, QUAD_N)
            validation = CompositeModel(state, offer, VALIDATION_QUAD_N)
            root = None
            for start in starts:
                try:
                    root = _solve_vector(model, start)
                    break
                except (AssertionError, ValueError, np.linalg.LinAlgError):
                    continue
            if root is None:
                continue
            try:
                stats = validation.two_price_statistics(*root)
            except AssertionError:
                continue
            residual = float(
                np.max(np.abs(np.asarray(stats["mapped"]) - root))
            )
            dl_min = (
                root[0] - float(model.w_l(1.0)) + offer.kappa / A
            )
            dh_max = (
                (root[1] - A * root[0]) / PI - float(model.w_h(0.0))
            )
            z_min = (
                root[1]
                - root[0]
                - PI * (float(model.w_h(1.0)) - float(model.w_l(1.0)))
                - PI * offer.kappa / A
            )
            seller_slacks = (
                float(stats["post_h_probe"]) - float(root[0]),
                float(root[1]) - float(stats["post_l_knockout"]),
            )
            offpath = (
                float(model.c_l(1.0)) - float(root[0]),
                float(model.c_h(1.0)) - float(root[1]),
            )
            if (
                residual < 3e-11
                and dl_min > 0.0
                and dh_max < offer.d_bar
                and z_min > 0.0
                and min(stats["masses"]) > 0.0
                and min(seller_slacks) > 0.0
                and min(offpath) > 0.0
            ):
                candidates.append(
                    (float(z_min), offer, tuple(float(x) for x in root))
                )
    return sorted(candidates, key=lambda item: item[0], reverse=True)


def bounded_search():
    """Search a fixed finite grid and return the first strict certificates."""

    perturbations = (0.0025, 0.005, 0.01, 0.02)
    probe_results, full_results = [], []
    for n_h in (7, 3):
        for eps in perturbations:
            state = StatePrimitives(2, n_h, 0.4 - eps, 0.4 + eps)
            probe_offers = (
                OfferPrimitives(0.05, 0.15),
                OfferPrimitives(0.02, 0.045),
                OfferPrimitives(0.02, 0.05),
                OfferPrimitives(0.03, 0.07),
            )
            for offer in probe_offers:
                try:
                    probe_results.append(solve_probe(state, offer))
                    break
                except (AssertionError, ValueError, np.linalg.LinAlgError):
                    continue

            full_offers = (
                OfferPrimitives(0.12, 1.2),
                OfferPrimitives(0.08, 1.2),
                OfferPrimitives(0.05, 1.2),
            )
            starts = (
                (0.609, 0.829),
                (0.60, 0.72),
                (0.59, 0.70),
            )
            for offer, start in zip(full_offers, starts):
                try:
                    full_results.append(solve_full_menu(state, offer, start))
                    break
                except (AssertionError, ValueError, np.linalg.LinAlgError):
                    continue
    return probe_results, full_results


def _print_certificate(label: str, certificate) -> None:
    print(label)
    for key, value in asdict(certificate).items():
        print(f"  {key}: {value}")


def main() -> None:
    probes, fulls = bounded_search()
    nearby = bounded_nearby_full_search()
    preferred_state = StatePrimitives(2, 3, 0.38, 0.42, 0.02, 0.0)
    preferred_probe = solve_probe(
        preferred_state, OfferPrimitives(0.02, 0.045)
    )
    preferred_full = solve_full_menu(
        preferred_state,
        OfferPrimitives(0.05, 1.0),
        (0.60968, 0.70534),
        widths=(0.004, 0.004),
    )
    print("bounded aligned-composite search: PASS")
    print(f"probe certificates found: {len(probes)}")
    print(f"full-menu certificates found: {len(fulls)}")
    print(f"strict nearby full-menu roots found: {len(nearby)}")
    _print_certificate(
        "PREFERRED PROBE n=(2,3), v=(.38,.42), d_S=(.02,0)",
        preferred_probe,
    )
    _print_certificate(
        "PREFERRED FULL n=(2,3), v=(.38,.42), d_S=(.02,0)",
        preferred_full,
    )


if __name__ == "__main__":
    main()
